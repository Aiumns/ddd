﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Cfi.App.Pace.Common;
using Cfi.App.Pace.Business;
using Cfi.App.CRM.Business;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Net;
using System.Net.Mail;
using System.Text;


public partial class Cargo_Can_Print_NonTaxable : BasePage
{
    string HSNCode = "";
    public string html2 = "";
    public string BankName;
    public string BankAddress;
    public string AccountNo;
    public string IFSCCode;
    public string SwiftCode;
    public string STaxRate;
    DisplayWrap dw = new DisplayWrap();

    //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
     public string SBCessTaxRate = "0.50";
     public string KKCessTaxRate = "0.50";
     public string CGSTTaxRate;
     public decimal SbCesstaxAmt ;
     public decimal KKCesstaxAmt;
    BLLogin bl = new BLLogin();
    BReport bReport = new BReport();
    string sno = "";
    string Invto_Code = "";
    string Invto_Name = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        string AddressCompany = "";
        if (Session["CompBrSNo"].ToString() == "53")
        {
            AddressCompany = "Khasra No. 1027/1,Plot No:29,Road No.6, Mahipalpur, Ext N.H.8 , New Delhi-110037<BR/>Tel: +91-11-71723040<BR/>EMail: vikas@vishwdeep.com";
        }
        else if (Session["CompBrSNo"].ToString() == "18")
        {
            AddressCompany = "Khasra No. 1027/1,Plot No:29,Road No.6, Mahipalpur, Ext N.H.8 , New Delhi-110037<BR/>Tel: +91 11 71723056<BR/>EMail: info@360logistics.net";
        }
        else if (Session["CompBrSNo"].ToString() == "54" || Session["CompBrSNo"].ToString() == "55")
        {
            AddressCompany = "Khasra No. 1027/1,Plot No:29,Road No.6, Mahipalpur, Ext N.H.8 , New Delhi-110037<BR/>Tel: +91-11-71723060/3065<BR/>EMail: info@reliablecargo.in";
        }

        else if (Session["CompBrSNo"].ToString() != "54" && Session["CompBrSNo"].ToString() != "55" && Session["CompBrSNo"].ToString() != "18" && Session["CompBrSNo"].ToString() != "53")
        {
            AddressCompany = "Khasra No. 1027/1,Plot No:29,Road No.6, Mahipalpur, Ext N.H.8 , New Delhi-110037<BR/>Tel: +91-11-71723057<BR/>EMail: info@pacexpress.net";
        }
        //if (Session["UserID"] == null)
        //{
        //    Response.Redirect("../LoginPace.aspx");
        //}
        using (CommonBusiness comBusins = new CommonBusiness())
        {            
            hdnSend.Value = "0";
            string[] SNo = Request.QueryString[0].ToString().Split(',');
            string type = Request.QueryString[1].ToString();
            string invoice = Request.QueryString[2].ToString();
            string Mainhtml = "";
            string destination = "";
            string address = "";
            string InvoiceToname = "";
            string InvDate = "";
            string InvNo = "";
            string InvDueDate = "";
            string awbNo = "";
            string HawbNo = "";
            string Consignee = "";
            string Shipper = string.Empty;
            string Packages = "";
            string Weight = "";
            string Origin = "";
            string Destination = "";
            string FlightNo = "";
            string FlightDate = "";
            string Airline = "";
            string Commodity = "";
            string FreightType = "";
            string AwbDate = "";
            string MasterSno = "";
            decimal totTaxAmt = 0;
            decimal totNontaxAmt = 0;
            decimal taxAmt = 0;
            string Currency = "";
            decimal exchange_rate = 1;
            string comName = "";
            string CustCareAdd = "";
            string headerhtml = "";
            string EmailIdFrom = "";
            string PrintableNote = "";
            string BROMsg = "";
            string IGMNo = "";
            string IGMDate = "";
            string MainText = "";
            string InvNoEmail = "";
            string panno = "";
            string serviceregno = "";
            string PrintableDesc = "";
            string ReferenceNo = "";
            //if (SNo.Length > 1)
            //{
            DataTable dt = new DataTable();
            if (Request.QueryString["Email"].ToString() == "y")
            {
                MailMessage mail = new MailMessage();
                string userName = "test@cargoflash.com";//ConfigurationManager.AppSettings["MailuserName"];
                string password = "Admin$567";//ConfigurationManager.AppSettings["Mailpassword"];
                string smtpHost = "mail.cargoflash.com";//ConfigurationManager.AppSettings["MailServer"];
                ////mail.Subject = Session["Subject"].ToString();
                mail.Subject = "INVOICE";
                mail.SubjectEncoding = Encoding.UTF8;
                mail.BodyEncoding = Encoding.UTF8;
                mail.IsBodyHtml = true;
                mail.Priority = MailPriority.High;
                ////mail.To.Add(new MailAddress(Session["EMailTo"].ToString()));
                mail.To.Add(new MailAddress("ddalal@cargoflash.com"));
                mail.From = new MailAddress("ddalal@cargoflash.com");
                ////mail.From = new MailAddress(Session["CompName"].ToString().Split('-')[0] + "<" + Session["EmailFrom"].ToString() + ">");
                string[] Company = Session["CompName"].ToString().Split('-');
                ////mail.Body = Session["Message"].ToString().Replace("\r\n", "<br/>");
                mail.Body ="Dear Sir, <br> Invoice for your use.";
                mail.IsBodyHtml = true;
                for (int i = 0; i < SNo.Length; i++)
                {
                    string EmailTo = string.Empty;
                    if (SNo[i].Contains("Performa"))
                        return;
                    int Sno = int.Parse(SNo[i]);
                    BCan BC = new BCan();
                    SqlDataReader dr = BC.Show_billing_master(Sno);
                    DataSet dsCompName = bl.getCustBranchBySNo(Convert.ToInt32(Session["CompBrSNo"]));
                    string[] CompanyName = Session["CompName"].ToString().Split('-');
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            if (dr["BRONEW"].ToString() == "Y")
                            {
                                BROMsg = "<B>PLEASE ALSO NOTE THAT YOUR SHIPMENT IS CONSIGNED TO BANK,SO PLEASE PRESENT BANK RELEASE ORDER BEFORE TAKING DELIVERY ORDER.</B>";
                            }
                            else
                            {
                                BROMsg = "";
                            }
                            sno = dr["Sno"].ToString();
                            Invto_Code = dr["Invto_Code"].ToString();
                            Invto_Name = dr["Invto_Name"].ToString();
                            PrintableNote = dr["note"].ToString();
                            string s = dr["address"].ToString();
                            char ch = (char)System.Windows.Forms.Keys.Return;
                            char ch2 = (char)System.Windows.Forms.Keys.Space;
                            string ch1 = Convert.ToString(ch);
                            string ch3 = Convert.ToString(ch2);
                            CustCareAdd = s.Replace(ch1, "<br>");
                            CustCareAdd = CustCareAdd.Replace(ch3, "&nbsp;");
                            comName = dr["name"].ToString();
                            string[] CompName = Session["CompName"].ToString().Split('-');
                            //if (CompName[0].ToString() == "THREE SIXTY LOGISTICS PVT. LTD.")
                            //{
                            string images = Server.MapPath("~/Images/" + (CompName[0].Split(' ')[0].ToString() == "THREE" ? "360" : CompName[0].Split(' ')[0].ToString()) + "_trans_logo.gif");
                            headerhtml = @"<table  align=""center"" width=""100%"" >   <tr height=""20""> <td align=""center"" valign=""top"" colspan=""3"">                                  <font size=""5""><b>" + dsCompName.Tables[0].Rows[0]["Name"].ToString() + @"</b></font></td> </tr>
                            <tr height=""30"">  <td align=""left"" valign=""top"" width=""20%"" rowspan=""2"">
                            <img src=" + images + @" width=""100px"">
                        </td><td align=""center"" valign=""top"" width=""60%"" ><font size=""2"">" + AddressCompany + @"</font></td><td align=""right"" width=""20%"" rowspan=""2""></td>
	                         </tr><tr>
            <td align=""center"" ><font size=""2"">";
                            MainText = Session["CompBrType"].ToString() != "PNP" ? "We are pleased to announce the planning of the following shipment under our consolidation service." : "We are pleased to announce the planning of the following shipment.";
                            //                        if (Session["CompBrType"].ToString() != "PNP")
                            //                        {
                            //                            string img = Server.MapPath("~/Images/pacelogo_new.jpg");
                            //                            MainText = "We are pleased to announce the planning of the following shipment under our consolidation service.";
                            //                            headerhtml = @"<table  align=""center"" width=""100%""> 
                            //                            <tr height=""20"">  
                            //                                <td align=""center"" valign=""top"" colspan=""3"">
                            //                                    <font size=""4""><b>" + dsCompName.Tables[0].Rows[0]["Name"].ToString() + @"</b></font></td>
                            //	                         </tr>
                            //                        <tr height=""20"">  
                            //                                <td align=""center"" valign=""top"" colspan=""3""> 
                            //                                    <font size=""2"">" + dsCompName.Tables[0].Rows[0]["Address"].ToString() + @"</font></td>
                            //	                         </tr>
                            //                        <tr height=""75"">
                            //                        <td align=""left"" valign=""top"" >
                            //                           <img src=" + img + @" width=""100px"">
                            //                        </td>	   
                            //                   
                            //            <td align=""center"" colspan=""3""><font size=""2"">";

                            //                        }
                            //                        else
                            //                        {
                            //                            MainText = "We are pleased to announce the planning of the following shipment.";
                            //                            string[] CompName = Session["CompName"].ToString().Split('-');
                            //                            //if (CompName[0].ToString() == "THREE SIXTY LOGISTICS PVT. LTD.")
                            //                            //{
                            //                            string img = Server.MapPath("~/Images/"+CompName[0].Split(' ')[0]+"_trans_logo.gif"); //Server.MapPath("~/Images/360Logo.JPG");
                            //                                headerhtml = @"<table  align=""center"" width=""100%""> 
                            //                            <tr height=""30"">  
                            //                                <td align=""center"" valign=""top"" colspan=""3"">                                  <font size=""4""><b>" + dsCompName.Tables[0].Rows[0]["Name"].ToString() + @"</b></font></td>
                            //	                         </tr>
                            //
                            // <tr height=""50"">
                            //                        <td align=""left"" valign=""top"" width=""30%"">
                            //                            <img src=" + img + @" width=""100px"">
                            //                        </td>	   
                            //                    <td align=""center"" valign=""top"">
                            //                  <font size=""2"">" + dsCompName.Tables[0].Rows[0]["Address"].ToString() + @"</font></td><td align=""right"" width=""30%""></td>
                            //	            </tr>
                            //
                            //
                            //
                            //            <tr>
                            //            <td align=""center"" colspan=""3""><font size=""2"">";
                            ////                            }
                            ////                            if (CompName[0].ToString() == "RED LOGISTICS LTD.")
                            ////                            {
                            ////                                string img = Server.MapPath("~/Images/RedLogisticslogo.gif");
                            ////                                headerhtml = @"<table  align=""center"" width=""100%""> 
                            ////                            <tr height=""30"">  
                            ////                                <td align=""center"" valign=""top"" colspan=""3"">                                  <font size=""4""><b>" + dsCompName.Tables[0].Rows[0]["Name"].ToString() + @"</b></font></td>
                            ////	                         </tr>
                            ////<tr height=""50"">
                            ////                        <td align=""left"" valign=""top"" width=""30%"">
                            ////                            <img src=" + img + @" width=""100px"">
                            ////                        </td>	   
                            ////                    <td align=""center"" valign=""top"">
                            ////                  <font size=""2"">" + dsCompName.Tables[0].Rows[0]["Address"].ToString() + @"</font></td><td align=""right"" width=""30%""></td>
                            ////	            </tr>
                            ////<tr>
                            ////            <td align=""center"" colspan=""3""><font size=""2"">";

                            ////                            }
                            //                        }
                            if (invoice.ToUpper() == "Y")
                            {
                                headerhtml += @"<br><B>Bill Of Supply</b></font></td>
            </tr></table>";

                            }
                            else
                            {
                                headerhtml += @"<br><B>CARGO ARRIVAL NOTICE CUM Bill Of Supply</b></font></td>
            </tr></table>";
                            }
                            MasterSno = dr["sno"].ToString();
                            destination = dr["destination"].ToString();
                            if (dr["invto_code_type"].ToString() == "Sub Agent")
                            {
                                InvoiceToname = dr["invto_name"].ToString();
                                address = dr["invto_address"].ToString();
                            }
                            if (dr["invto_code_type"].ToString() == "CAN Customer")
                            {
                                InvoiceToname = dr["invto_name"].ToString();
                                address = dr["invto_address"].ToString();
                            }
                            if (dr["invto_code_type"].ToString() == "Actual Customer")
                            {
                                InvoiceToname = dr["act_name"].ToString();
                                address = dr["invto_address"].ToString();
                            }

                            //InvNo = dr["invoice_pfx"].ToString() + dr["Sno"].ToString();
                            //dr["invoice_pfx"].ToString() + dr["Sno"].ToString();
                            int intSno = int.Parse(dr["Sno"].ToString());
                            if (intSno < 472)
                            {
                                InvNo = dr["invoice_pfx"].ToString() + dr["InvoiceNoByCompany"].ToString() + "/" + MasterSno;

                            }
                            else
                            {
                                InvNo = dr["invoice_pfx"].ToString() + dr["InvoiceNoByCompany"].ToString();

                                InvNo = dr["invoice_pfx"].ToString()+"/NT/" + dr["InvoiceNoByCompany"].ToString();

                                ////if (dr["NonTaxableInvNo"].ToString() != "" && dr["NonTaxableInvNo"].ToString() != null)
                                ////{
                                ////    InvNo = dr["NonTaxableInvNo"].ToString();
                                ////}
                            }


                            InvDate = DateTime.Parse(dr["bill_date"].ToString()).ToString("MMM dd yyyy");
                            STaxRate = comBusins.GetList("STaxRate", "TotalSTaxRate", "FromDate<='" + InvDate + "' and ToDate>='" + InvDate + "'").Rows[0][0].ToString();
                            InvDueDate = DateTime.Parse(dr["inv_due_date"].ToString()).ToString("MMM dd yyyy");
                            BankName = dr["BankName"].ToString();
                            BankAddress = dr["BankAdd"].ToString();
                            AccountNo = dr["AccountNo"].ToString();
                            IFSCCode = dr["IFSCCode"].ToString();
                            panno = dsCompName.Tables[0].Rows[0]["PanNo"].ToString();
                            serviceregno = DateTime.Parse(dr["bill_date"].ToString()) > DateTime.Parse("Sep 28 2010") ? dsCompName.Tables[0].Rows[0]["STaxNo"].ToString().Split(',').Length > 1 ? dsCompName.Tables[0].Rows[0]["STaxNo"].ToString().Split(',')[1] : dsCompName.Tables[0].Rows[0]["STaxNo"].ToString().Split(',')[0] : dsCompName.Tables[0].Rows[0]["STaxNo"].ToString();
                            awbNo = dr["mawb_no"].ToString();
                            if (dr["mawb_date"].ToString() == "" || dr["mawb_date"].ToString() == "1/1/9999 12:00:00 AM")
                            {
                                AwbDate = "";
                            }
                            else
                            {
                                AwbDate = (dr["mawb_date"].ToString() == "1/1/9999 12:00:00 AM" ? "" : "Dated " + DateTime.Parse(dr["mawb_date"].ToString()).ToString("MMM dd yyyy"));

                            }
                            HawbNo = dr["hawb_no"].ToString();
                            Consignee = dr["consignee"].ToString();
                            Shipper = dr["shipper"].ToString();
                            Packages = dr["pkgs"].ToString();
                            // Weight = dr["gross_wt"].ToString();
                            Weight = dr["chargeable_wt"].ToString();
                            Origin = dr["origin"].ToString();
                            //FlightNo = dr[""].ToString();
                            //FlightDate = dr[""].ToString();
                            Airline = dr["airline"].ToString();
                            Commodity = dr["commodity"].ToString();
                            FreightType = dr["freight_type"].ToString();
                            Currency = dr["curr_code"].ToString();
                            exchange_rate = decimal.Parse(dr["exchange_rate"].ToString());
                            FlightNo = dr["req_flno"].ToString();
                            FlightDate = (dr["req_fldt"].ToString() == "1/1/9999 12:00:00 AM" ? "" : DateTime.Parse(dr["req_fldt"].ToString()).ToString("MMM dd yyyy"));
                            IGMNo = dr["igm_no"].ToString();
                            IGMDate = dr["igm_dt"].ToString();
                        }
                        string html = "";
                        if (type == "p" && invoice.ToUpper() == "N")
                            html = @"<table  width=""95%"" border=""0"" cellspacing=""2""> <tr><td align=""center"" style=""font-size:8px"">" + headerhtml + @"</td></tr><tr> <td style=""font-size:8px"">Dear Sir/Madam,<br>" + MainText + @"<Br>" + PrintableNote + @" <BR>" + BROMsg + @"</td>	</tr>";

                        if (type == "p" && invoice.ToUpper() == "Y")
                            html = @"<table width=""95%"" border=""0"" cellspacing=""2""> <tr><td  align=""center"" style=""font-size:8px"">" + headerhtml + "<Br>" + PrintableNote + @"</td></tr>";

                        if (type == "l" && invoice.ToUpper() == "N")
                            html = @"<table width=""95%"" border=""0"" cellspacing=""2""> <tr><td  align=""center"" style=""font-size:8px""><br><B>CARGO ARRIVAL NOTICE CUM BILL OF SUPPLY</b><br> <br><br><br></td></tr><tr> <td style=""font-size:8px"" >Dear Sir/Madam,<br>" + MainText + @"<Br>" + PrintableNote + @"<BR>" + BROMsg + @" </td>	</tr>";

                        if (type == "l" && invoice.ToUpper() == "Y")

                            html = @"<table width=""95%"" border=""0"" cellspacing=""2""> <tr><td  align=""center"" style=""font-size:8px""> <br><B>TAX INVOICE</b><br> <br><br></td></tr>";



                        html += @"<tr><td  style=""border-top-style:ridge""></td><hr width=""2""/></tr>";
                        string[] CompNameNew = Session["CompName"].ToString().Split('-');
                        if (CompNameNew[0].ToString() == "THREE SIXTY LOGISTICS PVT. LTD.")
                        {
                            html += @" <tr><td><font size=""2""><b><I>Payment to be made in favour of THREE SIXTY LOGISTICS PVT. LTD.</I></B></td></tr>";
                        }
                        html += @" <tr><td style=""font-size:8px""><table width=""100%""><tr>
	 <td width=""60%"" colspan=""2""><b>" + InvoiceToname + @"</b><br>" + address + @"</td>
		    
	          <td colspan=""2"">IMPORT</font></td> 
		  </tr>
		  <tr>
                <td> &nbsp;</td><td> &nbsp;</td>
			  <td><font size=""20px"">Invoice No.</font></td>
	           <td><font size=""20px""><b>" + InvNo.ToUpper() + @"</b></font></td> 
			  
		  </tr>
		  <tr>
            <td> &nbsp;</td><td> &nbsp;</td>
			  <td><font size=""20px"">Invoice Date.</font></td>
	          <td><font size=""20px"">" + InvDate + @"</font></td> 
		  </tr>
		  <tr>
                <td> &nbsp;</td><td> &nbsp;</td>
			  <td><font size=""20px"">Due Date.</font></td>
	          <td><font size=""20px"">" + InvDueDate + @"</font></td> 
		  </tr>
		</table>
	 </td>
	</tr>";
                       
                        html += @"<tr><td  style=""border-top-style:ridge""></td></tr>";

                        html += @"<tr>
	  <td style=""font-size:8px""><hr width=""2""/>
	     <table width=""100%"">
		    <tr>
			  <td width=""20%"">AWB Number</td>
			  <td width=""40%"">" + awbNo + @"  " + AwbDate + @"</td>
			  <td width=""20%"">HAWB Number</td>
			  <td width=""20%"">" + HawbNo + @"</td>
			</tr>
		    <tr>
			  <td>Consignee</td>
			  <td>" + Consignee + @"</td>
			  <td>Packages/Weight</td>
			  <td>" + Packages + @"/ " + Weight + @"</td>
			</tr>
<tr><td>Shipper</td><td colspan=""3"">" + Shipper + @"</td></tr>
		    <tr>
			  <td>Origin</td>
			  <td>" + Origin + @"</td>
			  <td>Destination</td>
			  <td>" + destination + @"</td>
			</tr>
		    <tr>
			  <td>Flight No.</td>
			  <td>" + FlightNo + @"</td>
			  <td>Flight Dt.</td>
			  <td>" + FlightDate + @"</td>
			</tr>

		    <tr>
   
			  <td>Airline</font></td>
			  <td>" + Airline + @"</td>
   
			  <td>Commodity</td>
			  <td>" + Commodity + @"</td>
   		  
			</tr>
			
<tr>
   
			  <td>IGMNo</td>
			  <td>" + IGMNo + @"</td>
   
			  <td>IGM date</td>
			  <td>" + IGMDate + @"</td>
   		  
			</tr>
		    <tr>
	
			  <td>Freight Type</td>
			  <td>" + FreightType + @"</td>";
                        if (Convert.ToInt32(Session["CompBrSno"]).ToString() == "12")
                        {

                            html += @"<td>Reference No</td><td>" + ReferenceNo + @"</td>";
                        }
                       html+=@"</tr> </table></td>	</tr>";

                        //Data get from imports_billing_Trnas.
                        SqlDataReader trDr = BC.Show_billing_tran(int.Parse(MasterSno));
                        if (trDr.HasRows)
                        {
                            html += @"<tr>
	  <td style=""font-size:8px""><hr width=""2""/>
			<table width=""100%"" cellpadding=""1"" cellspacing=""0"" border=""0"">
				<tr><td colspan=""5"" height=""1"" style=""border-top-style:ridge""></td> </tr>
				<tr>
                    <td width=""30%"" valign=""top""><b>Particulars</b></td>
					<td width=""30%"" valign=""top""><b>Description</b></td>
					<td width=""15%"" valign=""top"" align=""right"" nowrap><b>Non-Taxable</b></td>
					<td width=""1%"">&nbsp;</td>
					<td valign=""top"" align=""right""><b>Taxable&nbsp;</b></td>              
				</tr>
				<tr><td colspan=""5"" height=""1"" style=""border-top-style:ridge""></td> </tr>";
                            totTaxAmt = 0;
                            totNontaxAmt = 0;
                            taxAmt = 0;
                            decimal amount = 0;
                            while (trDr.Read())
                            {
                                DataTable dtHSNoCode = dw.GetAllFromQuery("Select top 1 HSNCode from Charges where HeadName='" + trDr["headname"].ToString() + "' and HSNCode is not null");
                                if (dtHSNoCode.Rows.Count > 0 && dtHSNoCode != null)
                                {
                                    HSNCode = dtHSNoCode.Rows[0]["HSNCode"].ToString();
                                }

                                html += @"<tr>
					<td>" + trDr["headname"].ToString() + @"</td>
                    <td>" + HSNCode + @"</td>
					<td>" + trDr["description"].ToString() + @"</td>";
                                if (trDr["taxable"].ToString().ToUpper() == "N")
                                {
                                    amount = decimal.Parse(trDr["amount"].ToString()) / exchange_rate;
                                    amount = Math.Round(amount, 2, MidpointRounding.AwayFromZero);
                                    html += @"<td valign=""top"" align=""right"">" + amount + @"</td><td width=""1%"">&nbsp;</td><td valign=""top"" align=""right"" nowrap>&nbsp;</td> </tr>";
                                    totNontaxAmt += decimal.Parse(trDr["amount"].ToString()) / exchange_rate;
                                    totNontaxAmt = Math.Round(totNontaxAmt, 2, MidpointRounding.AwayFromZero);
                                }
                                else
                                {
                                    amount = decimal.Parse(trDr["amount"].ToString()) / exchange_rate;
                                    amount = Math.Round(amount, 2, MidpointRounding.AwayFromZero);
                                    html += @"<td valign=""top"" align=""right"">&nbsp;</td><td width=""1%"">&nbsp;</td><td valign=""top"" align=""right"" nowrap>" + amount + @"</td> </tr>";
                                    totTaxAmt += decimal.Parse(trDr["amount"].ToString()) / exchange_rate;
                                    // totTaxAmt += Convert.ToDecimal(trDr["tot_sTax_Amt"].ToString());
                                    totTaxAmt = Math.Round(totTaxAmt, 2, MidpointRounding.AwayFromZero);
                                    taxAmt += Convert.ToDecimal(trDr["stax_amt"].ToString()) / exchange_rate;
                                    taxAmt = Math.Round(taxAmt, 2, MidpointRounding.AwayFromZero);

                                      //===================Pradeep==========================
                                    //BillDate = Convert.ToDateTime(ds.Tables[0].Rows[0]["bill_Date"].ToString());
                                    //if (BillDate < Convert.ToDateTime("11/15/2015 12:00:00 AM"))
                                    //{
                                    //      taxAmt = totTaxAmt * decimal.Parse(ds.Tables[0].Rows[0]["service_tax_rate"].ToString()) / 100;
                                    //      SBCessTaxRate = "0.00";
                                    //      SbCesstaxAmt = 0;
                                    //}
                                    //else
                                    //{
                                    //      taxAmt = totTaxAmt * decimal.Parse(ds.Tables[0].Rows[0]["service_tax_rate"].ToString()) / 100;
                                    //      SbCesstaxAmt = totTaxAmt * decimal.Parse(SBCessTaxRate) / 100;
                                    //}





                                }
                            }
                            decimal Gtot = 0;
                            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                            Gtot = Convert.ToDecimal(totTaxAmt) + Convert.ToDecimal(taxAmt) + Convert.ToDecimal(totNontaxAmt) + SbCesstaxAmt + KKCesstaxAmt;

                            //Gtot = Math.Round(Gtot, MidpointRounding.AwayFromZero);

                            decimal netAmount = Convert.ToDecimal(totTaxAmt) + Convert.ToDecimal(taxAmt);
                            netAmount = Math.Round(netAmount, 2, MidpointRounding.AwayFromZero);
                            taxAmt = decimal.Round(taxAmt, 2);
                            taxAmt = Math.Round(taxAmt, 2, MidpointRounding.AwayFromZero);

                            if (Currency == "INR")
                            {
                                Gtot = Math.Round(Gtot, MidpointRounding.AwayFromZero);
                            }
                            //else
                            //{
                            //    Gtot = Gtot / exchange_rate;
                            //}

                            html += @"<tr><td colspan=""5"" style=""border-top-style:ridge""></td></tr>
				<tr>
				<td>&nbsp;</td>
				<td align=""right""><b>Total:</td>
				<td align=""right"">" + totNontaxAmt + @"</td>
				<td width=""1%"">&nbsp;</td>
				<td align=""right"">" + totTaxAmt + @"</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td align=""right"">Service Tax @ "+STaxRate+@"%:</td>
                <td align=""right"">&nbsp;</td>
                <td width=""1%"">&nbsp;</td>
                <td align=""right"">" + taxAmt + @"</td>
                </tr>		
				
                <tr>
                <td>&nbsp;</td>
                <td align=""right"">Net Amount:</td>

                <td align=""right"">" + Math.Round(totNontaxAmt, 2, MidpointRounding.AwayFromZero) + @"</td>


                <td width=""1%"">&nbsp;</td>

	
                <td align=""right"">" + (Convert.ToDecimal(totTaxAmt) + Convert.ToDecimal(taxAmt)) + @"</td>
                </tr>
                <tr><td colspan=""5"" style=""border-top-style:ridge""></td><hr width=""2""/></tr>
                <tr>
                <td>&nbsp;</td>
                <td align=""right"" valign=""top"">Total Amount Due: <b>" + Currency + @"</b></td>
                <td align=""right"">&nbsp;</td>
                <td width=""1%"">&nbsp;</td>
                <td align=""right""><b>" + Gtot.ToString("f2") + @"</b></td>
                </tr>			
				
             </table> 
      </td>
    </tr>";

                            HiddenField1.Value = (Math.Round(totNontaxAmt, 2, MidpointRounding.AwayFromZero) + Convert.ToDecimal(totTaxAmt) + Convert.ToDecimal(taxAmt)).ToString();

                            // string aa=Convert.ToString(Math.Round(Gtot,MidpointRounding.AwayFromZero));

                            string FinalWord = "";



                            if (Gtot.ToString().Contains("."))
                            {
                                string[] preDecimal = (Math.Round(totNontaxAmt, 2, MidpointRounding.AwayFromZero) + Convert.ToDecimal(totTaxAmt) + Convert.ToDecimal(taxAmt)).ToString().Split('.');
                                double pre = Convert.ToDouble(preDecimal[0]);
                                string preWord = PaceCommon.changeNumericToWords(pre);
                                try
                                {
                                    double post = Convert.ToDouble(preDecimal[1]);
                                    string postWord = PaceCommon.changeNumericToWords(post);
                                    FinalWord = preWord + " Point " + postWord;
                                }
                                catch
                                {
                                    FinalWord = preWord;
                                }
                            }
                            else
                            {
                                FinalWord = PaceCommon.changeNumericToWords(Convert.ToDouble(Gtot.ToString()));
                            }
                            string[] CompName1 = Session["CompName"].ToString().Split('-');
                            if (Convert.ToInt32(Session["CompBrSno"]).ToString() == "25")
                            {
                                html += @"<td colspan==""2""><font size==""2""><B><U>NOTE FOR PERSONAL EFFECT BASIS SHPT:</U></B></td></tr>
<tr>
<td >1. Delivery order will be issued strictly against payment of above charges vide DD or Cash only.</td></tr>
<tr><td >2. Consignee must carry Original Passport while collecting the delivery order for verification and clearance purpose.</td></tr>
<tr><td >3. All custom clearance & transportation charges, apart from above, will be on consignee's account.</td></tr>
<tr><td >4. Please contact us on the given no's for any kind of assistance or inquiry.</td></tr>
<tr><td >A. Mr. Gaurav Mehta  <B># 09873352693</B></td></tr>
<tr><td >B. Ms. Neelam Sharma <B># 07838089413</B></td></tr>";
                            }

                            if (CompName1[0].ToString() == "RED LOGISTICS LTD.")
                            {
                                html += @"<tr><td  style=""font-size:8px""><B>TOTAL(Words) :" + Currency + "  " + FinalWord +
                @"</B></td>
</tr>
            <tr>
            <td ><font size=""8px""><hr width=""2""/>
              A delivery order will be issued to you on production of this notice duly endorsed by the bank wherever applicable  on payment of our charges, as indicated above,along with the BANK RELEASE ORDER  wherever applicable between 0900 hours and 1700 hours on working days.
<tr><td style='font-size:12px'>
<b>BANK DETAILS:-</b></td></tr>
<tr><td>
<table><tr><td><b>Name:</b></td><td>" + BankName + @"</td></tr>
<tr><td><b>A/C No:</b></td><td>" + AccountNo + @"</td></tr>
<tr><td><b>Address:</b></td><td>" + BankAddress + @"</td></tr>
<tr><td><b>IFSC Code:</b></td><td>" + IFSCCode + @"</td></tr></table></td></tr>
<tr><td><b>Payment Terms:-</b>Only DD & Cash Accepted.</td></tr>
<tr><td>Payment to be made in favour of <b>RED LOGISTICS LTD.</b></font></td></tr>
<tr><td><b>PAN No.:</b> " + panno + @"</td></tr>.
<tr><td>All disputes are subject to New Delhi Jurisdiction only.</td></tr>
            </td>
            </tr>            
            <tr><td valign='top'  align='right'><br><b><font size=""2"">For " + CompanyName[0] + @"<br><br><br><br><font size=""2"">" + "" + @"
              
            <br><font size=""1"">Authorised Signatory</td> </tr>          
              </table>";

                            }
                            else if (CompName1[0].ToString() == "THREE SIXTY LOGISTICS PVT. LTD.")
                            {
                                html += @"<tr><td  style=""font-size:8px""><B>TOTAL(Words) :" + Currency + "  " + FinalWord +
                @"</B></td>
</tr>
            <tr>
            <td ><font size=""10px""><hr width=""2""/>
              A delivery order will be issued to you on production of this notice duly endorsed by the bank wherever applicable  on payment of our charges, as indicated above,along with the BANK RELEASE ORDER  wherever applicable between 0900 hours and 1700 hours on working days.
<tr><td style='font-size:12px'>
<b>BANK DETAILS:-</b></td></tr>
<tr><td>
<table><tr><td><b>Name:</b></td><td>" + BankName + @"</td></tr>
<tr><td><b>A/C No:</b></td><td>" + AccountNo + @"</td></tr>
<tr><td><b>Address:</b></td><td>" + BankAddress + @"</td></tr>
<tr><td><b>IFSC Code:</b></td><td>" + IFSCCode + @"</td></tr></table></td></tr>
<tr><td><b>Payment Terms:-</b> Only DD & Cash Accepted.</td></tr>
<tr><td>Payment to be made in favour of <b>THREE SIXTY LOGISTICS PVT. LTD.</b></td></tr>
<tr><td><b>PAN No.:</b> " + panno + @"</td></tr>.
<tr><td>All disputes are subject to New Delhi Jurisdiction only.</td></tr>
            </td>
            </tr>
            
            <tr>  <td valign='top'  align='right'><br><b><font size=""2"">For " + CompanyName[0] + @"<br><font size=""2"">" + "" + @"
              
            <font size=""1"">Authorised Signatory</td> </tr>          
              </table>";

                            }
                            else
                            {

                                html += @"<tr><td  style=""font-size:8px""><B>TOTAL(Words) :" + Currency + "  " + FinalWord +
                                 @"</B></td>
</tr>
            <tr>
            <td  width=""100%"" ><font size=""8px""><hr width=""2""/>
              A delivery order will be issued to you on production of this notice duly endorsed by the bank wherever applicable  on payment of our charges, as indicated above,along with the BANK RELEASE ORDER  wherever applicable between 0900 hours and 1700 hours on working days.
<tr><td style='font-size:12px'>
<b>BANK DETAILS:-</b></td></tr>
<tr><td>
<table><tr><td><b>Name:</b></td><td>" + BankName + @"</td></tr>
<tr><td><b>A/C No:</b></td><td>" + AccountNo + @"</td></tr>
<tr><td><b>Address:</b></td><td>" + BankAddress + @"</td></tr>
<tr><td><b>IFSC Code:</b></td><td>" + IFSCCode + @"</td></tr></table></td></tr>
<tr><td><b>Payment Terms:-</b> Only DD & Cash Accepted.</td></tr><tr><td><b>PAN No.:</b> " + panno + @".</td></tr><tr><td>All disputes are subject to New Delhi Jurisdiction only.</td></tr>
</font>
            </td>
            </tr>
            
            <tr>  <td valign='top'  style=""text-align='right'""><br><b><font size=""2"">For " + CompanyName[0] + @"<br><br><br><br><font size=""2"">" + "" + @"
              
           <font size=""1"">Authorised Signatory</td> </tr>          
              </table>";
                            }
                            InvNoEmail = InvNo.ToString().Replace('/', '_');
                            string path = Server.MapPath("./Email/" + InvNoEmail + ".pdf");
                            //string path = Server.MapPath("./Email/CAN"+SNo[i]+".pdf");
                            string name = Path.GetFileName(path);

                            if (File.Exists(path))
                            {
                                File.Delete(path);
                            }
                            System.IO.StringReader sr = new StringReader(html);
                            //System.IO.StringReader srCompany = new StringReader(CompanyName);
                            iTextSharp.text.Document pdfDoc = new Document(iTextSharp.text.PageSize.A4, 25f, 25f, 0f, 0f);
                            iTextSharp.text.html.simpleparser.HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                            //iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(Image);
                            PdfWriter.GetInstance(pdfDoc, new FileStream(path, FileMode.Create));
                            pdfDoc.Open();
                            htmlparser.Parse(sr);
                            pdfDoc.Close();
                            mail.Attachments.Add(new Attachment(path));


                        }// end while loop 

                    }//end  trDr read  if cond.
                }

                //Session["SNo"] = Request.QueryString[0].ToString();
                SmtpClient smtp = new SmtpClient(smtpHost, 25);

                smtp.Credentials = new NetworkCredential(userName, password);
                smtp.Send(mail);
                hdnSend.Value = "1";
                mail.Dispose();
                for (int j = 0; j < SNo.Length; j++)
                {
                    string oldPath = Server.MapPath("./Email/" + InvNoEmail + ".pdf");
                    //string oldPath = Server.MapPath("./Email/CAN" + SNo[j] + ".pdf");
                    if (File.Exists(oldPath))
                    {
                        File.Delete(oldPath);
                    }
                }
                Response.Redirect("BrowseImportInvoice.aspx?EmailSend=Y");

                // Response.Redirect("EmailInvoice.aspx?Sno=" + Request.QueryString[0].ToString() + "&InvNo=" + InvNo+"&Mail="+mail);
            }
            //}
            //CAN PRINT
            else
            {
                for (int j = 0; j < SNo.Length; j++)
                {

                    if (SNo[j].ToString() == string.Empty || SNo[j].Contains("Performa"))
                        break;
                    int Sno = int.Parse(SNo[j]);
                    //int Sno = int.Parse(Request.QueryString[0].ToString());
                    BCan BC = new BCan();

                    SqlDataReader dr = SNo.Length > 1 ? SNo[1] == "PerformaInvoice" ? BC.ImportPerformaInvoiceShow(Sno) : BC.Show_billing_master(Sno) : BC.Show_billing_master(Sno);
                    DataSet dsCompName = bl.getCustBranchBySNo(Convert.ToInt32(Session["CompBrSNo"]));

                    string[] CompanyName = Session["CompName"].ToString().Split('-');
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {

                            if (dr["BRONEW"].ToString() == "Y")
                            {
                                BROMsg = "<B>PLEASE ALSO NOTE THAT YOUR SHIPMENT IS CONSIGNED TO BANK,SO PLEASE PRESENT BANK RELEASE ORDER BEFORE TAKING DELIVERY ORDER.</B>";
                            }
                            else
                            {
                                BROMsg = "";
                            }

                            //GSTNo Applicable

                            string CompanyGstNo = "07ASGSDJDGSG2312";
                            DataTable dtCompanyGstNo = dw.GetAllFromQuery("select GstNo from CompanyDetails where Sno=" + Session["CompBrSNo"].ToString() + "");


                            if (dtCompanyGstNo.Rows.Count > 0)
                            {
                                CompanyGstNo = dtCompanyGstNo.Rows[0]["GstNo"].ToString();
                            }

                            PrintableNote = dr["note"].ToString();
                            sno = dr["Sno"].ToString();
                            Invto_Code = dr["Invto_Code"].ToString();
                            Invto_Name = dr["Invto_Name"].ToString();
                            string s = dr["address"].ToString();
                            char ch = (char)System.Windows.Forms.Keys.Return;
                            char ch2 = (char)System.Windows.Forms.Keys.Space;
                            string ch1 = Convert.ToString(ch);
                            string ch3 = Convert.ToString(ch2);
                            CustCareAdd = s.Replace(ch1, "<br>");
                            CustCareAdd = CustCareAdd.Replace(ch3, "&nbsp;");
                            comName = dr["name"].ToString();
                            string[] CompName = Session["CompName"].ToString().Split('-');
                            //if (CompName[0].ToString() == "THREE SIXTY LOGISTICS PVT. LTD.")
                            //{
                            string images = CompName[0].Split(' ')[0].ToString() == "THREE" ? "360" : CompName[0].Split(' ')[0].ToString();


                            if (comName == "RED EXPRESS TRANSPORT SERVICES LTD.")
                            {
                                //                                headerhtml = @"<table width=""100%"" >
                                //                            <tr>
                                // <td align=""center"" colspan=""3""><font size=""4""><B>" + dsCompName.Tables[0].Rows[0]["Name"].ToString().Replace("[WS]", "").Replace("(WS)", "") + @"</B>
                                //</td>
                                //                            </tr>
                                //<tr>
                                //<td align=""center"" colspan=""3"">" + dsCompName.Tables[0].Rows[0]["Address"].ToString() + @"
                                //</td>
                                //</tr>
                                //   <tr height=""25"" >
                                //                       <td align=""left"" valign=""top"">
                                //                            <img src=""../Images/RLOGO.jpg"" >
                                //                        </td>	   
                                //                    <td  valign=""top"">
                                //                  <font size=""2"">" + @"</font></td><td align=""right""></td>
                                //	            </tr>
                                //                        
                                //            <tr>
                                //            <td align=""center"" colspan=""3""><font size=""2"">";

                                headerhtml = @"<table  align=""center"" width=""100%"" >   <tr height=""20""> <td align=""center"" valign=""top"" colspan=""3"">                                  <font size=""5""><b>" + dsCompName.Tables[0].Rows[0]["Name"].ToString() + @"</b></font></td> </tr>
                            <tr height=""30"">  <td align=""left"" valign=""top"" width=""20%"" rowspan=""2"">
                          <img src=""../Images/RLOGO.jpg"" >
                        </td><td align=""center"" valign=""top"" width=""60%"" ><font size=""2"">" + AddressCompany + @"<br/>GST No: " + CompanyGstNo + @"</font></td><td align=""right"" width=""20%"" rowspan=""2""></td>
	                         </tr>

<tr>
            <td align=""center"" ><font size=""2"">";
                            }
                            else
                            {


                                headerhtml = @"<table  align=""center"" width=""100%"" >   <tr height=""20""> <td align=""center"" valign=""top"" colspan=""3"">                                  <font size=""5""><b>" + dsCompName.Tables[0].Rows[0]["Name"].ToString() + @"</b></font></td> </tr>
                            <tr height=""30"">  <td align=""left"" valign=""top"" width=""20%"" rowspan=""2"">
                            <img src=""../Images/" + images + @"_trans_logo.gif"" >
                        </td><td align=""center"" valign=""top"" width=""60%"" ><font size=""2"">" + AddressCompany + @"<br/>GST No: " + CompanyGstNo + @"</font></td><td align=""right"" width=""20%"" rowspan=""2""></td>
	                         </tr>

<tr>
            <td align=""center"" ><font size=""2"">";
                            }
                                MainText = Session["CompBrType"].ToString() != "PNP" ? "We are pleased to announce the planning of the following shipment under our consolidation service." : "We are pleased to announce the planning of the following shipment.";
                            
   if (SNo.Length > 1)
                            {
                                if (SNo[1] == "PerformaInvoice")
                                    headerhtml += @"<br><B>PERFORMA INVOICE</b></font></td>
            </tr></table>";
                                else
                                    if (invoice.ToUpper() == "Y")
                                    {
                                        headerhtml += @"<br><B>Bill Of Supply</b></font></td>
            </tr></table>";

                                    }
                                    else
                                    {
                                        headerhtml += @"<br><B>CARGO ARRIVAL NOTICE CUM Bill Of Supply</b></font></td>
            </tr></table>";

                                    }
                            }
                            else
                            {
                                if (invoice.ToUpper() == "Y")
                                {
                                    headerhtml += @"<br><B>Bill Of Supply</b></font></td>
            </tr></table>";

                                }
                                else
                                {
                                    headerhtml += @"<br><B>CARGO ARRIVAL NOTICE CUM Bill Of Supply</b></font></td>
            </tr></table>";

                                }
                            }
                            MasterSno = dr["sno"].ToString();
                            destination = dr["destination"].ToString();
                            if (dr["invto_code_type"].ToString() == "Sub Agent")
                            {
                                InvoiceToname = dr["invto_name"].ToString();
                                address = dr["invto_address"].ToString();
                            }
                            if (dr["invto_code_type"].ToString() == "CAN Customer")
                            {
                                InvoiceToname = dr["invto_name"].ToString();
                                address = dr["invto_address"].ToString();
                            }
                            if (dr["invto_code_type"].ToString() == "Actual Customer")
                            {
                                InvoiceToname = dr["act_name"].ToString();
                                address = dr["invto_address"].ToString();
                            }

                            //InvNo = dr["invoice_pfx"].ToString() + dr["Sno"].ToString();
                            //dr["invoice_pfx"].ToString() + dr["Sno"].ToString();
                            int intSno = int.Parse(dr["Sno"].ToString());
                            if (intSno < 472)
                            {
                                InvNo = dr["invoice_pfx"].ToString() + dr["InvoiceNoByCompany"].ToString() + "/" + MasterSno;

                            }
                            else
                            {
                                //////InvNo = dr["invoice_pfx"].ToString() + dr["InvoiceNoByCompany"].ToString();

                                //////InvNo = dr["invoice_pfx"].ToString() + "/NT/" + dr["InvoiceNoByCompany"].ToString();

                                ////if (dr["NonTaxableInvNo"].ToString() != "" && dr["NonTaxableInvNo"].ToString() != null)
                                ////{
                                ////    InvNo = dr["NonTaxableInvNo"].ToString();
                                ////}
                                if (DateTime.Parse(dr["bill_date"].ToString()) < DateTime.Parse("Jul 01 2017"))
                                {
                                    InvNo = dr["invoice_pfx"].ToString() + dr["InvoiceNoByCompany"].ToString();
                                }
                                else if (DateTime.Parse(dr["bill_date"].ToString()) >= DateTime.Parse("Jul 01 2017"))
                                {
                                    string billtype = "";

                                    string[] year = dr["bill_date"].ToString().Split('/');
                                    string y = year[2].Substring(2, 2);
                                    int yy = int.Parse(y) + 1;
                                    //***updated on  11 Jan 2018 for: March Financial Condition:************
                                    if (int.Parse(year[0].ToString()) < 4)
                                    {
                                        y = Convert.ToString(int.Parse(y) - 1);
                                        yy = int.Parse(y) + 1;
                                    }
                                    //***End of updated on  11 Jan 2018 for: March Financial Condition:************
                                    InvNo = dr["invoice_pfx"].ToString() + dr["InvoiceNoByCompany"].ToString();

                                    #region DEL
                                    if (dr["bill_type"].ToString().Contains("IMP/A/DEL/"))
                                    {
                                        billtype = "IADEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/A/DEL/"))
                                    {
                                        billtype = "EADEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("OTHWHS/"))
                                    {
                                        billtype = "OWHS";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/A/O/DEL/"))
                                    {
                                        billtype = "EAODEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/AC/O/DEL/"))
                                    {
                                        billtype = "EACODEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/CCU/"))
                                    {
                                        billtype = "IACCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/O/DEL/"))
                                    {
                                        billtype = "IAODEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("AIRWHS/"))
                                    {
                                        billtype = "AWHS";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("EXP/A/DN/DEL/"))
                                    {
                                        billtype = "EADNDEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/AC/DEL/"))
                                    {
                                        billtype = "IACDEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/DN/DEL/"))
                                    {
                                        billtype = "IADNDEL";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("IMP/A/CN/DEL/"))
                                    {
                                        billtype = "IACNDEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/DEL/"))
                                    {
                                        billtype = "ESDEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/O/DEL/"))
                                    {
                                        billtype = "ESODEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/DN/DEL/"))
                                    {
                                        billtype = "ESDNDEL";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("IMP/S/DEL/"))
                                    {
                                        billtype = "ISDEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/O/DEL/"))
                                    {
                                        billtype = "ISODEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/DN/DEL/"))
                                    {
                                        billtype = "ISDNDEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/CN/DEL/"))
                                    {
                                        billtype = "ISCNDEL";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/AC/DEL/"))
                                    {
                                        billtype = "IAACDEL";
                                    }

                                    #endregion Del

                                    #region MUM
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/BOM/"))
                                    {
                                        billtype = "IABOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/A/BOM/"))
                                    {
                                        billtype = "EABOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/A/O/BOM/"))
                                    {
                                        billtype = "EAOBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/AC/O/BOM/"))
                                    {
                                        billtype = "EACOBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/CCU/"))
                                    {
                                        billtype = "IACCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/O/BOM/"))
                                    {
                                        billtype = "IAOBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("AIRWHS/"))
                                    {
                                        billtype = "AWHS";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("EXP/A/DN/BOM/"))
                                    {
                                        billtype = "EADNBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/AC/BOM/"))
                                    {
                                        billtype = "IACBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/DN/BOM/"))
                                    {
                                        billtype = "IADNBOM";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("IMP/A/CN/BOM/"))
                                    {
                                        billtype = "IACNBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/BOM/"))
                                    {
                                        billtype = "ESBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/O/BOM/"))
                                    {
                                        billtype = "ESOBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/DN/BOM/"))
                                    {
                                        billtype = "ESDNBOM";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("IMP/S/BOM/"))
                                    {
                                        billtype = "ISBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/O/BOM/"))
                                    {
                                        billtype = "ISOBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/DN/BOM/"))
                                    {
                                        billtype = "ISDNBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/CN/BOM/"))
                                    {
                                        billtype = "ISCNBOM";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/AC/BOM/"))
                                    {
                                        billtype = "IAACBOM";
                                    }

                                    #endregion MUM

                                    #region CCU
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/CCU/"))
                                    {
                                        billtype = "IACCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/A/CCU/"))
                                    {
                                        billtype = "EACCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/A/O/CCU/"))
                                    {
                                        billtype = "EAOCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/AC/O/CCU/"))
                                    {
                                        billtype = "EACOCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/CCU/"))
                                    {
                                        billtype = "IACCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/O/CCU/"))
                                    {
                                        billtype = "IAOCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("AIRWHS/"))
                                    {
                                        billtype = "AWHS";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("EXP/A/DN/CCU/"))
                                    {
                                        billtype = "EADNCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/AC/CCU/"))
                                    {
                                        billtype = "IACCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/DN/CCU/"))
                                    {
                                        billtype = "IADNCCU";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("IMP/A/CN/CCU/"))
                                    {
                                        billtype = "IACNCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/CCU/"))
                                    {
                                        billtype = "ESCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/O/CCU/"))
                                    {
                                        billtype = "ESOCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/DN/CCU/"))
                                    {
                                        billtype = "ESDNCCU";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("IMP/S/CCU/"))
                                    {
                                        billtype = "ISCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/O/CCU/"))
                                    {
                                        billtype = "ISOCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/DN/CCU/"))
                                    {
                                        billtype = "ISDNCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/CN/CCU/"))
                                    {
                                        billtype = "ISCNCCU";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/AC/CCU/"))
                                    {
                                        billtype = "IAACCCU";
                                    }

                                    #endregion CCU

                                    #region MAA
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/MAA/"))
                                    {
                                        billtype = "IAMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/A/MAA/"))
                                    {
                                        billtype = "EAMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/A/O/MAA/"))
                                    {
                                        billtype = "EAOMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/AC/O/MAA/"))
                                    {
                                        billtype = "EACOMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/MAA/"))
                                    {
                                        billtype = "IAMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/O/MAA/"))
                                    {
                                        billtype = "IAOMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("AIRWHS/"))
                                    {
                                        billtype = "AWHS";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("EXP/A/DN/MAA/"))
                                    {
                                        billtype = "EADNMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/AC/MAA/"))
                                    {
                                        billtype = "IACMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/DN/MAA/"))
                                    {
                                        billtype = "IADNMAA";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("IMP/A/CN/MAA/"))
                                    {
                                        billtype = "IACNMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/MAA/"))
                                    {
                                        billtype = "ESMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/O/MAA/"))
                                    {
                                        billtype = "ESOMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/DN/MAA/"))
                                    {
                                        billtype = "ESDNMAA";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("IMP/S/MAA/"))
                                    {
                                        billtype = "ISMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/O/MAA/"))
                                    {
                                        billtype = "ISOMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/DN/MAA/"))
                                    {
                                        billtype = "ISDNMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/CN/MAA/"))
                                    {
                                        billtype = "ISCNMAA";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/AC/MAA/"))
                                    {
                                        billtype = "IAACMAA";
                                    }

                                    #endregion MAA

                                    #region COK
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/COK/"))
                                    {
                                        billtype = "IACOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/A/COK/"))
                                    {
                                        billtype = "EACOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/A/O/COK/"))
                                    {
                                        billtype = "EAOCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/AC/O/COK/"))
                                    {
                                        billtype = "EACOCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/COK/"))
                                    {
                                        billtype = "IACOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/O/COK/"))
                                    {
                                        billtype = "IAOCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("AIRWHS/"))
                                    {
                                        billtype = "AWHS";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("EXP/A/DN/COK/"))
                                    {
                                        billtype = "EADNCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/AC/COK/"))
                                    {
                                        billtype = "IACCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/DN/COK/"))
                                    {
                                        billtype = "IADNCOK";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("IMP/A/CN/COK/"))
                                    {
                                        billtype = "IACNCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/COK/"))
                                    {
                                        billtype = "ESCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/O/COK/"))
                                    {
                                        billtype = "ESOCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("EXP/S/DN/COK/"))
                                    {
                                        billtype = "ESDNCOK";
                                    }

                                    else if (dr["bill_type"].ToString().Contains("IMP/S/COK/"))
                                    {
                                        billtype = "ISCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/O/COK/"))
                                    {
                                        billtype = "ISOCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/DN/COK/"))
                                    {
                                        billtype = "ISDNCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/S/CN/COK/"))
                                    {
                                        billtype = "ISCNCOK";
                                    }
                                    else if (dr["bill_type"].ToString().Contains("IMP/A/AC/COK/"))
                                    {
                                        billtype = "IAACCOK";
                                    }

                                    #endregion COK
                                    InvNo = billtype + y + yy + "NT" + dr["InvoiceNoByCompany"].ToString();

                                    if (Convert.ToDateTime(dr["bill_Date"].ToString()) > Convert.ToDateTime("03/31/2018 12:00:00 AM") && (dr["Curr_Code"].ToString() != "INR"))
                                    {
                                        InvNo = billtype + y + yy + "NTE" + dr["InvoiceNoByCompany"].ToString();
                                    }


                                    if (DateTime.Parse(dr["bill_date"].ToString()) >= DateTime.Parse("Aug 01 2018"))
                                    {
                                        #region InvoiceNo Picked From Billing_Tran updated on 23 July 2018
                                        ////string billtyp = "";
                                        DataTable dtInvNo = dw.GetAllFromQuery("select top 1 invoiceNo,bill_type,InvoiceNoByCompany from billing_tran where taxable='N' and HeadType='I' and InvoiceNoByCompany>0 and master_sno=" + sno);
                                        if (dtInvNo.Rows.Count > 0)
                                        {
                                            ////billtyp = dtInvNo.Rows[0]["Bill_Type"].ToString();
                                            InvNo = billtype + y + yy + "NT" + dtInvNo.Rows[0]["InvoiceNoByCompany"].ToString();
                                        }
                                        else
                                        {
                                            InvNo = billtype + y + yy + "NT0";
                                        }
                                        #endregion

                                        
                                        if (Convert.ToDateTime(dr["bill_Date"].ToString()) > Convert.ToDateTime("03/31/2018 12:00:00 AM") && (dr["Curr_Code"].ToString() != "INR"))
                                        {
                                            InvNo = billtype + y + yy + "NTE" + dtInvNo.Rows[0]["InvoiceNoByCompany"].ToString();
                                        }
                                    }


                                }

                                ////else if (DateTime.Parse(dr["bill_date"].ToString()) >= DateTime.Parse("Jul 01 2018"))
                                ////{
                                ////    #region InvoiceNo Puicked From Billing_Tran updated on 23 July 2018
                                ////    string billtype = "";
                                ////    DataTable dtInvNo = dw.GetAllFromQuery("select top 1 invoiceNo,bill_type,InvoiceNoByCompany from billing_tran where taxable='N' and master_sno=" + sno);
                                ////    if (dtInvNo.Rows.Count > 0)
                                ////    {
                                ////        billtype = dtInvNo.Rows[0]["Bill_Type"].ToString();
                                ////    }
                                ////    #endregion


                                    

                                ////    string[] year = dr["bill_date"].ToString().Split('/');
                                ////    string y = year[2].Substring(2, 2);
                                ////    int yy = int.Parse(y) + 1;
                                ////    //***updated on  11 Jan 2018 for: March Financial Condition:************
                                ////    if (int.Parse(year[0].ToString()) < 4)
                                ////    {
                                ////        y = Convert.ToString(int.Parse(y) - 1);
                                ////        yy = int.Parse(y) + 1;
                                ////    }
                                ////    //***End of updated on  11 Jan 2018 for: March Financial Condition:************
                                ////    InvNo = dr["invoice_pfx"].ToString() + dr["InvoiceNoByCompany"].ToString();

                                ////    #region DEL
                                ////    if (dr["bill_type"].ToString().Contains("IMP/A/DEL/"))
                                ////    {
                                ////        billtype = "IADEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/DEL/"))
                                ////    {
                                ////        billtype = "EADEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("OTHWHS/"))
                                ////    {
                                ////        billtype = "OWHS";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/O/DEL/"))
                                ////    {
                                ////        billtype = "EAODEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/AC/O/DEL/"))
                                ////    {
                                ////        billtype = "EACODEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/CCU/"))
                                ////    {
                                ////        billtype = "IACCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/O/DEL/"))
                                ////    {
                                ////        billtype = "IAODEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("AIRWHS/"))
                                ////    {
                                ////        billtype = "AWHS";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/DN/DEL/"))
                                ////    {
                                ////        billtype = "EADNDEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/AC/DEL/"))
                                ////    {
                                ////        billtype = "IACDEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/DN/DEL/"))
                                ////    {
                                ////        billtype = "IADNDEL";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/CN/DEL/"))
                                ////    {
                                ////        billtype = "IACNDEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/DEL/"))
                                ////    {
                                ////        billtype = "ESDEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/O/DEL/"))
                                ////    {
                                ////        billtype = "ESODEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/DN/DEL/"))
                                ////    {
                                ////        billtype = "ESDNDEL";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/DEL/"))
                                ////    {
                                ////        billtype = "ISDEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/O/DEL/"))
                                ////    {
                                ////        billtype = "ISODEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/DN/DEL/"))
                                ////    {
                                ////        billtype = "ISDNDEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/CN/DEL/"))
                                ////    {
                                ////        billtype = "ISCNDEL";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/AC/DEL/"))
                                ////    {
                                ////        billtype = "IAACDEL";
                                ////    }

                                ////    #endregion Del

                                ////    #region MUM
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/BOM/"))
                                ////    {
                                ////        billtype = "IABOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/BOM/"))
                                ////    {
                                ////        billtype = "EABOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/O/BOM/"))
                                ////    {
                                ////        billtype = "EAOBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/AC/O/BOM/"))
                                ////    {
                                ////        billtype = "EACOBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/CCU/"))
                                ////    {
                                ////        billtype = "IACCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/O/BOM/"))
                                ////    {
                                ////        billtype = "IAOBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("AIRWHS/"))
                                ////    {
                                ////        billtype = "AWHS";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/DN/BOM/"))
                                ////    {
                                ////        billtype = "EADNBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/AC/BOM/"))
                                ////    {
                                ////        billtype = "IACBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/DN/BOM/"))
                                ////    {
                                ////        billtype = "IADNBOM";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/CN/BOM/"))
                                ////    {
                                ////        billtype = "IACNBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/BOM/"))
                                ////    {
                                ////        billtype = "ESBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/O/BOM/"))
                                ////    {
                                ////        billtype = "ESOBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/DN/BOM/"))
                                ////    {
                                ////        billtype = "ESDNBOM";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/BOM/"))
                                ////    {
                                ////        billtype = "ISBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/O/BOM/"))
                                ////    {
                                ////        billtype = "ISOBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/DN/BOM/"))
                                ////    {
                                ////        billtype = "ISDNBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/CN/BOM/"))
                                ////    {
                                ////        billtype = "ISCNBOM";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/AC/BOM/"))
                                ////    {
                                ////        billtype = "IAACBOM";
                                ////    }

                                ////    #endregion MUM

                                ////    #region CCU
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/CCU/"))
                                ////    {
                                ////        billtype = "IACCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/CCU/"))
                                ////    {
                                ////        billtype = "EACCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/O/CCU/"))
                                ////    {
                                ////        billtype = "EAOCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/AC/O/CCU/"))
                                ////    {
                                ////        billtype = "EACOCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/CCU/"))
                                ////    {
                                ////        billtype = "IACCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/O/CCU/"))
                                ////    {
                                ////        billtype = "IAOCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("AIRWHS/"))
                                ////    {
                                ////        billtype = "AWHS";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/DN/CCU/"))
                                ////    {
                                ////        billtype = "EADNCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/AC/CCU/"))
                                ////    {
                                ////        billtype = "IACCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/DN/CCU/"))
                                ////    {
                                ////        billtype = "IADNCCU";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/CN/CCU/"))
                                ////    {
                                ////        billtype = "IACNCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/CCU/"))
                                ////    {
                                ////        billtype = "ESCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/O/CCU/"))
                                ////    {
                                ////        billtype = "ESOCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/DN/CCU/"))
                                ////    {
                                ////        billtype = "ESDNCCU";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/CCU/"))
                                ////    {
                                ////        billtype = "ISCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/O/CCU/"))
                                ////    {
                                ////        billtype = "ISOCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/DN/CCU/"))
                                ////    {
                                ////        billtype = "ISDNCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/CN/CCU/"))
                                ////    {
                                ////        billtype = "ISCNCCU";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/AC/CCU/"))
                                ////    {
                                ////        billtype = "IAACCCU";
                                ////    }

                                ////    #endregion CCU

                                ////    #region MAA
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/MAA/"))
                                ////    {
                                ////        billtype = "IAMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/MAA/"))
                                ////    {
                                ////        billtype = "EAMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/O/MAA/"))
                                ////    {
                                ////        billtype = "EAOMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/AC/O/MAA/"))
                                ////    {
                                ////        billtype = "EACOMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/MAA/"))
                                ////    {
                                ////        billtype = "IAMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/O/MAA/"))
                                ////    {
                                ////        billtype = "IAOMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("AIRWHS/"))
                                ////    {
                                ////        billtype = "AWHS";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/DN/MAA/"))
                                ////    {
                                ////        billtype = "EADNMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/AC/MAA/"))
                                ////    {
                                ////        billtype = "IACMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/DN/MAA/"))
                                ////    {
                                ////        billtype = "IADNMAA";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/CN/MAA/"))
                                ////    {
                                ////        billtype = "IACNMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/MAA/"))
                                ////    {
                                ////        billtype = "ESMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/O/MAA/"))
                                ////    {
                                ////        billtype = "ESOMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/DN/MAA/"))
                                ////    {
                                ////        billtype = "ESDNMAA";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/MAA/"))
                                ////    {
                                ////        billtype = "ISMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/O/MAA/"))
                                ////    {
                                ////        billtype = "ISOMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/DN/MAA/"))
                                ////    {
                                ////        billtype = "ISDNMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/CN/MAA/"))
                                ////    {
                                ////        billtype = "ISCNMAA";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/AC/MAA/"))
                                ////    {
                                ////        billtype = "IAACMAA";
                                ////    }

                                ////    #endregion MAA

                                ////    #region COK
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/COK/"))
                                ////    {
                                ////        billtype = "IACOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/COK/"))
                                ////    {
                                ////        billtype = "EACOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/O/COK/"))
                                ////    {
                                ////        billtype = "EAOCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/AC/O/COK/"))
                                ////    {
                                ////        billtype = "EACOCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/COK/"))
                                ////    {
                                ////        billtype = "IACOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/O/COK/"))
                                ////    {
                                ////        billtype = "IAOCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("AIRWHS/"))
                                ////    {
                                ////        billtype = "AWHS";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("EXP/A/DN/COK/"))
                                ////    {
                                ////        billtype = "EADNCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/AC/COK/"))
                                ////    {
                                ////        billtype = "IACCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/DN/COK/"))
                                ////    {
                                ////        billtype = "IADNCOK";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/CN/COK/"))
                                ////    {
                                ////        billtype = "IACNCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/COK/"))
                                ////    {
                                ////        billtype = "ESCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/O/COK/"))
                                ////    {
                                ////        billtype = "ESOCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("EXP/S/DN/COK/"))
                                ////    {
                                ////        billtype = "ESDNCOK";
                                ////    }

                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/COK/"))
                                ////    {
                                ////        billtype = "ISCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/O/COK/"))
                                ////    {
                                ////        billtype = "ISOCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/DN/COK/"))
                                ////    {
                                ////        billtype = "ISDNCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/S/CN/COK/"))
                                ////    {
                                ////        billtype = "ISCNCOK";
                                ////    }
                                ////    else if (dr["bill_type"].ToString().Contains("IMP/A/AC/COK/"))
                                ////    {
                                ////        billtype = "IAACCOK";
                                ////    }

                                ////    #endregion COK
                                ////    InvNo = billtype + y + yy + "NT" + dtInvNo.Rows[0]["InvoiceNoByCompany"].ToString();
                                ////    if (Convert.ToDateTime(dr["bill_Date"].ToString()) > Convert.ToDateTime("03/31/2018 12:00:00 AM") && (dr["Curr_Code"].ToString() != "INR"))
                                ////    {
                                ////        InvNo = billtype + y + yy + "NTE" + dtInvNo.Rows[0]["InvoiceNoByCompany"].ToString();
                                ////    }
                                ////}
                            }


                            InvDate = DateTime.Parse(dr["bill_date"].ToString()).ToString("MMM dd yyyy");
                            STaxRate = comBusins.GetList("STaxRate", "TotalSTaxRate", "FromDate<='" +  InvDate + "' and ToDate>='" + InvDate + "'").Rows[0][0].ToString();
                            InvDueDate = DateTime.Parse(dr["inv_due_date"].ToString()).ToString("MMM dd yyyy");
                            BankName = dr["BankName"].ToString();
                            BankAddress = dr["BankAdd"].ToString();
                            AccountNo = dr["AccountNo"].ToString();
                            IFSCCode = dr["IFSCCode"].ToString();
                            SwiftCode = dr["SwiftCode"].ToString();
                            ReferenceNo = dr["ReferenceNo"].ToString();
                            panno = dsCompName.Tables[0].Rows[0]["PanNo"].ToString();
                            serviceregno = DateTime.Parse(dr["bill_date"].ToString()) > DateTime.Parse("Sep 28 2010") ? dsCompName.Tables[0].Rows[0]["STaxNo"].ToString().Split(',').Length > 1 ? dsCompName.Tables[0].Rows[0]["STaxNo"].ToString().Split(',')[1] : dsCompName.Tables[0].Rows[0]["STaxNo"].ToString().Split(',')[0] : dsCompName.Tables[0].Rows[0]["STaxNo"].ToString();
                            awbNo = dr["mawb_no"].ToString();
                            if (dr["mawb_date"].ToString() == "" || dr["mawb_date"].ToString() == "1/1/9999 12:00:00 AM")
                            {
                                AwbDate = "";
                            }

                            else
                            {
                                AwbDate = (dr["mawb_date"].ToString() == "1/1/9999 12:00:00 AM" ? "" : "Dated " + DateTime.Parse(dr["mawb_date"].ToString()).ToString("MMM dd yyyy"));

                            }
                            HawbNo = dr["hawb_no"].ToString();
                            Consignee = dr["consignee"].ToString();
                            Packages = dr["pkgs"].ToString();
                            Shipper = dr["shipper"].ToString();
                            //Weight = dr["gross_wt"].ToString();
                            Weight = dr["chargeable_wt"].ToString();
                            Origin = dr["origin"].ToString();
                            //FlightNo = dr[""].ToString();
                            //FlightDate = dr[""].ToString();
                            Airline = dr["airline"].ToString();
                            Commodity = dr["commodity"].ToString();
                            FreightType = dr["freight_type"].ToString();
                            Currency = dr["curr_code"].ToString();
                            exchange_rate = decimal.Parse(dr["exchange_rate"].ToString());

                            FlightNo = dr["req_flno"].ToString();
                            FlightDate = (dr["req_fldt"].ToString() == "1/1/9999 12:00:00 AM" ? "" : DateTime.Parse(dr["req_fldt"].ToString()).ToString("MMM dd yyyy"));
                            IGMNo = dr["igm_no"].ToString();
                            IGMDate = dr["igm_dt"].ToString();


                        }
                        string html = "";
                        if (type == "p" && invoice.ToUpper() == "N")
                            html = @"<table  width=""95%"" border=""0"" cellspacing=""2""> <tr><td colspan=""2"" align=""center"">" + headerhtml + @"</td></tr><tr> <td colspan=""3""><font size=""2"">Dear Sir/Madam,<br>" + MainText + @"<Br>" + PrintableNote + @"</font> <BR>" + BROMsg + @"</td>	</tr>";

                        if (type == "p" && invoice.ToUpper() == "Y")
                            html = @"<table width=""95%"" border=""0"" cellspacing=""2""> <tr><td colspan=""2"" align=""center"">" + headerhtml + "<Br>" + PrintableNote + @"</td></tr>";

                        if (type == "l" && invoice.ToUpper() == "N")
                            html = @"<table width=""95%"" border=""0"" cellspacing=""2""> <tr><td colspan=""2"" align=""center""><br><B>CARGO ARRIVAL NOTICE CUM INVOICE</b><br> <br><br><br></td></tr><tr> <td colspan=""3""><font size=""2"">Dear Sir/Madam,<br>" + MainText + @"<Br>" + PrintableNote + @"</font><BR>" + BROMsg + @" </td>	</tr>";

                        if (type == "l" && invoice.ToUpper() == "Y")

                            html = @"<table width=""95%"" border=""0"" cellspacing=""2""> <tr><td colspan=""2"" align=""center""> <br><B>TAX INVOICE</b><br> <br><br></td></tr>";



                        html += @"<tr><td colspan=""4"" style=""border-top-style:ridge""></td></tr>";
                        string[] CompNameNew = Session["CompName"].ToString().Split('-');
                        if (CompNameNew[0].ToString() == "THREE SIXTY LOGISTICS PVT. LTD.")
                        {
                            html += @" <tr><td><font size=""2""><b><I>Payment to be made in favour of THREE SIXTY LOGISTICS PVT. LTD.</I></B></td></tr>";
                        }

                        #region Agent GST No
                        DataTable dtAgentGstNo1 = new DataTable();
                        string AgentgstNoStateCode1 = "";
                        DataTable AgentGstNo1 = dw.GetAllFromQuery("select GstNo from billing_master where sno=" + sno + "");
                        if (AgentGstNo1 != null && AgentGstNo1.Rows.Count > 0)
                        {
                            AgentgstNoStateCode1 = AgentGstNo1.Rows[0]["GstNo"].ToString();
                            if (AgentgstNoStateCode1 == null || AgentgstNoStateCode1 == "")
                            {
                                /////dtAgentGstNo1 = dw.GetAllFromQuery("select GstNo from CustomerBranch where compbrsno=" + Session["CompBrSNo"].ToString() + " and sno=" + Invto_Code + "");
                                dtAgentGstNo1 = dw.GetAllFromQuery("select GstNo from AgentGstNo where compbrsno=" + Session["CompBrSNo"].ToString() + " and AgentName like '" + Invto_Name + "%'");
                                if (dtAgentGstNo1.Rows.Count > 0)
                                {
                                    AgentgstNoStateCode1 = dtAgentGstNo1.Rows[0]["GstNo"].ToString();
                                }
                                else
                                {
                                    AgentgstNoStateCode1 = "08";
                                }
                            }
                            else
                            {
                                AgentgstNoStateCode1 = AgentGstNo1.Rows[0]["GstNo"].ToString();
                            }
                        }
                        else
                        {
                            if (AgentgstNoStateCode1 == null || AgentgstNoStateCode1 == "")
                            {

                                ////dtAgentGstNo1 = dw.GetAllFromQuery("select GstNo from CustomerBranch where compbrsno=" + Session["CompBrSNo"].ToString() + " and sno=" + Invto_Code + "");
                                dtAgentGstNo1 = dw.GetAllFromQuery("select GstNo from AgentGstNo where compbrsno=" + Session["CompBrSNo"].ToString() + " and AgentName like '" + Invto_Name + "%'");

                                if (dtAgentGstNo1.Rows.Count > 0)
                                {
                                    AgentgstNoStateCode1 = dtAgentGstNo1.Rows[0]["GstNo"].ToString();
                                }
                                else
                                {
                                    AgentgstNoStateCode1 = "08";
                                }
                            }

                        }

                        string AgentStateCode = "DELHI";
                        DataTable GstStateCode = dw.GetAllFromQuery("Select State from GstStateCode where stateCode='" + AgentgstNoStateCode1.Substring(0, 2) + "'");
                        if (GstStateCode.Rows.Count > 0)
                        {
                            if (GstStateCode.Rows[0]["State"].ToString() != "" || GstStateCode.Rows[0]["State"].ToString() != null)
                                AgentStateCode = GstStateCode.Rows[0]["State"].ToString();
                        }

                        #endregion End of Agent GstNo
 html += @" <tr>
	 <td width=""60%""><font size=""2""><b>" + InvoiceToname + @"</b><br>" + address + @"</b><br/>GST No: " + AgentgstNoStateCode1 + @"<br/>Place of Supply: " + AgentStateCode + @"</td>
	 <td valign=""top"">
	    <table width=""100%"">
		  <tr>
			  <td>&nbsp;</td>
	          <td>IMPORT</td> 
		  </tr>
		  <tr>
			  <td>Bill of Supply No.</td>
	           <td><font size=""2""><b>" + InvNo.ToUpper() + @"</b></font></td> 
			  
		  </tr>
		  <tr>
			  <td>Bill of Supply Date.</td>
	          <td>" + InvDate + @"</td> 
		  </tr>
		  <tr>
			  <td>Due Date.</td>
	          <td>" + InvDueDate + @"</td> 
		  </tr>
		</table>
	 </td>
	</tr>";
                        html += @"<tr><td colspan=""3"" style=""border-top-style:ridge""></td></tr>";

                        html += @"<tr>
	  <td colspan=""2"">
	     <table width=""100%"">
		    <tr>
			  <td width=""20%"">AWB Number </td>
			  <td width=""40%"">" + awbNo + @"  " + AwbDate + @"</td>
			  <td width=""20%"">HAWB Number</td>
			  <td width=""20%"">" + HawbNo + @"</td>
			</tr>
		    <tr>
			  <td>Consignee</td>
			  <td>" + Consignee + @"</td>
			  <td>Packages/Weight</td>
			  <td>" + Packages + @"/ " + Weight + @"</td>
			</tr>
            <tr>
                <td>Shipper</td>
                <td colspan=""3"">" + Shipper + @"</td>
            </tr>
		    <tr>
			  <td>Origin</td>
			  <td>" + Origin + @"</td>
			  <td>Destination</td>
			  <td>" + destination + @"</td>
			</tr>
		    <tr>
			  <td>Flight No.</td>
			  <td>" + FlightNo + @"</td>
			  <td>Flight Dt.</td>
			  <td>" + FlightDate + @"</td>
			</tr>

		    <tr>
   
			  <td>Airline</td>
			  <td>" + Airline + @"</td>
   
			  <td>Commodity</td>
			  <td>" + Commodity + @"</td>
   		  
			</tr>
			
<tr>
   
			  <td>IGMNo</td>
			  <td>" + IGMNo + @"</td>
   
			  <td>IGM date</td>
			  <td>" + IGMDate + @"</td>
   		  
			</tr>
		    <tr>
	
			  <td>Freight Type</td>
			  <td>" + FreightType + @"</td>";
                        if (Convert.ToInt32(Session["CompBrSno"]).ToString() == "12")
                        {

                            html += @"<td>Reference No</td><td>" + ReferenceNo + @"</td>";
                        }
                        html += @"</tr> </table></td></tr>";

                        //Data get from imports_billing_Trnas.
                        SqlDataReader trDr = SNo.Length > 1 ? SNo[1] == "PerformaInvoice" ? BC.ImportsPerformaInvoiceTransShow(int.Parse(MasterSno)) : BC.Show_billing_tran_NoNTaxable(int.Parse(MasterSno)) : BC.Show_billing_tran_NoNTaxable(int.Parse(MasterSno));
                        if (trDr.HasRows)
                        {
                            html += @"<tr>
	  <td colspan=""2""  valign=""top"">
		<table width=""100%"" >
			<tr>
			<td  valign=""top"" colspan=""5""  cellpadding=""0"" cellspacing=""0"">
			<table width=""100%"" cellpadding=""2"" cellspacing=""0"" border=""0"">
				<tr><td colspan=""6"" height=""1"" style=""border-top-style:ridge""></td> </tr>
				<tr>
					<td width=""30%"" valign=""top""><b>Particulars</b></td>
                    <td width=""30%"" valign=""top""><b>HSN Code</b></td>
					<td width=""40%"" valign=""top""><b>Description</b></td>
					<td width=""15%"" valign=""top"" align=""right"" nowrap><b>Non-Taxable</b></td>
					<td width=""1%"">&nbsp;</td>
					<td valign=""top"" align=""right""><b>&nbsp;</b></td>
				</tr>
				<tr><td colspan=""6"" height=""1"" style=""border-top-style:ridge""></td> </tr>";
                            totTaxAmt = 0;
                            totNontaxAmt = 0;
                            taxAmt = 0;
                            decimal amount = 0;
                            while (trDr.Read())
                            {

                                if (trDr["taxable"].ToString().ToUpper() == "N")
                                {
                                    DataTable dtHSNoCode = dw.GetAllFromQuery("Select top 1 HSNCode from Charges where HeadName='" + trDr["headname"].ToString() + "' and HSNCode is not null");
                                    if (dtHSNoCode.Rows.Count > 0 && dtHSNoCode != null)
                                    {
                                        HSNCode = dtHSNoCode.Rows[0]["HSNCode"].ToString();
                                    }
                                    html += @"<tr>
                                    					<td>" + trDr["headname"].ToString() + @"</td>
                                                        <td>" + HSNCode + @"</td>
                                    					<td>" + trDr["description"].ToString() + @"</td>";
                                }
                                else
                                {
////                                    html += @"<tr>
////					<td>" + trDr["headname"].ToString() + @"</td>
////					<td>" + trDr["description"].ToString() + @"</td>";
                                }
                                if (trDr["taxable"].ToString().ToUpper() == "N")
                                {
                                    amount = decimal.Parse(trDr["amount"].ToString()) / exchange_rate;
                                    amount = Math.Round(amount, 2, MidpointRounding.AwayFromZero);
                                    html += @"<td valign=""top"" align=""right"">" + amount + @"</td><td width=""1%"">&nbsp;</td><td valign=""top"" align=""right"" nowrap>&nbsp;</td> </tr>";
                                    totNontaxAmt += decimal.Parse(trDr["amount"].ToString()) / exchange_rate;
                                    totNontaxAmt = Math.Round(totNontaxAmt, 2, MidpointRounding.AwayFromZero);
                                }
                                else
                                {
                                    amount = decimal.Parse(trDr["amount"].ToString()) / exchange_rate;
                                    amount = Math.Round(amount, 2, MidpointRounding.AwayFromZero);
                                    ////html += @"<td valign=""top"" align=""right"">&nbsp;</td><td width=""1%"">&nbsp;</td><td valign=""top"" align=""right"" nowrap>" + amount + @"</td> </tr>";
                                    totTaxAmt += decimal.Parse(trDr["amount"].ToString()) / exchange_rate;
                                    // totTaxAmt += Convert.ToDecimal(trDr["tot_sTax_Amt"].ToString());
                                    totTaxAmt = Math.Round(totTaxAmt, 2, MidpointRounding.AwayFromZero);
                                      //==============Pradeep========================
                                    taxAmt += Convert.ToDecimal(trDr["stax_amt"].ToString()) / exchange_rate;
                                    if (DateTime.Parse(InvDate) > DateTime.Parse("Nov 15 2015") && DateTime.Parse(InvDate) < DateTime.Parse("Jul 01 2017"))
                                    {
                                        //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************

                                        ////***********Commented on 02 Aug 2016 : SbCess and KK Cess picked from Billing_Tran ************************

                                          ////SbCesstaxAmt +=amount  *Convert.ToDecimal(SBCessTaxRate) / 100;
                                          ////KKCesstaxAmt += amount * Convert.ToDecimal(KKCessTaxRate) / 100;

                                        ////***********Commented on 02 Aug 2016 : SbCess and KK Cess picked from Billing_Tran ************************

                                        #region Gst Applicable

                                        SBCessTaxRate = comBusins.GetList("STaxRate", "SBCessTax", "FromDate<='" + InvDate + "' and ToDate>='" + InvDate + "'").Rows[0][0].ToString();
                                        SbCesstaxAmt = SbCesstaxAmt + Convert.ToDecimal(trDr["sbcessTaxAmt"].ToString()) / exchange_rate;

                                        KKCessTaxRate = comBusins.GetList("STaxRate", "KKCessTax", "FromDate<='" + InvDate + "' and ToDate>='" + InvDate + "'").Rows[0][0].ToString();
                                        KKCesstaxAmt = KKCesstaxAmt + Convert.ToDecimal(trDr["KKCesstaxAmt"].ToString()) / exchange_rate;

                                        #endregion End of Gst Applicable
                                        //////SbCesstaxAmt += decimal.Parse(trDr["sbcessTaxAmt"].ToString()) / exchange_rate;
                                        //////KKCesstaxAmt += decimal.Parse(trDr["kkcessTaxAmt"].ToString()) / exchange_rate;

                                          //SBCessTaxRate = "0.00";
                                          //SbCesstaxAmt = 0;
                                    }
                                    else if (DateTime.Parse(InvDate) >= DateTime.Parse("Jul 01 2017"))
                                    {

                                        #region Gst State Code Appicable from 01 july 2017

                                        DataTable dtCompGstNo = dw.GetAllFromQuery("select GstNo from CompanyDetails where compbrno=" + Session["CompBrSNo"].ToString() + "");
                                        string CompGstno = "07"; //delhi state code by default
                                        if (dtCompGstNo.Rows.Count > 0)
                                        {
                                            CompGstno = dtCompGstNo.Rows[0]["GstNo"].ToString();
                                        }

                                        ////string GstNo = ds.Tables[0].Rows[0]["GstNo"].ToString();
                                        ////string[] GstNoArray = Request.Form["ddlGstNo"].Split('-');
                                        //////string gstNoStateCode = ds.Tables[0].Rows[0]["service_tax_rate"].ToString().Substring(0, 2);

                                        // GST AgentGstNo picked from CustomerBranch or Billing_Master: both case applied below:
                                        DataTable dtAgentGstNo = new DataTable();
                                        string AgentgstNoStateCode = "";
                                        DataTable AgentGstNo = dw.GetAllFromQuery("select GstNo from billing_master where sno=" + sno + "");
                                        if (AgentGstNo != null && AgentGstNo.Rows.Count > 0)
                                        {
                                            AgentgstNoStateCode = AgentGstNo.Rows[0]["GstNo"].ToString();
                                            if (AgentgstNoStateCode == null || AgentgstNoStateCode == "")
                                            {
                                                /////dtAgentGstNo = dw.GetAllFromQuery("select GstNo from CustomerBranch where compbrsno=" + Session["CompBrSNo"].ToString() + " and sno=" + Invto_Code + "");
                                                dtAgentGstNo = dw.GetAllFromQuery("select GstNo from AgentGstNo where compbrsno=" + Session["CompBrSNo"].ToString() + " and AgentName like '" + Invto_Name + "%'");
                                                if (dtAgentGstNo.Rows.Count > 0)
                                                {
                                                    AgentgstNoStateCode = dtAgentGstNo.Rows[0]["GstNo"].ToString();
                                                }
                                                else
                                                {
                                                    AgentgstNoStateCode = "08";
                                                }
                                            }
                                            else
                                            {
                                                AgentgstNoStateCode = AgentGstNo.Rows[0]["GstNo"].ToString();
                                            }
                                        }
                                        else
                                        {
                                            if (AgentgstNoStateCode == null || AgentgstNoStateCode == "")
                                            {

                                                ////dtAgentGstNo = dw.GetAllFromQuery("select GstNo from CustomerBranch where compbrsno=" + Session["CompBrSNo"].ToString() + " and sno=" + Invto_Code + "");
                                                dtAgentGstNo = dw.GetAllFromQuery("select GstNo from AgentGstNo where compbrsno=" + Session["CompBrSNo"].ToString() + " and AgentName like '" + Invto_Name + "%'");
                                                if (dtAgentGstNo.Rows.Count > 0)
                                                {
                                                    AgentgstNoStateCode = dtAgentGstNo.Rows[0]["GstNo"].ToString();
                                                }
                                                else
                                                {
                                                    AgentgstNoStateCode = "08";
                                                }
                                            }

                                        }
                                        #endregion


                                        #region Gst Applicable
                                        if (AgentgstNoStateCode.Substring(0, 2) == CompGstno.Substring(0, 2))
                                        {
                                            CGSTTaxRate = comBusins.GetList("STaxRate", "TotalStaxRate", "FromDate<='" + InvDate + "' and ToDate>='" + InvDate + "'").Rows[0][0].ToString();

                                            /////taxAmt = totTaxAmt * decimal.Parse(ds.Tables[0].Rows[0]["service_tax_rate"].ToString()) / 100;

                                            taxAmt = totTaxAmt * decimal.Parse(CGSTTaxRate) / 100;


                                            SBCessTaxRate = comBusins.GetList("STaxRate", "SBCessTax", "FromDate<='" + InvDate + "' and ToDate>='" + InvDate + "'").Rows[0][0].ToString();
                                            SbCesstaxAmt = SbCesstaxAmt + Convert.ToDecimal(trDr["sbcessTaxAmt"].ToString()) / exchange_rate;

                                            ////KKCessTaxRate = comBusins.GetList("STaxRate", "KKCessTax", "FromDate<='" + InvDate + "' and ToDate>='" + InvDate + "'").Rows[0][0].ToString();
                                            ////KKCesstaxAmt = KKCesstaxAmt + Convert.ToDecimal(trDr["KKCesstaxAmt"].ToString()) / exchange_rate;

                                            KKCessTaxRate = "0.00";
                                            KKCesstaxAmt = 0;

                                        #endregion End of Gst Applicable
                                        }
                                        else
                                        {
                                            CGSTTaxRate = comBusins.GetList("STaxRate", "TotalStaxRate", "FromDate<='" + InvDate + "' and ToDate>='" + InvDate + "'").Rows[0][0].ToString();

                                            /////taxAmt = totTaxAmt * decimal.Parse(ds.Tables[0].Rows[0]["service_tax_rate"].ToString()) / 100;

                                            taxAmt = 0;


                                            SBCessTaxRate = "0.00";
                                            SbCesstaxAmt = 0;

                                            KKCessTaxRate = comBusins.GetList("STaxRate", "KKCessTax", "FromDate<='" + InvDate + "' and ToDate>='" + InvDate + "'").Rows[0][0].ToString();
                                            KKCesstaxAmt = KKCesstaxAmt + Convert.ToDecimal(trDr["KKCesstaxAmt"].ToString()) / exchange_rate;

                                        }
                                    }
                                    else
                                    {

                                          taxAmt = Math.Round(taxAmt, 2, MidpointRounding.AwayFromZero);
                                    }

                                }
                            }
                            decimal Gtot = 0;

                            //********************updated on 27 Oct 2016 on Diwaker Request INR should be RoundUp exp: 0.01 is 1 and Non-INR 0.01111 is 0.01 *************//
                            decimal sbcamt = 0;
                            decimal kkcamt = 0;
                            if (Currency == "INR")
                            {
                                sbcamt = Math.Ceiling(totTaxAmt * Convert.ToDecimal(SBCessTaxRate) / 100);
                                kkcamt = Math.Ceiling(totTaxAmt * Convert.ToDecimal(KKCessTaxRate) / 100);
                            }
                            else
                            {
                                sbcamt = decimal.Round((totTaxAmt * Convert.ToDecimal(SBCessTaxRate) / 100), 2);
                                kkcamt = decimal.Round((totTaxAmt * Convert.ToDecimal(KKCessTaxRate) / 100), 2);
                            }

                            //********************End of updated on 27 Oct 2016 on Diwaker Request INR should be RoundUp exp: 0.01 is 1 and Non-INR 0.01111 is 0.01 *************//

                            //Gtot = Math.Round(Gtot, MidpointRounding.AwayFromZero);
                            decimal netAmount = Convert.ToDecimal(totTaxAmt) + Convert.ToDecimal(taxAmt);
                            netAmount = Math.Round(netAmount, 2, MidpointRounding.AwayFromZero);
                            taxAmt = decimal.Round(taxAmt, 2);
                            taxAmt = Math.Round(taxAmt, 2, MidpointRounding.AwayFromZero);
                            //****************Updated On 03 May2016: KKCess tax Apply in Pace Power system*****************
                            SbCesstaxAmt = decimal.Round(SbCesstaxAmt, 2);
                            KKCesstaxAmt = decimal.Round(KKCesstaxAmt, 2);
                            ////***********Commented on 02 Aug 2016 : SbCess and KK Cess picked from Billing_Tran ************************
                            ////SbCesstaxAmt = Math.Round(SbCesstaxAmt, 2, MidpointRounding.AwayFromZero);
                            ////KKCesstaxAmt = Math.Round(KKCesstaxAmt, 2, MidpointRounding.AwayFromZero);
                            ////***********End of Commented on 02 Aug 2016 : SbCess and KK Cess picked from Billing_Tran ************************


                            //********************updated on 27 Oct 2016 on Diwaker Request INR should be RoundUp
                            /////Gtot = Convert.ToDecimal(totTaxAmt) + Convert.ToDecimal(taxAmt) + Convert.ToDecimal(totNontaxAmt) + SbCesstaxAmt + KKCesstaxAmt;
                            Gtot = Convert.ToDecimal(totTaxAmt) + Convert.ToDecimal(taxAmt) + Convert.ToDecimal(totNontaxAmt) + sbcamt + kkcamt;
                            //********************End of updated on 27 Oct 2016 on Diwaker Request INR should be RoundUp
                            if (Currency == "INR")
                            {
                                Gtot = Math.Round(Gtot, MidpointRounding.AwayFromZero);
                            }
                            //else
                            //{
                            //    Gtot = Gtot / exchange_rate;


                            if (DateTime.Parse(InvDate) < DateTime.Parse("Jul 01 2017"))
                            {

                                html += @"<tr><td colspan=""6"" style=""border-top-style:ridge""></td></tr>
				<tr>
				<td>&nbsp;</td>
				<td align=""right""><b>Total:</td>
<td>&nbsp;</td>
				<td align=""right"">" + totNontaxAmt + @"</td>
				<td width=""1%"">&nbsp;</td>
				<td align=""right"">&nbsp;</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td align=""right"">&nbsp;</td>
                <td align=""right"">&nbsp;</td>
                <td width=""1%"">&nbsp;</td>
                <td align=""right"">&nbsp;</td>
                </tr>	";
                                if (DateTime.Parse(InvDate) > DateTime.Parse("Nov 15 2015"))
                                {
                                    html += @"
<tr>
				<td>&nbsp;</td>
				<td align=""right"">&nbsp;</td>

                <td align=""right"">&nbsp;</td>
                <td width=""1%"">&nbsp;</td>
                <td align=""right"">&nbsp;</td>

                </tr>";
                                }
                                if (DateTime.Parse(InvDate) >= DateTime.Parse("Jun 01 2016"))
                                {
                                    html += @"
<tr>
				<td>&nbsp;</td>
				<td align=""right"">&nbsp;</td>

                <td align=""right"">&nbsp;</td>
                <td width=""1%"">&nbsp;</td>
                <td align=""right"">&nbsp;</td>

                </tr>";
                                }
                                //                              else
                                //                              {
                                //                                  html += @"
                                //<tr>
                                //				<td>&nbsp;</td>
                                //				<td align=""right"">KK Cess Tax @ " + KKCessTaxRate + @"%:</td>
                                //
                                //                <td align=""right"">&nbsp;</td>
                                //                <td width=""1%"">&nbsp;</td>
                                //                <td align=""right"">" + KKCesstaxAmt + @"</td>
                                //
                                //                </tr>";
                                //                              }

                                html += @" <tr>
                <td>&nbsp;</td>
                <td align=""right""><b>Net Amount:</b></td>
<td>&nbsp;</td>
                <td align=""right"">" + Math.Round(totNontaxAmt, 2, MidpointRounding.AwayFromZero) + @"</td>


                <td width=""1%"">&nbsp;</td>

	
                <td align=""right"">&nbsp;</td>
                </tr>
                <tr><td colspan=""6"" style=""border-top-style:ridge""></td></tr>
                <tr>
                <td>&nbsp;</td>
                <td align=""right"" valign=""top""><font size=""2"">Total Amount Due: <b>" + Currency + @"</b></font></td><td>&nbsp;</td>";
               
                                if (Currency == "INR")
                                    html += @"<td colspan=""2"" align=""right""><img src=""../Images/Newrupee-symbol.jpg"" style=""height:14px""/>&nbsp;&nbsp;<font size=""2""><b>" + Gtot.ToString("f2") + @"</b></font></td>";
                                else
                                    html += @"<td colspan=""2"" align=""right""><font size=""2""><b>" + Gtot.ToString("f2") + @"</b></font></td><td width=""1%"">&nbsp;</td>";
                                html += @"</tr>			
				
             </table>  	
             </td>
            </tr> 	
         </table> 
      </td>
    </tr><tr>";
                            }
                            else
                            {
                                #region Gst Applicable
                                html += @"<tr><td colspan=""6"" style=""border-top-style:ridge""></td></tr>
				<tr>
				<td>&nbsp;</td>
				<td align=""right""><b>Total:</td>
<td>&nbsp;</td>
				<td align=""right"">" + totNontaxAmt + @"</td>
				<td width=""1%"">&nbsp;</td>
				<td align=""right"">&nbsp;</td>
				</tr>
				<tr>
				<td>&nbsp;</td>
				<td align=""right"">&nbsp;</td>
                <td align=""right"">&nbsp;</td>
                <td width=""1%"">&nbsp;</td>
                <td align=""right"">&nbsp;</td>
                </tr>	";
                                if (DateTime.Parse(InvDate) > DateTime.Parse("Nov 15 2015"))
                                {
                                    html += @"
<tr>
				<td>&nbsp;</td>
				<td align=""right"">&nbsp;</td>

                <td align=""right"">&nbsp;</td>
                <td width=""1%"">&nbsp;</td>
                <td align=""right"">&nbsp;</td>

                </tr>";
                                }
                                if (DateTime.Parse(InvDate) >= DateTime.Parse("Jun 01 2016"))
                                {
                                    html += @"
<tr>
				<td>&nbsp;</td>
				<td align=""right"">&nbsp;</td>

                <td align=""right"">&nbsp;</td>
                <td width=""1%"">&nbsp;</td>
                <td align=""right"">&nbsp;</td>

                </tr>";
                                }
                                //                              else
                                //                              {
                                //                                  html += @"
                                //<tr>
                                //				<td>&nbsp;</td>
                                //				<td align=""right"">KK Cess Tax @ " + KKCessTaxRate + @"%:</td>
                                //
                                //                <td align=""right"">&nbsp;</td>
                                //                <td width=""1%"">&nbsp;</td>
                                //                <td align=""right"">" + KKCesstaxAmt + @"</td>
                                //
                                //                </tr>";
                                //                              }

                                html += @" <tr>
                <td>&nbsp;</td>
                <td align=""right""><b>Net Amount:</b></td>
<td>&nbsp;</td>

                <td align=""right"">" + Math.Round(totNontaxAmt, 2, MidpointRounding.AwayFromZero) + @"</td>


                <td width=""1%"">&nbsp;</td>

	
                <td align=""right"">&nbsp;</td>
                </tr>
                <tr><td colspan=""6"" style=""border-top-style:ridge""></td></tr>
                <tr>
                <td>&nbsp;</td>
                <td align=""right"" valign=""top""><font size=""2"">Total Amount Due: <b>" + Currency + @"</b></font></td><td>&nbsp;</td>";
               
                                if (Currency == "INR")
                                    html += @"<td colspan=""2"" align=""right""><img src=""../Images/Newrupee-symbol.jpg"" style=""height:14px""/>&nbsp;&nbsp;<font size=""2""><b>" + Gtot.ToString("f2") + @"</b></font></td>";
                                else
                                    html += @"<td colspan=""2"" align=""right""><font size=""2""><b>" + Gtot.ToString("f2") + @"</b></font></td>";
                                html += @"<td align=""right"">&nbsp;</td></tr>			
				
             </table>  	
             </td>
            </tr> 	
         </table> 
      </td>
    </tr><tr>";
                                #endregion
                            }

                            HiddenField1.Value = (Math.Round(totNontaxAmt, 2, MidpointRounding.AwayFromZero) + Convert.ToDecimal(totTaxAmt) + Convert.ToDecimal(taxAmt)).ToString();

                            // string aa=Convert.ToString(Math.Round(Gtot,MidpointRounding.AwayFromZero));

                            string FinalWord = "";



                            if (Gtot.ToString().Contains("."))
                            {
                                string[] preDecimal = (Math.Round(totNontaxAmt, 2, MidpointRounding.AwayFromZero) + Convert.ToDecimal(totTaxAmt) + Convert.ToDecimal(taxAmt)).ToString().Split('.');
                                double pre = Convert.ToDouble(preDecimal[0]);
                                string preWord = PaceCommon.changeNumericToWords(pre);
                                try
                                {
                                    double post = Convert.ToDouble(preDecimal[1]);
                                    string postWord = PaceCommon.changeNumericToWords(post);
                                    FinalWord = preWord + " Point " + postWord;
                                }
                                catch
                                {
                                    FinalWord = preWord;
                                }
                            }
                            else
                            {
                                FinalWord = PaceCommon.changeNumericToWords(Convert.ToDouble(Gtot.ToString()));
                            }
                            FinalWord = FinalWord.ToUpper().Contains("ONLY") ? FinalWord : FinalWord + " Only.";

                            string[] CompName1 = Session["CompName"].ToString().Split('-');
                            DataSet drUserName = bReport.getLogindetailNew(Session["UserId"].ToString());

                            if (Convert.ToInt32(Session["CompBrSno"]).ToString() == "25")
                            {
                                html += @"<td colspan==""2""><font size==""2""><B><U>NOTE FOR PERSONAL EFFECT BASIS SHPT:</U></B></td></tr>
<tr>
<td >1. Delivery order will be issued strictly against payment of above charges vide DD or Cash only.</td></tr>
<tr><td >2. Consignee must carry Original Passport while collecting the delivery order for verification and clearance purpose.</td></tr>
<tr><td >3. All custom clearance & transportation charges, apart from above, will be on consignee's account.</td></tr>
<tr><td >4. Please contact us on the given no's for any kind of assistance or inquiry.</td></tr>
<tr><td >A. Mr. Gaurav Mehta  <B># 09873352693</B></td></tr>
<tr><td >B. Ms. Neelam Sharma <B># 07838089413</B></td></tr>";
                            }

////////////////////////////////////////////////By Mayank(12 Feb 2013)///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                html += @"<td colspan=""2""><font size=""2""><B>TOTAL(Words) :" + FinalWord +@"</B></td></tr><tr><td colspan=""2"">
//              A delivery order will be issued to you on production of this notice duly endorsed by the bank wherever applicable  on payment of our charges, as indicated above,along with the BANK RELEASE ORDER  wherever applicable between 0900 hours and 1700 hours on working days.
//<tr><td style='font-size:12px'><b>BANK DETAILS:-</b></td></tr><tr><td>
//<table><tr><td><b>Name:</b></td><td>" + BankName + @"</td></tr>
//<tr><td><b>A/C No:</b></td><td>" + AccountNo + @"</td></tr>
//<tr><td><b>Address:</b></td><td>" + BankAddress + @"</td></tr>
//<tr><td><b>IFSC Code:</b></td><td>" + IFSCCode + @"</td></tr></table></td></tr>
//<tr><td><b>Payment Terms:-</b> Only DD & Cash Accepted.</td></tr>";

//                                if (CompName1[0].ToString() == "RED LOGISTICS LTD.")
//                                {
//                                    html += @"<tr><td>Payment to be made in favour of <b>RED LOGISTICS LTD.</b></td></tr>
//<tr><td><b>Service Tax Reg No:</b> AAECR3272LSTDO1</td></tr><tr><td><b>PAN No.</b> AAECR3272L</td></tr><tr><td>All disputes are subject to New Delhi Jurisdiction only.</td></tr></td></tr><tr><td valign='top' colspan='2' align='right'><br><b><font size=""2"">For " + CompanyName[0] + @"<br><br><br><br><font size=""2"">" + "" + @"<br><font size=""1"">Authorised Signatory</td></tr></table>";
//                                }
//                                else if (CompName1[0].ToString() == "THREE SIXTY LOGISTICS PVT. LTD.")
//                                {
//                                    html += @"<tr><td><b>Swift Code:</b>ABNAINBBDEL</td></tr>
//<tr><td>Payment to be made in favour of <b>THREE SIXTY LOGISTICS PVT. LTD.</b></td></tr>
//<tr><td><b>Service Tax Reg No:</b> AADCT2823LSD001</td></tr><tr><td><b>PAN No.</b> AADCT2823L.</td></tr><tr><td>All disputes are subject to New Delhi Jurisdiction only.</td></tr></td></tr><tr><td valign='top' colspan='2' align='right'><br><b><font size=""2"">For " + CompanyName[0] + @"<br><br><br><br><font size=""2"">" + "" + @"<br><font size=""1"">Authorised Signatory</td></tr></table>";
//                                }
//                                else
//                                {
//                                html += @"<tr><td><b>Service Tax Reg No :</b> "+ serviceregno + "</td></tr><tr><td><b>PAN No.:</b> AACCP7113Q</td></tr><tr><td>All disputes are subject to New Delhi Jurisdiction only.</td></tr></td></tr><tr><td valign='top' colspan='2' align='right'><br><b><font size='2'>For " + CompanyName[0] + @"<br><br><font size=""2"">" + "" + @"<br><font size=""1"">Authorised Signatory </td> </tr></table>";
//                                }
//////////////////////////////////////////////////////////Mayank END/////////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (CompName1[0].ToString() == "RED LOGISTICS LTD.")
                            {
                                html += @"<tr><td  style=""font-size:8px""><B>TOTAL(Words) :" + Currency + "  " + FinalWord +
                @"</B></td>
</tr>
            <tr>
            <td ><hr width=""2""/>
              A delivery order will be issued to you on production of this notice duly endorsed by the bank wherever applicable  on payment of our charges, as indicated above,along with the BANK RELEASE ORDER  wherever applicable between 0900 hours and 1700 hours on working days.
<tr><td style='font-size:12px'>
<b>BANK DETAILS:-</b></td></tr>
<tr><td>
<table><tr><td><b>Name:</b></td><td>" + BankName + @"</td></tr>
<tr><td><b>A/C No:</b></td><td>" + AccountNo + @"</td></tr>
<tr><td><b>Address:</b></td><td>" + BankAddress + @"</td></tr>
<tr><td><b>IFSC Code:</b></td><td>" + IFSCCode + @"</td></tr></table></td></tr>
<tr><td><b>Payment Terms:-</b>Only DD & Cash Accepted.</td></tr>
<tr><td>Payment to be made in favour of <b>RED LOGISTICS LTD.</b></font></td></tr>

<tr><td><b>PAN No.:</b> " + panno + @"</td></tr>.
<tr><td>All disputes are subject to New Delhi Jurisdiction only.</td></tr></table>
            </td>
            </tr>            
            <tr><td valign='top'  align='right'><br><b><font size=""2"">For " + CompanyName[0] + @"<br><br><br><br><font size=""2"">" + "" + @"
              
            <br><font size=""1"">Authorised Signatory</td> </tr>          
              </table>";

                            }
                            else if (CompName1[0].ToString() == "THREE SIXTY LOGISTICS PVT. LTD.")
                            {
                                html += @"<tr><td  style=""font-size:8px""><B>TOTAL(Words) :" + Currency + "  " + FinalWord +
                @"</B></td>
</tr>
            <tr>
            <td ><hr width=""2""/>
              A delivery order will be issued to you on production of this notice duly endorsed by the bank wherever applicable  on payment of our charges, as indicated above,along with the BANK RELEASE ORDER  wherever applicable between 0900 hours and 1700 hours on working days.
<tr><td style='font-size:12px'>
<b>BANK DETAILS:-</b></td></tr>
<tr><td>
<table><tr><td><b>Name:</b></td><td>" + BankName + @"</td></tr>
<tr><td><b>A/C No:</b></td><td>" + AccountNo + @"</td></tr>
<tr><td><b>Address:</b></td><td>" + BankAddress + @"</td></tr>
<tr><td><b>IFSC Code:</b></td><td>" + IFSCCode + @"</td></tr></table></td></tr>
<tr><td><b>Payment Terms:-</b> Only DD & Cash Accepted.</td></tr>
<tr><td>Payment to be made in favour of <b>THREE SIXTY LOGISTICS PVT. LTD.</b></td></tr>

<tr><td><b>PAN No.:</b> " + panno + @"</td></tr>.
<tr><td>All disputes are subject to New Delhi Jurisdiction only.</td></tr></table>
            </td>
            </tr>
            
            <tr>  <td valign='top'  align='right'><br><b><font size=""2"">For " + CompanyName[0] + @"<br><br><br><br><font size=""2"">" + "" + @"
              
            <font size=""1"">Authorised Signatory</td> </tr>          
              </table>";

                            }
                            else
                            {

                                html += @"<tr><td  style=""font-size:8px""><B>TOTAL(Words) :" + Currency + "  " + FinalWord +
                                 @"</B></td>
</tr>
            <tr>
            <td  width=""100%"" ><hr width=""2""/>
              A delivery order will be issued to you on production of this notice duly endorsed by the bank wherever applicable  on payment of our charges, as indicated above,along with the BANK RELEASE ORDER  wherever applicable between 0900 hours and 1700 hours on working days.
<tr><td style='font-size:12px'>
<b>BANK DETAILS:-</b></td></tr>
<tr><td>
<table><tr><td><b>Name:</b></td><td>" + BankName + @"</td></tr>
<tr><td><b>A/C No:</b></td><td>" + AccountNo + @"</td></tr>
<tr><td><b>Address:</b></td><td>" + BankAddress + @"</td></tr>";

                                if (CompanyName[0].ToString() == "Reliable Travels & Cargo Pvt Ltd")
                                {
                                    html += @"<tr><td><b>IFSC Code:</b></td><td>" + IFSCCode + @"</td></tr>";
                                    html += @"<tr><td><b>SWIFT Code:</b></td><td>" + SwiftCode + @"</td></tr></table></td></tr>";
                                }

                                else
                                {
                                    html += @"<tr><td><b>IFSC Code:</b></td><td>" + IFSCCode + @"</td></tr></table></td></tr>";
                                }
                                html += @"<tr><td><b>Payment Terms:-</b> Only DD & Cash Accepted.</td></tr><tr><td><b>PAN No.:</b> " + panno + @".</td></tr></table>
</font>
            </td>
            </tr>";
                                if (CompName1[0].ToString() == "Reliable Travels & Cargo Pvt Ltd")
                                {
                                    html += @"<tr>  <td valign='top'  style=""text-align='right'""><img src=""../Images/Reliable.jpg""></td> </tr>          
              </table>";
                                }
                                else if (CompName1[0].ToString() == "PACE EXPRESS TRAVELS & CARGO PVT. LTD.")
                                {
                                    html += @"<tr>  <td valign='top'  style=""text-align='right'""><img src=""../Images/pace.jpg""></td> </tr>          
              </table>";
                                }

                                else
                                {

                                    html += @"<tr>  <td valign='top'  style=""text-align='right'""><br><b><font size=""2"">For " + CompanyName[0] + @"<br><br><br><br><font size=""2"">" + "" + @"
              
           <font size=""1"">Authorised Signatory</td> </tr>          
              </table>";
                                    html2 += @"<table align=center><tr><td><b><font size=2>This is System Generated invoice, Signature and Stamp is not mandatory.</font></b></td></tr></table>";
                                }
                            }
                            html2 += html;

                        }// end while loop
                        //if (Request.QueryString["Email"].ToString() == "y")
                        //{
                        //    //Session["SNo"] = Request.QueryString[0].ToString();
                        //    Session["Email"] = lblCan.Text;
                        //    Response.Redirect("EmailInvoice.aspx?SNo=" + Sno + "&InvNo=" + InvNo);
                        //}

                    }//end  trDr read  if cond.

                    ///////html2 += @"<table align=center><tr><td><b><font size=2>This is System Generated invoice, Signature and Stamp is not mandatory.</font></b></td></tr></table>";
                    html2 += @"<p style='page-break-before:always'/>";
                }

                lblCan.Text = html2;
                //*************Start on 15 Dec 2016********************
                #region SendMail Pdf Code
                ////InvNoEmail = InvNo.ToString().Replace('/', '_');
                ////string path = Server.MapPath("./Email/" + InvNoEmail + ".pdf");
                //////string path = Server.MapPath("./Email/CAN"+SNo[i]+".pdf");
                ////string name = Path.GetFileName(path);

                ////if (File.Exists(path))
                ////{
                ////    File.Delete(path);
                ////}
                ////System.IO.StringReader sr = new StringReader(html2);
                //////System.IO.StringReader srCompany = new StringReader(CompanyName);
                ////iTextSharp.text.Document pdfDoc = new Document(iTextSharp.text.PageSize.A4, 25f, 25f, 0f, 0f);
                ////iTextSharp.text.html.simpleparser.HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                //////iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(Image);
                ////PdfWriter.GetInstance(pdfDoc, new FileStream(path, FileMode.Create));
                ////pdfDoc.Open();
                ////htmlparser.Parse(sr);
                ////pdfDoc.Close();
                
                ////MailMessage mm = new MailMessage("ddalal@cargoflash.com", "ddalal@cargoflash.com");
                ////// MailMessage mm = new MailMessage("jjayswal@cargoflash.com", "jjayswal@cargoflash.com");
                ////mm.Subject = "Invoice To Customer";
                ////mm.Body = "Dear Sir/Madam," + "<br/><br/>Please find attached INVOICE for payment in form of PDF.<br/><br/>Best Regards,<br/>Finance Department<br/>Reliable Cargo.";
                ////mm.Attachments.Add(new Attachment(path));
                //////mm.Attachments.Add(new Attachment(new MemoryStream(bytes), "Invoice.pdf"));
                ////mm.IsBodyHtml = true;
                ////SmtpClient smtp = new SmtpClient("mail.cargoflash.com");
                ////smtp.Credentials = new NetworkCredential("test@cargoflash.com", "Admin$567");
                ////smtp.Send(mm);

                #endregion sendMailCode
                //*************End on 15 Dec 2016********************
            }
        }
    }

}