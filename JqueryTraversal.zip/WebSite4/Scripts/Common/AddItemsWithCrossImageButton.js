﻿/* Common Javascript Description.
* Company              :   CargoFlash Infotech	Pvt. Ltd.
* Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
* Purpose              :   This class Comprise of Methods related to CrossList(In case of add new,update and Delete)
* Created By           :   Dhiraj Kumar.
* Created On           :   05 April 2010.
*/

//Method to add new data with cross list
//Added By:Dhiraj kumar
//Params:hiddenFeildID,textBoxId,labelID,linkbuttonClearID
function AddItemsWithCloseButtonImg(param) {
//    var param = document.getElementById(txtcustomerName).value + ',' + document.getElementById(hdnCustomerNameSNo).value + ',' + document.getElementById(lblADDCustomer).value + ',' + document.getElementById(lbnClearCustomer).value;
//    alert(param);
    var idArray = param.split(',');
    
    hdnValue = idArray[0];
    var textBoxID = idArray[1];
    var labelControlID = idArray[2];
    var lbnClear = idArray[3];
    var cities;
    document.getElementById(labelControlID).value = "";
    cities = document.getElementById(hdnValue).value;
    var codeToAdd = document.getElementById(textBoxID).value;

    if (codeToAdd == "")
        return;
    var flagCheck = "0";
    if (codeToAdd == 'ALL') {
        BindAllCode('Commodity', 'all');
        flagCheck = "1";
    }
    if (codeToAdd == 'DGR') {
        document.getElementById(hdnValue).value = "";
        BindAllCode('SPHC', 'DGR');
        flagCheck = "1";
    }
    if (codeToAdd == 'NDG') {
        document.getElementById(hdnValue).value = "";
        BindAllCode('SPHC', 'NDG');
        flagCheck = "1";
    }
    if (codeToAdd == 'Flight') {
        document.getElementById(hdnValue).value = "";
        BindAllCode('Flight', 'ALL');
        flagCheck = "1";
    }
    var checkExisting = new Array();

    checkExisting = document.getElementById(hdnValue).value.split(",");
    if (checkExisting.length == 1)
     {
        if (document.getElementById(hdnValue).value == "ALL" || document.getElementById(hdnValue).value == "DGR" || document.getElementById(hdnValue).value == "NDG")
            document.getElementById(hdnValue).value = "";
        else
            document.getElementById(hdnValue).value = document.getElementById(hdnValue).value + ",";
    }
    for (var i = 0; i < checkExisting.length; i++) {
        if (codeToAdd != "") {
            if (checkExisting[i] == 'DGR' || checkExisting[i] == 'ALL' || checkExisting[i] == 'NDG') {
                checkExisting.splice(i, 1);
                continue;
            }
            if (checkExisting[i] == codeToAdd.toUpperCase()) {
                flag = "1";
                return false;
            }
        }
    }
    if (codeToAdd.length > 2 && flagCheck == "0") {
        if (document.getElementById(hdnValue).value == "" || document.getElementById(hdnValue).value == ",")
            document.getElementById(hdnValue).value = codeToAdd;
        else
            document.getElementById(hdnValue).value += codeToAdd + ",";
    }
    document.getElementById(textBoxID).value = "";
    if ($('#' + hdnValue).val() != ",")
        ConvertSplittedValuesIntoCrossList(hdnValue, labelControlID);
    document.getElementById(textBoxID).focus();
    document.getElementById(textBoxID).select();
}

//Method used directly in case of update from code behind to convert a comma-separated values into cross list
function ConvertSplittedValuesIntoCrossList(hdnVal, labelControlID) {
    
    var valuesToSplit = new Array();
    //To display or hide link button(clear All)
    if ($('#' + hdnVal).val() == "")
        $('a[' + hdnVal + '|=' + hdnVal + ']').attr("style", "display:none");
    else
        $('a[' + hdnVal + '|=' + hdnVal + ']').attr("style", "display:block");
    document.getElementById(labelControlID).value = "";
    document.getElementById(hdnVal).value = document.getElementById(hdnVal).value.toUpperCase();
    valuesToSplit = document.getElementById(hdnVal).value.split(",");
    
    var htmlFinal = "<table style='vertical-align:top; width:100%'>";
    if (valuesToSplit.length > 0) {
        var controls = "";
        var txtArray = new Array();
        for (var i = 0; i < valuesToSplit.length; i++) {
            var txt = valuesToSplit[i];
            if (txt != "")
                htmlFinal += (i % 7 == 0 ? "<tr><td  style='vertical-align:top; text-align:left;' id=td" + txt + " >" : "") + "<span  style='vertical-align=top' id='lbl" + txt + "'> " + (i % 7 == 0 ? "" : ",") + txt + "&nbsp;<img  src='../Images/CloseButtonlbl.gif' style='vertical-align=bottom' alt=" + txt + " onclick='DeleteRecord(\"lbl" + txt + "\",\"" + hdnVal + "\",\"" + labelControlID + "\");'; id='img" + txt + "' /></span>" + (i + 6 % 7 == 0 ? "</td></tr>" : "");
        } 

    }
//    alert(htmlFinal + "</table>");
    document.getElementById(labelControlID).innerHTML = htmlFinal + "</table>";
}

function DeleteRecord(idClose, hdnValClose, labelControlID) {
    var closecity = idClose.substring(3, idClose.length);
    document.getElementById(hdnValClose).value += ",";
    var existingCities = document.getElementById(hdnValClose).value;
    document.getElementById(hdnValClose).value = existingCities.replace(closecity + ",", "");
    document.getElementById(idClose).style.display = 'none';
    if (document.getElementById(hdnValClose).value == "," || document.getElementById(hdnValClose).value == ",,") {
        document.getElementById(hdnValClose).value = "";
    }
    ConvertSplittedValuesIntoCrossList(hdnValClose, labelControlID);
}

//Method to Clear existong cross list
//Added By:Dhiraj kumar
function ClearCrossList(lblValue, hdnFeildValue, lbnButton) {
    $('#' + hdnFeildValue).val('');
    $('#' + lblValue).html('');
    $('#' + lbnButton).attr("style", "display:none");
}
