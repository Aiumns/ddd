﻿/* Home Javascript Description.
* Company              :   CargoFlash Infotech	Pvt. Ltd.
* Copyright            :   Copyright © 2010-2011 CargoFlash Infotech Pvt. Ltd.
* Purpose              :   This class implements the javascript functionality related to home page.
* Created By           :   Dhiraj  Kumar.
* Created On           :   O1 June 2010.
   
*/

function ShowDialog() {

    $(function () {
        var $dialogContent = $("#divDialogHome")
        dialogOpts = {
            title: "Select Company/Branch",
            modal: true,
            bgiframe: true,
            autoOpen: false,
            height: 250,
            width: 500,
            draggable: true,
            resizeable: true,
            closeOnEscape: false,
            buttons: {
                Cancel: function () {
                    $.ajax({
                        url: "Services/DisplayCompanyLogo.ashx?Cancel=true",
                        cache: false,
                        success: function (data) {
                            if (data != null) {
                                $("#divDialogHome").dialog('close');
                                window.location = "login.aspx";
                            }
                        }
                    });
                },
                Submit: function () {
                    var selectedItem = $('select option:selected').text();
                    var selectedValue = $('select option:selected').val();
                    $('#spanCompanyName').text(selectedItem);
                    GetCompanyLogo('imgCompanyLogo');
                    $.ajax({
                        url: "Services/DisplayCompanyLogo.ashx?CompanyBrachSNoForRFB=" + selectedValue,
                        cache: false,
                        dataType: "json",
                        async: false,
                        success: function (data) {
                            if (data != null) {
                                $("#lbnRFBCount").text("" + data.items + "");
                            }
                        }
                    });
                    $("#divDialogHome").dialog('close');
                }
            },
            open: function (event, ui) { $(".ui-dialog-titlebar-close").hide(); }
        };
        $dialogContent.dialog(dialogOpts);
        $dialogContent.dialog("open");
        return false;
    });
    dialogOpts = null;
}

//Added by:Dhiraj Kumar
//This function is called after companybranch is selected to get comapany logo and comapny name and set different writing different session 

function GetCompanyLogo(id) {
    var selectedValue = $('select option:selected').val();
    var selectedItem = $('select option:selected').text();
    var arraySelectedText = new Array();
    if (selectedItem.indexOf("&") > 0)
        selectedItem = selectedItem.replace('&', '^');
    $('#' + id).css('display', 'block');
    var src = "Services/DisplayCompanyLogo.ashx?CompanyBranchSNo=" + selectedValue + "&CityCode=" + arraySelectedText[1] + "&PlaceName=" + arraySelectedText[2] + "&SelectedItem=" + selectedItem;
    $('#' + id).css('display', 'block');
    $('#' + id).attr("src", src);
}


//Added by: Ashutosh Kumar
//This method used to display email marketing reminder if any.
function ShowEmailMarketingAlert(loginSNo) {
    $.ajax({
        url: "Services/GetEmailMarketingMailReminder.ashx?LoginSNo=" + loginSNo,
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data != null) {
                var contactSearchTable = "<table class=\"grdTable\"><tr><th class=\"grdTableHeader\">Campaign Name</th><th class=\"grdTableHeader\">Subject</th></tr>";
                $.each(data.items, function (i, item) {
                    if (item) {

                        contactSearchTable += "<tr><td><a href='CRM/Marketing/EmailMarketing.aspx?From=Home&EmailMktSNo=" + item.SNo + "'>" + item.CampaignName + "</a></td><td>" + item.Subject + "</td></tr>";

                    }

                });
                contactSearchTable += "</table>";
                $("#ReminderData").html(contactSearchTable);
            }

        }
    });
}

//Function add to implement StickyNotes

var cookieValue = "";
function AddStickyNotes(id) {
    var edited = function (note) {
        if ($.cookie(id) != null)
            cookieValue = $.cookie(id);
        if (cookieValue == "")
            cookieValue += note.text;
        else
            cookieValue += '$' + note.text;
        if (cookieValue != "")
            $.cookie(id, cookieValue, { expires: 7 });
    }
    var deleted = function (note) {
        var existing = $.cookie(id);
        var newVal = existing.replace('$' + note.text, "");
        if (newVal.length == existing.length)
            newVal = existing.replace(note.text, "");
        if (newVal.indexOf('$') == 0)
            newVal = newVal.substr(1, newVal.length);
        $.cookie(id, newVal, { expires: 7 });
    };
    var options = { resizable: true
					, controls: true
					, editCallback: edited
					, deleteCallback: deleted

    };
    jQuery("#notes").stickyNotes(options);
    var value = "";
    if ($.cookie(id) != null) {
        value = $.cookie(id);
        var stickyValue = new Array();
        stickyValue = value.split('$');
        var incr = 50;
        jQuery.each(stickyValue, function (index, note) {
            jQuery.fn.stickyNotes.renderNote({ "id": index,
                "text": note,
                "pos_x": incr,
                "pos_y": 50,
                "width": 190,
                "height": 150
            });
            jQuery.fn.stickyNotes.notes.push({ "id": index,
                "text": note,
                "pos_x": incr,
                "pos_y": 50,
                "width": 190,
                "height": 150
            });
            incr = incr + 200;
        });
    }

    else {
        jQuery.fn.stickyNotes.renderNote({ "id": 1,
            "text": "Click double to edit",
            "pos_x": 50,
            "pos_y": 50,
            "width": 190,
            "height": 150
        });
        jQuery.fn.stickyNotes.notes.push({ "id": 1,
            "text": "Click double to edit",
            "pos_x": 50,
            "pos_y": 50,
            "width": 190,
            "height": 150
        });
    }
}

//Funtion to create rounded div with border
jQuery(document).ready(function () {
    var topPos = 724;
    var leftPos = 50;
    var count = 1;
    var arrayHeader = new Array('Appointments', 'Next Follow Up', 'Events of the Day', 'Birthday(This Week)', 'Aniversary(This Week)');
    $('div.rounded_box').each(function (index) {
        var offset = $('div.rounded_box').offset();
     
        $('#' + this.id).wrap('<div class="rounded_border" title=' + arrayHeader[index] + (this.id=='divEvent'?' style="width:500px;height:339px;">':' style="width:300px;height:339px;">')  + arrayHeader[index] + '</div>');
        $('#' + this.id).corners("round 5px").parent().css('padding', '10px').corners("round 6px").offset({ top: topPos, left: leftPos });
        if (count % 3 == 0) {
            topPos += 470;
            leftPos = 50;
        }
        else
            leftPos += 350;
        count++;
    })
});

function FillData(DataFor) {
    var txt = "";
    $('div.rounded_box').each(function (index) {
        switch (index) {
            case 0:
             //   txt = GetAppointMentData();
                break;
            case 3:
                txt = GetBirthdayAniversaryData('DOB');
                break;
            case 4:
                txt = GetBirthdayAniversaryData('DOA');
                break;
        }
        $('#' + this.id).find('.innerText').html(txt);

    })
}

function GetBirthdayAniversaryData(DataFor) {
    var contactSearchTable = '';
    $.ajax({
        url: "CRM/Services/AlertsAndNotifications.ashx?DataFor=" + DataFor,
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data != null) {
                contactSearchTable = "<table class=\"grdTable\"><tr><th class=\"grdTableHeader\">Name</th><th class=\"grdTableHeader\">Date</th></tr>";
                $.each(data.items, function (i, item) {
                    if (item) {
                        contactSearchTable += "<tr><td><div title='" + item.Name + "'>" + item.ShortName + "</div></td><td>" + item.Date + "</td></tr>";
                    }

                });
                contactSearchTable += "</table>";
            }

        }
    });
    return contactSearchTable;
}

function GetAppointMentData() {
    var contactSearchTable = '';
    $.ajax({
        url: "CRM/Services/AppointmentData.ashx?HomePage=true",
        cache: false,
        async:false,
        dataType: "json",
        success: function (data) {
            if (data != null) {
                contactSearchTable = "<table class=\"grdTable\"><tr><th class=\"HeaderStyle\">Title</th><th class=\"HeaderStyle\">Description</th><th class=\"HeaderStyle\">Date</th><th class=\"HeaderStyle\">Time</th></tr>";
                $.each(data.items, function (i, item) {
                    if (item) {
                        contactSearchTable += "<tr" + (i % 2 == 0 ? " style='background-color:white;color:black;'" : " style='background-color:#d2d2d2;'") + "><td><div title='" + item.title + "'>" + item.title + "</div></td><td>" + item.description + "</td><td>" + item.start + "</td><td>" + item.time+ "</td></tr>";
                    }

                });
                contactSearchTable += "</table>";
            }

        }
    });
    $('#divAlertRound').html(contactSearchTable);
    GetNextFollowUpData();
}


function GetNextFollowUpData() {
    var contactSearchTable = '';
    $.ajax({
        url: "CRM/Services/AlertsAndNotifications.ashx",
        cache: false,
        async: false,
        dataType: "json",
        success: function (data) {
            if (data != null) {
                contactSearchTable = "<table class=\"grdTable\"><tr><th class=\"HeaderStyle\">Customer Name</th><th class=\"HeaderStyle\">Place</th><th class=\"HeaderStyle\">Phone</th><th class=\"HeaderStyle\">Date</th><th class=\"HeaderStyle\">Time</th></tr>";
                $.each(data.items, function (i, item) {
                    if (item) {
                        contactSearchTable += "<tr" + (i % 2 == 0 ? " style='background-color:white;color:black;'" : " style='background-color:#d2d2d2;'") + "><td>" + item.CustomerName + "</td><td>" +item.Place + "</td><td>" + (item.Phone==""?"---":item.Phone) + "</td><td>" + item.Date + "</td><td>" + item.Time + "</td></tr>";
                    }

                });
                contactSearchTable += "</table>";
            }

        }
    });
    $('#divEvent').html(contactSearchTable);
}
