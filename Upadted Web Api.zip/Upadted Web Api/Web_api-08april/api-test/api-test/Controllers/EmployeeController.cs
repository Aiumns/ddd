﻿using api_test.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
namespace api_test.Controllers
{
    public class EmployeeController : Controller
    {
        //private GccTestEntities db = new GccTestEntities();
        // GET: /Employee/
        
        public ActionResult Index()
        {
            return View();
        }
        
        public ActionResult Create()
        {
            return View();
        }
        
        [HttpPost]
        public ActionResult create(Employee employee)
        {
           using (var client = new HttpClient())
            {
                string Url = string.Empty;
                client.BaseAddress = new Uri("http://localhost:62536/api/EmployeeApi/create");
                
                //HTTP POST
                var postTask = client.PostAsJsonAsync<Employee>("employee", employee);
                postTask.Wait();

                var result = postTask.Result;
                int code = Convert.ToInt32(result.IsSuccessStatusCode);
                switch (code)
                {
                    case 200:
                        Url = "Index";
                        break;
                    case 201:
                        Url = "Index";
                        break;
                    default:
                        Url = "Index";
                        break;
                }
                return RedirectToAction(Url);
            }
            //ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");
            //return View(employee);            
        }

        [HttpGet]
        public ActionResult EmpList()
        {
            IEnumerable<Employee> emp = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:62536/api/EmployeeApi/");

                //Called Member default GET All records  
                //GetAsync to send a GET request   
                // PutAsync to send a PUT request  
                var responseTask = client.GetAsync("");
                responseTask.Wait();

                //To store result of web api response.   
                var result = responseTask.Result;

                //If success received   
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Employee>>();
                    readTask.Wait();
                    emp = readTask.Result;
                }
                else
                {
                    //Error response received   
                    emp = Enumerable.Empty<Employee>();
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }
            return View(emp);
        }

        public ActionResult Edit(int id)
        {
            Employee emp = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:62536/api/EmployeeApi/");
                //HTTP GET
                var responseTask = client.GetAsync("emp?id=" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<Employee>();
                    readTask.Wait();

                    emp = readTask.Result;
                }
            }
            return View(emp);
        }

        [HttpPost]
        public ActionResult Edit(Employee employee)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:62536/api/EmployeeApi/");
                //HTTP POST
                var putTask = client.PutAsJsonAsync<Employee>("employee", employee);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("EmpList");
                }
            }
            return View(employee);
        }

        public ActionResult Details(int id)
        {
            IEnumerable<Employee> emp = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:62536/api/EmployeeApi/");
                //Called Member default GET All records  
                //GetAsync to send a GET request   
                // PutAsync to send a PUT request  
                var responseTask = client.GetAsync("emp?id=" + id.ToString());
                responseTask.Wait();
                //To store result of web api response.   
                var result = responseTask.Result;
                //If success received   
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Employee>>();
                    readTask.Wait();
                    emp = readTask.Result;
                }
                else
                {
                    //Error response received   
                    emp = Enumerable.Empty<Employee>();
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }
            return View(emp);
        }
	}
}