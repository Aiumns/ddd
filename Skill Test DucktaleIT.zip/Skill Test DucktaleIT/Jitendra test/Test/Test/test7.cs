﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Test
{
    class a
    {
        public void display()
        {
            Console.WriteLine("this is parent class method");
        }
    }

    class b :a
    {
        public void display2()          
        {
            Console.WriteLine("this is child class method");
        }
    }

    class test7
    {
        static void Main()
        {
            b obj = new b();
            obj.display();
            obj.display2();
            Console.ReadLine();
        }
    }
}
