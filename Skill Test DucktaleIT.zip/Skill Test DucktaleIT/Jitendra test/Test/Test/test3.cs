﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class test3
    {
        static void Main()
        {
            var numberList = new List<int> { 1, 4, 4, 83, 22, 22, 90, 35 };
            int max  = numberList.OrderByDescending(rr => numberList).Max();
            Console.WriteLine(max);
            Console.ReadLine();
        }
    }
}
