﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Test5
    {
        static void Main()
        {
            var numberList = new List<int> { 1, 4, 4, 83, 22, 22, 90, 35 };
            numberList.Distinct();
            foreach (var dis in numberList)
            {
                Console.WriteLine(dis);           
            }                      
            Console.ReadLine();
        }
    }
}
