﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Test2
    {
        static void Main(string[] args)
        {
            string str = "turma";
            string Strrev = "";
            for (int i = str.Length - 1; i >= 0; i--)
            {
                Strrev += str[i]; 
            }
            Console.Write(Strrev);
            Console.ReadLine();
        }
    }
}
