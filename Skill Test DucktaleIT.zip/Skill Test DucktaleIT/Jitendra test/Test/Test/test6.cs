﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class test6
    {
        static void Main()
        {
            string str = "Deleveled";
            string strpalindrome = "";
            for (int i = str.Length-1; i >=0; i--)
            {
                strpalindrome += str[i];
            }
            if (str == strpalindrome)
            {
                Console.WriteLine("Input string is Palindrome  {0}", str);
            }
            else 
            {
                Console.WriteLine("Input string is not Palindrome  {0}", str); 
            }
            Console.ReadLine();
        }
    }
}
