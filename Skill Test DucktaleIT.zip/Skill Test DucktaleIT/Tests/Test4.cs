﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace BasicSkillsTest
{
    partial class Program
    {
        static string Test4(List<int> numberList)
        {
            throw new NotImplementedException();
        }
    }
}
