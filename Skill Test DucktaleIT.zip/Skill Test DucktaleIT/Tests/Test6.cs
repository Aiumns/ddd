﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace BasicSkillsTest
{
    partial class Program
    {
        static bool Test6(string pal)
        {
            throw new NotImplementedException();
        }
    }
}
