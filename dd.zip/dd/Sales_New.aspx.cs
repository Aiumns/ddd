using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Xml;
using System.Globalization;
public partial class Booking_Edit : System.Web.UI.Page
{
    #region Summary
    decimal total = 0;
    /// <summary>
    /// <class>Sales</class>
    /// <class>Sales Edit</class>
    /// <description>
    /// This Page intended to provides page level functionalitities and manage events
    /// </description>
    /// <dependency>Tables : one-one, one-many</dependency>
    /// <createdBy>Rajinder Singh Lamba</createdBy>
    /// <createdOn>DEC 22, 2007</createdOn>
    /// <modifications>
    ///		<modification>
    ///			<changeDescription></changeDescription>
    ///			<modifiedBy>Rajinder Singh Lamba</modifiedBy>
    ///			<modifiedOn>FEB 23, 2008</modifiedOn>
    ///		</modification>
    /// </modifications>			
    /// </summary>		
    #endregion

    bool IsExemption = false;
    DisplayWrap dw = new DisplayWrap();
    BLWrap bw = new BLWrap();
    SqlConnection con;
    SqlCommand com;
    SqlCommand cmd;
    string strCon = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
    public string calendarControl = "";
    int NA = 0;
    int invoiceNo = 0;
    int Lastinvoiceno = 0;
    int invoicesno = 0;
    public string strCity = "";
    protected void Page_Init(object sender, EventArgs e)
    {
        //textboxUser.Text = "something";
        //string text = textboxUser.Text;
        //UserControl_Wel c1 = new UserControl_Wel();
        //Label lblbb = (Label)c1.FindControl("lblWel");
        //TextBox txt = this.Parent.FindControl("txtVisitorName") as TextBox;

        UserControl _dummyUserControl = (UserControl)Page.LoadControl("Text_User.ascx");
        TextBox txt = _dummyUserControl.FindControl("txtuser") as TextBox;

        string GroupID = "";       
        DataTable dtGroupId = dw.GetAllFromQuery("SELECT Group_ID FROM dbo.Login_Master WHERE Email_ID='" + Session["EMailID"] + "'");
        if (dtGroupId.Rows.Count > 0)
        {
            GroupID = dtGroupId.Rows[0]["Group_ID"].ToString(); 
            ViewState["GroupID"] = GroupID;
        }
        if (Request.QueryString["Sales_ID"] != null)
        {
           /////////FillBuyingRouteDetails();
        }     
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        string STRID = Convert.ToString(Session["EMailID"]);
        if (STRID == "admin@groupconcorde.com")
        {          
            trBuyingDetails.Visible = true;
            trBuyingDetails2.Visible = true;
            trBuyingDetails3.Visible = true;
        }
        else
        {
            trBuyingDetails.Visible = false;
            trBuyingDetails2.Visible =false;
            trBuyingDetails3.Visible = false;
        }
 
        //***********************Due Carrier Formula**********************
        //decimal ThreeCharges = decimal.Parse(txtFSC.Text) + decimal.Parse(txtWSC.Text) + decimal.Parse(txtXRAY.Text);
        //decimal Result = ThreeCharges + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtOthers.Text);
        //Result = Math.Round(Result, MidpointRounding.AwayFromZero);
        //txtDueCarrier.Text = Result.ToString();


        //***********************Total Prepaid Formula**********************
        ////decimal Total_Prepaid = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentP.Text);
        ////Total_Prepaid = Total_Prepaid + decimal.Parse(txtSpAmt.Text);


       

        HtmlGenericControl body = (HtmlGenericControl)Page.Master.FindControl("MyBody");
        // body.Attributes.Add("onload", "OnOff()");
        Button1.Attributes.Add("onclick", "return CheckEmpty();");
        if (Session["EMailID"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        
        
        //{


        //    LoadGstStateCode();

        //    //#region findout from and to date

        //    //string Flight_date =FormatDateMM(txtFlightDate.Text);
        //    //string[] dateSplit = Flight_date.Split('/');
        //    //string Month = dateSplit[0].ToString();
        //    //string Year = dateSplit[2].ToString();
        //    //string Date1 = dateSplit[1].ToString();
        //    //string currentdate = Month + "/" + Date1 + "/" + Year;
        //    //string FinYear = Year.Substring(2, 2);



        //    //DateTime CurrDate = Convert.ToDateTime(currentdate);
        //    //string DateFinancial = "4/1/20" + FinYear + "";
        //    //DateTime FinanciaDate = DateTime.Parse(DateFinancial);


        //    //if (CurrDate < FinanciaDate)
        //    //{
        //    //    FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
        //    //}
        //    //else
        //    //{
        //    //    FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
        //    //}


        //    //string Lastdate = "";
        //    //bool flagInvoice = false;
        //    //if (int.Parse(Date1) < 16)
        //    //{
        //    //    Date1 = "1";
        //    //    flagInvoice = true;
        //    //}
        //    //else
        //    //{
        //    //    Date1 = "16";
        //    //}

        //    //string startDate = Month + "/" + Date1 + "/" + Year;
        //    //string endDate = Month + "/" + (flagInvoice ? "15" : (Convert.ToDateTime(Month + "/1/" + Year).AddMonths(1).AddDays(-1).Day.ToString())) + "/" + Year;

        //    //#endregion
           

        //    //    #region GstNo Applicable
        //    // DataTable dtAgent = dw.GetAllFromQuery("select Agent_Name from Agent_Master where Agent_ID=" + ddlAgentName.SelectedValue);
        //    //DataTable dtagentgstNo = new DataTable();
        //    //if (dtAgent.Rows.Count > 0)
        //    //{
        //    //    ViewState["Agent_ID"] = ddlAgentName.SelectedValue;

        //    //    DataTable dtGstNAlreadyExist = dw.GetAllFromQuery("Select gstNo from sales where agent_id=" + ViewState["Agent_ID"] + " and flight_date between '" + startDate + "' and '" + endDate + "' and airline_detail_id=" + ViewState["AirlineDetailID"] + "  and Gstno is not null");
        //    //    if (dtGstNAlreadyExist != null && dtGstNAlreadyExist.Rows.Count > 0)
        //    //    {
        //    //        txtGstNo.Text = dtGstNAlreadyExist.Rows[0]["GstNo"].ToString();
        //    //        txtGstNo.Enabled = true;

        //    //        ddlGst.Items.Insert(0, "-Select-");
        //    //        ddlGst.Items[0].Value = "0";

        //    //        dtagentgstNo = dw.GetAllFromQuery("Select GstNo,Address from AgentGstNo where agentname like '" + dtAgent.Rows[0]["Agent_Name"].ToString() + "%'");
        //    //        if (dtagentgstNo != null && dtagentgstNo.Rows.Count > 0)
        //    //        {

        //    //            for (int i = 0; i < dtagentgstNo.Rows.Count; i++)
        //    //            {

        //    //                ddlGst.Items.Add(new ListItem(dtagentgstNo.Rows[i]["GstNo"].ToString(), dtagentgstNo.Rows[i]["Address"].ToString()));
        //    //            }

        //    //            ddlGst.SelectedValue = dtGstNAlreadyExist.Rows[0]["GstNo"].ToString();
        //    //            ddlGst.Enabled = true;
        //    //        }


        //    //    }
        //    //    else
        //    //    {
        //    //        ddlGst.Items.Insert(0, "-Select-");
        //    //        ddlGst.Items[0].Value = "0";

        //    //        dtagentgstNo = dw.GetAllFromQuery("Select GstNo,Address from AgentGstNo where agentname like '" + ddlAgentName.SelectedItem.Text + "%'");
        //    //        if (dtagentgstNo != null && dtagentgstNo.Rows.Count > 0)
        //    //        {

        //    //            for (int i = 0; i < dtagentgstNo.Rows.Count; i++)
        //    //            {

        //    //                ddlGst.Items.Add(new ListItem(dtagentgstNo.Rows[i]["GstNo"].ToString(), dtagentgstNo.Rows[i]["Address"].ToString()));
        //    //            }


        //    //        }
        //    //    }
        //    //}
        //    //    #endregion End of GstApplicable
          



        //    //////*****************Added On 18 Apr 2011****************
        //    //// if (Session["groupid"].ToString() == "1" || Session["groupid"].ToString() == "9" || Session["groupid"].ToString() == "49" || Session["groupid"].ToString() == "56")
        //    //// {

        //    ////     PricipalePannel.Visible = true;
        //    //// }
        //    //////*****************End*********************************

        //    ////lblawbfee.Visible = false;
        //    ////txtAwbfee.Visible = false;
        //    ////hdnDimension.Value = Session["groupid"].ToString();

        //    //*****************Added On 18 Apr 2011****************
        //    PricipalePannel.Attributes.Add("style", "display:none");
        //    if (Session["groupid"].ToString() == "1" || Session["groupid"].ToString() == "9" || Session["groupid"].ToString() == "49" || Session["groupid"].ToString() == "56")
        //    {
        //        ////LblprinTxt.Visible = true;
        //        ////lblbrc.Visible = true;
        //        ////ChkMinAirline.Visible = true;
        //        ////txtPRate.Visible = true;
        //        ////lblbrc2.Visible = true;
        //        //PricipalePannel.Visible = true;                                                           
        //        PricipalePannel.Attributes.Add("style", "display:block");
        //    }
        //    //*****************End*********************************

           


        //    ViewState["edit"] = "0";
        //    ViewState["et"] = "1";

        //    if (!IsPostBack)
        //    {






        //        // CreateTextBoxesInTable();    
        //       // fillddl();
        //        fillGatewayDpr();
        //        ////Session["dtOtherCharges"] = null;
        //        ////Session["dtTemp"] = null;
        //        ////Session["dtTem"] = null;
        //        ////Session["dtOther"] = null;  
        //        rbCal.SelectedValue = "Cm";
        //        LoadACS();
        //        string SalesID = "";
        //        DataTable dtSalesEdit = new DataTable();
        //        if (Request.QueryString["Sales_ID"] != null)
        //        {
        //            SalesID = Request.QueryString["Sales_ID"];
        //            dtSalesEdit = dw.GetAllFromQuery("Select status,Approved_for_CSR,CSR_DATE,CSR_Remarks from sales where status in(11,12) and Sales_ID=" + SalesID);
        //            fillVolumeDimension(SalesID);
        //        }
        //        else
        //        {
        //            maketable();
        //            grdCal.DataSource = (DataTable)Session["dtTemp"];
        //            grdCal.DataBind();
        //        }

        //        if (dtSalesEdit.Rows.Count > 0)
        //        {
        //            if (dtSalesEdit.Rows[0]["Approved_for_CSR"].ToString() == "28")
        //            {
        //                ////ddlAwbNo.Attributes.Add("Enable","false");
        //                ddlAwbNo.Enabled = false;
        //                ddlAirline.Enabled = false;
        //                ddlAgentName.Enabled = false;
        //                ddlOrigin.Enabled = false;
        //                //body.Attributes.Add("onload", "AWB()");
        //                FillSalesFields();
        //                DateTime CSR_DATE = Convert.ToDateTime(dtSalesEdit.Rows[0]["CSR_DATE"].ToString());
        //                txtCSRDate.Text = FormatDateDD(CSR_DATE.ToShortDateString()); txtCSRDate.Enabled = false;
        //                txtCSRRemarks.Text = Convert.ToString(dtSalesEdit.Rows[0]["CSR_Remarks"]);
        //                tdCSRRemarks.Visible = true;
        //                tdTextCSR.Visible = true;
        //                //Button2.Visible = false;
        //                btnSModify.Visible = true;
        //                UpdateSales.Visible = false;
        //                Label1.Text = "* The CSR is already approved,If u made any change it will create CR/DR Note. *";
        //                Label1.ForeColor = System.Drawing.Color.Red;
        //                tdTextCSR.Visible = true;
        //                tdCSRRemarks.Visible = true;

        //            }
        //            else
        //            {
        //                // ddlAwbNo.Attributes.Add("Enable", "false");
        //                ddlAwbNo.Enabled = false;
        //                ddlAirline.Enabled = false;
        //                ddlAgentName.Enabled = false;
        //                ddlOrigin.Enabled = false;
        //                btnSModify.Visible = false;
        //                UpdateSales.Visible = true;
        //                tdCSRDate.Visible = false;
        //                tdtxtCSRDate.Visible = false;
        //                FillSalesFields();
        //            }
        //            Button1.Visible = false;

        //        }
        //        else
        //        {
        //            tdCSRDate.Visible = false;
        //            tdtxtCSRDate.Visible = false;
        //            Button1.Visible = true;
        //            UpdateSales.Visible = false;
        //            /////////FillAllFields();
        //        }
        //        ////maketable();
        //        ////grdCal.DataSource = (DataTable)Session["dtTemp"];
        //        ////grdCal.DataBind();
        //    }
        //    if (Session["table"] != null)
        //    {
        //        phRouteDetail.Controls.Clear();
        //        phRouteDetail.Controls.Add((Table)Session["table"]);
        //    }
        else
        {
            hdnEmail.Value = Session["EMailID"].ToString();
            ViewState["edit"] = "0";
            ViewState["et"] = "1";
            //GST StateCode
            LoadGstStateCode();
            if (!IsPostBack)
            {
                LoadACS();
                txtValuationCharge.Attributes.Add("onblur", "Valuation()");
                txtTax.Attributes.Add("onblur", "Tax()");
                Session["dtOtherCharges"] = null;
                string SalesID = "";
                DataTable dtSalesEdit = new DataTable();
                //ViewState["IncentiveAmount"] = hdn_Inc_amt.Value;
                //ViewState["CommissionAmount"] = hdn_comm_amt.Value;
                //ViewState["FreightDiffAmount"] = hdn_frt_diff_amt.Value;
                //ViewState["Total_UsedExemption_Limit"] = hdn_tot_usedex_limit.Value
                if (hdn_ex_cross_limit.Value == "")
                {
                    ViewState["Ex_crossed_limit"] = "N";
                }
                else
                {
                    ViewState["Ex_crossed_limit"] = hdn_ex_cross_limit.Value;
                }
                txtcertificate_no.Text = hdn_certificate_no.Value;
                if (Request.QueryString["Sales_ID"] != null)
                {
                    LoadACS();
                    LoadTrucker();
                    SalesID = Request.QueryString["Sales_ID"];
                    dtSalesEdit = dw.GetAllFromQuery("Select status,Approved_for_CSR,CSR_DATE,CSR_Remarks from sales where status in(11,12) and Sales_ID=" + SalesID);
                    fillVolumeDimension(SalesID);
                }

                if (dtSalesEdit.Rows.Count > 0)
                {
                    if (dtSalesEdit.Rows[0]["Approved_for_CSR"].ToString() == "28")
                    {
                        //body.Attributes.Add("onload", "AWB()");
                        FillSalesFields();
                        //tdAWBDate.Disabled = true;

                        DateTime CSR_DATE = Convert.ToDateTime(dtSalesEdit.Rows[0]["CSR_DATE"].ToString());
                        txtCSRDate.Text = FormatDateDD(CSR_DATE.ToShortDateString()); txtCSRDate.Enabled = false;

                        txtCSRRemarks.Text = Convert.ToString(dtSalesEdit.Rows[0]["CSR_Remarks"]);
                        tdCSRRemarks.Visible = true;
                        tdTextCSR.Visible = true;
                        //  Button2.Visible = false;
                        btnSModify.Visible = true;
                        UpdateSales.Visible = false;
                        Label1.Text = "* The CSR is already approved,If you made any change it will create CR/DR Note. *";
                        Label1.ForeColor = System.Drawing.Color.Red;
                        tdTextCSR.Visible = true;
                        tdCSRRemarks.Visible = true;

                    }
                    else
                    {
                        //body.Attributes.Add("onload", "AWB()");
                        //txtCSRRemarks.Text = Convert.ToString(dtSalesEdit.Rows[0]["CSR_Remarks"]);
                        //tdCSRRemarks.Visible = true;
                        //tdTextCSR.Visible = true;
                        //LoadTrucker();
                        btnSModify.Visible = false;
                        UpdateSales.Visible = true;
                        tdCSRDate.Visible = false;
                        tdtxtCSRDate.Visible = false;
                        FillSalesFields();
                    }
                    Button1.Visible = false;
                }
                else
                {
                    LoadTrucker();
                    tdCSRDate.Visible = false;
                    tdtxtCSRDate.Visible = false;
                    Button1.Visible = true;
                    UpdateSales.Visible = false;
                    tr_cert.Visible = false;
                    fillOtherCharges("0");
                    maketable();
                    grdCal.DataSource = (DataTable)Session["dtTemp"];
                    grdCal.DataBind();
                    ////LOAD_SCD();
                    /////FillAllFields();
                }
            }
        }
    }

    public void LoadGstStateCode()
    {
        try
        {
            string strAgent = "select * from GstStateCode order by Statecode";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlGstStateCode.Items.Insert(0, "- -Select- -");
            ddlGstStateCode.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlGstStateCode.Items.Add(new ListItem(dr["StateCode"].ToString() + "-" + dr["State"].ToString(), dr["StateCode"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public string City()
    {
        string strTemp1 = "";
        con = new SqlConnection(strCon);
        try
        {
            string[] DestCode = ddlDestination.SelectedItem.Value.Split('-');
            cmd = new SqlCommand("Route", con);
            cmd.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@destination", SqlDbType.VarChar).Value = DestCode[0].ToString();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (strTemp1 == "")
                    strTemp1 = "'" + Convert.ToString(dr["Routing"]).ToString().ToUpper().Trim() + "'";

            }
            cmd.Dispose();
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
        return strTemp1;
    }
    public DataTable tableVolumewt()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Route";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Origin_Code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Destination_Code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "rate";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Flight_no";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Flight_date";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Carrier";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Currency";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        Session["dtTem"] = dtTemp;
        return dtTemp;
    }
    public void maketableVolumewt()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Route";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Origin_Code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Destination_code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "rate";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "flight_no";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "flight_date";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Carrier";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        dc1 = new DataColumn();
        dc1.ColumnName = "Currency";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "0";
        dr[6] = "0";
        dr[7] = "0";
        dr[8] = "0";
        dtTemp.Rows.Add(dr);

        Session["dtTemp"] = dtTemp;
    }
    public void fillVolumeDimension(string Id)
    {
        //string bookingId = Request.QueryString["Booking_ID"].ToString();
        string strQuery = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            //////strQuery = "select * from Sales_Trans where Stock_id = '" + Id + "'";
            DisplayWrap de = new DisplayWrap();
            DataTable dttrans = de.GetAllFromQuery("Select stock_id from Sales where sales_id=" + Id + " ");
            if (dttrans.Rows.Count > 0)
            {
                strQuery = "select convert(varchar,flight_date,103) as flight_date, * from Sales_Trans where Stock_id=" + dttrans.Rows[0]["stock_id"].ToString();
            }
            
        }


        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand(strQuery, con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataTable dt = tableVolumewt();
        DataRow dw;
        int i = 1;
        while (dr.Read())
        {
            ////if (dr["Measurement_Unit"].ToString() != "" || dr["Measurement_Unit"].ToString() != null)
            ////    rbCal.SelectedValue = dr["Measurement_Unit"].ToString();
            dw = dt.NewRow();
            dw[0] = i++;

            string len = dr["Route"].ToString();
            string width = dr["Origin_Code"].ToString();
            string Height = dr["Destination_Code"].ToString();

            string l = dr["Route"].ToString();
            string w = dr["Origin_Code"].ToString();
            string h = dr["Destination_Code"].ToString();

            ////decimal l = System.Math.Round(decimal.Parse(len), MidpointRounding.AwayFromZero);
            ////decimal w = System.Math.Round(decimal.Parse(width), MidpointRounding.AwayFromZero);
            ////decimal h = System.Math.Round(decimal.Parse(Height), MidpointRounding.AwayFromZero);

            dw[1] = l;
            dw[2] = w;
            dw[3] = h;
            dw[4] = dr["rate"].ToString();
            dw[5] = dr["flight_no"].ToString();
            dw[6] = dr["flight_date"].ToString();
            dw[7] = dr["Carrier"].ToString();
            dw[8] = dr["Currency"].ToString();

            dt.Rows.Add(dw);

        }
        if (dt.Rows.Count > 0)
        {
            grdCal.DataSource = dt;
            grdCal.DataBind();
            Session["dtTemp"] = dt;
        }
        else
        {
            Session["dtTemp"] = null;
            maketableVolumewt();
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
        con.Close();
    }
    public void maketable()
    {
        DataTable dtTemp = new DataTable();
        DataColumn dc1 = new DataColumn();

        dc1 = new DataColumn();
        dc1.ColumnName = "SNo";
        dc1.DataType = System.Type.GetType("System.Int16");
        dc1.AutoIncrement = true;
        dc1.AutoIncrementStep = 1;
        //dc1.AutoIncrementSeed = 1;
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Route";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Origin_Code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Destination_code";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "rate";
        dc1.DataType = System.Type.GetType("System.Decimal");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "flight_no";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "flight_date";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Carrier";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);

        dc1 = new DataColumn();
        dc1.ColumnName = "Currency";
        dc1.DataType = System.Type.GetType("System.String");
        dtTemp.Columns.Add(dc1);


        DataRow dr = dtTemp.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dr[4] = "0";
        dr[5] = "0";
        dr[6] = "0";
        dr[7] = "0";
        dr[8] = "0";
        dtTemp.Rows.Add(dr);

        Session["dtTemp"] = dtTemp;
        ViewState["dtBeginCharges"] = dtTemp;
    }
    //================================================Added By:Pradeep Sharma======================
    protected void rbtnGateWay_CheckedChanged(object sender, EventArgs e)
    {
        //////Route_type.Visible = true;
    }
    protected void rbtnGateWay2_CheckedChanged(object sender, EventArgs e)
    {
        //////Route_type.Visible = true;
    }
    //interline
    protected void rbtnRouteType1_CheckedChanged(object sender, EventArgs e)
    {

        txtCenturionRoute.Text = "";
        phRouteDetail.Controls.Clear();
        SetPrincipalToDefault();
        ////PnlCarrier.Visible = true;
        RouteEnter.Visible = false;
        lblOrigin.Text = ddlOrigin.SelectedValue.Split('-')[0];
        lblDestination.Text = ddlDestination.SelectedItem.ToString().Split('-')[0];
        fillddl("Y");
       
    }
    public void fillddl(string interline)
    {
        //===========================================Added BY:Pradeep Sharma==================
        con = new SqlConnection(strCon);
        com = new SqlCommand("SpAK_PH_FillCarrier", con);
        com.CommandType = CommandType.StoredProcedure;
        ////if (rbtnRouteType1.Checked == true)
        ////{
        ////    com.Parameters.AddWithValue("@Interline", interline);
        ////}
        ////else
        ////{
            com.Parameters.AddWithValue("@Interline", interline);
        ////}
        con.Open();
        SqlDataAdapter adp = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        //////selCarrier.Items.Clear();
        if (dt.Rows.Count > 0)
        {
           ///// selCarrier.Items.Insert(0, new ListItem("--Select--", "0"));
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //////selCarrier.Items.Add(new ListItem(dt.Rows[i]["CarrierCode"].ToString(), dt.Rows[i]["CarrierCode"].ToString()));
            }

        }
        con.Close();


    }
    public void fillGatewayDpr()
    {
        DataTable dtGateway = dw.GetAllFromQuery("select GatewayCode from gateway");
        ////rbtnGateWay.DataSource = dtGateway;
        ////rbtnGateWay.DataTextField = "GatewayCode";
        ////rbtnGateWay.DataValueField = "GatewayCode";
        ////rbtnGateWay.DataBind();

    }
    protected void rbtnGateWay_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        ////rbtnRouteType1.Checked = false;
        ////rbtnRouteType2.Checked = false;
       //// selCarrier.SelectedValue = "0";
        txtCenturionRoute.Text = "";
        SetPrincipalToDefault();
        phRouteDetail.Controls.Clear();
        ////Route_type.Visible = true;
      /////  PnlCarrier.Visible = false;
        RouteEnter.Visible = false;

    }
    //non-interline
    protected void rbtnRouteType2_CheckedChanged(object sender, EventArgs e)
    {      
            txtCenturionRoute.Text = "";
            phRouteDetail.Controls.Clear();
          ////  PnlCarrier.Visible = false;
            RouteEnter.Visible = true;
            lblOrigin.Text = ddlOrigin.SelectedItem.ToString().Split('-')[0];
            lblDestination.Text = ddlDestination.SelectedItem.ToString().Split('-')[0];
            fillddl("N");   

    }
    protected void selCarrier_SelectedIndexChanged(object sender, EventArgs e)
    {
        //phRouteDetail.Controls.Clear();
        //SetPrincipalToDefault();     
        //if (selCarrier.SelectedValue == "0")
        //{
        //    RouteEnter.Visible = false;
        //}
        //else
        //{
        //    RouteEnter.Visible = true;
        //    lblOrigin.Text = ddlOrigin.SelectedItem.ToString().Split('-')[0];//ddlOrigin.SelectedValue.Split('-')[0];
        //    lblDestination.Text = ddlDestination.SelectedItem.ToString().Split('-')[0];
        //}
    }
    protected void btnSearchRates_Click(object sender, EventArgs e)
    {      
        CreateTextBoxesInTable();       
    }
    public void CreateTextBoxesInTable()
    {
            phRouteDetail.Controls.Clear();
            SetPrincipalToDefault();    
            double sumRate = 0, sumAmt = 0;           
            DataTable dtCurrency = dw.GetAllFromQuery("SELECT DISTINCT CurrencyCode as Currency FROM dbo.CurrencyMaster");
            DataTable dtCarrier = dw.GetAllFromQuery("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");           
            var route = GenerateRoute();
            //======================FlightNo in GridDropdown:By Pradeep Sharma=====================
            string FltNo = "";
            FltNo = "SELECT DISTINCT fm.Flight_No,fm.flight_id FROM flight_master fm INNER JOIN dbo.Flight_Details fd ON fm.Flight_ID = fd.Flight_ID WHERE fm.Airline_Detail_ID=" + ddlAirline.SelectedValue + " AND fm.Status=2";
            con = new SqlConnection(strCon);
            con.Open();
            SqlDataAdapter adp = new SqlDataAdapter(FltNo, con);
            DataTable dtFlightNo = new DataTable();
            adp.Fill(dtFlightNo);
            
            //=======================End===============================================
            int icount =Convert.ToInt32(txtCarrier.Text);
            double rate = 0, amt = 0;
            for (int i = 0; i < icount; i++)//for (int i = 0; i < route.Length - 1; i++)
            {
                Table table = new Table();
                table.Attributes["border"] = "1";
                table.Attributes["width"] = "90%";
                table.Attributes["cellSpacing"] = "0";
                table.Attributes["cellPadding"] = "0";
                table.Attributes["style"] = "margin:10px 10px 10px 10px; ";
                TableHeaderRow headerRow = new TableHeaderRow();
                TableCell[] headerCells = new TableCell[9];
                for (int jj = 0; jj <= headerCells.Length - 1; jj++)
                {
                    headerCells[jj] = new TableCell();
                }
                headerCells[0].Text = "Route";
                headerCells[1].Text = "Origin";
                headerCells[2].Text = "Destination";
                headerCells[3].Text = "Rate";
                headerCells[4].Text = "Amount";
                headerCells[5].Text = "Flight No";
                headerCells[6].Text = "Flight Date";
                headerCells[7].Text = "Currency";
                headerCells[8].Text = "Carrier";
                // headerCells[8].Text = "Carrier";

                headerRow.Cells.AddRange(headerCells);
                table.Rows.Add(headerRow);
                table.ID = "dynamicRouteTable" + i;
                TableRow tr = new TableRow();
                TableCell[] trCells = new TableCell[9];
                for (int j = 0; j <= trCells.Length - 1; j++)
                {
                    trCells[j] = new TableCell();
                }
                ////using (con = new SqlConnection(strCon))
                ////{
                ////    con.Open();
                ////    com = new SqlCommand("spAK_PH_GetPrincipalRate", con);
                ////    com.CommandType = CommandType.StoredProcedure;
                ////    com.Parameters.AddWithValue("@origin", route[i]);
                ////    com.Parameters.AddWithValue("@destination", route[i + 1]);
                ////    com.Parameters.AddWithValue("@interline", rbtnRouteType1.Checked ? "Y" : rbtnRouteType2.Checked ? "N" : "N/A");
                ////    com.Parameters.AddWithValue("@airlineCode", ddlAwbNo.SelectedItem.Text.Split('-')[0]);
                ////    if (txtCw.Text == "" || txtCw.Text == "0" || txtCw.Text == "0.00")
                ////    {
                ////        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "errorCW", " jAlert('Please Enter Chargeable weight')", true);
                ////        return;
                ////    }
                ////    else
                ////    {
                ////        com.Parameters.AddWithValue("@chwRate", txtCw.Text);
                ////    }
                ////    com.Parameters.AddWithValue("@carrierCode", selCarrier.SelectedValue);
                ////    rate = Convert.ToDouble(com.ExecuteScalar());
                ////}
                if (rate != 0)
                {
                    #region if part
                    if (txtPSpotRate.Text == "" || txtPSpotRate.Text == "0.00" || txtPSpotRate.Text == "0")
                    {
                        amt = rate * Convert.ToDouble(txtCw.Text);
                    }
                    else
                    {
                        amt = Convert.ToDouble(txtPSpotRate.Text) * Convert.ToDouble(txtCw.Text);
                    }
                    TextBox rout = new TextBox();
                    rout.Attributes.Add("id", "rout_" + i.ToString());
                    trCells[0].Controls.Add(rout);
                    //trCells[1].Text = route[i];
                    //trCells[2].Text = route[i + 1];

                    TextBox origin = new TextBox();
                    origin.Attributes.Add("id", "origin_" + i.ToString());
                    origin.Text = ddlOrigin.SelectedItem.Text.Split('-')[0];
                    trCells[1].Controls.Add(origin);//route[i];

                    TextBox destination = new TextBox();
                    destination.Attributes.Add("id", "destination_" + i.ToString());
                    destination.Text = ddlDestination.SelectedItem.Text.Split('-')[0];
                    trCells[2].Controls.Add(destination);//route[i];

                    //trCells[2].Text = ddlDestination.SelectedItem.Text.Split('-')[0];//route[i + 1];
                    TextBox rateTextBox = new TextBox();
                    rateTextBox.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false)");
                    ////if (rbtnRouteType2.Checked)
                    ////{
                    ////    if (route[i] == "MIA" || route[i] == "AMS" || route[i] == "JFK")
                    ////    {
                    ////        txtPRate.Text = Convert.ToString(rate);
                    ////        txtPAmount.Text = Convert.ToString(Math.Round(amt, 2));
                    ////        rateTextBox.Attributes.Add("onFocusOut", "ChangePrinciple(this.id)");
                    ////    }
                    ////    else
                    ////    {
                    ////        rateTextBox.Attributes.Add("onFocusOut", "CalculateAmt(this.id)");
                    ////    }
                    ////}
                    ////if (rbtnRouteType1.Checked)
                    ////{
                    ////    //sum rate and amount
                    ////    sumRate += rate;
                    ////    sumAmt += amt;
                    ////    txtPRate.Text = Convert.ToString(sumRate);
                    ////    txtPAmount.Text = Convert.ToString(Math.Round(sumAmt, 2));
                    ////    rateTextBox.Attributes.Add("onFocusOut", "InterlineCalculateRateAmt(this.id)");
                    ////}
                    rateTextBox.Attributes.Add("id", "Rate_" + i.ToString());
                    rateTextBox.Text = Convert.ToString(rate);
                    trCells[3].Controls.Add(rateTextBox);
                    TextBox amtTextBox = new TextBox();
                    amtTextBox.Attributes.Add("id", "Amt_" + i.ToString());
                    amtTextBox.Enabled = false;
                    amtTextBox.Text = Convert.ToString(Math.Round(amt, 2));
                    trCells[4].Controls.Add(amtTextBox);
                    TextBox FlightNo = new TextBox();
                    FlightNo.Attributes["class"] = "text";
                    trCells[5].Controls.Add(FlightNo);
                    TextBox flightDate = new TextBox();
                    flightDate.Attributes["class"] = "date-pick dp-applied";
                    trCells[6].Controls.Add(flightDate);

                    DropDownList currency = new DropDownList();
                    currency.DataSource = dtCurrency;
                    currency.Attributes["class"] = "text";
                    currency.DataTextField = "Currency";
                    currency.DataValueField = "Currency";
                    currency.DataBind();
                    currency.SelectedValue = "USD";
                    trCells[7].Controls.Add(currency);

                    DropDownList couriers = new DropDownList();
                    couriers.Attributes["class"] = "text";
                    couriers.DataSource = dtCarrier;
                    couriers.DataTextField = "CarrierName";
                    couriers.DataValueField = "CarrierName";
                    couriers.DataBind();
                    couriers.SelectedValue = "--Select--";
                    trCells[8].Controls.Add(couriers);

                    tr.Cells.AddRange(trCells);
                    table.Rows.Add(tr);
                    rate = 0;
                    #endregion
                }
                else
                {
                    #region else  part

                    TextBox rout = new TextBox();
                    rout.Attributes.Add("id", "rout_" + i.ToString());
                    trCells[0].Controls.Add(rout);

                    TextBox origin = new TextBox();
                    origin.Attributes.Add("id", "origin_" + i.ToString());
                    origin.Text = ddlOrigin.SelectedItem.Text.Split('-')[0];
                    trCells[1].Controls.Add(origin);//route[i];

                    //trCells[1].Text = ddlOrigin.SelectedItem.Text.Split('-')[0];//route[i];

                    TextBox destination = new TextBox();
                    destination.Attributes.Add("id", "destination_" + i.ToString());
                    destination.Text = ddlDestination.SelectedItem.Text.Split('-')[0];
                    trCells[2].Controls.Add(destination);//route[i];
                    //trCells[2].Text = ddlDestination.SelectedItem.Text.Split('-')[0];//route[i + 1];
                    TextBox rateTextBox = new TextBox();
                    rateTextBox.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false)");
                    ////if (rbtnRouteType2.Checked)
                    ////{
                    ////    if (route[i] == "MIA" || route[i] == "AMS" || route[i] == "JFK")
                    ////    {
                    ////        rateTextBox.Attributes.Add("onFocusOut", "ChangePrinciple(this.id)");
                    ////    }
                    ////    else
                    ////    {
                    ////        rateTextBox.Attributes.Add("onFocusOut", "CalculateAmt(this.id)");
                    ////    }
                    ////}
                    ////if (rbtnRouteType1.Checked)
                    ////{
                    ////    rateTextBox.Attributes.Add("onChange", "InterlineCalculateRateAmt(this.id)");
                    ////}
                    rateTextBox.Attributes.Add("id", "Rate_" + i.ToString());
                    rateTextBox.Text = "0";
                    trCells[3].Controls.Add(rateTextBox);
                    TextBox amtTextBox = new TextBox();
                    amtTextBox.Text = "0";
                    amtTextBox.Attributes.Add("id", "Amt_" + i.ToString());
                    amtTextBox.Enabled = false;
                    trCells[4].Controls.Add(amtTextBox);

                    TextBox FlightNo = new TextBox();
                    FlightNo.Attributes["class"] = "text";
                    trCells[5].Controls.Add(FlightNo);

                    TextBox flightDate = new TextBox();
                    flightDate.Attributes["class"] = "date-pick dp-applied";
                    trCells[6].Controls.Add(flightDate);

                    DropDownList currency = new DropDownList();
                    currency.Attributes["class"] = "text";
                    currency.DataSource = dtCurrency;
                    currency.DataTextField = "Currency";
                    currency.DataValueField = "Currency";
                    currency.DataBind();
                    currency.SelectedValue = "USD";
                    trCells[7].Controls.Add(currency);

                    DropDownList couriers = new DropDownList();
                    couriers.Attributes["class"] = "text";
                    couriers.DataSource = dtCarrier;
                    couriers.DataTextField = "CarrierName";
                    couriers.DataValueField = "CarrierName";
                    couriers.DataBind();
                    couriers.SelectedValue = "--Select--";
                    trCells[8].Controls.Add(couriers);

                    tr.Cells.AddRange(trCells);
                    table.Rows.Add(tr);
                    table.Rows.Add(tr);
                    #endregion
                }
                //phRouteDetail.Controls.Clear();
                phRouteDetail.Controls.Add(table);
                Session["table"] = table;
            }   
    }
    public string[] GenerateRoute()
    {

        return (lblOrigin.Text + "-" + txtCenturionRoute.Text.Trim() + "-" + lblDestination.Text).ToUpper().Split('-');

        ////if (rbtnGateWay.SelectedValue.Trim().ToUpper() == "JFK")//rbtnGateWay.SelectedValue.Trim()
        ////{
        ////    string middleroute = "";
        ////    foreach (string origin in txtCenturionRoute.Text.Trim().ToUpper().Split('-'))
        ////    {
        ////        if (IsGateway(origin))
        ////        {
        ////            middleroute += "-" + origin;
        ////        }
        ////        else
        ////        {
        ////            middleroute += "";
        ////        }

        ////    }
        ////    return (lblOrigin.Text + middleroute + "-" + lblDestination.Text).ToUpper().Split('-');
        ////}
        ////else
        ////{
        ////    return (lblOrigin.Text + "-" + rbtnGateWay.SelectedValue.Trim() + "-" + lblDestination.Text).ToUpper().Split('-');
        ////    //rbtnGateWay.SelectedValue.Trim()
        ////}
    }
    public Boolean IsGateway(string originCode)
    {
        Boolean bit = false;
        using (con = new SqlConnection(strCon))
        {
            con.Open();
            com = new SqlCommand("spAK_PH_IsGateway", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Origin", originCode);
            bit = Convert.ToBoolean(com.ExecuteScalar());
            return bit;
        }

    }
    //public void fillddl()
    //{
    //    DataTable dt = dw.GetAllFromQuery("SELECT CarrierName,CarrierCode FROM db_owner.tblCarrier");
    //    if (dt.Rows.Count > 0)
    //    {
    //        selCarrier.DataSource = dt;
    //        selCarrier.DataTextField = "CarrierCode";
    //        selCarrier.DataValueField = "CarrierCode";
    //        //selCarrier.Items.Insert(0, new ListItem("--Select--", "0"));
    //        //selCarrier.SelectedValue = "0";
    //        selCarrier.DataBind();
    //    }
    //}
    //fill Buying Roue Details on Sales Edit
    public void FillBuyingRouteDetails()
    {
        string stockID = "", chwt = "", interline = "",carrier="";
        DataTable dtSales = dw.GetAllFromQuery("SELECT stock_id,Charged_Weight,Interline,Carrier  FROM Sales where Sales_ID=" + Request.QueryString["Sales_ID"].ToString());
        if (dtSales.Rows.Count > 0)
        {
            stockID = dtSales.Rows[0]["stock_id"].ToString();
            chwt = dtSales.Rows[0]["Charged_Weight"].ToString();
            interline = dtSales.Rows[0]["Interline"].ToString();
            carrier = dtSales.Rows[0]["Carrier"].ToString();
        }
        DataTable dt = dw.GetAllFromQuery("SELECT Stock_ID,AirwayBill_no,Flight_No,CONVERT(VARCHAR,Flight_Date,103) AS Flight_Date,Origin_Code,Destination_Code ,Currency,Rate,Amount FROM db_owner.Sales_Trans WHERE Stock_ID=" + stockID);
        if (dt.Rows.Count > 0)
        {
            GenerateRouteTable(dt, chwt,interline,carrier);
        }
    }    
    //Generate Buying Detail Dynamic Route table For Edit
    public void GenerateRouteTable(DataTable dt, string chwt, string interline, string carrier)
    {
        Table table = new Table();
        table.Attributes["border"] = "1";
        table.Attributes["width"] = "90%";
        table.Attributes["cellSpacing"] = "0";
        table.Attributes["cellPadding"] = "0";
        table.Attributes["style"] = "margin:10px 10px 10px 10px; ";
        DataTable dtCurrency = dw.GetAllFromQuery("SELECT DISTINCT CurrencyCode as Currency FROM dbo.CurrencyMaster");
        
       
        TableHeaderRow headerRow = new TableHeaderRow();
        TableCell[] headerCells = new TableCell[7];
        for (int i = 0; i <= headerCells.Length - 1; i++)
        {
            headerCells[i] = new TableCell();
        }
        headerCells[0].Text = "Origin";
        headerCells[1].Text = "Destination";
        headerCells[2].Text = "Rate";
        headerCells[3].Text = "Amount";
        headerCells[4].Text = "Flight No";
        headerCells[5].Text = "Flight Date";
        headerCells[6].Text = "Currency";
        headerRow.Cells.AddRange(headerCells);
        table.Rows.Add(headerRow);
        table.ID = "dynamicRouteTable";
        double amt = 0;
        foreach (DataRow rw in dt.Rows)
        {
            TableRow tr = new TableRow();
            TableCell[] trCells = new TableCell[7];
            for (int j = 0; j <= trCells.Length - 1; j++)
            {
                trCells[j] = new TableCell();
            }

            //DataTable dtRate = dw.GetAllFromQuery("SELECT psr.Price_Value as Rate FROM db_owner.Principle_Rate_Master arm INNER JOIN db_owner.Destination_Master dm ON arm.Destination=dm.Destination_ID INNER JOIN dbo.City_Master cm ON cm.City_ID=arm.Origin inner join db_owner.Principle_Slab_Rate psr on psr.Rate_id=arm.Rate_ID inner join  db_owner.Slab_Master sm on sm.Slab_id=psr.Slab_id where " + chwt + " BETWEEN sm.Slab_Start AND sm.Slab_End and psr.airline_detail_id = (select top 1 ad.airline_detail_id from airline_detail ad inner join airline_master am on am.airline_id=ad.airline_id inner join city_master cm on ad.belongs_to_city=cm.city_id where am.airline_code='" + AwbCode + "' and cm.city_code='" + rw["Origin_Code"].ToString() + "') and dm.destination_code='" + rw["Destination_Code"].ToString() + "' and cm.city_code='" + rw["Origin_Code"].ToString() + "'");
            //if (dtRate.Rows.Count > 0)
            //    rate = Convert.ToDouble(dtRate.Rows[0][0].ToString());

            amt = Convert.ToDouble(rw["Amount"].ToString());
            trCells[0].Text = rw["Origin_Code"].ToString();
            trCells[1].Text = rw["Destination_Code"].ToString();
            //trCells[2].Text = Convert.ToString(rw["Rate"]);
            TextBox rateTextBox = new TextBox();
            rateTextBox.Attributes.Add("onkeypress", "return blockNonNumbers(this,event,2,false)");
            //Non-Interline
            if (interline.Trim().ToUpper() == "N")
            {
                if (rw["Origin_Code"].ToString() == "MIA" || rw["Origin_Code"].ToString() == "AMS" || rw["Origin_Code"].ToString() == "JFK")
                {
                    rateTextBox.Attributes.Add("onFocusOut", "ChangePrinciple(this.id)");
                }
                else
                {
                    rateTextBox.Attributes.Add("onFocusOut", "CalculateAmt(this.id)");
                }
            }
            //interline
            if (interline.Trim().ToUpper() == "Y")
            {
                //sum rate and amount
                rateTextBox.Attributes.Add("onFocusOut", "InterlineCalculateRateAmt(this.id)");
            }
            rateTextBox.Attributes.Add("id", "Rate_" + dt.Rows.IndexOf(rw).ToString());
            rateTextBox.Text = Convert.ToString(rw["Rate"]);
            trCells[2].Controls.Add(rateTextBox);
            //trCells[3].Text = Convert.ToString(Math.Round(amt, 2));
            TextBox amtTextBox = new TextBox();
            amtTextBox.Text = Convert.ToString(rw["Amount"]);
            amtTextBox.Attributes.Add("id", "Amt_" + dt.Rows.IndexOf(rw).ToString());
            amtTextBox.Attributes["disabled"] = "disabled";
            trCells[3].Controls.Add(amtTextBox);
            TextBox flightNo = new TextBox();
            flightNo.Text = rw["Flight_No"].ToString();
            flightNo.TabIndex = 32;
            trCells[4].Controls.Add(flightNo);
            TextBox flightDate = new TextBox();
            flightDate.TabIndex = 33;
            flightDate.Text = rw["Flight_Date"].ToString();
            flightDate.Attributes["class"] = "date-pick dp-applied";
            trCells[5].Controls.Add(flightDate);

            DropDownList currency = new DropDownList();
            currency.TabIndex = 34;
            currency.Attributes["class"] = "text";
            currency.DataSource = dtCurrency;
            currency.DataTextField = "Currency";
            currency.DataValueField = "Currency";
            currency.DataBind();
            currency.SelectedValue = rw["Currency"].ToString();
            trCells[6].Controls.Add(currency);
            tr.Cells.AddRange(trCells);
            table.Rows.Add(tr);          
        }
        phRouteDetail.Controls.Clear();
        phRouteDetail.Controls.Add(table);      
    }
    public void InsertSalesTrans(SqlTransaction trans, SqlConnection con)
    {
        ////if (ViewState["Stock_ID"] != null && Request.QueryString["Sales_ID"] != null)
        ////{
        ////    com = new SqlCommand("DELETE FROM db_owner.Sales_Trans WHERE Stock_ID=" + ViewState["Stock_ID"].ToString(), con, trans);
        ////    com.ExecuteNonQuery();
        ////}
        ////try
        ////{

        ////    if (phRouteDetail.Controls.Count > 0)
        ////    {
        ////        ////////Table dynamicTable = (Table)phRouteDetail.FindControl("dynamicRouteTable");

        ////        Table dynamicTable = (Table)Session["table"];
        ////        if (dynamicTable != null)
        ////        {
        ////            int r = 1;
        ////            foreach (TableRow tr in dynamicTable.Rows)
        ////            {
        ////                if (r != 1)
        ////                {
        ////                    com = new SqlCommand("INSERT INTO db_owner.Sales_Trans( Stock_ID ,AirwayBill_no ,Flight_No ,Flight_Date ,Origin_Code,Destination_Code ,Currency ,Rate ,Amount,Carrier,Route,Airline_detail_id)VALUES  ( (SELECT TOP 1 Stock_ID FROM dbo.Stock_Master WHERE AirWayBill_No=@AirwayBill_no),@AirwayBill_no,@Flight_No,@Flight_Date,@Origin_Code,@Destination_Code,@Currency,@Rate,@Amount,@Carrier,@Route,@Airline_detail_id)", con, trans);//spCenturionCargo_InsertSalesTrans
        ////                    //com.CommandType = CommandType.StoredProcedure;
        ////                    com.Parameters.AddWithValue("@AirwayBill_no", ddlAwbNo.SelectedItem.Text);
        ////                    com.Parameters.AddWithValue("@Origin_Code", tr.Cells[1].Text);//for Origin
        ////                    com.Parameters.AddWithValue("@Destination_Code", tr.Cells[2].Text);// For Destination    
        ////                    if (tr.Cells[2].HasControls())
        ////                    {
        ////                        com.Parameters.AddWithValue("@Rate", Convert.ToDouble(((TextBox)tr.Cells[3].Controls[0]).Text));//Rate
        ////                    }
        ////                    else
        ////                    {
        ////                        com.Parameters.AddWithValue("@Rate", Convert.ToDouble(tr.Cells[3].Text));//Rate
        ////                    }
        ////                    double amt = Convert.ToDouble(((TextBox)tr.Cells[3].Controls[0]).Text) * Convert.ToDouble(txtCw.Text);
        ////                    if (tr.Cells[4].HasControls())
        ////                    {
        ////                        com.Parameters.AddWithValue("@Amount", amt);//amount
        ////                    }
        ////                    else
        ////                    {
        ////                        com.Parameters.AddWithValue("@Amount", amt);//amount
        ////                    }
        ////                    com.Parameters.AddWithValue("@Flight_No", ((TextBox)tr.Cells[5].Controls[0]).Text);//flight No
        ////                    com.Parameters.AddWithValue("@Flight_Date", FormatDateMM(((TextBox)tr.Cells[6].Controls[0]).Text));//flight_Date
        ////                    com.Parameters.AddWithValue("@Currency", ((DropDownList)tr.Cells[7].Controls[0]).SelectedValue);//currency

        ////                    com.Parameters.AddWithValue("@Carrier", ((TextBox)tr.Cells[8].Controls[0]).Text);//Carrier

        ////                    com.Parameters.AddWithValue("@Route", ((TextBox)tr.Cells[0].Controls[0]).Text);//Carrier

        ////                    com.Parameters.AddWithValue("@Airline_Detail_id", Convert.ToInt64(ddlAirline.SelectedValue));//Carrier
        ////                    com.ExecuteNonQuery();
        ////                }
        ////                r++;
        ////            }
        ////            Session["table"] = null;

        ////        }
        ////    }

        ////}
        ////catch (SqlException ex)
        ////{

        ////}


        string insert;
        //con = new SqlConnection(strCon);
        DataTable dtDimension = new DataTable();
        if (Session["dtTemp"] != null)
        {

            com = new SqlCommand("DELETE FROM db_owner.Sales_Trans WHERE Stock_ID=" + ViewState["Stock_ID"].ToString(), con, trans);
            com.ExecuteNonQuery();
            com.Dispose();
            

            dtDimension = (DataTable)Session["dtTemp"];

            for (int i = 0; i < dtDimension.Rows.Count; i++)
            {

                insert = "INSERT INTO db_owner.Sales_Trans( Stock_ID ,AirwayBill_no ,Flight_No ,Flight_Date ,Origin_Code,Destination_Code ,Currency ,Rate ,Amount,Carrier,Route,Airline_detail_id)VALUES  ( (SELECT TOP 1 Stock_ID FROM dbo.Stock_Master WHERE AirWayBill_No=@AirwayBill_no),@AirwayBill_no,@Flight_No,@Flight_Date,@Origin_Code,@Destination_Code,@Currency,@Rate,@Amount,@Carrier,@Route,@Airline_detail_id)";

                SqlCommand com1 = new SqlCommand(insert, con, trans);
                com1.CommandType = CommandType.Text;
                com1.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = Convert.ToInt32(ViewState["Stock_ID"].ToString());
                com1.Parameters.Add("@AirwayBill_no", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text;
                com1.Parameters.Add("@Origin_Code", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Origin_Code"].ToString();
                com1.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Destination_Code"].ToString();
                com1.Parameters.Add("@Rate", SqlDbType.Decimal).Value = Convert.ToDecimal(dtDimension.Rows[i]["Rate"].ToString());
                com1.Parameters.Add("@Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(Convert.ToDecimal(dtDimension.Rows[i]["Rate"].ToString()) * Convert.ToDecimal(txtCw.Text));
                com1.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Flight_No"].ToString();
                com1.Parameters.Add("@Flight_Date", SqlDbType.Date).Value = Convert.ToDateTime(FormatDateDD(dtDimension.Rows[i]["Flight_Date"].ToString()));
                com1.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Currency"].ToString();
                com1.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Carrier"].ToString();
                com1.Parameters.Add("@Route", SqlDbType.VarChar).Value = dtDimension.Rows[i]["Route"].ToString();
                com1.Parameters.Add("@Airline_Detail_id", SqlDbType.Int).Value = Convert.ToInt64(ddlAirline.SelectedValue);
               com1.ExecuteNonQuery();
            }
        }


    }
    protected void btnChangePrincipal_Click(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtPRate.Text = hdnRate.Value;
            if (txtPSpotRate.Text == "" || txtPSpotRate.Text == "0.00" || txtPSpotRate.Text == "0")
            {
                txtPAmount.Text = hdnAmt.Value;
            }
        }

    }
    public void SetPrincipalToDefault()
    {
        txtPRate.Text = "0";

        if (txtPSpotRate.Text == "" || txtPSpotRate.Text == "0.00" || txtPSpotRate.Text == "0")
        {
            txtPAmount.Text = "0";
        }
    }
    //================================================End==========================================
    protected DataTable MakeTableCharges()
    {
        DataTable dt = new DataTable();
        DataColumn dc = new DataColumn();
        dc.ColumnName = "Sno";
        dc.AutoIncrement = true;
        dc.AutoIncrementStep = 1;
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "FeeName";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "Fee";
        dc.DataType = System.Type.GetType("System.Int32");
        dt.Columns.Add(dc);
        dc = new DataColumn();
        dc.ColumnName = "PaymentType";
        dc.DataType = System.Type.GetType("System.String");
        dt.Columns.Add(dc);
        DataRow dr = dt.NewRow();
        dr[0] = "0";
        dr[1] = "0";
        dr[2] = "0";
        dr[3] = "0";
        dt.Rows.Add(dr);
        //*******Added on 3 may 2011(Only to show zero on displaying grd-grid)*********
        Session["dtdisplayChargesZero"] = dt;
        //********End***********************

        return dt;
        //Session["dtOtherCharges"] = dt;
        //ViewState["dtBeginCharges"] = dt;

    }
    protected void grdCal_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grdCal.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblmsg.Visible = true;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }
        else
        {
            lblmsg.Visible = false;
            grdCal.EditIndex = e.NewEditIndex;
            grdCal.DataSource = (DataTable)Session["dtTemp"];
            grdCal.DataBind();
        }

    }
    protected void grdCal_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        int Sno = Convert.ToInt32(grdCal.DataKeys[e.RowIndex].Value);
        string str = "";
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                dt.Rows[e.RowIndex].Delete();
                ////int Pieces = 0;
                ////decimal VoulmeWt = 0;
                ////foreach (DataRow rw in dt.Rows)
                ////{
                ////    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                ////    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                ////}
                ////str = Pieces.ToString() + "/" + VoulmeWt.ToString();
                ////txtPieces.Text = Pieces.ToString();
                ////if (txtGw.Text != "")
                ////{
                ////    txtVolwt.Text = VoulmeWt.ToString();
                ////    if (decimal.Parse(txtGw.Text) > VoulmeWt)
                ////    {
                ////        txtCw.Text = txtGw.Text;
                ////    }
                ////    else
                ////    {
                ////        txtCw.Text = VoulmeWt.ToString();
                ////    }
                ////}
                ////else
                ////{
                ////    txtVolwt.Text = VoulmeWt.ToString();
                ////}
                break;
            }
        }
        if (dt.Rows.Count > 0)
        {
            Session["dtTemp"] = dt;
            grdCal.DataSource = dt;
            grdCal.DataBind();
            ///////((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
        }
        else
        {
            maketable();
            DataTable dtBeginCharges = (DataTable)ViewState["dtBeginCharges"];
            Session["dtTemp"] = dtBeginCharges;
            grdCal.DataSource = dtBeginCharges;
            grdCal.DataBind();
        }


    }
    protected void grdCal_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtTemp"];
        //string [] Key = {"SNo"}; 
        //grdCal.DataKeyNames = Key;
        //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames
        // int SNo = Convert.ToInt16(((TextBox)grdCal.FindControl("txtSNo")).Text);

        /////Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtl")).Text);
        int SNo = Convert.ToInt16(grdCal.DataKeys[e.RowIndex].Value);
        string L = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtl")).Text;
        string W = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtw")).Text;
        string H =((TextBox)grdCal.Rows[e.RowIndex].FindControl("txth")).Text;
        decimal P = Convert.ToDecimal(((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtp")).Text);

        string fltno = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtfltno")).Text;

        string fltdt = ((TextBox)grdCal.Rows[e.RowIndex].FindControl("txtfltdt")).Text;

        string Carrier = ((DropDownList)grdCal.Rows[e.RowIndex].FindControl("ddlcarr")).SelectedValue;

        string Currency = ((DropDownList)grdCal.Rows[e.RowIndex].FindControl("ddlCurr")).SelectedValue;
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["SNo"].ToString() == SNo.ToString())
            {
                dr[1] = L;
                dr[2] = W;
                dr[3] = H;
                dr[4] = P;
                dr[5] = fltno;
                dr[6] = fltdt;
                dr[7] = Carrier;
                dr[8] = Currency;
                //////dt.Rows.Add(dr);
            }
        }


        // decimal V = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("lblv")).Text);

        // Calculatin Volume Wait
        ////decimal Volume_Wt;

        ////if (rbCal.SelectedValue == "Cm")
        ////{
        ////    Volume_Wt = (L * W * H * P) / 6000;
        ////}
        ////else
        ////{
        ////    Volume_Wt = (L * W * H * P) / 366;

        ////}
        ////foreach (DataRow dr in dt.Rows)
        ////{
        ////    if (dr["SNo"].ToString() == SNo.ToString())
        ////    {
        ////        dr[1] = L;
        ////        dr[2] = W;
        ////        dr[3] = H;
        ////        dr[4] = P;
        ////        dr[5] = Math.Round(Volume_Wt, 3);
        ////    }
        ////}

        //////txtVolWt.Value = Convert.ToString(Math.Round(Volume_Wt, 2));
        ////if (txtGw.Text != "")
        ////{
        ////    Volume_Wt = Math.Round(Volume_Wt, 3);
        ////    txtVolwt.Text = Volume_Wt.ToString();
        ////    if (decimal.Parse(txtGw.Text) > Volume_Wt)
        ////    {
        ////        txtCw.Text = txtGw.Text;
        ////    }
        ////    else
        ////    {
        ////        Volume_Wt = Math.Round(Volume_Wt, 3);
        ////        txtCw.Text = Volume_Wt.ToString();
        ////    }
        ////}
        ////else
        ////{
        ////    Volume_Wt = Math.Round(Volume_Wt, 3);
        ////    txtVolwt.Text = Volume_Wt.ToString();
        ////}
        //ViewState["Volume_Wt"] = Convert.ToString(Math.Round(Volume_Wt, 2));
        Session["dtTemp"] = dt;
        grdCal.EditIndex = -1;
        grdCal.DataSource = dt;
        grdCal.DataBind();

        ////int Pieces = 0;
        ////decimal VoulmeWt = 0;
        ////foreach (DataRow rw in dt.Rows)
        ////{
        ////    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
        ////    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
        ////}
        ////string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
        ////txtPieces.Text = Pieces.ToString();
        ////VoulmeWt = Math.Round(VoulmeWt, 3);
        ////txtVolwt.Text = VoulmeWt.ToString();
        /////((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;
    }
    protected void grdCal_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCal.EditIndex = -1;
        grdCal.DataSource = (DataTable)Session["dtTemp"];
        grdCal.DataBind();
    }
    protected void grdCal_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            try
            {
                DataTable dt = (DataTable)Session["dtTemp"];
                if (dt.Rows[0]["SNo"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
                DataRow dr = dt.NewRow();
                //string strCustomerID = gvTemp.DataKeys[0].Value.ToString();  //Customer ID is stored as DataKeyNames
                ////Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtl")).Text)
                string L =((TextBox)grdCal.FooterRow.FindControl("txtl")).Text;
                string W = ((TextBox)grdCal.FooterRow.FindControl("txtw")).Text;
                string H = ((TextBox)grdCal.FooterRow.FindControl("txth")).Text;
                decimal P = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("txtp")).Text);

                string fltno = ((TextBox)grdCal.FooterRow.FindControl("txtfltno")).Text;
                string fltdt = ((TextBox)grdCal.FooterRow.FindControl("txtfltdt")).Text;
                string Carrier = ((DropDownList)grdCal.FooterRow.FindControl("ddlcarr")).SelectedValue;

                string Currency = ((DropDownList)grdCal.FooterRow.FindControl("ddlCurr")).SelectedValue;

                // decimal V = Convert.ToDecimal(((TextBox)grdCal.FooterRow.FindControl("lblv")).Text);

                // Calculatin Volume Wait
                ////decimal Volume_Wt;
                ////if (rbCal.SelectedValue == "Cm")
                ////{
                ////    Volume_Wt = (L * W * H * P) / 6000;
                ////}
                ////else
                ////{
                ////    Volume_Wt = (L * W * H * P) / 366;
                ////}


                //Prepare the Insert Command of the DataSource control
                dr[1] = L;
                dr[2] = W;
                dr[3] = H;
                dr[4] = P;
                dr[5] = fltno;
                dr[6] = fltdt;
                dr[7] = Carrier;
                dr[8] = Currency;
                dt.Rows.Add(dr);

                Session["dtTemp"] = dt;
                grdCal.DataSource = dt;
                grdCal.DataBind();
                ////int Pieces = 0;
                ////decimal VoulmeWt = 0;
                ////foreach (DataRow rw in dt.Rows)
                ////{
                ////    Pieces = Pieces + int.Parse(rw["Pieces"].ToString());
                ////    VoulmeWt = VoulmeWt + decimal.Parse(rw["Volume Wt"].ToString());
                ////}
                ////string str = Pieces.ToString() + "/" + VoulmeWt.ToString();
                ////txtPieces.Text = Pieces.ToString();
                ////if (txtGw.Text != "")
                ////{
                ////    VoulmeWt = Math.Round(VoulmeWt, 3);
                ////    txtVolwt.Text = VoulmeWt.ToString();
                ////    if (decimal.Parse(txtGw.Text) > VoulmeWt)
                ////    {
                ////        txtCw.Text = txtGw.Text;
                ////    }
                ////    else
                ////    {
                ////        VoulmeWt = Math.Round(VoulmeWt, 3);
                ////        txtCw.Text = VoulmeWt.ToString();
                ////    }
                ////}
                ////else
                ////{
                ////    VoulmeWt = Math.Round(VoulmeWt, 3);
                ////    txtVolwt.Text = VoulmeWt.ToString();
                ////}

                //ViewState["Volume_Wt"]=VoulmeWt.ToString();
                ////Session["dtTemp"] = dt;
                ////grdCal.DataSource = dt;
                ////grdCal.DataBind();
                ///////((Label)grdCal.FooterRow.FindControl("lblv")).Text = str;

                //ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('Order added successfully');</script>");
                //string s1 = "SELECT Fltno,hh,mm,fltdate,id FROM ac_fltDetails_tran ORDER BY fltno";
                //AccessDataSource1.SelectCommand = s1;


                //GridViewRow gv = GridView2.Rows[0];
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonEdit"))).Visible = false;
                //((LinkButton)(gv.Cells[4].FindControl("LinkButtonDelete"))).Visible = false;

                //fill();


            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(GetType(), "Message", "<SCRIPT LANGUAGE='javascript'>alert('" + ex.Message.ToString().Replace("'", "") + "');</script>");
            }
        }
    }
    protected void grdCal_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdCal_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow && grdCal.EditIndex == e.Row.RowIndex)
        {
            //Label ddlcarr = (e.Row.FindControl("lblcarr") as Label);
            DropDownList ddlcarr = (e.Row.FindControl("ddlcarr") as DropDownList);
            ddlcarr.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            ddlcarr.DataTextField = "CarrierCode";
            ddlcarr.DataValueField = "CarrierCode";
            ddlcarr.DataBind();
            //Add Default Item in the DropDownList.
            // Label lblcarr = (e.Row.FindControl("lblcarr") as Label);
            // HiddenField hfStatus = (e.Row.FindControl("hfcarr") as HiddenField);
            // string selectedCarrier = (e.Row.FindControl("lblcarr") as Label).Text;//DataBinder.Eval(e.Row.DataItem, "CarrierCode").ToString();
            string Carrier = (e.Row.DataItem as DataRowView)["Carrier"].ToString();
            ddlcarr.Items.FindByValue(Carrier).Selected = true;


            //Bind Currency
            DropDownList ddlcarrency = (e.Row.FindControl("ddlCurr") as DropDownList);
            ddlcarrency.DataSource = GetData("select Sno,CurrencyCode from CurrencyMaster order by CurrencyCode");
            ddlcarrency.DataTextField = "CurrencyCode";
            ddlcarrency.DataValueField = "CurrencyCode";
            ddlcarrency.DataBind();
            // ddlcarrency.Items.Insert(0, new ListItem("Please select"));
            //Add Default Item in the DropDownList.
            //string selectedcurrency = (e.Row.FindControl("ddlCurr") as DropDownList).SelectedItem.Text;//DataBinder.Eval(e.Row.DataItem, "CarrierCode").ToString();
            //ddlcarrency.Items.FindByValue(selectedcurrency).Selected = true;
            string selectedcurrency = (e.Row.DataItem as DataRowView)["Currency"].ToString();
            ddlcarrency.Items.FindByValue(selectedcurrency).Selected = true;

            /////////
            total += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "rate"));//
            txtPRate.Text = Convert.ToString(total);
            // txtlength.Attributes.Add("onkeypress", " javascript: return confirm('Are you sure to Cancel? ')");
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            DropDownList ddlcarr = (e.Row.FindControl("ddlcarr") as DropDownList);
            ddlcarr.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            ddlcarr.DataTextField = "CarrierCode";
            ddlcarr.DataValueField = "CarrierCode";
            ddlcarr.DataBind();
            //Add Default Item in the DropDownList.
            ddlcarr.Items.Insert(0, new ListItem("Please select"));


            //Bind Currency
            DropDownList ddlcarrency = (e.Row.FindControl("ddlCurr") as DropDownList);
            ddlcarrency.DataSource = GetData("select Sno,CurrencyCode from CurrencyMaster order by CurrencyCode");
            ddlcarrency.DataTextField = "CurrencyCode";
            ddlcarrency.DataValueField = "CurrencyCode";
            ddlcarrency.DataBind();
            ddlcarrency.Items.Insert(0, new ListItem("Please select"));

            /////////
            total += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "rate"));//Convert.ToInt32(((TextBox)grdCal.FooterRow.FindControl("txtp")).Text);;//
            txtPRate.Text = Convert.ToString(total);
            // txtlength.Attributes.Add("onkeypress", " javascript: return confirm('Are you sure to Cancel? ')");
        }

    }
    protected void lnkCal_Click(object sender, EventArgs e)
    {
        grdCal.Visible = true;
        rbCal.Visible = true;
    }
  
    #region Insert_BookingDimesion
    public void Insert_BookingDimesion(SqlTransaction tr, SqlConnection con, long SalesID)
    {
        //string insert;
        ////con = new SqlConnection(strCon);
        //DataTable dtDimension = new DataTable();
        //if (Session["dtTemp"] != null)
        //{
        //    dtDimension = (DataTable)Session["dtTemp"];

        //    for (int i = 0; i < dtDimension.Rows.Count; i++)
        //    {

        //        insert = "insert into Sales_Dimensions(Sales_ID,No_of_Packages,Length,Breadth,Height,Total,Measurement_Unit) values(@Sales_ID,@No_of_Packages,@Length,@Breadth,@Height,@Total,@Measurement_Unit)";

        //        SqlCommand com = new SqlCommand(insert, con, tr);
        //        com.CommandType = CommandType.Text;
        //        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        //        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = dtDimension.Rows[i]["Pieces"].ToString();
        //        com.Parameters.Add("@Length", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Length"].ToString();
        //        com.Parameters.Add("@Breadth", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Width"].ToString();
        //        com.Parameters.Add("@Height", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Height"].ToString();
        //        com.Parameters.Add("@Total", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Volume Wt"].ToString();
        //        if (rbCal.SelectedValue == "")
        //        {
        //            com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = "CM";
        //        }
        //        else
        //        {
        //            com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = rbCal.SelectedValue;
        //        }
        //        com.ExecuteNonQuery();
        //    }
        //}
    }
    #endregion
    #region Update_BookingDimesion
    public void Update_BookingDimesion(SqlTransaction tr, SqlConnection con, long SalesID)
    {
        string update;

        DataTable dtDimension = new DataTable();
        if (Session["dtTemp"] != null)
        {
            dtDimension = (DataTable)Session["dtTemp"];

            for (int i = 0; i < dtDimension.Rows.Count; i++)
            {


                update = "update Sales_Dimensions set Sales_ID=@Sales_ID,No_of_Packages=@No_of_Packages,Length=@Length,Breadth=@Breadth,Height=@Height,Total=@Total,Measurement_Unit=@Measurement_Unit where Sales_ID=@Sales_ID";

                SqlCommand com = new SqlCommand(update, con, tr);
                com.CommandType = CommandType.Text;
                ////com.Parameters.Add("@Sales_Dimension_ID", SqlDbType.Int).Value = SalesID;
                com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
                com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = dtDimension.Rows[i]["Pieces"].ToString();
                com.Parameters.Add("@Length", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Length"].ToString();
                com.Parameters.Add("@Breadth", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Width"].ToString();
                com.Parameters.Add("@Height", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Height"].ToString();
                com.Parameters.Add("@Total", SqlDbType.Decimal).Value = dtDimension.Rows[i]["Volume Wt"].ToString();
                if (rbCal.SelectedValue == "")
                {
                    com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = "CM";
                }
                else
                {
                    com.Parameters.Add("@Measurement_Unit", SqlDbType.VarChar).Value = rbCal.SelectedValue;
                }
                com.ExecuteNonQuery();

            }
        }
    }
    #endregion
//    public void FillSalesFields()
//    {
//        #region Gst Applicable
//        string agent_name = "";
//        DataTable dtagent = dw.GetAllFromQuery("select distinct Agent_Name from Sales s inner join Agent_master am on s.agent_id=am.agent_id where s.agent_id=" + ddlAgentName.SelectedValue + "");
//        if (dtagent != null && dtagent.Rows.Count > 0)
//        {
//            agent_name = dtagent.Rows[0]["Agent_Name"].ToString();
//            ViewState["Agent_ID"] = ddlAgentName.SelectedValue;
//            //////ddlAwbNo.SelectedItem.Text = dtagent.Rows[0]["Agent_Name"].ToString();
//        }

//        DataTable dtagentgstNo = new DataTable();
//        ddlGst.Items.Insert(0, "-Select-");
//        ddlGst.Items[0].Value = "0";
//        dtagentgstNo = dw.GetAllFromQuery("Select GstNo,Address from AgentGstNo where agentname like '" + ddlAgentName.SelectedItem.Text + "%'");
//        if (dtagentgstNo != null && dtagentgstNo.Rows.Count > 0)
//        {

//            for (int i = 0; i < dtagentgstNo.Rows.Count; i++)
//            {

//                ddlGst.Items.Add(new ListItem(dtagentgstNo.Rows[i]["GstNo"].ToString(), dtagentgstNo.Rows[i]["Address"].ToString()));
//            }
//        }





       
//        ///// GST Applicable
//        #endregion End of GstApplicable



//        Invtext.Visible = true;
//        InvValue.Visible = true;
//        string SalesID = "";
//        if (Request.QueryString["Sales_ID"] != null)
//        {
//            SalesID = Request.QueryString["Sales_ID"];
//        }
//        DateTime CurrentDate = DateTime.Now;
//        string strCurrentDate = CurrentDate.ToShortDateString();
//        txtCSRDate.Text = FormatDateDD(strCurrentDate);

//        //*****************Added On 28 Apr 2011   (Invoice No picked)  ******************
//        DataTable dtinvoice = dw.GetAllFromQuery("SELECT s.Invoice_No,ino.Prifix,ino.Fin_Year FROM db_owner.Invoice_No ino INNER JOIN db_owner.Sales s ON ino.SNo=s.Invoice_SNO WHERE Sales_ID=" + SalesID);
//       ////// lblInvoiceNo.Text = dtinvoice.Rows[0]["Prifix"].ToString() + "/" + dtinvoice.Rows[0]["Fin_Year"].ToString() + "/" + dtinvoice.Rows[0]["Invoice_No"].ToString();   

//        lblInvoiceNo.Text = "12334";

//        //******************End Of invoice No***************************
//        DataTable dtSales = dw.GetAllFromQuery("SELECT * FROM Sales where Sales_ID=" + SalesID);
//        if (dtSales.Rows.Count > 0)
//        {

//            txtGstNo.Text = dtSales.Rows[0]["GstNo"].ToString();
//            if (txtGstNo.Text != "")
//            {
//                txtGstNo.Enabled = true;
//                ddlGst.SelectedValue = dtSales.Rows[0]["GstNo"].ToString();
//                ddlGst.Enabled = true;
//            }
//            else
//            {
//                txtGstNo.Enabled = true;
//                ddlGst.Enabled = true;
//                ddlGst.SelectedValue = dtSales.Rows[0]["GstNo"].ToString();
//            }
//            txtGstAddr.Text = dtSales.Rows[0]["GstAddress"].ToString();
//            ddlGstStateCode.SelectedValue = dtSales.Rows[0]["StateCode"].ToString();





//            //*************************Added on 27 feb 2017 : Added new colum HB as Hard block shipment in PH system ************//

//            ddlHB.SelectedValue = dtSales.Rows[0]["HB"].ToString();

//            //************************End of HB shipment*************************************************************************//

//            //=========================Added By :Pradeep Sharma=================
//            #region if Route Available
//            if (phRouteDetail.Controls.Count > 0)
//            {            
              
//                //if (Convert.ToString(ViewState["GroupID"]) != "13" && dtSales.Rows[0]["AirWayBill_No"].ToString().Split('-')[0] == "307")
//                //{
//                if (dtSales.Rows[0]["AirWayBill_No"].ToString().Split('-')[0] == "435")
//                {
//                    trBuyingDetails.Visible = true; 
//                    trRoutingDetails.Visible = true;
//                    ////trhide.Visible = true;
                   
//                }
//                else
//                {
//                    trBuyingDetails.Visible = false; ;
//                    trRoutingDetails.Visible = false;
//                }
//                fillddl(dtSales.Rows[0]["Interline"].ToString());
//                   ///// Route_type.Visible = true;
//                    //////PnlCarrier.Visible = true;
//                    RouteEnter.Visible = true;
//                    lblOrigin.Text = dtSales.Rows[0]["City_Code"].ToString();
//                    txtCenturionRoute.Text = dtSales.Rows[0]["Inner_Route"].ToString().Substring(4, dtSales.Rows[0]["Inner_Route"].ToString().Length - 8);
//                    lblDestination.Text = dtSales.Rows[0]["Destination_Code"].ToString();
//                }
//            if (dtSales.Rows[0]["Gateway"].ToString().TrimEnd() != "N/A")
//                {
//                ///////////.Start:..........Mofify by Hemant Sharma on 8 Oct 2014.........///////////////////////////
//                   ///// rbtnGateWay.SelectedValue = dtSales.Rows[0]["Gateway"].ToString().TrimEnd();
//                    ///////////End:..........Mofify by Hemant Sharma on 8 Oct 2014.........///////////////////////////


//                    //for (int r = 0; r < rbtnGateWay.Items.Count; r++)
//                    //{
//                    //    if ((rbtnGateWay.Items[r].ToString()) == (dtSales.Rows[0]["Gateway"].ToString().TrimEnd()))
//                    //    {
//                    //        rbtnGateWay.SelectedIndex = r;
//                    //        break;

//                    //    }
//                    //    else if ((rbtnGateWay.Items[r].ToString()) == (dtSales.Rows[0]["Gateway"].ToString().TrimEnd()))
//                    //    {
//                    //        rbtnGateWay.SelectedIndex = r;
//                    //        break;
//                    //    }
//                    //    else if ((rbtnGateWay.Items[r].ToString()) == (dtSales.Rows[0]["Gateway"].ToString().TrimEnd()))
//                    //    {
//                    //        rbtnGateWay.SelectedIndex = r;
//                    //        break;
//                    //    }

//                    //} 
//                ////if (dtSales.Rows[0]["Interline"].ToString() == "Y")
//                ////    {
//                ////        selCarrier.SelectedValue = dtSales.Rows[0]["Carrier"].ToString();
//                ////        ////rbtnRouteType1.Checked = true;
//                ////    }
//                ////    else
//                ////    {
//                ////        selCarrier.SelectedValue = dtSales.Rows[0]["Carrier"].ToString();
//                ////        ////rbtnRouteType2.Checked = true;
//                ////    }
//                }        
                
//            }
//            #endregion

//            DataTable dtAirlineID = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + dtSales.Rows[0]["Airline_Detail_Id"].ToString() + "");
//            LoadACS();
//            ddlAgentName.SelectedValue = dtSales.Rows[0]["Agent_Id"].ToString();
//            ddlAgentName.Enabled = false;
//            LoadUserOrigin();
//            ddlOrigin.SelectedValue = dtSales.Rows[0]["City_ID"].ToString();
//            UserAirlineNamePlusCode();
//            ddlAirline.SelectedValue = dtSales.Rows[0]["Airline_Detail_Id"].ToString();
//            LoadDestination();
//            ddlDestination.SelectedValue = dtSales.Rows[0]["Destination_Id"].ToString();
//            txtRoute.Text = dtSales.Rows[0]["Routing"].ToString();
//            //////txtTruckchrgs.Text = dtSales.Rows[0]["Trucking_chrgs"].ToString();
//            //////txtTruckShareChrgs.Text = dtSales.Rows[0]["Truckingchrgs_Share"].ToString();
//            //////txtHandlingChrgs.Text = dtSales.Rows[0]["Handling_Chrgs"].ToString();
//            if (dtAirlineID.Rows[0]["Airline_ID"].ToString() == "2")
//            {
//                lblrate.Visible = false;
//                txtrate.Visible = false;
//            }
//            else
//            {

//                txtUSDToPHP.Text = dtSales.Rows[0]["ConversionRateToPHP"].ToString();

//            }
//            txtCSRRemarks.Text = dtSales.Rows[0]["csr_remarks"].ToString();
//            LoadFlight();
//         /////string temapVal = ddlAirline.SelectedItem.Text.Substring(0,9).TrimStart();

//            string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart();
//         if (temapVal == "PREMIER")
//        {      
           
//            ddlfltNo.SelectedItem.Text = dtSales.Rows[0]["flight_no"].ToString();
//            tdflighNo.Visible = false;
//            ddlfltNo.Visible = false;
//        }
//        else
//        {
//            ddlfltNo.SelectedItem.Text = dtSales.Rows[0]["flight_no"].ToString();
//            tdflighNo.Visible = true;
//            ddlfltNo.Visible = true;
//        }
//            LoadAgentStock();
//            ViewState["Stock_ID"] = dtSales.Rows[0]["Stock_ID"].ToString();
//            ViewState["City_ID"] = dtSales.Rows[0]["City_ID"].ToString();
//            DataTable dtAirWayBillNo = dw.GetAllFromQuery("select AirWayBill_No,Agent_ID from stock_Master where Stock_ID=" + dtSales.Rows[0]["Stock_ID"].ToString());
//            DataTable dtAgent = dw.GetAllFromQuery("select Agent_Name from Agent_Master where Agent_ID=" + dtAirWayBillNo.Rows[0]["Agent_ID"].ToString());
//            if (dtAgent.Rows.Count > 0)
//            {
//                ViewState["Agent_ID"] = dtAirWayBillNo.Rows[0]["Agent_ID"].ToString();
//                ddlAgentName.SelectedItem.Text = dtAgent.Rows[0]["Agent_Name"].ToString();
//            }

//            if (dtAirWayBillNo.Rows.Count > 0)
//            {
//                ddlAwbNo.SelectedItem.Text = dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString();
//                string AirlineCode = ddlAwbNo.SelectedItem.Text.Substring(0, 3);
//                DataTable AirlineID = dw.GetAllFromQuery("select Airline_ID from Airline_Master where Airline_Code=" + AirlineCode);
//                //**************Added on 16 Nov 2010*******************************
//                DataTable dtAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID from Airline_Detail where Belongs_To_City=" + ViewState["City_ID"].ToString());
//                DataTable dtOriginatedAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID from Airline_Detail where Belongs_To_City=" + ViewState["City_ID"].ToString());

//                if (dtOriginatedAirlineDetail.Rows.Count > 0 || dtOriginatedAirlineDetail != null)
//                {
//                    ViewState["Originated_Airline_Detail_ID"] = dtOriginatedAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();
//                }
//                long City_ID = long.Parse(dtSales.Rows[0]["City_ID"].ToString());
//                ViewState["City_ID"] = City_ID;
//                DataTable dtCity = dw.GetAllFromQuery("select City_ID,City_Code,City_Name from City_Master where City_ID=" + dtSales.Rows[0]["City_ID"].ToString());
//                if (dtCity.Rows.Count > 0)
//                {
//                    ////ddlOrigin.SelectedValue = dtCity.Rows[0]["City_Code"].ToString() + "-" + dtCity.Rows[0]["City_Name"].ToString();
//                    ddlOrigin.SelectedValue = dtCity.Rows[0]["City_ID"].ToString();
//                }
//                DataTable dtBooking_City = dw.GetAllFromQuery("select City_Code,City_Name from City_Master where City_ID=" + dtSales.Rows[0]["Booking_City_ID"].ToString());
//                if (dtBooking_City.Rows.Count > 0)
//                {
//                    ////////////txtBooking_Origin.Text = dtBooking_City.Rows[0]["City_Code"].ToString() + "-" + dtBooking_City.Rows[0]["City_Name"].ToString();
//                    ViewState["Booking_City_Id"] = dtSales.Rows[0]["Booking_City_ID"].ToString();
//                }



//                if (dtAirlineDetail.Rows.Count > 0)
//                {
//                    long AirlineDetailID = long.Parse(dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString());
//                    ViewState["AirlineDetailID"] = AirlineDetailID;
//                }
//            }
//            ///////////fillOtherCharges(ViewState["Booking_ID"].ToString());
//            LOAD_SCD();
//            //int m = CheckSubAgentStatus(Convert.ToInt32(ViewState["Agent_ID"].ToString()));
//            //ViewState["SubAgentStatus"] = m >= 1 ? "Y" : "N"; 
//            //if (m >= 1)
//            //{
//            //    trSubagent.Visible = true;
//            //    txtSubAgentName.Text = dtSales.Rows[0]["SubAgent_Name"].ToString();
//            //    txtSubAgent_address.Text = dtSales.Rows[0]["SubAgent_Adress"].ToString();
//            //}
//            ddlDestination.SelectedValue = dtSales.Rows[0]["Destination_ID"].ToString();
//            ddlShipmentType.SelectedValue = dtSales.Rows[0]["Shipment_ID"].ToString();
//            ddlScr.SelectedValue = dtSales.Rows[0]["Special_Commodity_ID"].ToString();
//            DateTime AWB_Date = DateTime.Parse(dtSales.Rows[0]["AWB_Date"].ToString());
//            txtAWBDate.Text = FormatDateDD(AWB_Date.ToShortDateString());
//            ViewState["Flight_Open_ID"] = dtSales.Rows[0]["Flight_Open_ID"].ToString();
//            DataTable dtFlight = dw.GetAllFromQuery("select Flight_ID,Flight_Date from Flight_Open where Flight_Open_ID=" + dtSales.Rows[0]["Flight_Open_ID"].ToString());
//            if (dtFlight.Rows.Count > 0)
//            {
//                DataTable dtFlightNo = dw.GetAllFromQuery("select Flight_No from Flight_Master where Flight_ID=" + dtFlight.Rows[0]["Flight_ID"].ToString());

//                if (dtFlightNo.Rows.Count > 0)
//                {
//                    //ddlfltNo.SelectedValue = dtFlightNo.Rows[0]["Flight_No"].ToString();
//                }
//            }

//            ////ddlfltNo.SelectedItem.Text = dtSales.Rows[0]["Flight_No"].ToString();
//            DateTime FlightDate = Convert.ToDateTime(dtSales.Rows[0]["Flight_Date"].ToString());
//            txtFlightDate.Text = FormatDateDD(FlightDate.ToShortDateString());
//            txtShipper.Text = dtSales.Rows[0]["Shipper_Name"].ToString();
//            txtShipperAddress.Text = dtSales.Rows[0]["Shipper_Address"].ToString();
//            txtConsignee.Text = dtSales.Rows[0]["Consignee_Name"].ToString();
//            txtConsigneeAddress.Text = dtSales.Rows[0]["Consignee_Address"].ToString();

//            txtPieces.Text = dtSales.Rows[0]["No_of_Packages"].ToString();
//            txtVolwt.Text = dtSales.Rows[0]["Volume_Weight"].ToString();
//            txtGw.Text = dtSales.Rows[0]["Gross_Weight"].ToString();
//            txtCw.Text = dtSales.Rows[0]["Charged_Weight"].ToString();

//            rbFType.SelectedValue = dtSales.Rows[0]["Freight_Type"].ToString();

//            //////txtTariffRate.Text = dtSales.Rows[0]["Tariff_Rate"].ToString();
//            //////txtFreightAmount.Text = dtSales.Rows[0]["Freight_Amount"].ToString();

//            //////txtTariffRate.Text = dtSales.Rows[0]["Selling_Rate"].ToString();
//            //////txtSpAmt.Text = dtSales.Rows[0]["SellingFrtAmt"].ToString();
//            if (dtSales.Rows[0]["SellingRate_MinStatus"].ToString() == "13")
//            {
//                ChkMinAgent.Checked = true;
//            }
//            else
//            {
//                ChkMinAgent.Checked = false;
//            }
//            //****Modify by Hemant Sharma on 10'th Oct 2013****////
//            //DataTable dttxtawbfee = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + ddlAirline.SelectedValue+ "");
//            if (ddlAirline.SelectedItem.ToString().Substring(0, ddlAirline.SelectedItem.ToString().IndexOf('(')) == "ZEST AIR")
//            {
//                if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
//                {
//                    lblawbfee.Visible = true;
//                    txtAwbfee.Visible = true;
//                    txtAWBFee.Text = (dtSales.Rows[0]["AWB_Fees"].ToString() == "" ? 0 : decimal.Parse( dtSales.Rows[0]["AWB_Fees"].ToString())).ToString();
//                }
//                else
//                {
//                    lblawbfee.Visible = false;
//                    txtAwbfee.Visible = false;
//                    txtAWBFee.Text = null;

//                }
//            }
//            else
//            {
//                txtAWBFee.Text = null;

//            }
//            txtTariffRate.Text = dtSales.Rows[0]["Selling_Rate"].ToString();
//            txtFreightAmount.Text = dtSales.Rows[0]["SellingFrtAmt"].ToString();

//            txtTariffRate.Text = dtSales.Rows[0]["Tariff_Rate"].ToString();
//            txtSpAmt.Text = dtSales.Rows[0]["Freight_Amount"].ToString();
//            DataTable dtFix_Charges = dw.GetAllFromQuery("select * from fix_charges where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
//            {
//                if (dtFix_Charges.Rows.Count > 0)
//                {
//                    hndXray_fixCharges.Value = dtFix_Charges.Rows[0]["Min_XRay_Charges"].ToString();
//                }
//            }
//            //*********** From Sales Table***************
//            DataTable dtSalesField = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);
//            if (dtSalesField.Rows.Count > 0)
//            {

//                if (dtSalesField.Rows[0]["Agent_Min_Status"].ToString() == "13")
//                {
//                    ChkMinAgent.Checked = true;
//                }
//                else
//                {
//                    ChkMinAgent.Checked = false;
//                }

//                ////if (decimal.Parse(txtCw.Text) < 45)
//                ////{
//                ////    //15% less of tarrif Rate in Spot Rate(only in case of Min and Normal)
//                ////    txtSpotRate.Text = Convert.ToString(Math.Round((decimal.Parse(txtTariffRate.Text) - (decimal.Parse(txtTariffRate.Text)*15/100)),2));
//                ////}


//                ////////txtIATACommission.Text = dtSalesField.Rows[0]["Commission"].ToString();
//                //////////// txtSCR_Incentive.Text = dtSalesField.Rows[0]["Special_Commodity_Incentive"].ToString();

//                //*****************Added ON 29_Sep_2010************New column Value 'Deal colour'
//                ///////////// ddlDealColour.SelectedValue = dtSalesField.Rows[0]["Deal_Colour"].ToString();
//                //******************End***********************************************************



//                //////txtdepart_Airport.Text = dtSalesField.Rows[0]["City_Code"].ToString();

//                txtdepart_Airport.Text = dtSalesField.Rows[0]["DeptAirportOrg"].ToString();

//                if (dtSalesField.Rows[0]["Principle_Min_Status"].ToString() == "13")
//                {
//                    ChkMinAirline.Checked = true;
//                }
//                else
//                {
//                    ChkMinAirline.Checked = false;
//                }



//                txtPRate.Text = dtSalesField.Rows[0]["Principle_Rate"].ToString();
//                txtPAmount.Text = dtSalesField.Rows[0]["Principle_Amount"].ToString();

//                txtPSpotRate.Text = dtSalesField.Rows[0]["Principle_Spot_Rate"].ToString();
//                txtSpotRateRemarks.Text = dtSalesField.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();
//                ///////////txtRemarks.Text = dtSalesField.Rows[0]["Other_Remarks"].ToString();
//            }
//            //*********End From Sales Table***************

//            //********Added on 21 June 2011 :EURtoGBP_Exchange Rate*******
//            txtUSDToPHP.Text = dtSales.Rows[0]["ConversionRateToPHP"].ToString();
//        //**********END of ExchangeRate*******************************


//        #region Duecarrier Part

//            //////rbDueFreight.SelectedValue = dtSales.Rows[0]["DueCarrier_Type"].ToString();
//            txtRFSC.Value = dtSales.Rows[0]["FSCRate"].ToString();
//            txtRWSC.Value = dtSales.Rows[0]["WSCRate"].ToString();
//            txtRXRAY.Value = dtSales.Rows[0]["XRayRate"].ToString();
//            decimal Fuel_Surcharges = decimal.Parse(dtSales.Rows[0]["Fuel_Surcharges"].ToString());
//            Fuel_Surcharges = Math.Round(Fuel_Surcharges, MidpointRounding.AwayFromZero);
//            txtFSC.Text = Fuel_Surcharges.ToString();
//            FSC.Value = Fuel_Surcharges.ToString();
//            //TextBox1.Text = dtHandover.Rows[0]["Fuel_Surcharges"].ToString();

//            decimal War_Surcharges = decimal.Parse(dtSales.Rows[0]["War_Surcharges"].ToString());
//            War_Surcharges = Math.Round(War_Surcharges, MidpointRounding.AwayFromZero);
//            txtWSC.Text = War_Surcharges.ToString();
//            WSC.Value = War_Surcharges.ToString();
//            //TextBox2.Text = dtHandover.Rows[0]["War_Surcharges"].ToString();


//            decimal Xray_Charges = decimal.Parse(dtSales.Rows[0]["Xray_Charges"].ToString());
//            Xray_Charges = Math.Round(Xray_Charges, MidpointRounding.AwayFromZero);
//            txtXRAY.Text = Xray_Charges.ToString();
//            XRay.Value = Xray_Charges.ToString();
//            //TextBox3.Text = dtHandover.Rows[0]["Xray_Charges"].ToString();

//            // Add  Miscellaneous Charges 4th march 2012 //////

//            decimal MSC_Charges = decimal.Parse(dtSales.Rows[0]["MSC_Charges"].ToString());
//            MSC_Charges = Math.Round(MSC_Charges, MidpointRounding.AwayFromZero);
//           ////// txtMSC.Text = MSC_Charges.ToString();

//            ///////// txtET.Text = dtSalesField.Rows[0]["ETChrg"].ToString();

//            decimal ETChrg = decimal.Parse(dtSales.Rows[0]["ETCharges"].ToString());
//            ETChrg = Math.Round(ETChrg, MidpointRounding.AwayFromZero);
//           ////// txtET.Text = ETChrg.ToString();
//          //////  hdnET.Value = ETChrg.ToString();


//            decimal ABC = Fuel_Surcharges + War_Surcharges + Xray_Charges + ETChrg;
//            Hidden3.Value = ABC.ToString();
//            txtHouses.Value = dtSales.Rows[0]["No_of_houses"].ToString();
//            decimal ACI = decimal.Parse(dtSales.Rows[0]["Total_ACI_Fees"].ToString());
//            ACI = Math.Round(ACI, MidpointRounding.AwayFromZero);
//            txtACIFee.Text = ACI.ToString();
//            decimal AWB = decimal.Parse(dtSales.Rows[0]["AWB_Fees"].ToString());
//            AWB = Math.Round(AWB, MidpointRounding.AwayFromZero);
//           /////// txtAWBFee.Text = AWB.ToString();
//            decimal DB = decimal.Parse(dtSales.Rows[0]["Disbursement_Charges"].ToString());
//            DB = Math.Round(DB, MidpointRounding.AwayFromZero);
//           ///// txtDisbursmentCharges.Text = DB.ToString();
//            decimal Cartage = decimal.Parse(dtSales.Rows[0]["Cartridge_Charges"].ToString());
//            Cartage = Math.Round(Cartage, MidpointRounding.AwayFromZero);
//           ////// txtCatrage.Text = Cartage.ToString();
//            decimal Other = decimal.Parse(dtSales.Rows[0]["Other_DueCarrier"].ToString());
//            Other = Math.Round(Other, MidpointRounding.AwayFromZero);
//           ////// txtOthers.Text = Other.ToString();
//            decimal Total_DueCarrier = decimal.Parse(dtSales.Rows[0]["Total_DueCarrier"].ToString());
//            Total_DueCarrier = Math.Round(Total_DueCarrier, MidpointRounding.AwayFromZero);
//            txtDueCarrier.Text = Total_DueCarrier.ToString();
//            // Hidden3.Value = txtDueCarrier.Text;
//            decimal VC = decimal.Parse(dtSales.Rows[0]["Valuation_Charge"].ToString());
//            VC = Math.Round(VC, MidpointRounding.AwayFromZero);
//          ///////  txtValuationCharge.Text = VC.ToString();
//            decimal TX = decimal.Parse(dtSales.Rows[0]["Tax"].ToString());
//            TX = Math.Round(TX, MidpointRounding.AwayFromZero);
//         /////   txtTax.Text = TX.ToString();
//            decimal TDP = decimal.Parse(dtSales.Rows[0]["TotalDueAgent_Prepaid"].ToString());
//            TDP = Math.Round(TDP, MidpointRounding.AwayFromZero);
//           ////// txtDueAgentP.Text = TDP.ToString();
//            decimal TDC = decimal.Parse(dtSales.Rows[0]["TotalDueAgent_Collect"].ToString());
//            TDC = Math.Round(TDC, MidpointRounding.AwayFromZero);
//          /////  txtDueAgentC.Text = TDC.ToString();
//          /////  decimal DueAgent = decimal.Parse(txtDueAgentP.Text) + decimal.Parse(txtDueAgentC.Text);
//          /////  txtDueAgent.Text = DueAgent.ToString();
//            decimal TP = decimal.Parse(dtSales.Rows[0]["Total_Prepaid"].ToString());
//            TP = Math.Round(TP, MidpointRounding.AwayFromZero);
//          ///////  txtPrepaid.Text = TP.ToString();
//            decimal TC = decimal.Parse(dtSales.Rows[0]["Total_Collect"].ToString());
//            TC = Math.Round(TC, MidpointRounding.AwayFromZero);
//           /////// txtCollect.Text = TC.ToString();

//#endregion








//    }    
    public DataSet ConvertXMLToDataSet(StringBuilder xmlData)
    {
        StringReader stream = null;
        XmlTextReader reader = null;
        try
        {
            string s1 = @"<?xml version=""1.0"" encoding=""UTF-8""?><tabledata xmlns:sql=""urn:schemas-microsoft-com:xml-sql"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">";
            string s2 = @"</tabledata>";
            DataSet xmlDS = new DataSet();
            stream = new StringReader(s1 + xmlData.ToString() + s2);
            reader = new XmlTextReader(stream);
            xmlDS.ReadXml(reader);
            return xmlDS;
        }
        catch
        {
            return null;
        }
        finally
        {
            if (reader != null) reader.Close();
        }
    }
    public void LOAD_SCD()
    {
        try
        {
            con = new SqlConnection(strCon);
            com = new SqlCommand("LOAD_SCD", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ddlAirline.SelectedValue);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            StringBuilder xmlData = new StringBuilder(dt.Rows[0]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlShipmentType, "Shipment_Master", "Shipment_Name", "Shipment_ID");
            xmlData = new StringBuilder(dt.Rows[1]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlScr, "Special_Commodity_Master", "Special_Commodity_Name", "Special_Commodity_ID");
            xmlData = new StringBuilder(dt.Rows[2]["Data"].ToString());
            ////////ddlDestination.DataSource = ConvertXMLToDataSet(xmlData).Tables[0];
            ////////ddlDestination.DataTextField = "Destination";
            ////////ddlDestination.DataValueField = "Destination_ID";
            ////////ddlDestination.DataBind();
        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadCommodity()
    {
        try
        {
            string strAgent = "select Special_Commodity_ID,Special_Commodity_Name from Special_Commodity_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlScr.Items.Insert(0, "- -Select- -");
            ddlScr.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlScr.Items.Add(new ListItem(dr["Special_Commodity_Name"].ToString(), dr["Special_Commodity_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadShipmentType()
    {
        try
        {
            string strAgent = "select Shipment_ID,Shipment_Name from Shipment_Master";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlShipmentType.Items.Insert(0, "- -Select- -");
            ddlShipmentType.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlShipmentType.Items.Add(new ListItem(dr["Shipment_Name"].ToString(), dr["Shipment_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
 ////   protected void Button1_Click(object sender, EventArgs e)
 ////   {


 ////       if (Convert.ToDateTime(FormatDateMM(txtFlightDate.Text)) >= Convert.ToDateTime("07/01/2017"))
 ////       {
 ////           if (txtGstNo.Text == "" && ddlGstStateCode.SelectedValue == "0")
 ////           {
 ////               ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
 ////               txtGstNo.Focus();
 ////               return;
 ////           }

 ////           if (txtGstNo.Text == "00" && ddlGstStateCode.SelectedValue == "0")
 ////           {
 ////               ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
 ////               txtGstNo.Focus();
 ////               return;
 ////           }

 ////       }


 ////       DataTable dtCompany = dw.GetAllFromQuery("select Company_ID from Airline_Detail where Airline_Detail_ID=" + ddlAirline.SelectedValue);
 ////       if (dtCompany.Rows.Count > 0)
 ////       {
 ////           ViewState["CompanyID"] = dtCompany.Rows[0]["Company_ID"].ToString();
 ////       }

 ////       DataTable dtStock_Id = dw.GetAllFromQuery("Select Stock_Id from Stock_Master where Airwaybill_No='" + ddlAwbNo.SelectedItem.Text + "'");
 ////       if (dtStock_Id.Rows.Count > 0)
 ////       {
 ////           ViewState["Stock_ID"] = dtStock_Id.Rows[0]["Stock_ID"].ToString();
 ////       }
 ////       con = new SqlConnection(strCon);
 ////       con.Open();
 ////       SqlTransaction tranupdate = con.BeginTransaction();
 ////       DataTable dtAWBCheck = dw.GetAllFromQuery("select * from Sales where AirWayBill_No='" + ddlAwbNo.SelectedItem.Text.Trim() + "'");
 ////       if (dtAWBCheck.Rows.Count <= 0)
 ////       {
 ////           try
 ////           {
 ////               long SalesID = 0;
 ////               Insert_Sales(tranupdate, con);
 ////               InsertSalesTrans(tranupdate, con);
 ////               DataTable dtSalesID = dw.GetAllFromQuery("select ident_current('Sales') as SalesID");
 ////               SalesID = long.Parse(dtSalesID.Rows[0]["SalesID"].ToString());
 ////              Update_AWBDate(tranupdate, con);
 ////              Update_Stock(tranupdate, con, ViewState["Stock_ID"].ToString());
 ////               //*****************Added For Dimensions*************************
 ////               DataTable dtTemp = new DataTable();
 ////               if (Session["dtTemp"] != null)
 ////               {
 ////                   dtTemp = (DataTable)Session["dtTemp"];
 ////                   if (dtTemp.Rows[0]["SNo"].ToString() == "0")
 ////                   {
 ////                       dtTemp.Rows[0].Delete();
 ////                   }
 ////               }
 ////               if (dtSalesID.Rows.Count > 0 && dtTemp.Rows.Count > 0)
 ////               {
 ////                  Insert_BookingDimesion(tranupdate, con, SalesID);

 ////               }

 ////               //****************END*******************************************
 ////               tranupdate.Commit();
 ////               con.Close();

 ////               //******************Added On 15 oct 2011 For FFR:EDI CODE to ACCS********************
 ////               DataTable dtAWBConfirm = dw.GetAllFromQuery("select * from Sales where AirWayBill_No='" + ddlAwbNo.SelectedItem.Text.Trim() + "'");


 ////               if (dtAWBConfirm.Rows.Count > 0)
 ////               {

 ////                   ////////////////EDICommunication(dtAWBConfirm.Rows[0]["AirWayBill_No"].ToString());
 ////               }
 ////               //******************End**************************************************************
 ////               ////////////Label1.Text = Label1.Text.Replace("\n", " ");
 ////               ////////////string strScript1 = "alert('" + Label1.Text + "');location.replace('salesEdit.aspx');";
 ////               ////////////ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox1", strScript1, true);
 ////               /////Response.Redirect("salesEdit.aspx");
 ////               string strScript = "alert('Sales added sucessfully');location.replace('salesEdit.aspx');";
 ////               ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Save", strScript, true);
 ////           }
 ////           catch (Exception ex)
 ////           {
 ////               Response.Write(ex.Message);
 ////               tranupdate.Rollback();
 ////               Label1.Visible = true;
 ////               Label1.Text = ex.Message;
 //// }
 //////////Response.Redirect("salesEdit.aspx");
 ////       }
 ////       else
 ////       {
 ////           lblSales.Visible = true;
 ////       }
 ////}
    #region Update_AWBDate
    public void Update_AWBDate(SqlTransaction tr, SqlConnection con)
    {
        string update;

        update = "update Stock_Master set Used_Date='" + FormatDateMM(txtAWBDate.Text) + "'" + "  where Stock_ID=" + ViewState["Stock_ID"].ToString();
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }
    #endregion
    #region Update_Stock
    public void Update_Stock(SqlTransaction tr, SqlConnection con, string StockID)
    {
        string update;

        update = "update Stock_Master set Status=11" + "  where Stock_ID=" + StockID;
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }


    #endregion
    #region Insert_Sales
    //public void Insert_Sales(SqlTransaction tr, SqlConnection con)
    //{
    //    #region Generate Invoice No

    //    string Flight_date = txtFlightDate.Text;
    //    string[] dateSplit = Flight_date.Split('/');
    //    string Month = dateSplit[1].ToString();
    //    string Year = dateSplit[2].ToString();
    //    string Date1 = dateSplit[0].ToString();
    //    string currentdate = Month + "/" + Date1 + "/" + Year;
    //    string FinYear = Year.Substring(2, 2);
    //    // string dateCurrent = DateTime.Now.ToShortDateString();

    //    DateTime CurrDate = Convert.ToDateTime(currentdate);
    //    //****************Updated on 16 Apr 2018 as New year from Jan i/o Apr
    //    ////string DateFinancial = "4/1/20" + FinYear + "";
    //    string DateFinancial = "1/1/20" + FinYear + "";
    //    //****************End of Updated on 16 Apr 2018 as New year from Jan i/o Apr
    //    DateTime FinanciaDate = DateTime.Parse(DateFinancial);

    //    //****************Updated on 16 Apr 2018 as year 2018 i/o 2017-18
    //    ////if (CurrDate < FinanciaDate)
    //    ////{
    //    ////    //****************Updated on 16 Apr 2018 as year 2018 i/o 2017-18
    //    ////    ////FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
    //    ////    FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1);
    //    ////    //****************End of Updated on 16 Apr 2018 as year 2018 i/o 2017-18
    //    ////}
    //    ////else
    //    ////{
    //    ////    //****************Updated on 16 Apr 2018 as year 2018 i/o 2017-18
    //    ////    ////FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
    //    ////    FinYear = "20" + FinYear;
    //    ////    //****************End of Updated on 16 Apr 2018 as year 2018 i/o 2017-18
    //    ////}

        
    //    FinYear = "20" + FinYear;
    //    //****************End of Updated on 16 Apr 2018 as year 2018 i/o 2017-18
    //    //*********************End***************************************************************

    //    //*******************End****************************************

    //         string Lastdate = "";
    //    bool flagInvoice = false;
    //    if (int.Parse(Date1) < 16)
    //    {
    //        Date1 = "1";
    //        flagInvoice = true;
    //    }
    //    else
    //    {
    //        Date1 = "16";
    //    }

    //    //for (int year = 2006; year <= DateTime.Today.Year; year++)
    //    //    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
    //    // string Year = DateTime.Today.Year.ToString();

    //    string startDate = Month + "/" + Date1 + "/" + Year;
    //    string endDate = Month + "/" + (flagInvoice ? "15" : (Convert.ToDateTime(Month + "/1/" + Year).AddMonths(1).AddDays(-1).Day.ToString())) + "/" + Year;

    //    ////DataTable dtInvPrFx = dw.GetAllFromQuery("select prifix from Invoice_no where airline_detail_id=" + ddlAirline.SelectedValue + "");

    //    ///**************************************end of invoice function **********************************
    //    #endregion

    //    string insert;
    //    //****Modify by Hemant Sharma on 10'th Oct 2013****////
    //    //*****************Added on 27 Feb 2017 : New column in Table HB*******************//
    //    ////insert = "insert into Sales(Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_SNo,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_code,Originated_Airline_Detail_ID,ConversionRateToPHP,Selling_Rate,SellingFrtAmt,csr_remarks,SectorDestCode,SectorDestID,Routing,DeptAirportOrg,Total_DueCarrier,spot_rate,SellingRate_MinStatus,SubAgent_Name,SubAgent_Adress,AWB_Fees,Gateway,Interline,Carrier,Inner_Route) values(@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Currency,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_SNo,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Selling_Rate,@SellingFrtAmt,@csr_remarks,@SectorDestCode,@SectorDestID,@Routing,@DeptAirportOrg,@Total_DueCarrier,@spot_rate,@SellingRate_MinStatus,@SubAgent_Name,@SubAgent_Adress,@AWB_Fees,@Gateway,@Interline,@Carrier,@Inner_Route)";
    //    insert = "insert into Sales(Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_SNo,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_code,Originated_Airline_Detail_ID,ConversionRateToPHP,Selling_Rate,SellingFrtAmt,csr_remarks,SectorDestCode,SectorDestID,Routing,DeptAirportOrg,Total_DueCarrier,spot_rate,SellingRate_MinStatus,SubAgent_Name,SubAgent_Adress,AWB_Fees,Gateway,Interline,Carrier,Inner_Route,HB) values(@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Currency,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_SNo,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Selling_Rate,@SellingFrtAmt,@csr_remarks,@SectorDestCode,@SectorDestID,@Routing,@DeptAirportOrg,@Total_DueCarrier,@spot_rate,@SellingRate_MinStatus,@SubAgent_Name,@SubAgent_Adress,@AWB_Fees,@Gateway,@Interline,@Carrier,@Inner_Route,@HB)";
    //    SqlCommand com = new SqlCommand(insert, con, tr);
    //    com.CommandType = CommandType.Text;
    //    //======================In Case of PREMIER TRANS AIRE flight no insert by grid:pradeep sharma============== 
     
    //    //if (phRouteDetail.Controls.Count > 0)
    //    //{
            
    //    //    //////Table dynamicTable = (Table)phRouteDetail.FindControl("dynamicRouteTable");

    //    //    Table dynamicTable = (Table)Session["table"];
    //    //    if (dynamicTable != null)
    //    //    {               int r=1;
    //    //        int tempval = 0;
    //    //        string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart();
    //    //        foreach (TableRow tbr in dynamicTable.Rows)
    //    //        {
    //    //            if (r != 1 && temapVal == "PREMIER" && tempval == 0)
    //    //            {
    //    //                com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ((TextBox)tbr.Cells[5].Controls[0]).Text;
    //    //                ViewState["GridFlightNo"] = ((TextBox)tbr.Cells[5].Controls[0]).Text;
    //    //                tempval++;
                       
    //    //            }
    //    //            r++;
    //    //        }
    //    //    }
    //    //}
    //    //else
    //    //{
    //        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = "WE-123";

    //    //////}
    //    if (ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart() == "PREMIER")
    //    {
    //        //string tempval = ViewState["GridFlightNo"].ToString();
    //        //DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + tempval + "') ");

    //        ////com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = (object)DBNull.Value;
    //        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = 1234;
    //        string dest = "";
    //        DataTable dtDestination = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
    //        if (dtDestination.Rows.Count > 0)
    //        {
    //            dest = dtDestination.Rows[0]["Destination_Code"].ToString();
    //        }

    //        com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dest;
    //        com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = ddlDestination.SelectedValue;
    //        //DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
    //        //if (dtSectorDest.Rows.Count > 0)
    //        //{
    //        //    com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

    //        //    com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
    //        //}
    //        //else
    //        //{
    //            //com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = "";

    //            //com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
    //        //}

    //    }
    //    else
    //    {

    //        DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + ddlfltNo.SelectedItem.Text + "') ");
    //        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString());
    //        DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
    //        if (dtSectorDest.Rows.Count > 0)
    //        {
    //            com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

    //            com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
    //        }
    //        else
    //        {
    //            com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = ddlDestination.SelectedValue; 

    //            com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
    //        }
    //    }
    //    //=======================END==============================================
    //    com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
    //    com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
    //    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
    //    com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
    //    com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
    //    com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
    //    com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
    //    com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
    //    com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
    //    string strOrgin = "";
    //    DataTable dtOrigin = dw.GetAllFromQuery("select city_Code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
    //    if (dtOrigin.Rows.Count > 0)
    //    {
    //        strOrgin = dtOrigin.Rows[0]["city_Code"].ToString();
    //    }
    //    #region For BuyingDetails
    //    //==============Added By:Pradeep Sharma===========================
    //    ////if (Convert.ToString(ViewState["GroupID"]) != "13" )
    //    if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
    //    {
    //        string  Inter_NonInterline = "";
           
    //        ////if (rbtnRouteType1.Checked)///Interline
    //        ////{
    //        ////    Inter_NonInterline = "Y";
                
    //        ////}
    //        ////////if (rbtnRouteType2.Checked)//Non-Interline
    //        ////{
    //        ////    Inter_NonInterline = "N";
                
    //        ////}
    //        //////com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = selCarrier.SelectedValue;
    //        /////com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = rbtnGateWay.SelectedValue;
    //       /////// com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = Inter_NonInterline;
    //        com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
    //        com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
    //        com.Parameters.Add("@Interline", SqlDbType.VarChar).Value ="Y";
    //        com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = lblOrigin.Text + "-" + txtCenturionRoute.Text + "-" + lblDestination.Text;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
    //        com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "N/A";
    //        com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
    //        com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = "N/A";
    //    }
    //    #endregion
    //    ////strOrgin = strOrgin.Substring(0, 3);
    //    com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
    //    ////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
    //    com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
    //    com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
    //    string strDestination = "";
    //    DataTable dtDest = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
    //    if (dtOrigin.Rows.Count > 0)
    //    {
    //        strDestination = dtDest.Rows[0]["Destination_Code"].ToString();
    //    }
    //    com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
    //    com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
    //    com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
    //    com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
    //    com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
    //    com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
    //    com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
    //    ////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
    //    ////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));
    //    com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
    //    com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
    //    com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
    //    com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
    //    com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
    //    com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
    //    com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "USD";
    //    com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
    //    com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
    //    com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
    //    com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
    //    #region Generating CSR Serial Auto Number
    //    string CSR_Date;
    //    CSR_Date = (txtFlightDate.Text);
    //    string[] d = CSR_Date.Split(new char[] { '/' });
    //    string strDD = d[0];
    //    string strMM = d[1];
    //    string strYYYY = d[2];
    //    string First = "";
    //    string Last = "";
    //    string FinancialYearLast = string.Empty;
    //    int LastYear = 0;
    //    string FinancialYearFirst = string.Empty;
    //    if (int.Parse(strMM) > 3)
    //    {
    //        FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
    //        LastYear = (DateTime.Now.Year + 1);
    //        FinancialYearLast = "03/31/" + LastYear.ToString();
    //    }
    //    else
    //    {
    //        FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
    //        LastYear = (DateTime.Now.Year - 1);
    //        FinancialYearFirst = "04/01/" + LastYear.ToString();
    //    }

    //    if (int.Parse(strDD) <= 15)
    //    {
    //        First = "01/" + strMM + "/" + strYYYY;
    //        Last = "15/" + strMM + "/" + strYYYY;
    //    }
    //    else
    //    {
    //        First = "16/" + strMM + "/" + strYYYY;
    //        DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
    //        string LastDate = Date.Day.ToString();
    //        Last = LastDate + "/" + strMM + "/" + strYYYY;
    //    }
    //    DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ddlAgentName.SelectedValue + " and Airline_Detail_ID=" + ddlAirline.SelectedValue + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
    //    if (dtCSR_SNo.Rows.Count > 0)
    //    {
    //        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
    //    }
    //    else
    //    {
    //        long Maximum = 0;
    //        DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ddlAirline.SelectedValue + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
    //        if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
    //        {
    //            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
    //        }
    //        else
    //        {
    //            Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
    //            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
    //        }

    //    }
    //    // }
    //    #endregion
    //    com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
    //    if (ChkMinAgent.Checked == true)
    //    {
    //        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
    //    }
    //    if (ChkMinAirline.Checked == true)
    //    {
    //        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
    //    }
    //    com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
    //    com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
    //    com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
    //    com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
    //    com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
    //    DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
    //    if (dtcity_Code.Rows.Count > 0)
    //    {

    //        com.Parameters.Add("@Booking_City_code", SqlDbType.VarChar).Value = dtcity_Code.Rows[0]["city_code"].ToString();
    //    }

    //    com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

    //    //******************Added on 29_Sep_2010**********************************
    //    ////com.Parameters.Add("@Deal_Colour", SqlDbType.VarChar).Value = ddlDealColour.SelectedValue;
    //    com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
    //    ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
    //    ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));
    //    ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));
    //    ////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
    //    ////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
    //    com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
    //    com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));
    //    //****Modify by Hemant Sharma on 10'th Oct 2013****////
    //       DataTable dtDomestic = dw.GetAllFromQuery("select Airline_Name from Airline_Master am inner join Airline_detail ad on am.airline_id=ad.airline_id where ad.airline_detail_id=" + ddlAirline.SelectedValue + "");
    //    if (dtDomestic.Rows[0]["Airline_Name"].ToString() == "ZEST AIR")
    //    {
    //    //if (ddlAirline.SelectedItem.ToString().Substring(0, ddlAirline.SelectedItem.ToString().IndexOf('(')) == "ZEST AIR")
    //    //{
    //    //    if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
    //    //    {
    //            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtAWBFee.Text;
    //        //}
    //        //else
    //        //{
    //        //    com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = null;

    //        //}
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = (object)DBNull.Value;

    //    }
    //    //com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(hdninvno.Value);
    //    //com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(hdnInvsno.Value);
    //    com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
       
    //    com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
    //    com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
    //    com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDueCarrier.Text == "" ? 0 : decimal.Parse(txtDueCarrier.Text));
    //    com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
    //    if (ChkMinAgent.Checked == true)
    //    {
    //        com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
    //    }
    //    //************added on 27 Feb 2017 : New column HB***************//
    //    com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
    //    //************End of 27 Feb 2017 : New column HB***************//
    ////============================== Sub agent ===================================//
    //    com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y"?txtSubAgentName.Text:(object)DBNull.Value;
    //    com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;
    //     com.ExecuteNonQuery();
    //    #region Invoiceno Generation
    //    DataTable dtInvoiceNo = new DataTable();
    //    //con = new SqlConnection(strCon);
    //    //con.Open();
    //    SqlCommand cmd;
    //    cmd = new SqlCommand("InsertInvoiceno", con, tr);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Parameters.Add("@agent_id ", SqlDbType.BigInt).Value = int.Parse(ddlAgentName.SelectedValue);
    //    cmd.Parameters.Add("@startDate ", SqlDbType.VarChar).Value = startDate;
    //    cmd.Parameters.Add("@endDate ", SqlDbType.VarChar).Value = endDate;
    //    cmd.Parameters.Add("@Fin_Year ", SqlDbType.VarChar).Value = FinYear;
    //    cmd.Parameters.Add("@Stock_id", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
    //    cmd.Parameters.Add("@AirlineID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
    //     cmd.ExecuteNonQuery();
    //    #endregion
    //}
    #endregion
    public string FormatDateDD(string date)
    {
        string[] d = date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strMM + "/" + strDD + "/" + strYYYY;
        return strMMDDYYYY;
    }
    public string FormatDateMM(string date)
    {

        string[] d = date.Split(new char[] { '/' });

        string strMM = d[0];
        string strDD = d[1];
        string strYYYY = d[2];
        string strMMDDYYYY = strDD + "/" + strMM + "/" + strYYYY;
        return strMMDDYYYY;
    }
    protected void ddlScr_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    #region Edit_Sales
    //public void Edit_Sales(SqlTransaction tr, SqlConnection con, string SalesID)
    //{
    //    string update;
    //    //****Modify by Hemant Sharma on 10'th Oct 2013****//// 
    //    update = "update Sales set CSR_SNo=@CSR_SNo,Flight_No=@Flight_No,Flight_Open_ID=@Flight_Open_ID,AirWayBill_No=@AirWayBill_No,AWB_Date=@AWB_Date,CSR_Date=@CSR_Date,Flight_Date=@Flight_Date,Stock_ID=@Stock_ID,Agent_ID=@Agent_ID,Special_Commodity_ID=@Special_Commodity_ID,Shipment_Name=@Shipment_Name,Shipment_ID=@Shipment_ID,City_ID=@City_ID,City_Code=@City_Code,Destination_ID=@Destination_ID,Destination_Code=@Destination_Code,Airline_Detail_ID=@Airline_Detail_ID,No_of_Packages=@No_of_Packages,Gross_Weight=@Gross_Weight,Volume_Weight=@Volume_Weight,Charged_Weight=@Charged_Weight,Freight_Type=@Freight_Type,Tariff_Rate=@Tariff_Rate,Freight_Amount=@Freight_Amount,Principle_Rate=@Principle_Rate,Principle_Amount=@Principle_Amount,Principle_Spot_Rate=@Principle_Spot_Rate,Principle_Spot_Rate_Remarks=@Principle_Spot_Rate_Remarks,Shipper_Name=@Shipper_Name,Shipper_Address=@Shipper_Address,Consignee_Name=@Consignee_Name,Consignee_Address=@Consignee_Address,Approved_for_CSR=@Approved_for_CSR,Sales_Added_Date=@Sales_Added_Date,Agent_Min_Status=@Agent_Min_Status,CSR_Remarks=@CSR_Remarks,Principle_Min_Status=@Principle_Min_Status,Status=@Status,Last_Modified_By=@Last_Modified_By,Last_Modified_On=@Last_Modified_On,Booking_City_ID=@Booking_City_ID,Booking_City_Code=@Booking_City_Code,Originated_Airline_Detail_ID=@Originated_Airline_Detail_ID,ConversionRateToPHP=@ConversionRateToPHP,Selling_Rate=@Selling_Rate,SellingFrtAmt=@SellingFrtAmt,Routing=@Routing,DeptAirportOrg=@DeptAirportOrg,Total_DueCarrier=@Total_DueCarrier,spot_rate=@spot_rate,SellingRate_MinStatus=@SellingRate_MinStatus,SubAgent_Name=@SubAgent_Name,SubAgent_Adress=@SubAgent_Adress,AWB_Fees=@AWB_Fees,Gateway=@Gateway,Interline=@Interline,Inner_Route=@Inner_Route,Carrier=@Carrier,HB=@HB where Sales_ID=@Sales_ID";
    //    SqlCommand com = new SqlCommand(update, con, tr);
    //    com.CommandType = CommandType.Text;
    //    //com.Parameters.Add("@Booking_ID", SqlDbType.DateTime).Value = HandoverID;
    //    com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = long.Parse(SalesID);
    //    #region Generating CSR Serial Auto Number
    //    string CSR_Date;
    //    CSR_Date = (txtFlightDate.Text);
    //    //if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "232" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "297")
    //    //{
    //    //    CSR_Date = (txtFlightDate.Text);

    //    //}
    //    //else
    //    //{
    //    //     CSR_Date = (txtAWBDate.Text);
    //    //}
    //    string[] d = CSR_Date.Split(new char[] { '/' });
    //    string strDD = d[0];
    //    string strMM = d[1];
    //    string strYYYY = d[2];
    //    string First = "";
    //    string Last = "";

    //    string FinancialYearLast = string.Empty;
    //    int LastYear = 0;
    //    string FinancialYearFirst = string.Empty;
    //    if (int.Parse(strMM) > 3)
    //    {
    //        FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
    //        LastYear = (DateTime.Now.Year + 1);
    //        FinancialYearLast = "03/31/" + LastYear.ToString();
    //    }
    //    else
    //    {
    //        FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
    //        LastYear = (DateTime.Now.Year - 1);
    //        FinancialYearFirst = "04/01/" + LastYear.ToString();
    //    }

    //    if (int.Parse(strDD) <= 15)
    //    {
    //        First = "01/" + strMM + "/" + strYYYY;
    //        Last = "15/" + strMM + "/" + strYYYY;
    //    }
    //    else
    //    {
    //        First = "16/" + strMM + "/" + strYYYY;
    //        DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
    //        string LastDate = Date.Day.ToString();
    //        Last = LastDate + "/" + strMM + "/" + strYYYY;
    //    }
    //    DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ddlAgentName.SelectedValue + " and Airline_Detail_ID=" + ddlAirline.SelectedValue + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
    //    if (dtCSR_SNo.Rows.Count > 0)
    //    {
    //        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
    //    }
    //    else
    //    {
    //        long Maximum = 0;
    //        DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ddlAirline.SelectedValue + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
    //        if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
    //        {
    //            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
    //        }
    //        else
    //        {
    //            Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
    //            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
    //        }

    //    }
    //    // }
    //    #endregion


    //    //======================In Case of PREMIER TRANS AIRE flight no insert by grid:pradeep sharma============== 

    //    if (phRouteDetail.Controls.Count > 0)
    //    {
    //        ////Table dynamicTable = (Table)phRouteDetail.FindControl("dynamicRouteTable");
    //        Table dynamicTable = (Table)Session["table"];
    //        if (dynamicTable != null)
    //        {
    //            int r = 1;
    //            int tempval = 0;
    //            string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart();
    //            foreach (TableRow tbr in dynamicTable.Rows)
    //            {
    //                if (r != 1 && temapVal == "PREMIER" && tempval == 0)
    //                {
    //                    com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ((TextBox)tbr.Cells[4].Controls[0]).Text;
    //                    tempval++;

    //                }
    //                r++;
    //            }
    //        }
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();

    //    }
    //    //=======================END==============================================

    //    DataTable dtFltopnId = dw.GetAllFromQuery("select Flight_open_id from flight_open where flight_id=(select flight_id from flight_master where flight_no='" + ddlfltNo.SelectedItem.Text + "')");

    //    if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
    //    {
    //        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = (object)DBNull.Value;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
    //    }
    //    //com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
    //    com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
    //    com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateDD(txtAWBDate.Text);
    //    string Sales_ID = "";
    //    if (Request.QueryString["Sales_ID"] != null)
    //    {
    //        Sales_ID = Request.QueryString["Sales_ID"];
    //    }
    //    DataTable dtSales_ID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + Sales_ID);
    //    if (dtSales_ID.Rows[0]["Approved_for_CSR"].ToString() == "28")
    //    {
    //        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtCSRDate.Text);
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

    //    }
    //    com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateDD(txtFlightDate.Text);

    //    com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
    //    com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
    //    com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
    //    com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
    //    com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
    //    //com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["Booking_City_Id"].ToString()); 

    //    com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);


    //    string strOrgin = "";
    //    DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
    //    if (dtcity_Code.Rows.Count > 0)
    //    {
    //        strOrgin = dtcity_Code.Rows[0]["city_code"].ToString();
    //    }
    //    ////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtdepart_Airport.Text;

    //    com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;

    //    com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;

    //    string strDestination = "";

    //    DataTable dtDest_Code = dw.GetAllFromQuery("select Destination_code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
    //    if (dtDest_Code.Rows.Count > 0)
    //    {
    //        strDestination = dtDest_Code.Rows[0]["Destination_code"].ToString();
    //    }
    //    com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
    //    com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
    //    com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
    //    com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
    //    com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
    //    com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
    //    com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
    //    //////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
    //    //////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));
    //    com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
    //    com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
    //    com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
    //    com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
    //    com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
    //    com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
    //    com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
    //    com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
    //    com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
    //    com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
    //    ////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
    //    if (dtSales_ID.Rows[0]["Approved_for_CSR"].ToString() == "28")
    //    {
    //        com.Parameters.Add("@Approved_for_CSR", SqlDbType.Int).Value = 28;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Approved_for_CSR", SqlDbType.Int).Value = 29;
    //    }
    //    com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
    //    // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = status;
    //    if (ChkMinAgent.Checked == true)
    //    {
    //        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
    //    }
    //    com.Parameters.Add("@CSR_Remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
    //    if (ChkMinAirline.Checked == true)
    //    {
    //        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
    //    }
    //    com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
    //    com.Parameters.Add("@Last_Modified_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
    //    com.Parameters.Add("@Last_Modified_On", SqlDbType.DateTime).Value = DateTime.Now;
    //    com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
    //    DataTable dtcity = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
    //    if (dtcity_Code.Rows.Count > 0)
    //    {
    //        com.Parameters.Add("@Booking_City_code", SqlDbType.VarChar).Value = dtcity.Rows[0]["city_code"].ToString();
    //    }
    //    com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
    //    //**********************************Added On 29_Sep_2010*******************
    //    ////com.Parameters.Add("@Deal_Colour", SqlDbType.VarChar).Value =ddlDealColour.SelectedValue;
    //    com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
    //    ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));

    //    ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));

    //    ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));

    //    ////////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));


    //    //////////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));


       

    //    com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));


    //    com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));


    //    com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
    //    com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
    //    com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDueCarrier.Text == "" ? 0 : decimal.Parse(txtDueCarrier.Text));
    //    com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));

    //    //*********************Added on 27 FEB 2017: New Column HB added************//
    //    com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
    //    //*********************END of 27 FEB 2017: New Column HB added************//

    //    if (ChkMinAgent.Checked == true)
    //    {
    //        com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
    //    }
    //    com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
    //    com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;
    //    //****Modify by Hemant Sharma on 10'th Oct 2013****////

    //    if (ddlAirline.SelectedItem.ToString().Substring(0, ddlAirline.SelectedItem.ToString().IndexOf('(')) == "ZEST AIR")
    //    {
    //        if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
    //        {
    //            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtAWBFee.Text;
    //        }
    //        else
    //        {
    //            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = (object)DBNull.Value;

    //        }
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = (object)DBNull.Value;

    //    }
    //    #region For BuyingDetails
    //    ////if (Convert.ToString(ViewState["GroupID"]) != "7" || Convert.ToString(ViewState["GroupID"]) != "8")
    //    if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
    //    {
    //        ////string Gateway = rbtnGateWay.SelectedValue, Inter_NonInterline = "";

    //        ////if (rbtnRouteType1.Checked)///Interline
    //        ////{
    //        ////    Inter_NonInterline = "Y";
    //        ////    //com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = selCarrier.SelectedValue;
    //        ////}
    //        ////if (rbtnRouteType2.Checked)//Non-Interline
    //        ////{
    //        ////    Inter_NonInterline = "N";
    //        ////    //com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
    //        ////}
    //        com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
    //        com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
    //        com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "Y";
    //        com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = lblOrigin.Text + "-" + txtCenturionRoute.Text + "-" + lblDestination.Text;

    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
    //        com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "N/A";
    //        com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
    //        com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = "N/A";
    //    }
    //    #endregion
    //    com.ExecuteNonQuery();
    //}
    #endregion
    #region Insert_Sales_History
    //public void Insert_Sales_History(SqlTransaction tr, SqlConnection con, DataTable dtSales)
    //{
    //    string insert;

    //    insert = "insert into Sales_History(Sales_ID,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Selling_Rate,SellingFrtAmt,SubAgent_Name,SubAgent_Adress) values(@Sales_ID,@CSR_SNo,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Selling_Rate,@SellingFrtAmt,@SubAgent_Name,@SubAgent_Adress)";

    //    SqlCommand com = new SqlCommand(insert, con, tr);
    //    com.CommandType = CommandType.Text;
    //    com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Sales_ID"].ToString());
    //    com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["CSR_SNo"].ToString());

    //    com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = dtSales.Rows[0]["Flight_No"].ToString();
    //    if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
    //    {
    //        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = (object)DBNull.Value;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Flight_Open_ID"].ToString());
    //    }
    //    com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = dtSales.Rows[0]["AirWayBill_No"].ToString();
    //    com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["AWB_Date"].ToString();
    //    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["CSR_Date"].ToString();
    //    com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["Flight_Date"].ToString();

    //    com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Stock_ID"].ToString());
    //    com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Agent_ID"].ToString());
    //    com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Special_Commodity_ID"].ToString());
    //    com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Shipment_Name"].ToString();
    //    com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Shipment_ID"].ToString());

    //    //DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ViewState["Booking_City_Id"].ToString() + "");
    //    //if (dtcity_Code.Rows.Count > 0)
    //    //{

    //    //    com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtSales.Rows[0]["City_Code"].ToString(); dtcity_Code.Rows[0]["city_code"].ToString();
    //    //}


    //    //com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["Booking_City_Id"].ToString()); 

    //    com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["City_ID"].ToString());
    //    string strOrgin = "";
    //    DataTable dtOrigin = dw.GetAllFromQuery("select city_code from city_master where city_id=" + dtSales.Rows[0]["City_ID"].ToString() + "");
    //    if (dtOrigin.Rows.Count > 0)
    //    {
    //        strOrgin = dtOrigin.Rows[0]["city_code"].ToString();
    //    }
    //    com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
    //    // com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = ddlOrigin.SelectedValue.Trim();
    //    com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Destination_ID"].ToString());
    //    com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtSales.Rows[0]["Destination_Code"].ToString();
    //    com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Airline_Detail_ID"].ToString());

    //    ////com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Total_Prepaid"].ToString());

    //    com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["No_of_Packages"].ToString());
    //    com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Gross_Weight"].ToString());
    //    com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Volume_Weight"].ToString());
    //    com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Charged_Weight"].ToString());


    //    com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtSales.Rows[0]["Freight_Type"].ToString();


    //    ////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));

    //    ////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));

    //    com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));

    //    com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));

    //    com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Rate"].ToString());
    //    com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Amount"].ToString());
    //    com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Spot_Rate"].ToString());
    //    com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtSales.Rows[0]["Principle_Spot_Rate"].ToString();

    //    com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtSales.Rows[0]["Currency"].ToString();

    //    com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Nature_and_Quantity"].ToString();
    //    com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtSales.Rows[0]["Shipper_Address"].ToString();
    //    com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Consignee_Name"].ToString();
    //    com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtSales.Rows[0]["Consignee_Address"].ToString();
    //    ////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtSales.Rows[0]["Remarks"].ToString();

    //    com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["Sales_Added_Date"].ToString();
    //    com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Agent_Min_Status"].ToString());

    //    com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Principle_Min_Status"].ToString());
    //    int adddeal = (dtSales.Rows[0]["Add_To_Deal"].ToString() == "" ? 14 : int.Parse(dtSales.Rows[0]["Add_To_Deal"].ToString()));
    //    com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = adddeal;
    //    com.Parameters.Add("@Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Status"].ToString());
    //    com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = dtSales.Rows[0]["Entered_By"].ToString();
    //    com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = dtSales.Rows[0]["Entered_On"].ToString();


    //    com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Booking_City_Id"].ToString());

    //    DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + dtSales.Rows[0]["Booking_City_Id"].ToString() + "");
    //    if (dtcity_Code.Rows.Count > 0)
    //    {

    //        com.Parameters.Add("@Booking_City_code", SqlDbType.VarChar).Value = dtcity_Code.Rows[0]["city_code"].ToString();
    //    }

    //    com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Originated_Airline_Detail_ID"].ToString());

    //    //****************************Added On 29_Sep_2010*****************

    //    com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
    //    com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
    //    com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));
    //    com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDueCarrier.Text == "" ? 0 : decimal.Parse(txtDueCarrier.Text));

    //    com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
    //    com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;
    //    com.ExecuteNonQuery();
    //}
    #endregion
    //protected void UpdateSales_Click(object sender, EventArgs e)
    //{

    //    if (Convert.ToDateTime(FormatDateMM(txtFlightDate.Text)) >= Convert.ToDateTime("07/01/2017"))
    //    {
    //        if (txtGstNo.Text == "" && ddlGstStateCode.SelectedValue == "0")
    //        {
    //            ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
    //            txtGstNo.Focus();
    //            return;
    //        }

    //        if (txtGstNo.Text == "00" && ddlGstStateCode.SelectedValue == "0")
    //        {
    //            ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
    //            txtGstNo.Focus();
    //            return;
    //        }
    //    }



    //    long Sales_ID = 0;
    //    con = new SqlConnection(strCon);
    //    con.Open();
    //    SqlTransaction tranupdate = con.BeginTransaction();
    //    string SalesID = "";
    //    if (Request.QueryString["Sales_ID"] != null)
    //    {
    //        SalesID = Request.QueryString["Sales_ID"];
    //    }
    //    DataTable dtHandoverID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);
    //    Sales_ID = long.Parse(dtHandoverID.Rows[0]["Sales_ID"].ToString());
    //    try
    //    {
    //        Edit_Sales(tranupdate, con, SalesID);
    //        InsertSalesTrans(tranupdate, con);
    //        Insert_Sales_History(tranupdate, con, dtHandoverID);
    //        //***************Updating Dimensions****************
    //        DataTable dtTemp = new DataTable();
    //        if (Session["dtTemp"] != null)
    //        {
    //            dtTemp = (DataTable)Session["dtTemp"];
    //            if (dtTemp.Rows.Count > 0)
    //            {
    //                if (dtTemp.Rows[0]["SNo"].ToString() == "0")
    //                {
    //                    dtTemp.Rows[0].Delete();
    //                }
    //            }
    //        }
    //        if (dtHandoverID.Rows.Count > 0 && dtTemp.Rows.Count > 0)
    //        {
    //            Update_BookingDimesion(tranupdate, con, Sales_ID);

    //        }
    //        //*************End***********************************
    //        tranupdate.Commit();
    //        con.Close();
    //        //******************Added On 15 oct 2011 For FFR:EDI CODE to ACCS********************
    //        ////DataTable dtAWBConfirm = dw.GetAllFromQuery("select FFR_Remarks,* from Sales where AirWayBill_No='" + ddlAwbNo.SelectedItem.Text.Trim() + "'");

    //        ////string Booked = "";

    //        ////if (dtAWBConfirm.Rows.Count > 0)
    //        ////{
    //        ////    //if (dtAWBConfirm.Rows[0]["FFR_Remarks"].ToString().Contains("OSI/SUCESS"))
    //        ////    //{
    //        ////    //    Booked = "Y";
    //        ////    //}
    //        ////    //else
    //        ////    //{
    //        ////    //////////////////////EDICommunication(dtAWBConfirm.Rows[0]["AirWayBill_No"].ToString());
    //        ////    //}
    //        ////}
    //        //******************End**************************************************************
    //        //if (Booked != "Y")
    //        //{
    //        ////////Label1.Text = Label1.Text.Replace("\n", " ");
    //        ////////string strScript = "alert('" + Label1.Text + "');location.replace('salesEdit.aspx');";

    //        ////////ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "alertBox", strScript, true);
    //        //}
    //        //else
    //        //    Response.Redirect("salesEdit.aspx");

    //        string strScript = "alert('Sales Updated sucessfully');location.replace('salesEdit.aspx');";

    //        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Update", strScript, true);


    //    }
    //    catch (Exception ex)
    //    {
    //        Response.Write(ex.Message);
    //        tranupdate.Rollback();
    //        Label1.Visible = true;
    //        Label1.Text = ex.Message;
    //    }

    //    /////////////Response.Redirect("SalesEdit.aspx");
    //}
    //protected void btnSModify_Click(object sender, EventArgs e)
    //{

    //    if (Convert.ToDateTime(FormatDateMM(txtFlightDate.Text)) >= Convert.ToDateTime("07/01/2017"))
    //    {
    //        if (txtGstNo.Text == "" && ddlGstStateCode.SelectedValue == "0")
    //        {
    //            ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
    //            txtGstNo.Focus();
    //            return;
    //        }
    //        if (txtGstNo.Text == "00" && ddlGstStateCode.SelectedValue == "0")
    //        {
    //            ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
    //            txtGstNo.Focus();
    //            return;
    //        }
    //    }
    //    con = new SqlConnection(strCon);
    //    con.Open();
    //    SqlTransaction tranupdate = con.BeginTransaction();

    //    string SalesID = "";
    //    if (Request.QueryString["Sales_ID"] != null)
    //    {
    //        SalesID = Request.QueryString["Sales_ID"];
    //    }
    //    DataTable dtHandoverID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);
    //    ViewState["Stock_ID"] = dtHandoverID.Rows[0]["Stock_ID"].ToString();
    //    string AWBDate = txtAWBDate.Text;
    //    string CSRdate = txtCSRDate.Text;
    //    string[] d = AWBDate.Split(new char[] { '/' });
    //    string strD = d[0];
    //    int D = Convert.ToInt32(d[0]);
    //    string strM = d[1];
    //    int M = Convert.ToInt32(d[1]);
    //    string strYY = d[2];
    //    int YY = Convert.ToInt32(d[2]);

    //    string[] g = CSRdate.Split(new char[] { '/' });
    //    string strDD = g[0];
    //    int DD = Convert.ToInt32(g[0]);
    //    string strMM = g[1];
    //    int MM = Convert.ToInt32(g[1]);
    //    string strYYYY = g[2];
    //    int YYYY = Convert.ToInt32(g[2]);
    //    string strDate = "";
    //    if (D <= 15)
    //    {
    //        strDate = "16/" + strM + "/" + strYY;
    //        strDate = FormatDateMM(strDate);

    //    }
    //    else
    //    {
    //        int Month = M + 1;
    //        int Year = YY;
    //        if (Month == 13)
    //        {
    //            Month = 1;
    //            Year = YY + 1;
    //        }
    //        strDate = "01/" + Month.ToString() + "/" + Year.ToString();
    //        strDate = FormatDateMM(strDate);
    //    }
    //    CSRdate = FormatDateMM(CSRdate);
    //    //if (DateTime.Parse(CSRdate) >= DateTime.Parse(strDate))
    //    //{
    //    try
    //    {
    //        Edit_Sales(tranupdate, con, SalesID);
    //        Insert_Sales_History(tranupdate, con, dtHandoverID);
    //        long BookingID = Convert.ToInt64(ViewState["Booking_ID"]);
    //        Update_AWBDate(tranupdate, con);
    //        tranupdate.Commit();
    //        con.Close();
    //    }
    //    catch (Exception ex)
    //    {
    //        Response.Write(ex.Message);
    //        tranupdate.Rollback();
    //    }
    //    if (dtHandoverID.Rows[0]["Approved_for_CSR"].ToString() == "28")
    //    {
    //        con = new SqlConnection(strCon);
    //        con.Open();
    //        SqlTransaction tr = con.BeginTransaction();
    //        try
    //        {
    //            UpdateApproveStatus(tr, con, SalesID);
    //            InsertSalesTrans(tranupdate, con);
    //            Insert_Sales_DrCr1(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
    //            Insert_Sales_DrCr2(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
    //            tr.Commit();
    //            con.Close();
    //        }
    //        catch (Exception ex)
    //        {
    //            Response.Write(ex.Message);
    //            tr.Rollback();
    //        }
    //    }
    //    Response.Redirect("SalesEdit.aspx");

    //}//End of UpdateSalesClick
    #region UpdateApproveStatus
    public void UpdateApproveStatus(SqlTransaction tr, SqlConnection con, string SalesID)
    {
        string update;
        update = "update Sales set Approved_for_CSR=29 , Sales_type='CRDR' where Sales_ID=" + SalesID;
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }
    #endregion
    #region Insert_Sales_DrCr1

    //public void Insert_Sales_DrCr1(SqlTransaction tr, SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    //{

    //    string insert;

    //   ///// insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

    //     ////insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

    //     insert = "insert into Sales(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_SNo,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_code,Originated_Airline_Detail_ID,ConversionRateToPHP,Selling_Rate,SellingFrtAmt,csr_remarks,SectorDestCode,SectorDestID,Routing,DeptAirportOrg,Total_DueCarrier,spot_rate,SellingRate_MinStatus,SubAgent_Name,SubAgent_Adress,AWB_Fees,Gateway,Interline,Carrier,Inner_Route,HB) values(@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Currency,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_SNo,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Selling_Rate,@SellingFrtAmt,@csr_remarks,@SectorDestCode,@SectorDestID,@Routing,@DeptAirportOrg,@Total_DueCarrier,@spot_rate,@SellingRate_MinStatus,@SubAgent_Name,@SubAgent_Adress,@AWB_Fees,@Gateway,@Interline,@Carrier,@Inner_Route,@HB)";

    //    SqlCommand com = new SqlCommand(insert, con, tr);
    //    com.CommandType = CommandType.Text;

    //    com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
    //    com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "CRDR";
    //    com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());

    //    com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();
    //    DataTable dtFltopnId = dw.GetAllFromQuery("select Flight_open_id from flight_open where flight_id=(select flight_id from flight_master where flight_no='" + ddlfltNo.SelectedItem.Text + "')");
    //    com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
    //    com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
    //    DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
    //    DateTime CSR_Date = Convert.ToDateTime(dtOriginal.Rows[0]["CSR_Date"].ToString());
    //    com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
    //    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = CSR_Date.ToShortDateString();//changed by Sudarshan sir
    //    DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
    //    com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();
    //    com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
    //    com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
    //    com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
    //    com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
    //    com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
    //    string strOrgin = "";
    //    DataTable dtCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
    //    if (dtCityCode.Rows.Count > 0)
    //    {
    //        strOrgin = dtCityCode.Rows[0]["city_code"].ToString();
    //    }
    //    com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
    //    com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
    //    //com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = ddlOrigin.SelectedValue.Trim();
    //    com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();
    //    com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();
    //    com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);



    //    ////com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());

    //    com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
    //    com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
    //    com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
    //    com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());

    //    com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
    //    //////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Selling_Rate"].ToString());
    //    //////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["SellingFrtAmt"].ToString());



    //    com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
    //    com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["txtTariffRate"].ToString());

    //    com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
    //    com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
    //    com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());

    //    com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();

    //    com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "EUR";
    //    com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
    //    com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
    //    com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
    //    com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
    //    /////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();

    //    com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
    //    com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
    //    if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
    //    {
    //        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
    //    }
    //    if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
    //    {
    //        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
    //    }
    //    // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;

    //    com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
    //    com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
    //    com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;


    //    com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);


    //    DataTable dtCheckCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");

    //    com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtCheckCityCode.Rows[0]["city_code"].ToString();

    //    com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

    //    com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
    //    ////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
    //    ////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));


    //    com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));


    //    com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));


    //    ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
    //    ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));

    //    ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));

    //    com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
    //    com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDueCarrier.Text == "" ? 0 : decimal.Parse(txtDueCarrier.Text));

    //    //*************************Added on 09 March 2017 **************//

    //    com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
    //    com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
    //    com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));



    //    if (ChkMinAgent.Checked == true)
    //    {
    //        com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
    //    }


    //    //************added on 27 Feb 2017 : New column HB***************//
    //    com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
    //    //************End of 27 Feb 2017 : New column HB***************//
    //    //============================== Sub agent ===================================//
    //    com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
    //    com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;

    //    com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_No"].ToString());
    //    com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_SNO"].ToString());

    //    //**********************End Of 09 March 2017********************//



    //    com.ExecuteNonQuery();

    //}

    public void Insert_Sales_DrCrNew(SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    {

        string insert;

        ///// insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

        ////insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

        insert = "insert into Sales_DRCR(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_code,Originated_Airline_Detail_ID,ConversionRateToPHP,Selling_Rate,SellingFrtAmt,csr_remarks,SectorDestCode,SectorDestID,Routing,DeptAirportOrg,Total_DueCarrier,spot_rate,SellingRate_MinStatus,SubAgent_Name,SubAgent_Adress,AWB_Fees,Gateway,Interline,Carrier,Inner_Route,HB,Invoice_No,Invoice_SNo,CRDR) values(@Sales_ID,@Sales_type,@CSR_SNo,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Currency,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Selling_Rate,@SellingFrtAmt,@csr_remarks,@SectorDestCode,@SectorDestID,@Routing,@DeptAirportOrg,@Total_DueCarrier,@spot_rate,@SellingRate_MinStatus,@SubAgent_Name,@SubAgent_Adress,@AWB_Fees,@Gateway,@Interline,@Carrier,@Inner_Route,@HB,@Invoice_No,@Invoice_SNo,@CRDR)";

        SqlCommand com = new SqlCommand(insert, con);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "CRDR";
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());

        if (phRouteDetail.Controls.Count > 0)
        {
            ////Table dynamicTable = (Table)phRouteDetail.FindControl("dynamicRouteTable");
            Table dynamicTable = (Table)Session["table"];
            if (dynamicTable != null)
            {
                int r = 1;
                int tempval = 0;
                string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart();
                foreach (TableRow tbr in dynamicTable.Rows)
                {
                    if (r != 1 && temapVal == "PREMIER" && tempval == 0)
                    {
                        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ((TextBox)tbr.Cells[5].Controls[0]).Text;
                        ViewState["GridFlightNo"] = ((TextBox)tbr.Cells[5].Controls[0]).Text;
                        tempval++;

                    }
                    r++;
                }
            }
        }
        else
        {
            com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();

        }
        if (ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart() == "PREMIER")
        {
            string tempval = ViewState["GridFlightNo"].ToString();
            DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + tempval + "') ");

            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = (object)DBNull.Value;
            string dest = "";
            DataTable dtDestination = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
            if (dtDestination.Rows.Count > 0)
            {
                dest = dtDestination.Rows[0]["Destination_Code"].ToString();
            }

            com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dest;
            com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = ddlDestination.SelectedValue;
            //DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
            //if (dtSectorDest.Rows.Count > 0)
            //{
            //    com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

            //    com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
            //}
            //else
            //{
            //com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = "";

            //com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
            //}

        }
        else
        {

            DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + ddlfltNo.SelectedItem.Text + "') ");
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString());
            DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
            if (dtSectorDest.Rows.Count > 0)
            {
                com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

                com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
            }
            else
            {
                com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = ddlDestination.SelectedValue;

                com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
            }
        }
        //=======================END==============================================
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        string strOrgin = "";
        DataTable dtOrigin = dw.GetAllFromQuery("select city_Code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strOrgin = dtOrigin.Rows[0]["city_Code"].ToString();
        }
        #region For BuyingDetails
        //==============Added By:Pradeep Sharma===========================
        ////if (Convert.ToString(ViewState["GroupID"]) != "13" )
        if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
        {
            string Inter_NonInterline = "";

            ////if (rbtnRouteType1.Checked)///Interline
            ////{
            ////    Inter_NonInterline = "Y";

            ////}
            ////if (rbtnRouteType2.Checked)//Non-Interline
            ////{
            ////    Inter_NonInterline = "N";

            ////}
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "Y";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = lblOrigin.Text + "-" + txtCenturionRoute.Text + "-" + lblDestination.Text;
        }
        else
        {
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = "N/A";
        }
        #endregion
        ////strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        ////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = "";
        DataTable dtDest = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strDestination = dtDest.Rows[0]["Destination_Code"].ToString();
        }
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        ////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        ////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "USD";
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;


        com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_No"].ToString());
        com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_SNO"].ToString());


        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtcity_Code.Rows.Count > 0)
        {

            com.Parameters.Add("@Booking_City_code", SqlDbType.VarChar).Value = dtcity_Code.Rows[0]["city_code"].ToString();
        }

        com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

        //******************Added on 29_Sep_2010**********************************
        ////com.Parameters.Add("@Deal_Colour", SqlDbType.VarChar).Value = ddlDealColour.SelectedValue;
        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
        ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));
        ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));
        ////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        ////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));
        //****Modify by Hemant Sharma on 10'th Oct 2013****////
        DataTable dtDomestic = dw.GetAllFromQuery("select Airline_Name from Airline_Master am inner join Airline_detail ad on am.airline_id=ad.airline_id where ad.airline_detail_id=" + ddlAirline.SelectedValue + "");
        if (dtDomestic.Rows[0]["Airline_Name"].ToString() == "ZEST AIR")
        {
            //if (ddlAirline.SelectedItem.ToString().Substring(0, ddlAirline.SelectedItem.ToString().IndexOf('(')) == "ZEST AIR")
            //{
            //    if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
            //    {
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtAWBFee.Text;
            //}
            //else
            //{
            //    com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = null;

            //}
        }
        else
        {
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = (object)DBNull.Value;

        }
        //com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(hdninvno.Value);
        //com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(hdnInvsno.Value);
        com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;

        com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDueCarrier.Text == "" ? 0 : decimal.Parse(txtDueCarrier.Text));
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        }
        //************added on 27 Feb 2017 : New column HB***************//
        com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;

        com.Parameters.Add("@CRDR", SqlDbType.Char).Value = ddlCrDr.SelectedItem.Text;
        //************End of 27 Feb 2017 : New column HB***************//
        //============================== Sub agent ===================================//
        com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;
        com.ExecuteNonQuery();

        //////com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();
        //////DataTable dtFltopnId = dw.GetAllFromQuery("select Flight_open_id from flight_open where flight_id=(select flight_id from flight_master where flight_no='" + ddlfltNo.SelectedItem.Text + "')");
        //////com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
        //////com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        //////DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
        //////DateTime CSR_Date = Convert.ToDateTime(dtOriginal.Rows[0]["CSR_Date"].ToString());
        //////com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
        //////com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = CSR_Date.ToShortDateString();//changed by Sudarshan sir
        //////DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
        //////com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();
        //////com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        //////com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        //////com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
        //////com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
        //////com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
        //////string strOrgin = "";
        //////DataTable dtCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        //////if (dtCityCode.Rows.Count > 0)
        //////{
        //////    strOrgin = dtCityCode.Rows[0]["city_code"].ToString();
        //////}
        //////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        //////com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        ////////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = ddlOrigin.SelectedValue.Trim();
        //////com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();
        //////com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();
        //////com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);



        //////////com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());

        //////com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
        //////com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
        //////com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
        //////com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());

        //////com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
        ////////////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Selling_Rate"].ToString());
        ////////////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["SellingFrtAmt"].ToString());



        //////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
        //////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["txtTariffRate"].ToString());

        //////com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
        //////com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
        //////com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());

        //////com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();

        //////com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "EUR";
        //////com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
        //////com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
        //////com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
        //////com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
        ///////////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();

        //////com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
        //////com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        //////if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
        //////{
        //////    com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        //////}
        //////if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
        //////{
        //////    com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        //////}
        //////// com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;

        //////com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
        //////com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        //////com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;


        //////com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);


        //////DataTable dtCheckCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");

        //////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtCheckCityCode.Rows[0]["city_code"].ToString();

        //////com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

        //////com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        //////////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        //////////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));


        //////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));


        //////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));


        //////////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
        //////////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));

        //////////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));

        //////com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
        //////com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDueCarrier.Text == "" ? 0 : decimal.Parse(txtDueCarrier.Text));

        ////////*************************Added on 09 March 2017 **************//

        //////com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        //////com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        //////com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));



        //////if (ChkMinAgent.Checked == true)
        //////{
        //////    com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        //////}


        ////////************added on 27 Feb 2017 : New column HB***************//
        //////com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
        ////////************End of 27 Feb 2017 : New column HB***************//
        ////////============================== Sub agent ===================================//
        //////com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        //////com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;

        //////com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_No"].ToString());
        //////com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_SNO"].ToString());

        ////////**********************End Of 09 March 2017********************//



        //////com.ExecuteNonQuery();

    }

    public void Edit_Sales_DrCrNew(SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    {

        string update;

        ///// insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

        ////insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";

        update = "update Sales_DRCR set Sales_ID=@Sales_ID,Sales_type=@Sales_type,CSR_SNo=@CSR_SNo,Flight_No=@Flight_No,Flight_Open_ID=@Flight_Open_ID,AirWayBill_No=@AirWayBill_No,AWB_Date=@AWB_Date,CSR_Date=@CSR_Date,Flight_Date=@Flight_Date,Stock_ID=@Stock_ID,Agent_ID=@Agent_ID,Special_Commodity_ID=@Special_Commodity_ID,Shipment_ID=@Shipment_ID,Shipment_Name=@Shipment_Name,City_ID=@City_ID,City_Code=@City_Code,Destination_ID=@Destination_ID,Destination_Code=@Destination_Code,Airline_Detail_ID=@Airline_Detail_ID,No_of_Packages=@No_of_Packages,Gross_Weight=@Gross_Weight,Volume_Weight=@Volume_Weight,Charged_Weight=@Charged_Weight,Freight_Type=@Freight_Type,Tariff_Rate=@Tariff_Rate,Freight_Amount=@Freight_Amount,Principle_Rate=@Principle_Rate,Principle_Amount=@Principle_Amount,Principle_Spot_Rate=@Principle_Spot_Rate,Principle_Spot_Rate_Remarks=@Principle_Spot_Rate_Remarks,Currency=@Currency,Shipper_Name=@Shipper_Name,Shipper_Address=@Shipper_Address,Consignee_Name=@Consignee_Name,Consignee_Address=@Consignee_Address,Sales_Added_Date=@Sales_Added_Date,Add_To_Deal=@Add_To_Deal,Agent_Min_Status=@Agent_Min_Status,Principle_Min_Status=@Principle_Min_Status,Status=@Status,Last_Modified_BY=@Last_Modified_BY,Last_Modified_On=@Last_Modified_On,Booking_City_ID=@Booking_City_ID,Booking_City_code=@Booking_City_code,Originated_Airline_Detail_ID=@Originated_Airline_Detail_ID,ConversionRateToPHP=@ConversionRateToPHP,Selling_Rate=@Selling_Rate,SellingFrtAmt=@SellingFrtAmt,csr_remarks=@csr_remarks,SectorDestCode=@SectorDestCode,SectorDestID=@SectorDestID,Routing=@Routing,DeptAirportOrg=@DeptAirportOrg,Total_DueCarrier=@Total_DueCarrier,spot_rate=@spot_rate,SellingRate_MinStatus=@SellingRate_MinStatus,SubAgent_Name=@SubAgent_Name,SubAgent_Adress=@SubAgent_Adress,AWB_Fees=@AWB_Fees,Gateway=@Gateway,Interline=@Interline,Carrier=@Carrier,Inner_Route=@Inner_Route,HB=@HB,Invoice_No=@Invoice_No,Invoice_SNo=@Invoice_SNo,CRDR=@CRDR where Sales_ID=@Sales_ID";

        SqlCommand com = new SqlCommand(update, con);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "CRDR";
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());

        if (phRouteDetail.Controls.Count > 0)
        {
            ////Table dynamicTable = (Table)phRouteDetail.FindControl("dynamicRouteTable");

            Table dynamicTable = (Table)Session["table"];
            if (dynamicTable != null)
            {
                int r = 1;
                int tempval = 0;
                string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart();
                foreach (TableRow tbr in dynamicTable.Rows)
                {
                    if (r != 1 && temapVal == "PREMIER" && tempval == 0)
                    {
                        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ((TextBox)tbr.Cells[5].Controls[0]).Text;
                        ViewState["GridFlightNo"] = ((TextBox)tbr.Cells[5].Controls[0]).Text;
                        tempval++;

                    }
                    r++;
                }
            }
        }
        else
        {
            com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();

        }
        if (ddlAirline.SelectedItem.Text.Substring(0, 7).TrimStart() == "PREMIER")
        {
            string tempval = ViewState["GridFlightNo"].ToString();
            DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + tempval + "') ");

            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = (object)DBNull.Value;
            string dest = "";
            DataTable dtDestination = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
            if (dtDestination.Rows.Count > 0)
            {
                dest = dtDestination.Rows[0]["Destination_Code"].ToString();
            }

            com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dest;
            com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = ddlDestination.SelectedValue;
            //DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
            //if (dtSectorDest.Rows.Count > 0)
            //{
            //    com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

            //    com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
            //}
            //else
            //{
            //com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = "";

            //com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
            //}

        }
        else
        {

            DataTable dtflightOpenID = dw.GetAllFromQuery("select flight_open_Id from flight_open where flight_Id=(select flight_Id from flight_master where flight_No='" + ddlfltNo.SelectedItem.Text + "') ");
            com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString());
            DataTable dtSectorDest = dw.GetAllFromQuery("select fm.Destination,dm.destination_code from flight_master fm inner join Destination_Master dm on fm.Destination=dm.Destination_Id where flight_id=(select flight_id from flight_open where flight_open_id=" + long.Parse(dtflightOpenID.Rows[0]["Flight_Open_ID"].ToString()) + ")");
            if (dtSectorDest.Rows.Count > 0)
            {
                com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = dtSectorDest.Rows[0]["destination_code"].ToString();

                com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = dtSectorDest.Rows[0]["Destination"].ToString();
            }
            else
            {
                com.Parameters.Add("@SectorDestCode", SqlDbType.VarChar).Value = ddlDestination.SelectedValue;

                com.Parameters.Add("@SectorDestID", SqlDbType.Int).Value = (object)DBNull.Value;
            }
        }
        //=======================END==============================================
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        string strOrgin = "";
        DataTable dtOrigin = dw.GetAllFromQuery("select city_Code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strOrgin = dtOrigin.Rows[0]["city_Code"].ToString();
        }
        #region For BuyingDetails
        //==============Added By:Pradeep Sharma===========================
        ////if (Convert.ToString(ViewState["GroupID"]) != "13" )
        if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "435")
        {
            string Inter_NonInterline = "";

            ////if (rbtnRouteType1.Checked)///Interline
            ////{
            ////    Inter_NonInterline = "Y";

            ////}
            ////if (rbtnRouteType2.Checked)//Non-Interline
            ////{
            ////    Inter_NonInterline = "N";

            ////}
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "Y";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = lblOrigin.Text + "-" + txtCenturionRoute.Text + "-" + lblDestination.Text;
        }
        else
        {
            com.Parameters.Add("@Gateway", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Interline", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Carrier", SqlDbType.VarChar).Value = "N/A";
            com.Parameters.Add("@Inner_Route", SqlDbType.VarChar).Value = "N/A";
        }
        #endregion
        ////strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        ////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = "";
        DataTable dtDest = dw.GetAllFromQuery("select Destination_Code from Destination_Master where Destination_id=" + ddlDestination.SelectedValue + "");
        if (dtOrigin.Rows.Count > 0)
        {
            strDestination = dtDest.Rows[0]["Destination_Code"].ToString();
        }
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        ////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        ////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "USD";
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;


        com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_No"].ToString());
        com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_SNO"].ToString());


        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Last_Modified_BY", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Last_Modified_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        DataTable dtcity_Code = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        if (dtcity_Code.Rows.Count > 0)
        {

            com.Parameters.Add("@Booking_City_code", SqlDbType.VarChar).Value = dtcity_Code.Rows[0]["city_code"].ToString();
        }

        com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

        //******************Added on 29_Sep_2010**********************************
        ////com.Parameters.Add("@Deal_Colour", SqlDbType.VarChar).Value = ddlDealColour.SelectedValue;
        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
        ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));
        ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));
        ////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        ////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));
        com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));
        //****Modify by Hemant Sharma on 10'th Oct 2013****////
        DataTable dtDomestic = dw.GetAllFromQuery("select Airline_Name from Airline_Master am inner join Airline_detail ad on am.airline_id=ad.airline_id where ad.airline_detail_id=" + ddlAirline.SelectedValue + "");
        if (dtDomestic.Rows[0]["Airline_Name"].ToString() == "ZEST AIR")
        {
            //if (ddlAirline.SelectedItem.ToString().Substring(0, ddlAirline.SelectedItem.ToString().IndexOf('(')) == "ZEST AIR")
            //{
            //    if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
            //    {
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = txtAWBFee.Text;
            //}
            //else
            //{
            //    com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = null;

            //}
        }
        else
        {
            com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = (object)DBNull.Value;

        }
        //com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(hdninvno.Value);
        //com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(hdnInvsno.Value);
        com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;

        com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDueCarrier.Text == "" ? 0 : decimal.Parse(txtDueCarrier.Text));
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        }
        //************added on 27 Feb 2017 : New column HB***************//
        com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
        com.Parameters.Add("@CRDR", SqlDbType.Char).Value = ddlCrDr.SelectedItem.Text;
        //************End of 27 Feb 2017 : New column HB***************//
        //============================== Sub agent ===================================//
        com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;
        com.ExecuteNonQuery();

        //////com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();
        //////DataTable dtFltopnId = dw.GetAllFromQuery("select Flight_open_id from flight_open where flight_id=(select flight_id from flight_master where flight_no='" + ddlfltNo.SelectedItem.Text + "')");
        //////com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
        //////com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        //////DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
        //////DateTime CSR_Date = Convert.ToDateTime(dtOriginal.Rows[0]["CSR_Date"].ToString());
        //////com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
        //////com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = CSR_Date.ToShortDateString();//changed by Sudarshan sir
        //////DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
        //////com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();
        //////com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        //////com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        //////com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
        //////com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
        //////com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
        //////string strOrgin = "";
        //////DataTable dtCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
        //////if (dtCityCode.Rows.Count > 0)
        //////{
        //////    strOrgin = dtCityCode.Rows[0]["city_code"].ToString();
        //////}
        //////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        //////com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        ////////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = ddlOrigin.SelectedValue.Trim();
        //////com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();
        //////com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();
        //////com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);



        //////////com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());

        //////com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
        //////com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
        //////com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
        //////com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());

        //////com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
        ////////////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Selling_Rate"].ToString());
        ////////////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["SellingFrtAmt"].ToString());



        //////com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
        //////com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["txtTariffRate"].ToString());

        //////com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
        //////com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
        //////com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());

        //////com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();

        //////com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "EUR";
        //////com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
        //////com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
        //////com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
        //////com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
        ///////////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();

        //////com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
        //////com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        //////if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
        //////{
        //////    com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        //////}
        //////if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
        //////{
        //////    com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        //////}
        //////// com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;

        //////com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
        //////com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        //////com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;


        //////com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);


        //////DataTable dtCheckCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");

        //////com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtCheckCityCode.Rows[0]["city_code"].ToString();

        //////com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);

        //////com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        //////////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));
        //////////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));


        //////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));


        //////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));


        //////////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));
        //////////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));

        //////////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));

        //////com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
        //////com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDueCarrier.Text == "" ? 0 : decimal.Parse(txtDueCarrier.Text));

        ////////*************************Added on 09 March 2017 **************//

        //////com.Parameters.Add("@Routing", SqlDbType.VarChar).Value = txtRoute.Text.ToUpper();
        //////com.Parameters.Add("@DeptAirportOrg", SqlDbType.VarChar).Value = txtdepart_Airport.Text;
        //////com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));



        //////if (ChkMinAgent.Checked == true)
        //////{
        //////    com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 13;
        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@SellingRate_MinStatus", SqlDbType.Int).Value = 14;
        //////}


        ////////************added on 27 Feb 2017 : New column HB***************//
        //////com.Parameters.Add("@HB", SqlDbType.Char).Value = ddlHB.SelectedValue;
        ////////************End of 27 Feb 2017 : New column HB***************//
        ////////============================== Sub agent ===================================//
        //////com.Parameters.Add("@SubAgent_Name", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgentName.Text : (object)DBNull.Value;
        //////com.Parameters.Add("@SubAgent_Adress", SqlDbType.VarChar).Value = ViewState["SubAgentStatus"].ToString() == "Y" ? txtSubAgent_address.Text : (object)DBNull.Value;

        //////com.Parameters.Add("@Invoice_No", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_No"].ToString());
        //////com.Parameters.Add("@Invoice_SNO", SqlDbType.BigInt).Value = Convert.ToInt32(dtOriginal.Rows[0]["Invoice_SNO"].ToString());

        ////////**********************End Of 09 March 2017********************//



        //////com.ExecuteNonQuery();

    }
    #endregion
    #region Insert_Sales_DrCr2
    //public void Insert_Sales_DrCr2(SqlTransaction tr, SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    //{
    //    string insert;

    //    insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Freight_Type,Tariff_Rate,Freight_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Currency,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,Booking_City_ID,Booking_City_Code,Originated_Airline_Detail_ID,ConversionRateToPHP,Seling_Rate,SellingFrtAmt,csr_remarks,Total_DueCarrier) values(@Sales_ID,@Sales_type,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Collect,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@Booking_City_ID,@Booking_City_Code,@Originated_Airline_Detail_ID,@ConversionRateToPHP,@Seling_Rate,@SellingFrtAmt,@csr_remarks,@Total_DueCarrier)";


    //    SqlCommand com = new SqlCommand(insert, con, tr);
    //    com.CommandType = CommandType.Text;

    //    com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
    //    com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "CRDR";
    //    com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());

    //    com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedItem.Text.Trim();
    //    DataTable dtFltopnId = dw.GetAllFromQuery("select Flight_open_id from flight_open where flight_id=(select flight_id from flight_master where flight_no='" + ddlfltNo.SelectedItem.Text + "')");
    //    com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtFltopnId.Rows[0]["Flight_Open_ID"].ToString());
    //    com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
    //    DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
    //    com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
    //    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtCSRDate.Text);
    //    DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
    //    com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();

    //    com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
    //    com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
    //    com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
    //    com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
    //    com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
    //    string strOrgin = "";
    //    DataTable dtCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");
    //    if (dtCityCode.Rows.Count > 0)
    //    {
    //        strOrgin = dtCityCode.Rows[0]["city_code"].ToString();
    //    }
    //    com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
    //    com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
    //    //com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = ddlOrigin.SelectedValue.Trim();
    //    com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();

    //    com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();

    //    com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);


    //    ////com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());


    //    com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
    //    com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
    //    com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
    //    com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());


    //    com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
    //    com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
    //    com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["Freight_Amount"].ToString());


    //    com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
    //    com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
    //    com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());

    //    com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();

    //    com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "EUR";

    //    com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
    //    com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
    //    com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
    //    com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
    //    ////com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();


    //    com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
    //    // com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
    //    if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
    //    {
    //        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
    //    }
    //    if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
    //    {
    //        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
    //    }
    //    else
    //    {
    //        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
    //    }
    //    // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
    //    com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
    //    com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
    //    com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;


    //    com.Parameters.Add("@Booking_City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);


    //    DataTable dtCheckCityCode = dw.GetAllFromQuery("select city_code from city_master where city_id=" + ddlOrigin.SelectedValue + "");

    //    com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtCheckCityCode.Rows[0]["city_code"].ToString();

    //    com.Parameters.Add("@Originated_Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);


    //    com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));



    //    ////com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));

    //    ////com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtSpAmt.Text == "" ? 0 : decimal.Parse(txtSpAmt.Text));


    //    com.Parameters.Add("@Selling_Rate", SqlDbType.Decimal).Value = (txtTariffRate.Text == "" ? 0 : decimal.Parse(txtTariffRate.Text));


    //    com.Parameters.Add("@SellingFrtAmt", SqlDbType.Decimal).Value = (txtFreightAmount.Text == "" ? 0 : decimal.Parse(txtFreightAmount.Text));

    //    ////com.Parameters.Add("@Handling_Chrgs", SqlDbType.Decimal).Value = (txtHandlingChrgs.Text == "" ? 0 : decimal.Parse(txtHandlingChrgs.Text));

    //    ////com.Parameters.Add("@TruckingChrgs_Share", SqlDbType.Decimal).Value = (txtTruckShareChrgs.Text == "" ? 0 : decimal.Parse(txtTruckShareChrgs.Text));

    //    ////com.Parameters.Add("@Trucking_chrgs", SqlDbType.Decimal).Value = (txtTruckchrgs.Text == "" ? 0 : decimal.Parse(txtTruckchrgs.Text));

    //    com.Parameters.Add("@csr_remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;

    //    com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = (txtDueCarrier.Text == "" ? 0 : decimal.Parse(txtDueCarrier.Text));

    //    com.ExecuteNonQuery();
    //}
    #endregion
    public void LoadACS()
    {
        try
        {
            con = new SqlConnection(strCon);
            com = new SqlCommand("LOADACS", con);
            com.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            StringBuilder xmlData = new StringBuilder(dt.Rows[0]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlAgentName, "Agent_Master", "Agent_Name", "Agent_ID");
            xmlData = new StringBuilder(dt.Rows[1]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlScr, "Special_Commodity_Master", "Special_Commodity_Name", "Special_Commodity_ID");

            xmlData = new StringBuilder(dt.Rows[2]["Data"].ToString());
            bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlShipmentType, "Shipment_Master", "Shipment_Name", "Shipment_ID");
            ddlScr.SelectedValue = "35";
            ddlShipmentType.SelectedValue = "8";
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadUserOrigin()
    {
        try
        {

            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("LOAD_ORIGIN", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);

            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt = new DataTable();
            //da.Fill(dt);
            SqlDataReader dr = com.ExecuteReader();
            ddlOrigin.Items.Clear();
            ddlOrigin.Items.Insert(0, "- -Select- -");
            ddlOrigin.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlOrigin.Items.Add(new ListItem(dr["City_Code"].ToString() + "-" + dr["City_Name"].ToString(), dr["City_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadAgentStock()
    {
        string strAgent = "select Stock_ID,AirWayBill_No FROM dbo.Stock_Master sm INNER JOIN dbo.Airline_Master am ON SUBSTRING(sm.AirWayBill_No,1,3)=SUBSTRING(am.Airline_Code,1,3) INNER JOIN dbo.Airline_Detail ad ON am.Airline_ID = ad.Airline_ID where sm.Status=16 and sm.Agent_ID=" + ddlAgentName.SelectedValue + " and Airline_Detail_ID="+ddlAirline.SelectedValue+" ";
        con = new SqlConnection(strCon);
        con.Open();
        com = new SqlCommand(strAgent, con);
        SqlDataReader dr = com.ExecuteReader();
        ddlAwbNo.Items.Clear();
        ddlAwbNo.Items.Insert(0, "- -Select- -");
        ddlAwbNo.Items[0].Value = "0";
        while (dr.Read())
        {
            ddlAwbNo.Items.Add(new ListItem(dr["AirWayBill_No"].ToString(), dr["Stock_ID"].ToString()));
        }
        dr.Dispose();
        con.Close();
    }
    protected void ddlAgent_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        ddlOrigin.Items.Clear();
        ddlAirline.Items.Clear();
        ddlDestination.Items.Clear();
        LoadUserOrigin();      
        ////int i=CheckSubAgentStatus(Convert.ToInt32(ddlAgentName.SelectedValue));        
        ////ViewState["SubAgentStatus"] = i >= 1 ? "Y" : "N"; 
        ////trSubagent.Visible = i >= 1 ? true : false; 

        DataTable dtAgent = dw.GetAllFromQuery("select Agent_Name from Agent_Master where Agent_ID=" + ddlAgentName.SelectedValue);
        DataTable dtagentgstNo = new DataTable();
        if (dtAgent.Rows.Count > 0)
        {
            ViewState["Agent_ID"] = ddlAgentName.SelectedValue;
            ddlAgentName.SelectedItem.Text = dtAgent.Rows[0]["Agent_Name"].ToString();

            #region GstNo Applicable

          
           
                ddlGst.Items.Insert(0, "-Select-");
                ddlGst.Items[0].Value = "0";

                dtagentgstNo = dw.GetAllFromQuery("Select GstNo,Address from AgentGstNo where agentname like '" + ddlAgentName.SelectedItem.Text + "%'");
                if (dtagentgstNo != null && dtagentgstNo.Rows.Count > 0)
                {

                    for (int i = 0; i < dtagentgstNo.Rows.Count; i++)
                    {

                        ddlGst.Items.Add(new ListItem(dtagentgstNo.Rows[i]["GstNo"].ToString(), dtagentgstNo.Rows[i]["Address"].ToString()));
                    }


                }
            
            #endregion End of GstApplicable
        }
    }
    protected int  CheckSubAgentStatus(int Agent_ID)
    {
        com = new SqlCommand("CheckSubAgentStatus", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("Agent_ID", SqlDbType.BigInt).Value = Agent_ID;
        con.Open();
        SqlDataAdapter sda = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        sda.Fill(ds);
        con.Close();
        return ds.Tables[0].Rows.Count;
    }
    protected void ddlOrigin_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlOrigin.SelectedValue == "0")
        {
            ddlAirline.Items.Clear();
            ddlDestination.Items.Clear();
        }
        else
        {
            ddlAirline.Items.Clear();
            ddlDestination.Items.Clear();
            UserAirlineNamePlusCode();
            ViewState["AirlineDetailID"] = ddlAgentName.SelectedValue;
            //LoadDestination();
        }
    }
    public void UserAirlineNamePlusCode()
    {
        try
        {
            //string strQuery = "";
            //string Airline_Access = Rights();
            //strQuery = "select  a.Airline_Name,b.Airline_Detail_ID,c.City_Name from Airline_master a inner join Airline_Detail b on a.Airline_ID=b.Airline_ID inner join City_Master c on c.City_ID=b.Belongs_To_City where b.Airline_Detail_ID in" + "(" + Airline_Access + ") and Belongs_To_City =" + ddlOrigin.SelectedValue;

            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand("LOAD_AIRLINE", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@Belongs_To_City", SqlDbType.Int).Value = long.Parse(ddlOrigin.SelectedValue);
            com.Parameters.Add("@agent_id", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
            SqlDataReader dr = com.ExecuteReader();
            ddlAirline.Items.Clear();
            ddlAirline.Items.Insert(0, "- -Select- -");
            ddlAirline.Items[0].Value = "0";

            while (dr.Read())
            {

                ddlAirline.Items.Add(new ListItem(dr["Airline_Name"].ToString() + "(" + dr["City_Name"].ToString() + ")", dr["Airline_Detail_ID"].ToString()));
                //total_airlines = total_airlines + dr["Airline_Detail_ID"].ToString()+",";

            }
            //all_airlines = total_airlines;
            //int len_airline = all_airlines.Length;
            //Fill_Airline = all_airlines.Substring(0, (len_airline-1));
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void ddlAirline_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        if (ddlAirline.SelectedItem.Text == "ZEST AIR(I)(MANILA)")
        {
            trBuyingDetails.Visible = false;
            trRoutingDetails.Visible = false;
        }
        string temapVal = ddlAirline.SelectedItem.Text.Substring(0,7).TrimStart();
        if (temapVal == "PREMIER")
        {
            //trBuyingDetails.Visible = true; ;
            //////trRoutingDetails.Visible = true;
            /////trhide.Visible = true;
            ddlfltNo.Visible = false;
            tdflighNo.Visible = false;
           
        }
        else
        {           
            trRoutingDetails.Visible = false;
           ////// trhide.Visible = false;
            ddlfltNo.Visible = true;
            tdflighNo.Visible =true;
        }
        LoadDestination();
        LoadAgentStock();
        LoadFlight();        //Rate();
        DataTable dtAirlineID = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + ddlAirline.SelectedValue + "");
        hdnAirlineDetailId.Value = dtAirlineID.Rows[0]["Airline_ID"].ToString();
        if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
        {
            lblrate.Visible = false;
            txtrate.Visible = false;
        }
        else
        {
            lblrate.Visible = true;
            txtrate.Visible = true;
        }
        //****Modify by Hemant Sharma on 10'th Oct 2013////
        DataTable dtDomestic = dw.GetAllFromQuery("select Airline_Name from Airline_Master am inner join Airline_detail ad on am.airline_id=ad.airline_id where ad.airline_detail_id=" + ddlAirline.SelectedValue + "");
        if (dtDomestic.Rows[0]["Airline_Name"].ToString() == "ZEST AIR")
        {
            //if (ddlAirline.SelectedValue == "9" || ddlAirline.SelectedValue == "10" || ddlAirline.SelectedValue == "11" || ddlAirline.SelectedValue == "12" || ddlAirline.SelectedValue == "13" || ddlAirline.SelectedValue == "14" || ddlAirline.SelectedValue == "15" || ddlAirline.SelectedValue == "16" || ddlAirline.SelectedValue == "17" || ddlAirline.SelectedValue == "18")
            //{
                //lblawbfee.Visible = true;
                //txtAwbfee.Visible = true;
                DataTable dt = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + ddlAirline.SelectedValue + "");
                txtAWBFee.Text = dt.Rows[0]["AWB_Fees"].ToString();
            //}
            //else
            //{
            //    lblawbfee.Visible = false;
            //    txtAwbfee.Visible = false;
            //}

        }
        else
        {
            //lblawbfee.Visible = false;
            //txtAwbfee.Visible = false;
        }

    }    
    public void Rate()
    {
        DataTable dtAirlineID = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + ddlAirline.SelectedValue + "");

        hdnAirlineDetailId.Value = dtAirlineID.Rows[0]["Airline_ID"].ToString();

        if (dtAirlineID.Rows[0]["Airline_ID"].ToString() == "2")
        {
            //if (ddlDestination.SelectedValue == "1489" || ddlDestination.SelectedValue == "349" || ddlDestination.SelectedValue == "1499" || ddlDestination.SelectedValue == "1017")
            //{
                lblrate.Visible = false;
                txtrate.Visible = false;
            //}
            //else
            //{
                lblrate.Visible = false;
                txtrate.Visible = false;
            //}
        }
        else if (ddlAirline.SelectedValue=="10")
        {
            lblrate.Visible = false;
            txtrate.Visible = false;
        }
        else
        {
            lblrate.Visible = true;
            txtrate.Visible = true;
        }
       
    }  
    public void LoadFlight()
    {
        try
        {
            string FltNo = "";
            FltNo = "SELECT DISTINCT fm.Flight_No,fm.flight_id FROM flight_master fm INNER JOIN dbo.Flight_Details fd ON fm.Flight_ID = fd.Flight_ID WHERE fm.Airline_Detail_ID=" + ddlAirline.SelectedValue + " AND fm.Status=2";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(FltNo, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlfltNo.Items.Clear();
            ddlfltNo.Items.Insert(0, "- -Select- -");
            ddlfltNo.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlfltNo.Items.Add(new ListItem(dr["Flight_No"].ToString(), dr["flight_id"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public void LoadDestination()
    {
        try
        {
            string strAgent = "";
            strAgent = "Select distinct dm.Destination_ID,dm.Destination_Code,dm.Destination_Name from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ar.Airline_Detail_ID=" + ddlAirline.SelectedValue + " order by dm.Destination_Code";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strAgent, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlDestination.Items.Clear();
            ddlDestination.Items.Add("--Select--");
            ddlDestination.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlDestination.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }     

    protected void btnDrCr_Click(object sender, EventArgs e)
    {
        string note = ddlCrDr.SelectedItem.Text;  
        long Sales_ID = 0;
        con = new SqlConnection(strCon);
        con.Open();
        ////SqlTransaction tranupdate = con.BeginTransaction();
        string SalesID = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            SalesID = Request.QueryString["Sales_ID"];
        }
        DataTable dtHandoverID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);
        Sales_ID = long.Parse(dtHandoverID.Rows[0]["Sales_ID"].ToString());
        try
        {
            if (dtHandoverID.Rows.Count > 0)
            {
                DataTable dtSalesDRCR = dw.GetAllFromQuery("select * from Sales_DRCR where Sales_ID=" + SalesID);
                if (dtSalesDRCR.Rows.Count > 0)
                {
                    Edit_Sales_DrCrNew(con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                }
                else
                {
                    Insert_Sales_DrCrNew(con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                }
            
            con.Close();


            string strScript = "alert('CRDR generated sucessfully');location.replace('SalesEditDRCR.aspx');";

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Update", strScript, true);

            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            //tranupdate.Rollback();
            Label1.Visible = true;
            Label1.Text = ex.Message;
        }

    }
    protected void ddlCrDr_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCrDr.SelectedItem.Text == "Select")
        {
            btnDrCr.Visible = false;
        }
        else
        {
            btnDrCr.Visible = true;
        }
    }

    protected void ddlDestination_SelectedIndexChanged(object sender, EventArgs e)
    {
        LOAD_SCD();
        ViewState["AirlineDetailID"] = ddlAirline.SelectedValue;
        lblOrigin.Text = ddlOrigin.SelectedItem.ToString().Split('-')[0];
        lblDestination.Text = ddlDestination.SelectedItem.ToString().Split('-')[0];

        //#region Duecarrier
        //DataTable dtAirlineCharges = dw.GetAllFromQuery(" select * from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
        //Hidden1.Value = dtAirlineCharges.Rows[0]["ACI_Fees"].ToString();
        //Hidden2.Value = dtAirlineCharges.Rows[0]["DisBursementCharges"].ToString();
        //DataTable dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and Shipment_ID=" + ddlShipmentType.SelectedValue + "  and Destination=" + ddlDestination.SelectedValue);


        //if (dtAirlineCharges.Rows.Count > 0)
        //{
        //    if (dtAirlineCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
        //    {

        //        if (dtAirlineCharges.Rows[0]["FreightSurCharge_On"].ToString().Trim() == "Chargeable Wt.")
        //        {
        //            HiddenFSC.Value = "C";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox1.Value = dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString();
        //            }
        //        }
        //        else
        //        {
        //            HiddenFSC.Value = "G";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox1.Value = dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString();
        //            }
        //        }
        //    }
        //    if (dtAirlineCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
        //    {

        //        if (dtAirlineCharges.Rows[0]["WarSurcharge_On"].ToString().Trim() == "Chargeable Wt.")
        //        {
        //            HiddenWSC.Value = "C";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox2.Value = dtChargesDetails.Rows[0]["Security_SurCharge"].ToString();
        //            }
        //        }
        //        else
        //        {
        //            HiddenWSC.Value = "G";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox2.Value = dtChargesDetails.Rows[0]["Security_SurCharge"].ToString();
        //            }
        //        }
        //    }
        //    if (dtAirlineCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
        //    {

        //        if (dtAirlineCharges.Rows[0]["XRayCharge_On"].ToString().Trim() == "Chargeable Wt.")
        //        {
        //            HiddenXRay.Value = "C";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox3.Value = dtChargesDetails.Rows[0]["XRay_Charges"].ToString();
        //            }
        //        }
        //        else
        //        {
        //            HiddenXRay.Value = "G";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox3.Value = dtChargesDetails.Rows[0]["XRay_Charges"].ToString();
        //            }
        //        }
        //    }
        //}
        //if (HTextBox1.Value == "")
        //{
        //    HTextBox1.Value = "0";
        //    txtRFSC.Value = "0";
        //}
        //else
        //{
        //    txtRFSC.Value = HTextBox1.Value;
        //}
        //if (HTextBox2.Value == "")
        //{
        //    HTextBox2.Value = "0";
        //    txtRWSC.Value = "0";
        //}
        //else
        //{
        //    txtRWSC.Value = HTextBox2.Value;
        //}
        //if (HTextBox3.Value == "")
        //{
        //    HTextBox3.Value = "0";
        //    txtRXRAY.Value = "0";
        //}
        //else
        //{
        //    txtRXRAY.Value = HTextBox3.Value;
        //}
        //DataTable dtFix_Charges = dw.GetAllFromQuery("select * from fix_charges where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
        //{
        //    if (dtFix_Charges.Rows.Count > 0)
        //    {
        //        hndXray_fixCharges.Value = dtFix_Charges.Rows[0]["Min_XRay_Charges"].ToString();
        //    }
        //}
        //if (hndXray_fixCharges.Value == "")
        //{
        //    hndXray_fixCharges.Value = "0";
        //}


        //#endregion


        //////CreateTextBoxesInTable();  


        //#region MainCode
        //if (txtCw.Text == "")
        //{
        //    txtCw.Text = "0";
        //}

        //decimal chgwt = 0;
        //chgwt = Convert.ToDecimal(txtCw.Text);
        //DataTable dtSlabID = dw.GetAllFromQuery("select Slab_ID from Slab_Master where Slab_Start<=" + Math.Round(chgwt, MidpointRounding.AwayFromZero) + " and Slab_End>=" + Math.Round(chgwt, MidpointRounding.AwayFromZero));//Beneficial Rate Ka slabID is slab id ka next slabID hoga\
        //string strSlab = "";
        //foreach (DataRow rw in dtSlabID.Rows)
        //{
        //    strSlab = strSlab + rw["Slab_ID"].ToString() + ",";
        //}
        //strSlab = strSlab.Remove(strSlab.LastIndexOf(','));

        //DataTable dtAgentRateID = dw.GetAllFromQuery("select Agent_Rate_ID from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and Destination=" + ddlDestination.SelectedValue + " and Shipment_ID=" + ddlShipmentType.SelectedValue + " and Status=2 and valid_from <= '" + FormatDateDD(txtFlightDate.Text) + "' and valid_to >= '" + FormatDateDD(txtFlightDate.Text) + "'");
        //long AgentRateID = 0;
        //if (dtAgentRateID.Rows.Count > 0)
        //{
        //    AgentRateID = long.Parse(dtAgentRateID.Rows[0]["Agent_Rate_ID"].ToString());

        //    DataTable dtFinalSlab = dw.GetAllFromQuery("select  Slab_ID from Agent_Slab_Rate where Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'and Agent_Rate_ID='" + AgentRateID + "' and Slab_ID in(" + strSlab + ")");

        //    int SlabID = 0;
        //    if (dtFinalSlab.Rows.Count <= 0)
        //    {
        //        DataTable dtSlabNotExist = dw.GetAllFromQuery("select max(Slab_ID) as Slab_ID from Agent_Slab_Rate where Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'and Agent_Rate_ID='" + AgentRateID + "' ");
        //        if (dtSlabNotExist.Rows.Count > 0)
        //        {
        //            SlabID = int.Parse(dtSlabNotExist.Rows[0]["Slab_ID"].ToString());
        //        }

        //    }
        //    else//********if (dtFinalSlab.Rows.Count <= 0)********
        //    {
        //        if (dtFinalSlab.Rows.Count > 0)
        //        {
        //            SlabID = int.Parse(dtFinalSlab.Rows[0]["Slab_ID"].ToString());
        //        }
        //    }

        //    DataTable dtMin = dw.GetAllFromQuery("select Price_Value as Min from Agent_Slab_Rate where Slab_ID=1 and Agent_Rate_ID=" + AgentRateID);

        //    string Agent_Min;
        //    if (dtMin.Rows.Count > 0)
        //    {
        //        Agent_Min = dtMin.Rows[0]["Min"].ToString();
        //        ViewState["Min"] = Agent_Min;
        //    }
        //}
        //decimal Min = 0;
        //if (ViewState["Min"] != null)
        //{
        //    Min = Convert.ToDecimal(ViewState["Min"].ToString());
        //}
        //HTariffMinimum.Value = Min.ToString();
        //if (decimal.Parse(txtSpAmt.Text) == decimal.Parse(txtFreightAmount.Text) && Min == decimal.Parse(txtFreightAmount.Text))
        //{
        //    ChkMinAgent.Checked = true;
        //}

        ////*****End Calculation of Minimum of Existing Slab**************


        ////*****Calculation of Principle Amount*******************

        //DataTable dtPSlabID = dw.GetAllFromQuery("select Slab_ID from Slab_Master where Slab_Start<=" + Math.Round(decimal.Parse(txtCw.Text), MidpointRounding.AwayFromZero) + " and     Slab_End>=" + Math.Round(decimal.Parse(txtCw.Text), MidpointRounding.AwayFromZero));//Beneficial Rate Ka slabID is slab id ka next slabID hoga\
        //string strPSlab = "";
        //foreach (DataRow rw in dtPSlabID.Rows)
        //{
        //    strPSlab = strPSlab + rw["Slab_ID"].ToString() + ",";
        //}
        //strPSlab = strPSlab.Remove(strPSlab.LastIndexOf(','));

        //DataTable dtRateID = dw.GetAllFromQuery("select Rate_ID from Principle_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and Destination=" + ddlDestination.SelectedValue + " and Shipment_ID=" + ddlShipmentType.SelectedValue + " and Status=2 and valid_from <= '" + FormatDateDD(txtFlightDate.Text) + "' and valid_to >= '" + FormatDateDD(txtFlightDate.Text) + "'");

        //if (dtRateID.Rows.Count > 0)
        //{
        //    DataTable dtFinalSlab = dw.GetAllFromQuery("select  Slab_ID from Principle_Slab_Rate where Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'and Rate_ID='" + dtRateID.Rows[0]["Rate_ID"].ToString() + "' and Slab_ID in(" + strPSlab + ")");

        //    int SlabID = 0;
        //    if (dtFinalSlab.Rows.Count <= 0)
        //    {
        //        DataTable dtSlabNotExist = dw.GetAllFromQuery("select max(Slab_ID) as Slab_ID from Principle_Slab_Rate where Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'and Rate_ID='" + dtRateID.Rows[0]["Rate_ID"].ToString() + "' ");
        //        if (dtSlabNotExist.Rows.Count > 0)
        //        {
        //            SlabID = int.Parse(dtSlabNotExist.Rows[0]["Slab_ID"].ToString());

        //        }
        //    }
        //    else
        //    {
        //        if (dtFinalSlab.Rows.Count > 0)
        //        {
        //            SlabID = int.Parse(dtFinalSlab.Rows[0]["Slab_ID"].ToString());

        //        }
        //    }
        //    DataTable dtPriceValue = dw.GetAllFromQuery("select  Price_Value from Principle_Slab_Rate where Airline_Detail_ID='" + ViewState["AirlineDetailID"].ToString() + "'and Rate_ID='" + dtRateID.Rows[0]["Rate_ID"].ToString() + "' and Slab_ID =" + SlabID.ToString());
        //    if (dtPriceValue.Rows.Count > 0)
        //    {
        //        txtPRate.Text = dtPriceValue.Rows[0]["Price_Value"].ToString();
        //        decimal PAmount = decimal.Parse(txtPRate.Text) * decimal.Parse(txtCw.Text);
        //        PAmount = Math.Round(PAmount, MidpointRounding.AwayFromZero);
        //        txtPAmount.Text = PAmount.ToString();
        //    }

        //    DataTable dtMin = dw.GetAllFromQuery("select Price_Value as Min from Principle_Slab_Rate where Slab_ID=1 and           Rate_ID=" + dtRateID.Rows[0]["Rate_ID"].ToString());

        //    string Principle_Min;
        //    if (dtMin.Rows.Count > 0)
        //    {
        //        Principle_Min = dtMin.Rows[0]["Min"].ToString();
        //        HPrincipleMinimum.Value = Principle_Min.ToString();
        //        ViewState["Principle_Min"] = Principle_Min;
        //    }
        //}

        //decimal PMin = 0;
        //if (ViewState["Principle_Min"] != null)
        //{
        //    PMin = Convert.ToDecimal(ViewState["Principle_Min"].ToString());
        //}

        //if (decimal.Parse(txtPAmount.Text) < PMin)
        //{
        //    ChkMinAirline.Checked = true;
        //    txtPAmount.Text = PMin.ToString();
        //    txtPRate.Text = PMin.ToString();
        //}
        ////****End Calculation of Principle Amount****************

        //DataTable dtAirlineCharges = dw.GetAllFromQuery(" select * from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
        //Hidden1.Value = dtAirlineCharges.Rows[0]["ACI_Fees"].ToString();
        //Hidden2.Value = dtAirlineCharges.Rows[0]["DisBursementCharges"].ToString();
        //DataTable dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and Shipment_ID=" + ddlShipmentType.SelectedValue + "  and Destination=" + ddlDestination.SelectedValue);


        //if (dtAirlineCharges.Rows.Count > 0)
        //{
        //    if (dtAirlineCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
        //    {

        //        if (dtAirlineCharges.Rows[0]["FreightSurCharge_On"].ToString().Trim() == "Chargeable Wt.")
        //        {
        //            HiddenFSC.Value = "C";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox1.Value = dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString();
        //            }
        //        }
        //        else
        //        {
        //            HiddenFSC.Value = "G";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox1.Value = dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString();
        //            }
        //        }
        //    }
        //    if (dtAirlineCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
        //    {

        //        if (dtAirlineCharges.Rows[0]["WarSurcharge_On"].ToString().Trim() == "Chargeable Wt.")
        //        {
        //            HiddenWSC.Value = "C";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox2.Value = dtChargesDetails.Rows[0]["Security_SurCharge"].ToString();
        //            }
        //        }
        //        else
        //        {
        //            HiddenWSC.Value = "G";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox2.Value = dtChargesDetails.Rows[0]["Security_SurCharge"].ToString();
        //            }
        //        }
        //    }
        //    if (dtAirlineCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
        //    {

        //        if (dtAirlineCharges.Rows[0]["XRayCharge_On"].ToString().Trim() == "Chargeable Wt.")
        //        {
        //            HiddenXRay.Value = "C";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox3.Value = dtChargesDetails.Rows[0]["XRay_Charges"].ToString();
        //            }
        //        }
        //        else
        //        {
        //            HiddenXRay.Value = "G";
        //            if (dtChargesDetails.Rows.Count > 0)
        //            {
        //                HTextBox3.Value = dtChargesDetails.Rows[0]["XRay_Charges"].ToString();
        //            }
        //        }
        //    }
        //}
        //if (HTextBox1.Value == "")
        //{
        //    HTextBox1.Value = "0";
        //    txtRFSC.Value = "0";
        //}
        //else
        //{
        //    txtRFSC.Value = HTextBox1.Value;
        //}
        //if (HTextBox2.Value == "")
        //{
        //    HTextBox2.Value = "0";
        //    txtRWSC.Value = "0";
        //}
        //else
        //{
        //    txtRWSC.Value = HTextBox2.Value;
        //}
        //if (HTextBox3.Value == "")
        //{
        //    HTextBox3.Value = "0";
        //    txtRXRAY.Value = "0";
        //}
        //else
        //{
        //    txtRXRAY.Value = HTextBox3.Value;
        //}
        //DataTable dtFix_Charges = dw.GetAllFromQuery("select * from fix_charges where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
        //{
        //    if (dtFix_Charges.Rows.Count > 0)
        //    {
        //        hndXray_fixCharges.Value = dtFix_Charges.Rows[0]["Min_XRay_Charges"].ToString();
        //    }
        //}
        //if (hndXray_fixCharges.Value == "")
        //{
        //    hndXray_fixCharges.Value = "0";
        //}

        //#endregion MainCode

        //#region Surcharge Calculations
        //string FinancialYear = String.Empty;

        //string CSR_Date = (txtAWBDate.Text);
        //DateTime curDate = DateTime.Parse(FormatDateDD(txtAWBDate.Text));
        //string FinancialYearFirst = String.Empty;
        //string FinancialYearLast = String.Empty;

        //if (curDate.Month <= 3)
        //{
        //    int startYr = curDate.Year - 1;
        //    FinancialYearFirst = startYr.ToString();
        //    FinancialYearLast = curDate.Year.ToString();
        //}
        //else
        //{
        //    int endYr = curDate.Year + 1;
        //    FinancialYearFirst = curDate.Year.ToString();
        //    FinancialYearLast = endYr.ToString();
        //}
        //FinancialYear = FinancialYearFirst.ToString() + "-" + FinancialYearLast.ToString();

        //DataTable dtAgentwiseSurcharge = dw.GetAllFromQuery("select * from Agentwise_Surcharge where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Financial_Year='" + FinancialYear + "'");
        ////if (dtAgentwiseSurcharge.Rows.Count <= 0)
        ////{
        ////    //InsertAgentWiseSurcharge(FinancialYear);
        ////}
        //DataTable dtTDS_Surcharge = dw.GetAllFromQuery("select SurCharge,Company_SurCharge_Limit,NonCompany_SurCharge_Limit from TDS where  valid_from <= '" + AWB_Date + "'" + " and valid_to >= '" + AWB_Date + "'");
        //if (dtAgentwiseSurcharge.Rows.Count > 0)
        //{
        //    if (dtTDS_Surcharge.Rows.Count > 0)
        //    {
        //        txtSurcharge.Text = dtTDS_Surcharge.Rows[0]["SurCharge"].ToString();
        //    }
        //    else
        //    {
        //        txtSurcharge.Text = "0";
        //    }
        //}
        //else
        //{
        //    if (dtTDS_Surcharge.Rows.Count > 0)
        //    {
        //        SqlConnection con1 = new SqlConnection(strCon);
        //        con1.Open();
        //        SqlCommand cmd = new SqlCommand("SURCHARGE_REPORT", con1);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("COMPANY_ID", ViewState["CompanyID"].ToString());
        //        cmd.Parameters.AddWithValue("AGENT_ID", ViewState["Agent_ID"].ToString());
        //        cmd.Parameters.AddWithValue("FROM_DATE", ("04/01/" + FinancialYearFirst.ToString()));
        //        cmd.Parameters.AddWithValue("TO_DATE", FormatDateDD(txtAWBDate.Text));
        //        cmd.Parameters.AddWithValue("Airline_Detail_ID", ViewState["AirlineDetailID"].ToString());
        //        cmd.Parameters.AddWithValue("REPORT_TYPE", "TOTAL");
        //        SqlDataAdapter da_SQL = new SqlDataAdapter(cmd);
        //        DataTable dtAgentwiseTotal = new DataTable();
        //        da_SQL.Fill(dtAgentwiseTotal);

        //        // DataTable dtAgentwiseTotal = dw.GetAllFromQuery("select  Sum(Used_Exemption_Limit) as Used_Exemption_Limit from Agentwise_Used_TDS where Agent_ID=" + ViewState["Agent_ID"].ToString() + " group by Agent_ID");

        //        decimal TotalAgentUsedLimit = 0;
        //        if (dtAgentwiseTotal.Rows.Count > 0)
        //        {
        //            TotalAgentUsedLimit = decimal.Parse(dtAgentwiseTotal.Rows[0]["Used_Exemption_Limit"].ToString());
        //        }

        //        TotalAgentUsedLimit = TotalAgentUsedLimit + TDS();
        //        ViewState["TotalAgentUsedLimit"] = TotalAgentUsedLimit;
        //        DataTable dtAgentType = dw.GetAllFromQuery("select Agent_Type from Agent_Master where Agent_ID=" + ViewState["Agent_ID"].ToString());
        //        if (dtAgentType.Rows.Count > 0)
        //        {
        //            if (dtAgentType.Rows[0]["Agent_Type"].ToString() == "21")
        //            {
        //                decimal Company_SurCharge_Limit = decimal.Parse(dtTDS_Surcharge.Rows[0]["Company_SurCharge_Limit"].ToString());
        //                if (TotalAgentUsedLimit > Company_SurCharge_Limit)
        //                {
        //                    InsertAgentWiseSurcharge(FinancialYear, Convert.ToDecimal(dtTDS_Surcharge.Rows[0]["SurCharge"].ToString()));
        //                    if (dtTDS_Surcharge.Rows.Count > 0)
        //                    {
        //                        txtSurcharge.Text = dtTDS_Surcharge.Rows[0]["SurCharge"].ToString();
        //                    }
        //                    else
        //                    {
        //                        txtSurcharge.Text = "0";
        //                    }
        //                }
        //                else
        //                {
        //                    txtSurcharge.Text = "0";
        //                }
        //            }
        //            else
        //            {
        //                decimal NonCompany_SurCharge_Limit = decimal.Parse(dtTDS_Surcharge.Rows[0]["NonCompany_SurCharge_Limit"].ToString());
        //                if (TotalAgentUsedLimit > NonCompany_SurCharge_Limit)
        //                {
        //                    InsertAgentWiseSurcharge(FinancialYear, Convert.ToDecimal(dtTDS_Surcharge.Rows[0]["SurCharge"].ToString()));
        //                    if (dtTDS_Surcharge.Rows.Count > 0)
        //                    {
        //                        txtSurcharge.Text = dtTDS_Surcharge.Rows[0]["SurCharge"].ToString();
        //                    }
        //                    else
        //                    {
        //                        txtSurcharge.Text = "0";
        //                    }
        //                }
        //                else
        //                {
        //                    txtSurcharge.Text = "0";
        //                }
        //            }
        //        }//*****End of (dtAgentType.Rows.Count > 0)
        //    }
        //    else
        //    {
        //        txtSurcharge.Text = "0";
        //    }
        //}
        ////***************End Surcharge Calculation***********
        //#endregion End Surcharge Calculations

    }

    protected void grd_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grd.EditIndex = -1;
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        grd.DataSource = dt;
        grd.DataBind();
    }
    protected void grd_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["Sno"].ToString() == "0")
                {
                    dt.Rows[0].Delete();
                }
            }
            TextBox txthader = grd.FooterRow.FindControl("txtheader") as TextBox;
            TextBox txtfee = grd.FooterRow.FindControl("txtvalue") as TextBox;
            DropDownList drp = (DropDownList)(grd.FooterRow.FindControl("ddlgrd"));
            string paymenttype = drp.SelectedItem.Text;
            DataRow dr = dt.NewRow();
            dr[1] = txthader.Text;
            dr[2] = txtfee.Text;
            dr[3] = paymenttype;
            dt.Rows.Add(dr);
            Session["dtOtherCharges"] = dt;
            decimal DueAgent = 0, DueAgentP = 0, DueAgentC = 0;
            foreach (DataRow rw in dt.Rows)
            {
                DueAgent = DueAgent + Convert.ToDecimal(rw["Fee"].ToString());
                if (rw["PaymentType"].ToString() == "PREPAID")
                {
                    DueAgentP = DueAgentP + Convert.ToDecimal(rw["Fee"].ToString());
                }
                if (rw["PaymentType"].ToString() == "COLLECT")
                {
                    DueAgentC = DueAgentC + Convert.ToDecimal(rw["Fee"].ToString());
                }
            }
            //****************************************
            txtDueAgentP.Text = DueAgentP.ToString();
            txtDueAgentC.Text = DueAgentC.ToString();
            txtDueAgent.Text = DueAgent.ToString();
            //****************************************

            //******Calculation of Dbcharges****************
            decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
            txtDueAgentP.Text = dueP.ToString();
            decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
            txtDueAgentC.Text = dueC.ToString();
            decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
            txtPrepaid.Text = PP.ToString();
            decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
            txtCollect.Text = CC.ToString();
            if (txtDueAgentC.Text != "0")
            {
                decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
                //Taking 10% of Dbcharges*******************
                CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
                CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
                decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
                if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
                {
                    txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
                }
                else
                {
                    txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
                }
            }
            else
            {
                txtDisbursmentCharges.Text = "0";
            }
            //****End of Dbcharges**************************

            //*****Managing Values After PostBack***********

            decimal ACI = decimal.Parse(Hidden1.Value) * decimal.Parse(txtHouses.Value);
            txtACIFee.Text = ACI.ToString();
            //decimal Due = decimal.Parse(Hidden3.Value) + (ACI - decimal.Parse(Hidden1.Value));
            decimal ThreeCharges = decimal.Parse(txtFSC.Text) + decimal.Parse(txtWSC.Text) + decimal.Parse(txtXRAY.Text);
            decimal Result = ThreeCharges + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtOthers.Text);
            Result = Math.Round(Result, MidpointRounding.AwayFromZero);
            txtDueCarrier.Text = Result.ToString();

            //*****End of Manage Values******************

            grd.DataSource = dt;
            grd.DataBind();

            if (rbDueFreight.SelectedValue == "PREPAID")
            {
                decimal Total_Prepaid = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentP.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    Total_Prepaid = Total_Prepaid + decimal.Parse(txtSpAmt.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = txtDueAgentC.Text;
                }
                else
                {
                    decimal Total_Collect = decimal.Parse(txtSpAmt.Text) + decimal.Parse(txtDueAgentC.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = Total_Prepaid.ToString();
                }
            }
            else
            {
                decimal Total_Collect = decimal.Parse(txtDueCarrier.Text) + decimal.Parse(txtValuationCharge.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtDueAgentC.Text);
                if (rbFType.SelectedValue == "PREPAID")
                {
                    decimal Total_Prepaid = decimal.Parse(txtSpAmt.Text) + decimal.Parse(txtDueAgentP.Text);
                    txtPrepaid.Text = Total_Prepaid.ToString();
                    txtCollect.Text = Total_Collect.ToString();
                }
                else
                {
                    Total_Collect = Total_Collect + decimal.Parse(txtSpAmt.Text);
                    txtCollect.Text = Total_Collect.ToString();
                    txtPrepaid.Text = txtDueAgentP.Text;
                }
            }
        }
    }
    protected void grd_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow && grdCal.EditIndex == e.Row.RowIndex)
        {
            //Label ddlcarr = (e.Row.FindControl("lblcarr") as Label);
            //DropDownList ddlcarr = (e.Row.FindControl("ddlcarr") as DropDownList);
            //ddlcarr.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            //ddlcarr.DataTextField = "CarrierCode";
            //ddlcarr.DataValueField = "CarrierCode";
            //ddlcarr.DataBind();
            ////Add Default Item in the DropDownList.
            //// Label lblcarr = (e.Row.FindControl("lblcarr") as Label);
            //// HiddenField hfStatus = (e.Row.FindControl("hfcarr") as HiddenField);
            //// string selectedCarrier = (e.Row.FindControl("lblcarr") as Label).Text;//DataBinder.Eval(e.Row.DataItem, "CarrierCode").ToString();
            //string Carrier = (e.Row.DataItem as DataRowView)["Carrier"].ToString();
            //ddlcarr.Items.FindByValue(Carrier).Selected = true;


            ////Bind Currency
            //DropDownList ddlcarrency = (e.Row.FindControl("ddlCurr") as DropDownList);
            //ddlcarrency.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            //ddlcarrency.DataTextField = "CarrierCode";
            //ddlcarrency.DataValueField = "CarrierCode";
            //ddlcarrency.DataBind();
            //// ddlcarrency.Items.Insert(0, new ListItem("Please select"));
            ////Add Default Item in the DropDownList.
            ////string selectedcurrency = (e.Row.FindControl("ddlCurr") as DropDownList).SelectedItem.Text;//DataBinder.Eval(e.Row.DataItem, "CarrierCode").ToString();
            ////ddlcarrency.Items.FindByValue(selectedcurrency).Selected = true;
            //string selectedcurrency = (e.Row.DataItem as DataRowView)["Currency"].ToString();
            //ddlcarrency.Items.FindByValue(selectedcurrency).Selected = true;

            ///////////
            //total += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "rate"));//
            //txtPRate.Text = Convert.ToString(total);
            // txtlength.Attributes.Add("onkeypress", " javascript: return confirm('Are you sure to Cancel? ')");
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            //DropDownList ddlcarr = (e.Row.FindControl("ddlcarr") as DropDownList);
            //ddlcarr.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            //ddlcarr.DataTextField = "CarrierCode";
            //ddlcarr.DataValueField = "CarrierCode";
            //ddlcarr.DataBind();
            ////Add Default Item in the DropDownList.
            //ddlcarr.Items.Insert(0, new ListItem("Please select"));


            ////Bind Currency
            //DropDownList ddlcarrency = (e.Row.FindControl("ddlCurr") as DropDownList);
            //ddlcarrency.DataSource = GetData("select Carrier_SNo,CarrierName,CarrierCode,Interline from InterLineCarrier");
            //ddlcarrency.DataTextField = "CarrierCode";
            //ddlcarrency.DataValueField = "CarrierCode";
            //ddlcarrency.DataBind();
            //ddlcarrency.Items.Insert(0, new ListItem("Please select"));

            ///////////
            //total += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "rate"));//Convert.ToInt32(((TextBox)grdCal.FooterRow.FindControl("txtp")).Text);;//
            //txtPRate.Text = Convert.ToString(total);
            // txtlength.Attributes.Add("onkeypress", " javascript: return confirm('Are you sure to Cancel? ')");
        }
        ////if (e.Row.RowType == DataControlRowType.DataRow)
        ////{
        ////    if (ViewState["edit"].ToString() == ViewState["et"].ToString())
        ////    {
        ////        Label lbl = (Label)e.Row.Cells[3].FindControl("lblpaymenttype");
        ////        DropDownList ddl = (DropDownList)e.Row.Cells[3].FindControl("ddlgrd");
        ////        if (ViewState["edit"].ToString() == "PREPAID")
        ////        {
        ////            //ddl.SelectedIndex=2;
        ////        }
        ////        else
        ////        {
        ////            //ddl.SelectedIndex=1;

        ////        }
        ////    }
        ////    if (grd.EditIndex == e.Row.RowIndex)
        ////    {
        ////        //DropDownList ddlGrd = (DropDownList)e.Row.FindControl("ddlgrd");
        ////        //ddlGrd.SelectedItem.Text = ViewState["PaymentMode"].ToString();

        ////        //ddlGrd.Items.Add(new ListItem("PREPAID","PREPAID"));
        ////        //ddlGrd.Items.Add(new ListItem("COLLECT","COLLECT"));
        ////        //ddlGrd.SelectedIndex = ddlGrd.Items.IndexOf(ddlGrd.Items.FindByText((e.Row.c));

        ////    }

        ////}
    }
    protected void grd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        int Sno = Convert.ToInt32(grd.DataKeys[e.RowIndex].Value);
        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == Sno.ToString())
            {
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[e.RowIndex]["PaymentType"].ToString() == "PREPAID")
                    {
                        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        decimal Prepaid = decimal.Parse(txtPrepaid.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgentP.Text = DueAgentP.ToString();
                        txtPrepaid.Text = Prepaid.ToString();
                        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgent.Text = DueAgent.ToString();
                    }
                    if (dt.Rows[e.RowIndex]["PaymentType"].ToString() == "COLLECT")
                    {
                        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgentC.Text = DueAgentC.ToString();
                        decimal Collect = decimal.Parse(txtCollect.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtCollect.Text = Collect.ToString();
                        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - decimal.Parse(dt.Rows[e.RowIndex]["Fee"].ToString());
                        txtDueAgent.Text = DueAgent.ToString();
                    }
                    dt.Rows[e.RowIndex].Delete();

                    //******Calculation of DbCharges*****************
                    decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = dueP.ToString();
                    decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = dueC.ToString();
                    decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = PP.ToString();
                    decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
                    txtCollect.Text = CC.ToString();
                    if (txtDueAgentC.Text != "0")
                    {
                        decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
                        //Taking 10% of Dbcharges*******************
                        CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
                        CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
                        decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
                        if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
                        {
                            txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
                        }
                        else
                        {
                            txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
                        }
                    }
                    else
                    {
                        txtDisbursmentCharges.Text = "0";
                    }
                    //***End of Calculation of DbCharges*****************
                }
                break;
            }
        }//****End of Foreach loop**********

        //**********Calculation of DueCarrier on Update*********
        decimal ThreeCharges = decimal.Parse(txtFSC.Text) + decimal.Parse(txtWSC.Text) + decimal.Parse(txtXRAY.Text);
        decimal Result = ThreeCharges + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtOthers.Text);
        Result = Math.Round(Result, MidpointRounding.AwayFromZero);
        txtDueCarrier.Text = Result.ToString();
        //********End of Calculation Of DueCarrier**************

        if (dt.Rows.Count > 0)
        {
            Session["dtOtherCharges"] = dt;
            grd.DataSource = dt;
            grd.DataBind();
        }
        else
        {
            DataTable dtBeginCharges = MakeTableCharges();
            Session["dtOtherCharges"] = dtBeginCharges;
            grd.DataSource = dtBeginCharges;
            grd.DataBind();
        }

    }
    protected void grd_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (grd.DataKeys[e.NewEditIndex].Value.ToString() == "0")
        {
            lblmsg.Visible = true;
        }
        else
        {
            lblmsg.Visible = false;
            Label edit = (Label)grd.Rows[e.NewEditIndex].FindControl("lblpaymenttype");
            Label txtFee = (Label)grd.Rows[e.NewEditIndex].FindControl("txtvalue");
            ViewState["Fee"] = txtFee.Text;
            ViewState["PaymentMode"] = edit.Text;
            ViewState["edit"] = edit.Text;
            ViewState["et"] = ViewState["edit"];
            grd.EditIndex = e.NewEditIndex;
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            grd.DataSource = dt;
            grd.DataBind();
        }
    }
    protected void grd_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable dt = (DataTable)Session["dtOtherCharges"];
        int sno = Convert.ToInt32(grd.DataKeys[e.RowIndex].Value);
        string strheader = ((TextBox)grd.Rows[e.RowIndex].FindControl("txtheader")).Text;
        //int value =Convert.ToInt32(((TextBox)grd.Rows[e.RowIndex].FindControl("txtvalue")).Text);
        decimal value = Convert.ToInt32(((TextBox)grd.Rows[e.RowIndex].FindControl("txtvalue")).Text);
        DropDownList drp = (DropDownList)(grd.Rows[e.RowIndex].FindControl("ddlgrd"));
        string paymenttype = drp.SelectedItem.Text;

        decimal Fee = Convert.ToDecimal(ViewState["Fee"]);
        string PaymentMode = Convert.ToString(ViewState["PaymentMode"]);

        //********* FOR CHANGING PAYMENT TYPE Prepaid to Collect**********

        if (PaymentMode == "PREPAID")
        {
            if (paymenttype == "COLLECT")
            {
                if (Fee > value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                }
                if (Fee < value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                }
                if (Fee == value)
                {
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - Fee;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + value;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - Fee;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) + value;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                }
            }
        }
        if (PaymentMode == "COLLECT")
        {
            if (paymenttype == "PREPAID")
            {
                if (Fee > value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                }
                if (Fee < value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                }
                if (Fee == value)
                {
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - Fee;
                    DueAgentC = Math.Round(DueAgentC, MidpointRounding.AwayFromZero);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + value;
                    DueAgentP = Math.Round(DueAgentP, MidpointRounding.AwayFromZero);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = DueAgentP + DueAgentC;
                    txtDueAgent.Text = DueAgent.ToString();
                    decimal Collect = decimal.Parse(txtCollect.Text) - Fee;
                    Collect = Math.Round(Collect, MidpointRounding.AwayFromZero);
                    txtCollect.Text = Collect.ToString();
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + value;
                    Prepaid = Math.Round(Prepaid, MidpointRounding.AwayFromZero);
                    txtPrepaid.Text = Prepaid.ToString();
                }
            }
        }

        //********End of FOR CHANGING PAYMENT TYPE Prepaid to Collect**********

        if (PaymentMode == "PREPAID")
        {
            if (paymenttype == "PREPAID")
            {
                if (Fee > value)
                {
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) - (Fee - value);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - (Fee - value);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
                    txtDueAgent.Text = DueAgent.ToString();
                }
                if (Fee < value)
                {
                    decimal Prepaid = decimal.Parse(txtPrepaid.Text) + (value - Fee);
                    txtPrepaid.Text = Prepaid.ToString();
                    decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + (value - Fee);
                    txtDueAgentP.Text = DueAgentP.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
                    txtDueAgent.Text = DueAgent.ToString();
                }
            }
            //if (paymenttype == "COLLECT")
            //{
            //    if (Fee > value)
            //    {
            //        decimal Collect = decimal.Parse(txtCollect.Text) - (Fee - value);
            //        txtCollect.Text = Collect.ToString();
            //        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - (Fee - value);
            //        txtDueAgentC.Text = DueAgentC.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //    if (Fee < value)
            //    {
            //        decimal Collect = decimal.Parse(txtCollect.Text) + (value - Fee);
            //        txtCollect.Text = Collect.ToString();
            //        decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + (value - Fee);
            //        txtDueAgentC.Text = DueAgentC.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //}
        }
        if (PaymentMode == "COLLECT")
        {
            if (paymenttype == "COLLECT")
            {
                if (Fee > value)
                {
                    decimal Collect = decimal.Parse(txtCollect.Text) - (Fee - value);
                    txtCollect.Text = Collect.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) - (Fee - value);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
                    txtDueAgent.Text = DueAgent.ToString();
                }
                if (Fee < value)
                {
                    decimal Collect = decimal.Parse(txtCollect.Text) + (value - Fee);
                    txtCollect.Text = Collect.ToString();
                    decimal DueAgentC = decimal.Parse(txtDueAgentC.Text) + (value - Fee);
                    txtDueAgentC.Text = DueAgentC.ToString();
                    decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
                    txtDueAgent.Text = DueAgent.ToString();
                }
            }
            //if (paymenttype == "PREPAID")
            //{
            //    if (Fee > value)
            //    {
            //        decimal Prepaid = decimal.Parse(txtPrepaid.Text) - (Fee - value);
            //        txtPrepaid.Text = Prepaid.ToString();
            //        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) - (Fee - value);
            //        txtDueAgentP.Text = DueAgentP.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) - (Fee - value);
            //        txtDueAgent.Text = DueAgent.ToString();
            //    }
            //    if (Fee < value)
            //    {
            //        decimal Prepaid = decimal.Parse(txtPrepaid.Text) + (value - Fee);
            //        txtPrepaid.Text = Prepaid.ToString();
            //        decimal DueAgentP = decimal.Parse(txtDueAgentP.Text) + (value - Fee);
            //        txtDueAgentP.Text = DueAgentP.ToString();
            //        decimal DueAgent = decimal.Parse(txtDueAgent.Text) + (value - Fee);
            //        txtDueAgent.Text = DueAgent.ToString();

            //    }
            //}

        }

        //************** Calculation Of DbCharges*********
        decimal dueP = Math.Round(decimal.Parse(txtDueAgentP.Text), MidpointRounding.AwayFromZero);
        txtDueAgentP.Text = dueP.ToString();
        decimal dueC = Math.Round(decimal.Parse(txtDueAgentC.Text), MidpointRounding.AwayFromZero);
        txtDueAgentC.Text = dueC.ToString();
        decimal PP = Math.Round(decimal.Parse(txtPrepaid.Text), MidpointRounding.AwayFromZero);
        txtPrepaid.Text = PP.ToString();
        decimal CC = Math.Round(decimal.Parse(txtCollect.Text), MidpointRounding.AwayFromZero);
        txtCollect.Text = CC.ToString();
        if (txtDueAgentC.Text != "0")
        {
            decimal CollectDueAgentForDbcharges = decimal.Parse(txtDueAgentC.Text);
            //Taking 10% of Dbcharges*******************
            CollectDueAgentForDbcharges = CollectDueAgentForDbcharges * 10;
            CollectDueAgentForDbcharges = CollectDueAgentForDbcharges / 100;
            decimal DbchargesAirlineDetail = decimal.Parse(Hidden2.Value);
            if (CollectDueAgentForDbcharges >= DbchargesAirlineDetail)
            {
                txtDisbursmentCharges.Text = CollectDueAgentForDbcharges.ToString();
            }
            else
            {
                txtDisbursmentCharges.Text = DbchargesAirlineDetail.ToString();
            }
        }
        else
        {
            txtDisbursmentCharges.Text = "0";
        }

        //********End of Calculation Of DbCharges*********

        //**********Calculation of DueCarrier on Update*********
        decimal ThreeCharges = decimal.Parse(txtFSC.Text) + decimal.Parse(txtWSC.Text) + decimal.Parse(txtXRAY.Text);
        decimal Result = ThreeCharges + decimal.Parse(txtACIFee.Text) + decimal.Parse(txtAWBFee.Text) + decimal.Parse(txtDisbursmentCharges.Text) + decimal.Parse(txtCatrage.Text) + decimal.Parse(txtOthers.Text);
        Result = Math.Round(Result, MidpointRounding.AwayFromZero);
        txtDueCarrier.Text = Result.ToString();
        //********End of Calculation Of DueCarrier**************

        foreach (DataRow dr in dt.Rows)
        {
            if (dr["Sno"].ToString() == sno.ToString())
            {
                dr[1] = strheader;
                dr[2] = value;
                dr[3] = paymenttype;
            }
        }
        Session["dtOtherCharges"] = dt;
        grd.DataSource = dt;
        grd.EditIndex = -1;
        grd.DataBind();


    }

 
    public void fillOtherCharges(string bookingId)
    {
        //string bookingId = Request.QueryString["Booking_ID"].ToString();
        string strQuery = "select * from Other_Charges where booking_Id = '" + bookingId + "'";
        con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand(strQuery, con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataTable dt = MakeTableCharges();
        dt.Rows[0].Delete();
        DataRow dw;
        int i = 1;
        while (dr.Read())
        {
            dw = dt.NewRow();
            dw[0] = i++;

            string amount = dr["Amount"].ToString();
            decimal amt = System.Math.Round(decimal.Parse(amount), MidpointRounding.AwayFromZero);
            dw[1] = dr["Charge_Name"].ToString();
            dw[2] = amt;
            dw[3] = dr["Prepaid_or_Collect"].ToString();
            dt.Rows.Add(dw);

        }
        Session["dtOtherCharges"] = dt;
        if (dt.Rows.Count > 0)
        {
            grd.DataSource = dt;
            grd.DataBind();
        }
        else
        {
            grd.DataSource = MakeTableCharges();
            grd.DataBind();
        }
        con.Close();
    }
    public void FillSalesFields()
    {
      
        string SalesID = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            SalesID = Request.QueryString["Sales_ID"];
        }
        DateTime CurrentDate = DateTime.Now;
        string strCurrentDate = CurrentDate.ToShortDateString();
        txtCSRDate.Text = FormatDateDD(strCurrentDate);



        //DataTable dtSales = dw.GetAllFromQuery("SELECT Booking_AWB.*,Sales.* FROM   Booking_AWB INNER JOIN Sales ON  Booking_AWB.Sales_ID =Sales.Sales_ID  where Sales.Sales_ID=" + SalesID);
        DataTable dtSales = dw.GetAllFromQuery("SELECT * FROM Sales where Sales_ID=" + SalesID);
        if (dtSales.Rows.Count > 0)
        {

            DataTable dtAirlineID = dw.GetAllFromQuery("SELECT * FROM dbo.Airline_Detail WHERE Airline_Detail_ID=" + dtSales.Rows[0]["Airline_Detail_Id"].ToString() + "");
            LoadACS();
            
            ddlAgentName.SelectedValue = dtSales.Rows[0]["Agent_Id"].ToString();
            ddlAgentName.Enabled = false;
            LoadUserOrigin();
            ddlOrigin.SelectedValue = dtSales.Rows[0]["City_ID"].ToString();
            UserAirlineNamePlusCode();
            ddlAirline.SelectedValue = dtSales.Rows[0]["Airline_Detail_Id"].ToString();
            LoadDestination();
            ddlDestination.SelectedValue = dtSales.Rows[0]["Destination_Id"].ToString();
            //////txtRoute.Text = dtSales.Rows[0]["Routing"].ToString();
            //////txtTruckchrgs.Text = dtSales.Rows[0]["Trucking_chrgs"].ToString();
            //////txtTruckShareChrgs.Text = dtSales.Rows[0]["Truckingchrgs_Share"].ToString();
            //////txtHandlingChrgs.Text = dtSales.Rows[0]["Handling_Chrgs"].ToString();
           ////// LOAD_SCD();
           txtUSDToPHP.Text = dtSales.Rows[0]["ConversionRateToPHP"].ToString();

            txtCSRRemarks.Text = dtSales.Rows[0]["csr_remarks"].ToString();
            ///////LoadFlight();
            string temapVal = ddlAirline.SelectedItem.Text.Substring(0, 9).TrimStart();






            #region GstNo Applicable
            string agent_name = "";
            ///// GST Applicable

            ddlAgentName.SelectedValue = dtSales.Rows[0]["Agent_id"].ToString();

            LoadAgentStock();
            ViewState["Stock_ID"] = dtSales.Rows[0]["Stock_ID"].ToString();
            ViewState["City_ID"] = dtSales.Rows[0]["City_ID"].ToString();


            DataTable dtAirWayBillNo = dw.GetAllFromQuery("select AirWayBill_No,Agent_ID from stock_Master where Stock_ID=" + dtSales.Rows[0]["Stock_ID"].ToString());
            if (dtAirWayBillNo.Rows.Count > 0)
            {
               ///// LoadAgentStock();
               // ddlAwbNo.SelectedIndex = ddlAwbNo.Items.IndexOf(ddlAwbNo.Items.FindByValue(dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString())); // If you want to find text by value field.
               // ddlAwbNo.SelectedIndex = ddlAwbNo.Items.IndexOf(ddlAwbNo.Items.FindByText(dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString()));
               /////// LoadACS();
                
                ddlAwbNo.SelectedItem.Text = dtAirWayBillNo.Rows[0]["AirWayBill_No"].ToString();

                string AirlineCode = ddlAwbNo.SelectedItem.Text.Substring(0, 3);
                DataTable AirlineID = dw.GetAllFromQuery("select Airline_ID from Airline_Master where Airline_Code=" + AirlineCode);
                DataTable dtAirlineDetail = dw.GetAllFromQuery("select Airline_Detail_ID from Airline_Detail where Airline_ID=" + AirlineID.Rows[0]["Airline_ID"].ToString() + " and Belongs_To_City=" + dtSales.Rows[0]["City_ID"].ToString());
                long City_ID = long.Parse(dtSales.Rows[0]["City_ID"].ToString());
                ViewState["City_ID"] = City_ID;
                DataTable dtCity = dw.GetAllFromQuery("select City_Code,City_Name from City_Master where City_ID=" + dtSales.Rows[0]["City_ID"].ToString());
                if (dtCity.Rows.Count > 0)
                {
                    ddlOrigin.SelectedValue = dtCity.Rows[0]["City_Code"].ToString() + "-" + dtCity.Rows[0]["City_Name"].ToString();
                }
                if (dtAirlineDetail.Rows.Count > 0)
                {
                    long AirlineDetailID = long.Parse(dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString());
                    ViewState["AirlineDetailID"] = AirlineDetailID;
                    hdnAirlineDetailId.Value = dtAirlineDetail.Rows[0]["Airline_Detail_ID"].ToString();

                    if (AirlineDetailID.ToString() != "163" && AirlineDetailID.ToString() != "166")
                        ET.Style.Add("display", "None");


                }
            }



            DataTable dtagent = dw.GetAllFromQuery("select distinct Agent_Name from Sales s inner join Agent_master am on s.agent_id=am.agent_id where s.agent_id=" + dtSales.Rows[0]["Agent_id"].ToString() + "");
            if (dtagent != null && dtagent.Rows.Count > 0)
            {
                agent_name = dtagent.Rows[0]["Agent_Name"].ToString();
                ViewState["Agent_ID"] = dtAirWayBillNo.Rows[0]["Agent_ID"].ToString();
                ddlAgentName.SelectedItem.Text = dtagent.Rows[0]["Agent_Name"].ToString();
            }

            DataTable dtagentgstNo = new DataTable();
            ddlGst.Items.Insert(0, "-Select-");
            ddlGst.Items[0].Value = "0";
            dtagentgstNo = dw.GetAllFromQuery("Select GstNo,Address from AgentGstNo where agentname like '" + ddlAgentName.SelectedItem.Text + "%'");
            if (dtagentgstNo != null && dtagentgstNo.Rows.Count > 0)
            {

                for (int i = 0; i < dtagentgstNo.Rows.Count; i++)
                {

                    ddlGst.Items.Add(new ListItem(dtagentgstNo.Rows[i]["GstNo"].ToString(), dtagentgstNo.Rows[i]["Address"].ToString()));
                }
            }





            txtGstNo.Text = dtSales.Rows[0]["GstNo"].ToString();
            if (txtGstNo.Text != "")
            {
                txtGstNo.Enabled = true;
                ddlGst.SelectedValue = dtSales.Rows[0]["GstNo"].ToString();
                ddlGst.Enabled = true;
            }
            else
            {
                txtGstNo.Enabled = true;
                ddlGst.Enabled = true;
                ddlGst.SelectedValue = dtSales.Rows[0]["GstNo"].ToString();
            }
            txtGstAddr.Text = dtSales.Rows[0]["GstAddress"].ToString();
            ddlGstStateCode.SelectedValue = dtSales.Rows[0]["StateCode"].ToString();
            ///// GST Applicable
            #endregion End of GstApplicable
            txtTruckOrigin.Text = dtSales.Rows[0]["Truckingorigin"].ToString();
            txtTruckerAmt.Text = dtSales.Rows[0]["TruckerAmount"].ToString();
            txtTruckerPerkg.Text = dtSales.Rows[0]["TruckerPerKg"].ToString();
            ddlTruckerSupplier.SelectedValue = dtSales.Rows[0]["TruckerSupplier_Id"].ToString();
            txtVendorAwbNo.Text = dtSales.Rows[0]["VendorAwbNo"].ToString();

            ViewState["Booking_ID"] = dtSales.Rows[0]["Booking_ID"].ToString();
            ViewState["Stock_ID"] = dtSales.Rows[0]["Stock_ID"].ToString();

            //////DataTable dtAgent = dw.GetAllFromQuery("select Agent_Name from Agent_Master where Agent_ID=" + dtAirWayBillNo.Rows[0]["Agent_ID"].ToString());
            //////if (dtAgent.Rows.Count > 0)
            //////{
            //////    ViewState["Agent_ID"] = dtAirWayBillNo.Rows[0]["Agent_ID"].ToString();
            //////    ddlAwbNo.SelectedItem.Text = dtAgent.Rows[0]["Agent_Name"].ToString();
            //////}


            fillOtherCharges(ViewState["Booking_ID"].ToString());
            LOAD_SCD();
            ddlDestination.SelectedValue = dtSales.Rows[0]["Destination_ID"].ToString();
            ddlShipmentType.SelectedValue = dtSales.Rows[0]["Shipment_ID"].ToString();
            ddlScr.SelectedValue = dtSales.Rows[0]["Special_Commodity_ID"].ToString();
            DateTime AWB_Date = DateTime.Parse(dtSales.Rows[0]["AWB_Date"].ToString());
            txtAWBDate.Text = FormatDateDD(AWB_Date.ToShortDateString());
            ViewState["Flight_Open_ID"] = dtSales.Rows[0]["Flight_Open_ID"].ToString();
            DataTable dtFlight = dw.GetAllFromQuery("select Flight_ID,Flight_Date from Flight_Open where Flight_Open_ID=" + dtSales.Rows[0]["Flight_Open_ID"].ToString());
            if (dtFlight.Rows.Count > 0)
            {
                DataTable dtFlightNo = dw.GetAllFromQuery("select Flight_No from Flight_Master where Flight_ID=" + dtFlight.Rows[0]["Flight_ID"].ToString());

                if (dtFlightNo.Rows.Count > 0)
                {
                    //ddlfltNo.SelectedValue = dtFlightNo.Rows[0]["Flight_No"].ToString();
                }
            }
            ddlfltNo.SelectedValue = dtSales.Rows[0]["Flight_No"].ToString();
            DateTime FlightDate = Convert.ToDateTime(dtSales.Rows[0]["Flight_Date"].ToString());
            txtFlightDate.Text = FormatDateDD(FlightDate.ToShortDateString());

            #region ShipperConsignee Details on 04 Nov 2011
            //******Shipper consignee Details (Now picked from Shipper_Details, not from Sales Table********

            ////txtShipper.Text = dtSales.Rows[0]["Shipper_Name"].ToString();
            ////txtShipperAddress.Text = dtSales.Rows[0]["Shipper_Address"].ToString();
            ////txtConsignee.Text = dtSales.Rows[0]["Consignee_Name"].ToString();
            ////txtConsigneeAddress.Text = dtSales.Rows[0]["Consignee_Address"].ToString();

            DataTable dtShipperConsigneeDetails = dw.GetAllFromQuery("Select * from Shipper_Details where stock_id=" + dtSales.Rows[0]["Stock_Id"].ToString() + "");

            if (dtShipperConsigneeDetails.Rows.Count > 0)
            {
                txtShipper.Text = dtShipperConsigneeDetails.Rows[0]["Shipper_Name"].ToString();
                txtShipperAddress.Text = dtShipperConsigneeDetails.Rows[0]["Shipper_Address"].ToString();
                txtConsignee.Text = dtShipperConsigneeDetails.Rows[0]["Consignee_Name"].ToString();
                txtConsigneeAddress.Text = dtShipperConsigneeDetails.Rows[0]["Consignee_Address"].ToString();
            }
            else
            {
                txtShipper.Text = "";
                txtShipperAddress.Text = "";
                txtConsignee.Text = "";
                txtConsigneeAddress.Text = "";
            }


            //******************End Of Shipper Consignee Details************************
            #endregion
            #region Checking AGentWiseTDS

            #endregion
            txtPieces.Text = dtSales.Rows[0]["No_of_Packages"].ToString();
            txtVolwt.Text = dtSales.Rows[0]["Volume_Weight"].ToString();
            txtGw.Text = dtSales.Rows[0]["Gross_Weight"].ToString();
            txtCw.Text = dtSales.Rows[0]["Charged_Weight"].ToString();

            rbFType.SelectedValue = dtSales.Rows[0]["Freight_Type"].ToString();
            txtTariffRate.Text = dtSales.Rows[0]["Tariff_Rate"].ToString();
            txtSpAmt.Text = dtSales.Rows[0]["Freight_Amount"].ToString();
            lblFreightAmount.Text = txtSpAmt.Text;
            txtSpRate.Text = dtSales.Rows[0]["Special_Rate"].ToString();
            txtFreightAmount.Text = dtSales.Rows[0]["Special_Amount"].ToString();

            DataTable dtAirlineCharges = dw.GetAllFromQuery(" select * from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
            Hidden1.Value = dtAirlineCharges.Rows[0]["ACI_Fees"].ToString();
            Hidden2.Value = dtAirlineCharges.Rows[0]["DisBursementCharges"].ToString();
            DataTable dtChargesDetails = dw.GetAllFromQuery("select Freight_SurCharge,Security_SurCharge,XRay_Charges from Agent_Rate_Master where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and Shipment_ID=" + ddlShipmentType.SelectedValue + "  and Destination=" + ddlDestination.SelectedValue);

            if (dtAirlineCharges.Rows.Count > 0)
            {
                if (dtAirlineCharges.Rows[0]["FreightSurCharge_Charged"].ToString() == "13")
                {

                    if (dtAirlineCharges.Rows[0]["FreightSurCharge_On"].ToString().Trim() == "Chargeable Wt.")
                    {
                        HiddenFSC.Value = "C";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox1.Value = dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString();
                        }
                    }
                    else
                    {
                        HiddenFSC.Value = "G";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox1.Value = dtChargesDetails.Rows[0]["Freight_SurCharge"].ToString();
                        }
                    }
                }
                if (dtAirlineCharges.Rows[0]["WarSurCharge_Charged"].ToString() == "13")
                {

                    if (dtAirlineCharges.Rows[0]["WarSurcharge_On"].ToString().Trim() == "Chargeable Wt.")
                    {
                        HiddenWSC.Value = "C";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox2.Value = dtChargesDetails.Rows[0]["Security_SurCharge"].ToString();
                        }
                    }
                    else
                    {
                        HiddenWSC.Value = "G";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox2.Value = dtChargesDetails.Rows[0]["Security_SurCharge"].ToString();
                        }
                    }
                }
                if (dtAirlineCharges.Rows[0]["XRayCharge_Charged"].ToString() == "13")
                {

                    if (dtAirlineCharges.Rows[0]["XRayCharge_On"].ToString().Trim() == "Chargeable Wt.")
                    {
                        HiddenXRay.Value = "C";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox3.Value = dtChargesDetails.Rows[0]["XRay_Charges"].ToString();
                        }
                    }
                    else
                    {
                        HiddenXRay.Value = "G";
                        if (dtChargesDetails.Rows.Count > 0)
                        {
                            HTextBox3.Value = dtChargesDetails.Rows[0]["XRay_Charges"].ToString();
                        }
                    }
                }
            }

            DataTable dtFix_Charges = dw.GetAllFromQuery("select * from fix_charges where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
            {
                if (dtFix_Charges.Rows.Count > 0)
                {
                    hndXray_fixCharges.Value = dtFix_Charges.Rows[0]["Min_XRay_Charges"].ToString();
                }
            }
            //*********** From Sales Table***************
            DataTable dtSalesField = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);
            if (dtSalesField.Rows.Count > 0)
            {

                if (dtSalesField.Rows[0]["Agent_Min_Status"].ToString() == "13")
                {
                    ChkMinAgent.Checked = true;
                }
                else
                {
                    ChkMinAgent.Checked = false;
                }
                txtSpotRate.Text = dtSalesField.Rows[0]["Spot_Rate"].ToString();


                txtIATACommission.Text = dtSalesField.Rows[0]["Commission"].ToString();
                txtSCR_Incentive.Text = dtSalesField.Rows[0]["Special_Commodity_Incentive"].ToString();
                txtTDS.Text = dtSalesField.Rows[0]["TDS"].ToString();
                txtcertificate_no.Text = dtSalesField.Rows[0]["Certificate_No"].ToString();
                if (txtcertificate_no.Text == "")
                {
                    tr_cert.Attributes.Add("style", "display:none");

                    //tr_cert.Visible = false;
                }
                txtSurcharge.Text = dtSalesField.Rows[0]["Surcharge"].ToString();
                txtEducationalCess.Text = dtSalesField.Rows[0]["Education_Cess"].ToString();

                if (dtSalesField.Rows[0]["Principle_Min_Status"].ToString() == "13")
                {
                    ChkMinAirline.Checked = true;
                }
                else
                {
                    ChkMinAirline.Checked = false;
                }
                txtPRate.Text = dtSalesField.Rows[0]["Principle_Rate"].ToString();
                txtPAmount.Text = dtSalesField.Rows[0]["Principle_Amount"].ToString();

                txtPSpotRate.Text = dtSalesField.Rows[0]["Principle_Spot_Rate"].ToString();
                txtSpotRateRemarks.Text = dtSalesField.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();
                txtRemarks.Text = dtSalesField.Rows[0]["Other_Remarks"].ToString();
            }
            //*********End From Sales Table***************


            rbDueFreight.SelectedValue = dtSales.Rows[0]["DueCarrier_Type"].ToString();
            txtRFSC.Value = dtSales.Rows[0]["FSCRate"].ToString();
            txtRWSC.Value = dtSales.Rows[0]["WSCRate"].ToString();
            txtRXRAY.Value = dtSales.Rows[0]["XRayRate"].ToString();
            decimal Fuel_Surcharges = decimal.Parse(dtSales.Rows[0]["Fuel_Surcharges"].ToString());
            Fuel_Surcharges = Math.Round(Fuel_Surcharges, MidpointRounding.AwayFromZero);
            txtFSC.Text = Fuel_Surcharges.ToString();
            FSC.Value = Fuel_Surcharges.ToString();
            //TextBox1.Text = dtHandover.Rows[0]["Fuel_Surcharges"].ToString();

            decimal War_Surcharges = decimal.Parse(dtSales.Rows[0]["War_Surcharges"].ToString());
            War_Surcharges = Math.Round(War_Surcharges, MidpointRounding.AwayFromZero);
            txtWSC.Text = War_Surcharges.ToString();
            WSC.Value = War_Surcharges.ToString();
            //TextBox2.Text = dtHandover.Rows[0]["War_Surcharges"].ToString();


            decimal Xray_Charges = decimal.Parse(dtSales.Rows[0]["Xray_Charges"].ToString());
            Xray_Charges = Math.Round(Xray_Charges, MidpointRounding.AwayFromZero);
            txtXRAY.Text = Xray_Charges.ToString();
            XRay.Value = Xray_Charges.ToString();
            //TextBox3.Text = dtHandover.Rows[0]["Xray_Charges"].ToString();

            // Add  Miscellaneous Charges 4th march 2012 //////

            decimal MSC_Charges = decimal.Parse(dtSales.Rows[0]["MSC_Charges"].ToString());
            MSC_Charges = Math.Round(MSC_Charges, MidpointRounding.AwayFromZero);
            txtMSC.Text = MSC_Charges.ToString();

            ///////// txtET.Text = dtSalesField.Rows[0]["ETChrg"].ToString();

            decimal ETChrg = decimal.Parse(dtSales.Rows[0]["ETCharges"].ToString());
            ETChrg = Math.Round(ETChrg, MidpointRounding.AwayFromZero);
            txtET.Text = ETChrg.ToString();
            hdnET.Value = ETChrg.ToString();


            decimal ABC = Fuel_Surcharges + War_Surcharges + Xray_Charges + ETChrg;
            Hidden3.Value = ABC.ToString();
            txtHouses.Value = dtSales.Rows[0]["No_of_houses"].ToString();
            decimal ACI = decimal.Parse(dtSales.Rows[0]["Total_ACI_Fees"].ToString());
            ACI = Math.Round(ACI, MidpointRounding.AwayFromZero);
            txtACIFee.Text = ACI.ToString();
            decimal AWB = decimal.Parse(dtSales.Rows[0]["AWB_Fees"].ToString());
            AWB = Math.Round(AWB, MidpointRounding.AwayFromZero);
            txtAWBFee.Text = AWB.ToString();
            decimal DB = decimal.Parse(dtSales.Rows[0]["Disbursement_Charges"].ToString());
            DB = Math.Round(DB, MidpointRounding.AwayFromZero);
            txtDisbursmentCharges.Text = DB.ToString();
            decimal Cartage = decimal.Parse(dtSales.Rows[0]["Cartridge_Charges"].ToString());
            Cartage = Math.Round(Cartage, MidpointRounding.AwayFromZero);
            txtCatrage.Text = Cartage.ToString();
            decimal Other = decimal.Parse(dtSales.Rows[0]["Other_DueCarrier"].ToString());
            Other = Math.Round(Other, MidpointRounding.AwayFromZero);
            txtOthers.Text = Other.ToString();
            decimal Total_DueCarrier = decimal.Parse(dtSales.Rows[0]["Total_DueCarrier"].ToString());
            Total_DueCarrier = Math.Round(Total_DueCarrier, MidpointRounding.AwayFromZero);
            txtDueCarrier.Text = Total_DueCarrier.ToString();
            // Hidden3.Value = txtDueCarrier.Text;
            decimal VC = decimal.Parse(dtSales.Rows[0]["Valuation_Charge"].ToString());
            VC = Math.Round(VC, MidpointRounding.AwayFromZero);
            txtValuationCharge.Text = VC.ToString();
            decimal TX = decimal.Parse(dtSales.Rows[0]["Tax"].ToString());
            TX = Math.Round(TX, MidpointRounding.AwayFromZero);
            txtTax.Text = TX.ToString();
            decimal TDP = decimal.Parse(dtSales.Rows[0]["TotalDueAgent_Prepaid"].ToString());
            TDP = Math.Round(TDP, MidpointRounding.AwayFromZero);
            txtDueAgentP.Text = TDP.ToString();
            decimal TDC = decimal.Parse(dtSales.Rows[0]["TotalDueAgent_Collect"].ToString());
            TDC = Math.Round(TDC, MidpointRounding.AwayFromZero);
            txtDueAgentC.Text = TDC.ToString();
            decimal DueAgent = decimal.Parse(txtDueAgentP.Text) + decimal.Parse(txtDueAgentC.Text);
            txtDueAgent.Text = DueAgent.ToString();
            decimal TP = decimal.Parse(dtSales.Rows[0]["Total_Prepaid"].ToString());
            TP = Math.Round(TP, MidpointRounding.AwayFromZero);
            txtPrepaid.Text = TP.ToString();
            decimal TC = decimal.Parse(dtSales.Rows[0]["Total_Collect"].ToString());
            TC = Math.Round(TC, MidpointRounding.AwayFromZero);
            txtCollect.Text = TC.ToString();
            //txtCSRRemarks.Text = dtSales.Rows[0]["Agent_Deal_Remarks"].ToString();

        }
    }

    public void FillAllFields()
    {

       
       //// string HandoverID = "";
        //if (Request.QueryString["Handover_ID"] != null)
        //{
        //    HandoverID = Request.QueryString["Handover_ID"];
        //}
        //con = new SqlConnection(strCon);
        //com = new SqlCommand("SALES_LOAD", con);
        //com.CommandType = CommandType.StoredProcedure;
        //com.Parameters.Add("@HandoverID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        //SqlDataAdapter da = new SqlDataAdapter(com);
        //DataTable dtHandover = new DataTable();
        //da.Fill(dtHandover);

        //dtHandover = dw.GetAllFromQuery("SELECT Booking_AWB.*,Handover.* FROM   Booking_AWB INNER JOIN Handover ON  Booking_AWB.Handover_ID =Handover.Handover_ID  where Handover.Handover_ID=" + HandoverID);
        
    }

    #region InsertAgentWiseSurcharge
    public void InsertAgentWiseSurcharge(string FinancialYear, decimal Surcharge)
    {
        try
        {
            String CSR_Period = "";
            string Debit_Node_ID = "";
            DataTable DtAirline = dw.GetAllFromQuery("SELECT airline_detail_id FROM AIRLINE_DETAIL WHERE COMPANY_ID=" + ViewState["CompanyID"].ToString() + "");
            if (DtAirline.Rows.Count > 0)
            {

                //***************************Updated On 15 Feb 2012: Tk-On-Awb datewise, Rest Airline On Flightdatewise********************//

                //////if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "232" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "297" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "360")
                //////{
                //////    CSR_Period = FormatDateDD(txtFlightDate.Text);

                //////}
                //////else
                //////{
                //////    CSR_Period = FormatDateDD(txtAWBDate.Text);
                //////}

                if ((ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "235") || (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "071"))
                {
                    CSR_Period = FormatDateDD(txtAWBDate.Text);

                }
                else
                {
                    CSR_Period = FormatDateDD(txtFlightDate.Text);

                }

                //*******************************End Of 15 Feb 2012***************************************************************************

                for (int i = 0; i < DtAirline.Rows.Count; i++)
                {
                    string[] ARR = FinancialYear.Split('-');
                    string From_Date = "04/01/" + ARR[0];
                    string To_Date = FormatDateDD(txtAWBDate.Text);
                    SqlConnection con1 = new SqlConnection(strCon);
                    con1.Open();
                    SqlCommand cmd = new SqlCommand("SURCHARGE_REPORT", con1);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("COMPANY_ID", ViewState["CompanyID"].ToString());
                    cmd.Parameters.AddWithValue("AGENT_ID", ViewState["Agent_ID"].ToString());
                    cmd.Parameters.AddWithValue("FROM_DATE", From_Date);
                    cmd.Parameters.AddWithValue("TO_DATE", To_Date);
                    cmd.Parameters.AddWithValue("Airline_Detail_ID", DtAirline.Rows[i]["Airline_Detail_ID"].ToString());
                    cmd.Parameters.AddWithValue("REPORT_TYPE", "SINGLE");
                    SqlDataReader dr_agent = cmd.ExecuteReader();
                    if (dr_agent.HasRows)
                    {
                        if (dr_agent.Read())
                        {
                            decimal TDSableAmt = Convert.ToDecimal(dr_agent["ONLY_TDS"].ToString());
                            decimal Surcharge_Amt = ((TDSableAmt * Convert.ToDecimal(txtTDS.Text)) / 100) * Surcharge / 100;
                            string insert;

                            insert = "insert into Surcharge_DebitNote(Agent_ID,Airline_Detail_ID,CSR_Period,TDSable_Amount,Surcharge_Amount) values(@Agent_ID,@Airline_Detail_ID,@CSR_Period,@TDSable_Amount,@Surcharge_Amount)";
                            con = new SqlConnection(strCon);
                            con.Open();
                            SqlCommand com = new SqlCommand(insert, con);
                            com.CommandType = CommandType.Text;

                            com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
                            com.Parameters.Add("@Airline_Detail_ID", SqlDbType.VarChar).Value = DtAirline.Rows[i]["Airline_Detail_ID"].ToString();
                            //com.Parameters.Add("@CSR_Period", SqlDbType.VarChar).Value = From_Date + "-" + To_Date;
                            com.Parameters.Add("@CSR_Period", SqlDbType.VarChar).Value = CSR_Period;
                            com.Parameters.Add("@TDSable_Amount", SqlDbType.Decimal).Value = TDSableAmt;
                            com.Parameters.Add("@Surcharge_Amount", SqlDbType.Decimal).Value = Surcharge_Amt;
                            com.ExecuteNonQuery();
                            com.Dispose();
                            DataTable Dt_Id = dw.GetAllFromQuery("select ident_current('Surcharge_DebitNote') as Debit_Node_ID");

                            if (Debit_Node_ID == "")
                            {
                                Debit_Node_ID = (Dt_Id.Rows[0]["Debit_Node_ID"].ToString());
                            }
                            else
                            {
                                Debit_Node_ID = Debit_Node_ID + "," + (Dt_Id.Rows[0]["Debit_Node_ID"].ToString());

                            }
                        }

                    }
                }
            }



            string insert_Query = "INSERT into Agentwise_Surcharge(Agent_ID,Financial_Year,Surcharge_Status,Debit_Node_ID) values(@Agent_ID,@Financial_Year,@Surcharge_Status,@Debit_Node_ID)";
            con = new SqlConnection(strCon);
            con.Open();
            SqlCommand com_Query = new SqlCommand(insert_Query, con);
            com_Query.CommandType = CommandType.Text;
            com_Query.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
            com_Query.Parameters.Add("@Financial_Year", SqlDbType.VarChar).Value = FinancialYear;
            com_Query.Parameters.Add("@Surcharge_Status", SqlDbType.Int).Value = 13;
            com_Query.Parameters.Add("@Debit_Node_ID", SqlDbType.VarChar).Value = Debit_Node_ID;
            com_Query.ExecuteNonQuery();
            com_Query.Dispose();

        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
            Response.Write(err);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }

    #endregion

    #region DeleteOldOtherCahrges
    public void DeleteOtherCharges(long BookingID)
    {
        dw.GetAllFromQuery("delete from Other_Charges where Booking_ID=" + BookingID);
    }
    #endregion

    #region Update_OtherCharges
    public void Update_OtherCharges(SqlTransaction tr, SqlConnection con, long BookingID)
    {
        string insert;
        DeleteOtherCharges(BookingID);
        if (Session["dtOtherCharges"] != null)
        {
            DataTable dt = (DataTable)Session["dtOtherCharges"];
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                insert = "insert into Other_Charges(Booking_ID,AirWayBill_No,Charge_Name,Amount,Prepaid_or_Collect) values(@Booking_ID,@AirWayBill_No,@Charge_Name,@Amount,@Prepaid_or_Collect)";

                SqlCommand com = new SqlCommand(insert, con, tr);
                com.CommandType = CommandType.Text;
                com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = BookingID;
                com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text;
                com.Parameters.Add("@Charge_Name", SqlDbType.VarChar).Value = dt.Rows[i]["FeeName"].ToString();
                com.Parameters.Add("@Amount", SqlDbType.Decimal).Value = dt.Rows[i]["Fee"].ToString();
                com.Parameters.Add("@Prepaid_or_Collect", SqlDbType.VarChar).Value = dt.Rows[i]["PaymentType"].ToString();
                com.ExecuteNonQuery();
            }
        }
    }
    #endregion

    //public DataSet ConvertXMLToDataSet(StringBuilder xmlData)
    //{
    //    StringReader stream = null;
    //    XmlTextReader reader = null;
    //    try
    //    {
    //        string s1 = @"<?xml version=""1.0"" encoding=""UTF-8""?><tabledata xmlns:sql=""urn:schemas-microsoft-com:xml-sql"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">";
    //        string s2 = @"</tabledata>";
    //        DataSet xmlDS = new DataSet();
    //        stream = new StringReader(s1 + xmlData.ToString() + s2);
    //        reader = new XmlTextReader(stream);
    //        xmlDS.ReadXml(reader);
    //        return xmlDS;
    //    }
    //    catch
    //    {
    //        return null;
    //    }
    //    finally
    //    {
    //        if (reader != null) reader.Close();
    //    }
    //}
    //public void LOAD_SCD()
    //{
    //    try
    //    {
    //        con = new SqlConnection(strCon);
    //        com = new SqlCommand("LOAD_SCD", con);
    //        com.CommandType = CommandType.StoredProcedure;
    //        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
    //        SqlDataAdapter da = new SqlDataAdapter(com);
    //        DataTable dt = new DataTable();
    //        da.Fill(dt);
    //        StringBuilder xmlData = new StringBuilder(dt.Rows[0]["Data"].ToString());
    //        bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlShipmentType, "Shipment_Master", "Shipment_Name", "Shipment_ID");
    //        xmlData = new StringBuilder(dt.Rows[1]["Data"].ToString());
    //        bw.SetDDL(ConvertXMLToDataSet(xmlData), ddlScr, "Special_Commodity_Master", "Special_Commodity_Name", "Special_Commodity_ID");
    //        xmlData = new StringBuilder(dt.Rows[2]["Data"].ToString());
    //        ddlDestination.DataSource = ConvertXMLToDataSet(xmlData).Tables[0];
    //        ddlDestination.DataTextField = "Destination";
    //        ddlDestination.DataValueField = "Destination_ID";
    //        ddlDestination.DataBind();
    //    }
    //    catch (SqlException sqe)
    //    {
    //        string err = sqe.ToString();
    //    }
    //    finally
    //    {
    //        if (con != null && con.State == ConnectionState.Open)
    //            con.Close();
    //    }
    //}

    //public void LoadDestination()
    //{
    //    try
    //    {
    //        string strAgent = "";
    //        strAgent = "Select distinct dm.Destination_ID,dm.Destination_Code,dm.Destination_Name from agent_rate_master ar inner join Airline_Detail ad on ar.Airline_Detail_ID=ad.Airline_Detail_ID inner join Destination_Master dm on ar.Destination=dm.Destination_ID where ar.Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString();
    //        con = new SqlConnection(strCon);
    //        con.Open();
    //        com = new SqlCommand(strAgent, con);
    //        SqlDataReader dr = com.ExecuteReader();
    //        ddlDestination.Items.Clear();
    //        //ddlDestination.Items.Insert(0, "- -Select- -");
    //        //ddlDestination.Items[0].Value = "0";
    //        while (dr.Read())
    //        {
    //            ddlDestination.Items.Add(new ListItem(dr["Destination_Code"].ToString() + "-" + dr["Destination_Name"].ToString(), dr["Destination_ID"].ToString()));
    //        }
    //        con.Close();
    //    }
    //    catch (SqlException sqe)
    //    {
    //        string err = sqe.ToString();
    //    }
    //    finally
    //    {
    //        if (con != null && con.State == ConnectionState.Open)
    //            con.Close();
    //    }
    //}
    public void LoadTrucker()
    {
        try
        {
            string strTrucker = "";
            strTrucker = "Select Sno,Supplier_Name from Trucking_Supplier ";
            con = new SqlConnection(strCon);
            con.Open();
            com = new SqlCommand(strTrucker, con);
            SqlDataReader dr = com.ExecuteReader();
            ddlTruckerSupplier.Items.Clear();
            ddlTruckerSupplier.Items.Insert(0, "- -Select- -");
            ddlTruckerSupplier.Items[0].Value = "0";
            while (dr.Read())
            {
                ddlTruckerSupplier.Items.Add(new ListItem(dr["Supplier_Name"].ToString(), dr["SNo"].ToString()));
            }
            con.Close();
        }
        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
        }
    }
    

    protected void Button1_Click(object sender, EventArgs e)
    {

        ViewState["Stock_ID"] = ddlAwbNo.SelectedValue;
        

        if (Convert.ToDateTime(FormatDateMM(txtFlightDate.Text)) >= Convert.ToDateTime("07/01/2017"))
        {
            if (txtGstNo.Text == "" && ddlGstStateCode.SelectedValue == "0")
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
                txtGstNo.Focus();
                return;
            }

            if (txtGstNo.Text == "00" && ddlGstStateCode.SelectedValue == "0")
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
                txtGstNo.Focus();
                return;
            }

        }
        if (hdn_ex_cross_limit.Value == "")//////////handler not hit case//////
        {

            ViewState["Ex_crossed_limit"] = "N";
        }
        else
        {
            ViewState["Ex_crossed_limit"] = hdn_ex_cross_limit.Value;
        }
        txtcertificate_no.Text = hdn_certificate_no.Value;
        ViewState["Ex_crossed_limit"] = hdn_ex_cross_limit.Value;
        ////DataTable dtFlight = GetFlightDetails(ddlfltNo.SelectedValue, txtFlightDate.Text);
        ////if (dtFlight.Rows.Count == 0)
        ////{
        ////    ClientScript.RegisterStartupScript(Page.GetType(), "AlertFlight", "<script>alert('Flight not found on this flight Date. Open flight or check flight schedule');</script>");
        ////    return;
        ////}
        ////else
        ////{
        ////    ViewState["Flight_Open_Id_New"] = dtFlight.Rows[0]["Flight_Open_ID"];

        ////}
        string Actual_Discount = "";
        string SpotRate = "";
        string SpotAmount = "";
        string CommAmount = "";
        string Inc_Amount = "";
        string Current_Discount = "";
        string Overall_Amount = "";
        string _Chargd_weight = "";
        string _spotRate = "";
        string _Commission = "";
        string _Special_commodity_incentive = "";
        string _Frieght_Amount = "";
        _Chargd_weight = txtCw.Text;
        _spotRate = txtSpotRate.Text;
        _Commission = txtIATACommission.Text;
        _Special_commodity_incentive = txtSCR_Incentive.Text;
        _Frieght_Amount = txtSpAmt.Text;



        //*********************** Condition on  AddToSales Condition on Insentive and Frieght on 23_June_2010
        Actual_Discount = Convert.ToString((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) * 5 / 100);
        if ((_spotRate == "" ? 0 : decimal.Parse(_spotRate)) > 0)
        {
            SpotAmount = Convert.ToString((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) - ((_spotRate == "" ? 0 : decimal.Parse(_spotRate)) * (_Chargd_weight == "" ? 0 : decimal.Parse(_Chargd_weight))));
        }

        CommAmount = Convert.ToString(((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) * (_Commission == "" ? 0 : decimal.Parse(_Commission))) / 100);

        Inc_Amount = Convert.ToString((((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) - decimal.Parse(CommAmount)) * (_Special_commodity_incentive == "" ? 0 : decimal.Parse(_Special_commodity_incentive))) / 100);


        Current_Discount = Convert.ToString((SpotAmount == "" ? 0 : decimal.Parse(SpotAmount)) + (CommAmount == "" ? 0 : decimal.Parse(CommAmount)) + (Inc_Amount == "" ? 0 : decimal.Parse(Inc_Amount)));

        Overall_Amount = Convert.ToString((Current_Discount == "" ? 0 : decimal.Parse(Current_Discount)) - (Actual_Discount == "" ? 0 : decimal.Parse(Actual_Discount)));
        //*************************************End of Condition on Insentive and Frieght on 23_June_2010

        string AWbNum = ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3);


        //// IATA Rule Condition Closed
        ////if (Overall_Amount.Contains("-") && AWbNum != "235")
        ////{
        ////    /////ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('IATA COMM IS LESS AS PER IATA RULE');</script>");

        ////}
        ////else
        ////{

        if ((txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim())) > 0 && ddlTruckerSupplier.SelectedItem.Text == "- -Select- -")
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('Please Select Trucker Supplier Name');</script>");
            ddlTruckerSupplier.Focus();
        }
        else
        {

            con = new SqlConnection(strCon);
            con.Open();
            SqlTransaction tranupdate = con.BeginTransaction();

            decimal UsedExemptionLimit = TDS();

            //decimal TDS_Amount = UsedExemptionLimit;
            //decimal FinalTDS=TDS_Amount * decimal.Parse(txtTDS.Text);
            //FinalTDS = FinalTDS / 100;
            //decimal Sur

            ViewState["Total_UsedExemption_Limit"] = UsedExemptionLimit;
            string HandoverID = "";
            if (Request.QueryString["Handover_ID"] != null)
            {
                HandoverID = Request.QueryString["Handover_ID"];
            }
            DataTable dtHandover = dw.GetAllFromQuery("select * from  Sales where Handover_ID=" + HandoverID);
            DataTable dtHandoverTotalAmount = dw.GetAllFromQuery("SELECT Booking_AWB.Total_DueCarrier, Handover.Freight_Amount from Booking_AWB INNER JOIN Handover ON Booking_AWB.Handover_ID = Handover.Handover_ID where Handover.Handover_ID=" + HandoverID);
            decimal HandOverAmount = 0;
            if (dtHandoverTotalAmount.Rows.Count > 0)
            {
                HandOverAmount = decimal.Parse(dtHandoverTotalAmount.Rows[0]["Total_DueCarrier"].ToString()) + decimal.Parse(dtHandoverTotalAmount.Rows[0]["Freight_Amount"].ToString());
            }
            decimal Used_Limit = 0;
            if (rbFType.SelectedValue == "PREPAID")
            {
                Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtSpAmt.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
            }
            else
            {
                Used_Limit = decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - decimal.Parse(txtDueAgentC.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
            }
            Used_Limit = -HandOverAmount + Used_Limit;
            DataTable dtUsed_Limit = dw.GetAllFromQuery("SELECT ISNULL(Used_Limit,0) AS Used_Limit from Agent_Branch where Agent_ID=" + ddlAgentName.SelectedValue + " and Belongs_To_City=" + ddlOrigin.SelectedValue);

            //*************Added on 28 Mar 2011 Offline City (Agent) case*************//
            if (dtUsed_Limit.Rows.Count <= 0)
            {
                string ULimit = "";
                DataTable dtOfflineCity = dw.GetAllFromQuery("select offline_CityId from booking_master where booking_id=" + dtHandover.Rows[0]["Booking_Id"].ToString() + " and Offline_CityID!=''");
                if (dtOfflineCity.Rows.Count > 0)
                {
                    dtUsed_Limit = dw.GetAllFromQuery("SELECT ISNULL(Used_Limit,0) AS Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + dtOfflineCity.Rows[0]["offline_CityId"].ToString() + "");
                    if (dtUsed_Limit.Rows.Count > 0)
                    {
                        ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
                    }
                    else
                    {
                        dtUsed_Limit = dw.GetAllFromQuery("SELECT ISNULL(Used_Limit,0) AS Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and offline_city=" + dtOfflineCity.Rows[0]["offline_CityId"].ToString() + "");
                        if (dtUsed_Limit.Rows.Count > 0)
                        {
                            ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
                        }
                    }


                    if (ULimit == "")
                    {
                        ULimit = "0";
                    }

                    Used_Limit = decimal.Parse(ULimit) + Used_Limit;
                    Used_Limit = Math.Round(Used_Limit, MidpointRounding.AwayFromZero);
                }

            }
            else
            {
                Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) + Used_Limit;
                Used_Limit = Math.Round(Used_Limit, MidpointRounding.AwayFromZero);

            }
            //*************End********************************

            ////Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) + Used_Limit;
            ////Used_Limit = Math.Round(Used_Limit, MidpointRounding.AwayFromZero);

            DataTable dtAWBCheck = dw.GetAllFromQuery("select * from Sales where AirWayBill_No='" + ddlAwbNo.SelectedItem.Text.Trim() + "'");
            if (dtAWBCheck.Rows.Count <= 0)
            {
                try
                {
                    if (dtHandover.Rows.Count > 0)
                    {

                        Update_Sales(tranupdate, con, HandoverID);
                        //Update_BookingAWB(tranupdate, con, HandoverID, dtHandover.Rows[0]["Sales_ID"].ToString());

                        DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                        if (dtOtherChargesID.Rows.Count > 0)
                        {
                            if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                            {
                                dtOtherChargesID.Rows[0].Delete();
                            }
                        }
                        //long BookingID = Convert.ToInt64(ViewState["Booking_ID"]);
                        //Update_OtherCharges(tranupdate, con, BookingID);
                        Update_AWBDate(tranupdate, con);
                        /////Update_Handover(tranupdate, con, HandoverID, dtHandover.Rows[0]["Sales_ID"].ToString());
                        //dw.GetAllFromQuery("update Handover set Added_To_Sales=11 where Handover_ID='" + HandoverID + "'");
                        Update_Stock(tranupdate, con, ViewState["Stock_ID"].ToString());
                        //dw.GetAllFromQuery("update Stock_Master set Status=11" + "  where Stock_ID='" + dtHandover.Rows[0]["Stock_ID"].ToString() + "'");
                        //tranupdate.Save(Stock);

                        ////////Update_AgentLimit(tranupdate, con, Used_Limit);
                        //if (IsExemption == true)
                        //    InsertUsedLimit(tranupdate, con);
                        //if (ViewState["Ex_crossed_limit"].ToString() == "Y")
                        //{
                        //    UpdateAgentWiseTDSStatus(tranupdate, con);
                        //}
                        //tranupdate.Save(AgentLimit);
                        tranupdate.Commit();
                        con.Close();
                        Response.Write("<script language='javascript'>window.alert('Details saved sucessfully');window.location='SalesEdit.aspx';</script>");
                        // Response.Redirect("AddToSales.aspx");
                    }
                    if (dtHandover.Rows.Count <= 0)
                    {
                        Insert_Sales(tranupdate, con, HandoverID);
                        DataTable dtSalesID = dw.GetAllFromQuery("select ident_current('Sales') as SalesID");
                        //Update_BookingAWB(tranupdate, con, HandoverID, dtSalesID.Rows[0]["SalesID"].ToString());
                        DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                        if (dtOtherChargesID.Rows.Count > 0)
                        {
                            if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                            {
                                dtOtherChargesID.Rows[0].Delete();
                            }
                        }
                        ///////long BookingID = Convert.ToInt64(ViewState["Booking_ID"]);

                        InsertSalesTrans(tranupdate, con);
                        /////Update_OtherCharges(tranupdate, con, BookingID);
                        Update_AWBDate(tranupdate, con);
                        /////Update_Handover(tranupdate, con, HandoverID, dtSalesID.Rows[0]["SalesID"].ToString());

                        //dw.GetAllFromQuery("update Handover set Added_To_Sales=11 where Handover_ID='" + HandoverID + "'");

                        Update_Stock(tranupdate, con, ViewState["Stock_ID"].ToString());

                        //decimal Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtFreightAmount.Text);                
                       ///// Update_AgentLimit(tranupdate, con, Used_Limit);
                        ////if (IsExemption == true)
                        ////    InsertUsedLimit(tranupdate, con);
                        ////if (ViewState["Ex_crossed_limit"].ToString() == "Y")
                        ////{
                        ////    UpdateAgentWiseTDSStatus(tranupdate, con);
                        ////}
                        tranupdate.Commit();
                        con.Close();

                        Response.Write("<script language='javascript'>window.alert('Details saved sucessfully');window.location='SalesEdit.aspx';</script>");
                    }
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                    tranupdate.Rollback();
                }
                ////Response.Redirect("sales_new.aspx?id=" + ddlAwbNo.SelectedValue);

                
               //// Response.Redirect("sales_new.aspx?id=" + ddlAwbNo.SelectedValue);
            }
            else
            {
                lblSales.Visible = true;
            }
        }
        /////*********IATA  Rule condition Close///////
        ///////}
    }
    #region AgentwiseSurcharge_Insert
    public void AgentwiseSurcharge_Insert(SqlTransaction tr, SqlConnection con)
    {
        string insert;

        insert = "insert into Agentwise_Surcharge(Agent_ID,Financial_Year) values(@Agent_ID,@Financial_Year)";
        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        string FinancialYear = DateTime.Now.Year.ToString() + "-" + Convert.ToString(DateTime.Now.Year + 1);
        com.Parameters.Add("@Financial_Year", SqlDbType.VarChar).Value = FinancialYear;
        com.ExecuteNonQuery();
    }
    #endregion


    #region InsertUsedLimit
    public void InsertUsedLimit(SqlTransaction tr, SqlConnection con)
    {
        string insert;

        insert = "insert into Agentwise_Used_TDS(Agent_ID,Stock_ID,Company_ID,Airline_Detail_ID,CSR_Date,Freight_Diff_Amount,Commission_Amount,Incentive_Amount,Used_Exemption_Limit,Entered_By,Entered_On,Certificate_No) values(@Agent_ID,@Stock_ID,@Company_ID,@Airline_Detail_ID,@CSR_Date,@Freight_Diff_Amount,@Commission_Amount,@Incentive_Amount,@Used_Exemption_Limit,@Entered_By,@Entered_On,@Certificate_No)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = int.Parse(ViewState["CompanyID"].ToString());
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
        
        //********************Update On 15 Feb 2012: TK-On-AwbDateWise, rest of Airline on FlightDateWise*************************


        //////if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "232" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "297")
        //////{
        //////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        //////}
        //////else
        //////{
        //////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        //////}

        if ((ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "235") || (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "071"))
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);

        }
        else
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        }


        //******************************************End of 15 FEB 2012*****************************************************


        decimal dfa = Convert.ToDecimal(ViewState["FreightDiffAmount"]);
        com.Parameters.Add("@Freight_Diff_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["FreightDiffAmount"]);
        decimal Coam = Convert.ToDecimal(ViewState["CommissionableAmount"]);
        com.Parameters.Add("@Commission_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["CommissionableAmount"]);
        decimal Incentiver = Convert.ToDecimal(ViewState["IncentiveAmount"]);
        com.Parameters.Add("@Incentive_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["IncentiveAmount"]);
        com.Parameters.Add("@Used_Exemption_Limit", SqlDbType.Decimal).Value = decimal.Parse(ViewState["Total_UsedExemption_Limit"].ToString());
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;

        com.Parameters.Add("@Certificate_No", SqlDbType.VarChar).Value = txtcertificate_no.Text;
        com.ExecuteNonQuery();
    }

    #endregion

    #region UpdateAgentWiseTDSStatus
    public void UpdateAgentWiseTDSStatus(SqlTransaction tr, SqlConnection con)
    {
        string update;

        update = "update Agentwise_TDS set Exemption_limit_crossed=@Exemption_limit_crossed where Agent_ID=@Agent_ID and Agent_TDS_ID=@Agent_TDS_ID";

        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Exemption_limit_crossed", SqlDbType.Char).Value = ViewState["Ex_crossed_limit"].ToString();
        com.Parameters.Add("@Agent_ID", SqlDbType.Int).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Agent_TDS_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_TDS_ID"].ToString());



        com.ExecuteNonQuery();
    }

    #endregion
    #region TDS
    public decimal TDS()
    {
        decimal FreightDiffRate = 0, FreightDiffAmount = 0;
        if (ChkMinAgent.Checked == true)
        {
            FreightDiffRate = decimal.Parse(txtTariffRate.Text) - decimal.Parse(txtSpotRate.Text);
            FreightDiffAmount = FreightDiffRate;
        }
        else
        {
            if (decimal.Parse(txtSpotRate.Text) != 0)
            {
                FreightDiffRate = decimal.Parse(txtTariffRate.Text) - decimal.Parse(txtSpotRate.Text);
                FreightDiffAmount = FreightDiffRate * decimal.Parse(txtCw.Text);
            }
            else
            {
                FreightDiffAmount = 0;
            }
        }
        ViewState["FreightDiffAmount"] = FreightDiffAmount;

        decimal FreightAmt = decimal.Parse(txtSpAmt.Text);//Commissionalbe Amount
        decimal Commission = decimal.Parse(txtIATACommission.Text);//Commission Rate
        decimal Incentive = decimal.Parse(txtSCR_Incentive.Text);

        decimal CommissionAmount = FreightAmt * Commission;
        CommissionAmount = CommissionAmount / 100;
        ViewState["CommissionableAmount"] = CommissionAmount;

        decimal IncentiveAmount = FreightAmt - CommissionAmount;
        IncentiveAmount = IncentiveAmount * Incentive;
        IncentiveAmount = IncentiveAmount / 100;
        ViewState["IncentiveAmount"] = IncentiveAmount;

        //********Main TDS Formula*******************************************
        decimal UsedExemptionLimit = FreightDiffAmount + CommissionAmount + IncentiveAmount;
        //UsedExemptionLimit = UsedExemptionLimit + TotalAgentUsedLimit;
        return UsedExemptionLimit;
        //********End Main TDS Formula*******************************************
    }
    #endregion

    #region Update_AgentLimit
    public void Update_AgentLimit(SqlTransaction tr, SqlConnection con, decimal Used_Limit)
    {
        string update;

        update = "update Agent_Branch set Used_Limit=" + Used_Limit + " where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + ViewState["City_ID"].ToString();
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.ExecuteNonQuery();
    }


    #endregion




    #region Update_HandOver
    public void Update_Handover(SqlTransaction tr, SqlConnection con, string HandoverID, string SalesID)
    {
        string update;

        update = "update Handover set Added_To_Sales=@Added_To_Sales,Agent_Deal_Remarks=@Agent_Deal_Remarks where Handover_ID=@Handover_ID";
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
        com.Parameters.Add("@Added_To_Sales", SqlDbType.Int).Value = 11;

        com.ExecuteNonQuery();

    }


    #endregion

    #region Update_BookingAWB
    public void Update_BookingAWB(SqlTransaction tr, SqlConnection con, string HandoverID, string SalesID)
    {
        string update;

        update = "update Booking_AWB set Sales_ID=@Sales_ID,Shipper_Name=@Shipper_Name,Shipper_Address=@Shipper_Address,Consignee_Name=@Consignee_Name,Consignee_Address=@Consignee_Address,Disbursement_Charges=@Disbursement_Charges,AWB_Fees=@AWB_Fees,Valuation_Charge=@Valuation_Charge,Tax=@Tax,No_of_houses=@No_of_houses,Total_ACI_Fees=@Total_ACI_Fees,Cartridge_Charges=@Cartridge_Charges,DueCarrier_Type=@DueCarrier_Type,TotalDueAgent_Prepaid=@TotalDueAgent_Prepaid,TotalDueAgent_Collect=@TotalDueAgent_Collect,Total_DueCarrier=@Total_DueCarrier,Total_Prepaid=@Total_Prepaid,Total_Collect=@Total_Collect,War_Surcharges=@War_Surcharges,Fuel_Surcharges=@Fuel_Surcharges,Xray_Charges=@Xray_Charges where Handover_ID=@Handover_ID";


        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        //com.Parameters.Add("@Booking_ID", SqlDbType.DateTime).Value = HandoverID;
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;

        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;

        // com.Parameters.Add("@AWC_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);

        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = txtHouses.Value;
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = txtDueAgentP.Text;
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = txtDueAgentC.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = txtDueCarrier.Text;
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = txtPrepaid.Text;
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = txtCollect.Text;
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(WSC.Value);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(FSC.Value);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(XRay.Value);


        //com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        //com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        //com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        //com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        //com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        //com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;


        com.ExecuteNonQuery();

    }


    #endregion

    #region Insert_Sales
    public void Insert_Sales(SqlTransaction tr, SqlConnection con, string HandoverID)
    {
        #region Generate Invoice No for GST effecting 01 Apr 2017

        string Flight_date = txtFlightDate.Text;
        string[] dateSplit = Flight_date.Split('/');
        string Month = dateSplit[1].ToString();
        string Year = dateSplit[2].ToString();
        string Date1 = dateSplit[0].ToString();
        string currentdate = Month + "/" + Date1 + "/" + Year;
        string FinYear = Year.Substring(2, 2);
        // string dateCurrent = DateTime.Now.ToShortDateString();

        DateTime CurrDate = Convert.ToDateTime(currentdate);
        string DateFinancial = "4/1/20" + FinYear + "";
        DateTime FinanciaDate = DateTime.Parse(DateFinancial);


        if (CurrDate < FinanciaDate)
        {
            FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
        }
        else
        {
            FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
        }
        //*********************End***************************************************************

        //*******************End****************************************

        string Lastdate = "";
        bool flagInvoice = false;
        if (int.Parse(Date1) < 16)
        {
            Date1 = "1";
            flagInvoice = true;
        }
        else
        {
            Date1 = "16";
        }

        //for (int year = 2006; year <= DateTime.Today.Year; year++)
        //    ddlyear.Items.Add(new ListItem(year.ToString(), year.ToString()));
        // string Year = DateTime.Today.Year.ToString();

        string startDate = Month + "/" + Date1 + "/" + Year;
        string endDate = Month + "/" + (flagInvoice ? "15" : (Convert.ToDateTime(Month + "/1/" + Year).AddMonths(1).AddDays(-1).Day.ToString())) + "/" + Year;

        ////DataTable dtInvPrFx = dw.GetAllFromQuery("select prifix from Invoice_no where airline_detail_id=" + ddlAirline.SelectedValue + "");

        ///**************************************end of invoice function **********************************
        #endregion

        string insert;

        insert = "insert into Sales(Sales_Type,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,DueCarrier_Type,TotalDueAgent_Prepaid,TotalDueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,FSCRate,WSCRate,XRayRate,War_Surcharges,Fuel_Surcharges,Xray_Charges,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,GSAComm_Rate,Principle_Spot_Rate_Remarks,Other_DueCarrier,Other_Remarks,Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity,Remarks,TDS,Surcharge,Education_Cess,CSR_SNo,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,TruckerAmount,TruckerPerKg,TruckerSupplier_id,TruckingOrigin,VendorAwbNo,SubAgent_Id,SubAgntRefNo,Cpp_FinalAgentCity,MSC_Charges,KE_Principle_Rate,KE_Principle_Spot_Rate,KE_Principle_Min_Status,KE_Principle_Amount,ETCharges,Certificate_No,GstNo,stateCode,GstAddress,ConversionRateToPHP) values(@Sales_Type,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Remarks,@TDS,@Surcharge,@Education_Cess,@CSR_SNo,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@TruckerAmount,@TruckerPerKg,@TruckerSupplier_id,@TruckingOrigin,@VendorAwbNo,@SubAgent_Id,@SubAgntRefNo,@Cpp_FinalAgentCity,@MSC_Charges,@KE_Principle_Rate,@KE_Principle_Spot_Rate,@KE_Principle_Min_Status,@KE_Principle_Amount,@ETCharges,@Certificate_No,@GstNo,@stateCode,@GstAddress,@ConversionRateToPHP)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_Type", SqlDbType.VarChar).Value = "INV";
        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value =ddlAwbNo.SelectedValue;
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = ddlAwbNo.SelectedValue;
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = "1234";
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = 123;
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);

        //********************************Updated Csr Date on 15 Feb 2012, TK-On Awb Date , rest are on Flight Date.************************************



        ////if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "232" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "297" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "180")
        ////{
        ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        ////}
        ////else
        ////{
        ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        ////}

        if ((ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "235") || (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "071"))
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);

        }
        else
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        }

        //********************************End Of Csr Date Updataion of 15 Feb 2012*****************************************************************************************


        //com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = int.Parse(ddlScr.SelectedValue);
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = int.Parse(ddlShipmentType.SelectedValue);
        string strOrgin = ddlOrigin.SelectedItem.Text;
        strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        // com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = ddlOrigin.SelectedValue.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = ddlDestination.SelectedItem.Text;
        strDestination = strDestination.Substring(0, 3);
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(txtHouses.Value);
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;

        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentP.Text);
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentC.Text);
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtDueCarrier.Text);
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtPrepaid.Text);
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtCollect.Text);
        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRFSC.Value);
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRWSC.Value);
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = decimal.Parse(txtRXRAY.Value);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpotRate.Text);
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(txtIATACommission.Text);
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(txtSCR_Incentive.Text);

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtTariffRate.Text);
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtSpAmt.Text);

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpRate.Text);
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtFreightAmount.Text);


        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        DataTable dtGSA = dw.GetAllFromQuery("select GSAComm_Rate from Airline_Detail where Airline_Detail_ID=" + ddlAirline.SelectedValue);
        com.Parameters.Add("@GSAComm_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtGSA.Rows[0]["GSAComm_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtOthers.Text); ;
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;

        DataTable dtBooking_AWBDetails = dw.GetAllFromQuery("select Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity from Booking_AWB where Handover_ID=" + HandoverID);

        ////com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Currency"].ToString();
        ////com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["CHGS_Code"].ToString();
        ////com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Declared_Carriage_Value"].ToString();
        ////com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Declared_Custom_Value"].ToString();
        ////com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Handling_Information"].ToString();
        ////com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Nature_and_Quantity"].ToString();


        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = "";
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = "";
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = "";
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = "";
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = "";
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = "";


        ////com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        ////com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        ////com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        ////com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(txtTDS.Text);
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(txtSurcharge.Text);
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(txtEducationalCess.Text);
        #region Generating CSR Serial Auto Number

        //string CSR_Date=(txtAWBDate.Text);

        string CSR_Date;

        ////if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "232" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "297" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "180")
        ////{
        ////    CSR_Date = (txtFlightDate.Text);

        ////}
        ////else
        ////{
        ////    CSR_Date = (txtAWBDate.Text);
        ////}


        if ((ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "235") || (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "071"))
        {
            CSR_Date = (txtAWBDate.Text);

        }
        else
        {
            CSR_Date = (txtFlightDate.Text);

        }



        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string First = "";
        string Last = "";

        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = "03/31/" + LastYear.ToString();
        }
        else
        {
            FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = "04/01/" + LastYear.ToString();
        }

        if (int.Parse(strDD) <= 15)
        {
            First = "01/" + strMM + "/" + strYYYY;
            Last = "15/" + strMM + "/" + strYYYY;
        }
        else
        {
            First = "16/" + strMM + "/" + strYYYY;
            DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
            string LastDate = Date.Day.ToString();
            Last = LastDate + "/" + strMM + "/" + strYYYY;
        }
        DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ddlAgentName.SelectedValue + " and Airline_Detail_ID=" + ddlAirline.SelectedValue + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
        if (dtCSR_SNo.Rows.Count > 0)
        {
            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
        }
        else
        {
            long Maximum = 0;
            DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ddlAirline.SelectedValue + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
            if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
            {
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
            }
            else
            {
                Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
            }

        }
        // }
        #endregion

        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@TruckerAmount", SqlDbType.Decimal).Value = (txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim()));
        com.Parameters.Add("@TruckerPerKg", SqlDbType.Decimal).Value = (txtTruckerPerkg.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerPerkg.Text.Trim()));
        com.Parameters.Add("@TruckerSupplier_id", SqlDbType.Int).Value = (object)DBNull.Value;
        com.Parameters.Add("@TruckingOrigin", SqlDbType.VarChar).Value = txtTruckOrigin.Text;
        com.Parameters.Add("@VendorAwbNo", SqlDbType.VarChar).Value = txtVendorAwbNo.Text;


        #region SubAgent
        DataTable SubAgentId = dw.GetAllFromQuery("Select isnull(subAgent_Id,0) as subAgent_Id,SubAgntRefNo from Booking_Master where stock_id=" + ddlAwbNo.SelectedValue + "");

        if (SubAgentId.Rows.Count > 0)
        {
            com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = SubAgentId.Rows[0]["subAgent_Id"].ToString() == "0" ? (object)DBNull.Value : int.Parse(SubAgentId.Rows[0]["subAgent_Id"].ToString());
            com.Parameters.Add("@SubAgntRefNo", SqlDbType.VarChar).Value = SubAgentId.Rows[0]["SubAgntRefNo"].ToString();
        }
        else
        {
            com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = (object)DBNull.Value;
            com.Parameters.Add("@SubAgntRefNo", SqlDbType.VarChar).Value = "";

        }


        #endregion



        DataTable dtCppAgentCity = dw.GetAllFromQuery("select Offline_City from agent_Master where agent_id=" + long.Parse(ddlAgentName.SelectedValue) + " and Offline_Agent='Y'");



        if (dtCppAgentCity.Rows.Count > 0)
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(dtCppAgentCity.Rows[0]["Offline_City"].ToString());
        }
        else
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(ddlOrigin.SelectedValue);
        }

        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtMSC.Text);

        //================================ Updated on 2nd july 2012 rates for ke =============================
        com.Parameters.Add("@KE_Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@KE_Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 14;
        }

        com.Parameters.Add("@KE_Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(txtET.Text);
        com.Parameters.Add("@Certificate_No", SqlDbType.VarChar).Value = txtcertificate_no.Text;

        //Gst Applicable
        com.Parameters.Add("@StateCode", SqlDbType.VarChar).Value = ddlGstStateCode.SelectedValue;
        if (txtGstNo.Text == "")
        {
            com.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = ddlGstStateCode.SelectedValue;
        }
        else
        {
            ////if (txtGstNo.Text == "00" || txtGstNo.Text == "0")
            ////{
            ////    txtGstNo.Text = "00";
            ////}
            com.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = txtGstNo.Text;
        }

        com.Parameters.Add("@GstAddress", SqlDbType.VarChar).Value = txtGstAddr.Text;

        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        //End of Gst Applicable
        //======================================================================================================



        com.ExecuteNonQuery();


        #region Gst Calculation Insertion
        string GstType = "CGST";
        decimal CGST = 9;
        decimal SGST = 9;
        decimal IGST = 18;
        string CompGstNo = "07";
        string AgentgstNo = txtGstNo.Text;
        DataTable dtCompgstNo = dw.GetAllFromQuery("Select GstNo from Airline_detail where Airline_Detail_id=" + Convert.ToInt64(ddlAirline.SelectedValue) + " and gstNo is not null");
        if (dtCompgstNo != null || dtCompgstNo.Rows.Count > 0)
        {
            CompGstNo = dtCompgstNo.Rows[0]["GstNo"].ToString();

        }
        if (AgentgstNo == "")
        {
            AgentgstNo = ddlGstStateCode.SelectedValue;
        }

        if (CompGstNo.Substring(0, 2) == AgentgstNo.Substring(0, 2))
        {
            IGST = 0;
        }
        else
        {
            CGST = 0;
            SGST = 0;
            GstType = "IGST";
        }
        com = new SqlCommand("GstAmtInsertion", con, tr);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = int.Parse(ddlAwbNo.SelectedValue);
        com.Parameters.Add("@CGSTRate", SqlDbType.Decimal).Value = CGST;
        com.Parameters.Add("@SGSTRate", SqlDbType.Decimal).Value = SGST;
        com.Parameters.Add("@IGSTRate", SqlDbType.Decimal).Value = IGST;
        com.Parameters.Add("@GstType", SqlDbType.VarChar).Value = GstType;
        com.ExecuteNonQuery();
        #endregion End of GstCaculation Insertion


        #region ShipperConsignee Insertion
        com = new SqlCommand("Insert_Shipper_Details", con, tr);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = int.Parse(ddlAwbNo.SelectedValue);
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.ExecuteNonQuery();
        #endregion

        #region Invoiceno Generation For GST wffectin 01 Apr 2017
        DataTable dtInvoiceNo = new DataTable();
        //con = new SqlConnection(strCon);
        //con.Open();
        //SqlCommand cmd;
        //cmd = new SqlCommand("InsertInvoiceno", con, tr);
        //cmd.CommandType = CommandType.StoredProcedure;
        //cmd.Parameters.Add("@agent_id ", SqlDbType.BigInt).Value = long.Parse(ddlAgentName.SelectedValue);
        //cmd.Parameters.Add("@startDate ", SqlDbType.VarChar).Value = startDate;
        //cmd.Parameters.Add("@endDate ", SqlDbType.VarChar).Value = endDate;
        //cmd.Parameters.Add("@Fin_Year ", SqlDbType.VarChar).Value = FinYear;
        //cmd.Parameters.Add("@Stock_id", SqlDbType.BigInt).Value = long.Parse(ddlAwbNo.SelectedValue);
        //cmd.Parameters.Add("@AirlineID", SqlDbType.BigInt).Value = Convert.ToInt64(ddlAirline.SelectedValue);
        //cmd.ExecuteNonQuery();
        #endregion
    }
    #endregion

    #region Update_Sales
    public void Update_Sales(SqlTransaction tr, SqlConnection con, string HandoverID)
    {

        #region From and To date
        string Flight_date = txtFlightDate.Text;
        string[] dateSplit = Flight_date.Split('/');
        string Month = dateSplit[1].ToString();
        string Year = dateSplit[2].ToString();
        string Date1 = dateSplit[0].ToString();
        string currentdate = Month + "/" + Date1 + "/" + Year;
        string FinYear = Year.Substring(2, 2);



        DateTime CurrDate = Convert.ToDateTime(currentdate);
        string DateFinancial = "4/1/20" + FinYear + "";
        DateTime FinanciaDate = DateTime.Parse(DateFinancial);


        if (CurrDate < FinanciaDate)
        {
            FinYear = "20" + Convert.ToString(decimal.Parse(FinYear) - 1) + "" + "-" + FinYear;
        }
        else
        {
            FinYear = "20" + FinYear + "" + "-" + Convert.ToString(decimal.Parse(FinYear) + 1);
        }


        string Lastdate = "";
        bool flagInvoice = false;
        if (int.Parse(Date1) < 16)
        {
            Date1 = "1";
            flagInvoice = true;
        }
        else
        {
            Date1 = "16";
        }

        string startDate = Month + "/" + Date1 + "/" + Year;
        string endDate = Month + "/" + (flagInvoice ? "15" : (Convert.ToDateTime(Month + "/1/" + Year).AddMonths(1).AddDays(-1).Day.ToString())) + "/" + Year;


        #endregion End of From and to date





        string update;

        //Gst Applicale
        update = "update Sales set Flight_No=@Flight_No,Flight_Open_ID=@Flight_Open_ID,AirWayBill_No=@AirWayBill_No,AWB_Date=@AWB_Date,CSR_Date=@CSR_Date,Flight_Date=@Flight_Date,Stock_ID=@Stock_ID,Agent_ID=@Agent_ID,Special_Commodity_ID=@Special_Commodity_ID,Shipment_Name=@Shipment_Name,Shipment_ID=@Shipment_ID,City_ID=@City_ID,City_Code=@City_Code,Destination_ID=@Destination_ID,Destination_Code=@Destination_Code,Airline_Detail_ID=@Airline_Detail_ID,Disbursement_Charges=@Disbursement_Charges,AWB_Fees=@AWB_Fees,Valuation_Charge=@Valuation_Charge,Tax=@Tax,No_of_houses=@No_of_houses,Total_ACI_Fees=@Total_ACI_Fees,Cartridge_Charges=@Cartridge_Charges,DueCarrier_Type=@DueCarrier_Type,TotalDueAgent_Prepaid=@TotalDueAgent_Prepaid,TotalDueAgent_Collect=@TotalDueAgent_Collect,Total_DueCarrier=@Total_DueCarrier,Total_Prepaid=@Total_Prepaid,Total_Collect=@Total_Collect,FSCRate=@FSCRate,WSCRate=@WSCRate,XRayRate=@XRayRate,War_Surcharges=@War_Surcharges,Fuel_Surcharges=@Fuel_Surcharges,Xray_Charges=@Xray_Charges,No_of_Packages=@No_of_Packages,Gross_Weight=@Gross_Weight,Volume_Weight=@Volume_Weight,Charged_Weight=@Charged_Weight,Spot_Rate=@Spot_Rate,Commission=@Commission,Special_Commodity_Incentive=@Special_Commodity_Incentive,Freight_Type=@Freight_Type,Tariff_Rate=@Tariff_Rate,Freight_Amount=@Freight_Amount,Special_Rate=@Special_Rate,Special_Amount=@Special_Amount,Principle_Rate=@Principle_Rate,Principle_Amount=@Principle_Amount,Principle_Spot_Rate=@Principle_Spot_Rate,GSAComm_Rate=@GSAComm_Rate,Principle_Spot_Rate_Remarks=@Principle_Spot_Rate_Remarks,Other_DueCarrier=@Other_DueCarrier,Other_Remarks=@Other_Remarks,Currency=@Currency,CHGS_Code=@CHGS_Code,Declared_Carriage_Value=@Declared_Carriage_Value,Declared_Custom_Value=@Declared_Custom_Value,Handling_Information=@Handling_Information,Nature_and_Quantity=@Nature_and_Quantity,Remarks=@Remarks,TDS=@TDS,Surcharge=@Surcharge,Education_Cess=@Education_Cess,CSR_SNo=@CSR_SNo,Sales_Added_Date=@Sales_Added_Date,Agent_Min_Status=@Agent_Min_Status,Principle_Min_Status=@Principle_Min_Status,Status=@Status,Entered_By=@Entered_By,Entered_On=@Entered_On,Add_To_Deal=@Add_To_Deal,TruckerAmount=@TruckerAmount,TruckerPerKg=@TruckerPerKg,TruckerSupplier_id=@TruckerSupplier_id,TruckingOrigin=@TruckingOrigin,VendorAwbNo=@VendorAwbNo,SubAgent_Id=@SubAgent_Id,SubAgntRefNo=@SubAgntRefNo,Cpp_FinalAgentCity=@Cpp_FinalAgentCity,MSC_Charges=@MSC_Charges,KE_Principle_Rate=@KE_Principle_Rate,KE_Principle_Spot_Rate=@KE_Principle_Spot_Rate,KE_Principle_Min_Status=@KE_Principle_Min_Status,KE_Principle_Amount=@KE_Principle_Amount,ETCharges=@ETCharges,Certificate_No=@Certificate_No,GstNo=@GstNo,stateCode=@stateCode,GstAddress=@GstAddress where Handover_ID=@Handover_ID";


        SqlCommand com = new SqlCommand(update, con, tr);

        com.CommandType = CommandType.Text;
        //com.Parameters.Add("@Booking_ID", SqlDbType.DateTime).Value = HandoverID;
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedValue.Trim();
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = 1234;
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);

        //*******************************Updated on 15 Feb 2012, Tk-On-Awb date, rest Airlines on -Flight Datewise**************************************

        ////if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "232" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "297" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "360" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "180")
        ////{
        ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        ////}
        ////else
        ////{
        ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        ////}

        if ((ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "235") || (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "071"))
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);

        }
        else
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
        }


        //*******************************End of 15 Feb 2012*************************************************************


        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        string strOrgin = ddlOrigin.SelectedValue.Trim();
        strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = ddlDestination.SelectedItem.Text;
        strDestination = strDestination.Substring(0, 3);
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"]);

        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(txtHouses.Value);
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;

        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentP.Text);
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentC.Text);
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtDueCarrier.Text);
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtPrepaid.Text);
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtCollect.Text);

        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRFSC.Value);
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRWSC.Value);
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = decimal.Parse(txtRXRAY.Value);
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);

        //com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(WSC.Value);
        //com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(FSC.Value);
        //com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(XRay.Value);

        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpotRate.Text);
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(txtIATACommission.Text);
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(txtSCR_Incentive.Text);

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtTariffRate.Text);
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtSpAmt.Text);

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpRate.Text);
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtFreightAmount.Text);



        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);


        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        DataTable dtGSA = dw.GetAllFromQuery("select GSAComm_Rate from Airline_Detail where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@GSAComm_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtGSA.Rows[0]["GSAComm_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtOthers.Text); ;
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;

        DataTable dtBooking_AWBDetails = dw.GetAllFromQuery("select Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity from Booking_AWB where Handover_ID=" + HandoverID);

        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Currency"].ToString();
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["CHGS_Code"].ToString();
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Declared_Carriage_Value"].ToString();
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Declared_Custom_Value"].ToString();
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Handling_Information"].ToString();
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = dtBooking_AWBDetails.Rows[0]["Nature_and_Quantity"].ToString();
        ////com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value =txtShipper.Text;
        ////com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        ////com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        ////com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(txtTDS.Text);
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(txtSurcharge.Text);
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(txtEducationalCess.Text);
        #region Generating CSR Serial Auto Number

        //string CSR_Date = (txtAWBDate.Text);
        string CSR_Date;

        //************************************Updated On 15 Feb 2012: Tk-On-Awb Date and Rest Airline on -FlightDate***************************


        ////if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "232" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "297" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "180")
        ////{
        ////    CSR_Date = (txtFlightDate.Text);

        ////}
        ////else
        ////{
        ////    CSR_Date = (txtAWBDate.Text);
        ////}

        if ((ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "235") || (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "071"))
        {
            CSR_Date = (txtAWBDate.Text);

        }
        else
        {
            CSR_Date = (txtFlightDate.Text);

        }
        //********************************END of 15 Feb 2012***************************************************************************************
        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string First = "";
        string Last = "";

        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = "03/31/" + LastYear.ToString();
        }
        else
        {
            FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = "04/01/" + LastYear.ToString();
        }

        if (int.Parse(strDD) <= 15)
        {
            First = "01/" + strMM + "/" + strYYYY;
            Last = "15/" + strMM + "/" + strYYYY;
        }
        else
        {
            First = "16/" + strMM + "/" + strYYYY;
            DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
            string LastDate = Date.Day.ToString();
            Last = LastDate + "/" + strMM + "/" + strYYYY;
        }



        DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
        if (dtCSR_SNo.Rows.Count > 0)
        {
            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
        }
        else
        {
            long Maximum = 0;
            DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
            if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
            {
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
            }
            else
            {
                Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
            }

        }
        // }
        #endregion

        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 20;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@TruckerAmount", SqlDbType.Decimal).Value = (txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim()));
        com.Parameters.Add("@TruckerPerKg", SqlDbType.Decimal).Value = (txtTruckerPerkg.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerPerkg.Text.Trim()));
        com.Parameters.Add("@TruckerSupplier_id", SqlDbType.Int).Value = ddlTruckerSupplier.SelectedValue;
        com.Parameters.Add("@TruckingOrigin", SqlDbType.VarChar).Value = txtTruckOrigin.Text;
        com.Parameters.Add("@VendorAwbNo", SqlDbType.VarChar).Value = txtVendorAwbNo.Text;

        #region SubAgent
        DataTable SubAgentId = dw.GetAllFromQuery("Select isnull(subAgent_Id,0) as subAgent_Id,SubAgntRefNo from Booking_Master where stock_id=" + ViewState["Stock_ID"].ToString() + "");

        if (SubAgentId.Rows.Count > 0)
        {
            com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = SubAgentId.Rows[0]["subAgent_Id"].ToString() == "0" ? (object)DBNull.Value : int.Parse(SubAgentId.Rows[0]["subAgent_Id"].ToString());
            com.Parameters.Add("@SubAgntRefNo", SqlDbType.VarChar).Value = SubAgentId.Rows[0]["SubAgntRefNo"].ToString();
        }
        else
        {
            com.Parameters.Add("@SubAgent_Id", SqlDbType.Int).Value = (object)DBNull.Value;
            com.Parameters.Add("@SubAgntRefNo", SqlDbType.VarChar).Value = "";

        }

        #endregion

        DataTable dtCppAgentCity = dw.GetAllFromQuery("select Offline_City from agent_Master where agent_id=" + long.Parse(ViewState["Agent_ID"].ToString()) + " and Offline_Agent='Y'");



        if (dtCppAgentCity.Rows.Count > 0)
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(dtCppAgentCity.Rows[0]["Offline_City"].ToString());
        }
        else
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        }

        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtMSC.Text);

        //================================Updated on  2nd july 2012 rates for ke =============================
        com.Parameters.Add("@KE_Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@KE_Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 14;
        }

        com.Parameters.Add("@KE_Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(txtET.Text);
        com.Parameters.Add("@Certificate_No", SqlDbType.VarChar).Value = txtcertificate_no.Text;

        //Gst Applicable
        com.Parameters.Add("@StateCode", SqlDbType.VarChar).Value = ddlGstStateCode.SelectedValue;
        if (txtGstNo.Text == "")
        {
            com.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = ddlGstStateCode.SelectedValue;
        }
        else
        {
            com.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = txtGstNo.Text;
        }
        com.Parameters.Add("@GstAddress", SqlDbType.VarChar).Value = txtGstAddr.Text;
        //End of Gst Applicable
        //======================================================================================================
        com.ExecuteNonQuery();


        #region Gst Calculation Insertion
        string GstType = "CGST";
        decimal CGST = 9;
        decimal SGST = 9;
        decimal IGST = 18;
        string CompGstNo = "07";
        string AgentgstNo = txtGstNo.Text;
        DataTable dtCompgstNo = dw.GetAllFromQuery("Select GstNo from Airline_detail where Airline_Detail_id=" + Convert.ToInt64(ViewState["AirlineDetailID"]) + " and gstNo is not null");
        if (dtCompgstNo != null || dtCompgstNo.Rows.Count > 0)
        {
            CompGstNo = dtCompgstNo.Rows[0]["GstNo"].ToString();

        }
        if (AgentgstNo == "")
        {
            AgentgstNo = ddlGstStateCode.SelectedValue;
        }

        if (CompGstNo.Substring(0, 2) == AgentgstNo.Substring(0, 2))
        {
            IGST = 0;
        }
        else
        {
            CGST = 0;
            SGST = 0;
            GstType = "IGST";
        }
        com = new SqlCommand("GstAmtInsertion", con, tr);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = int.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@CGSTRate", SqlDbType.Decimal).Value = CGST;
        com.Parameters.Add("@SGSTRate", SqlDbType.Decimal).Value = SGST;
        com.Parameters.Add("@IGSTRate", SqlDbType.Decimal).Value = IGST;
        com.Parameters.Add("@GstType", SqlDbType.VarChar).Value = GstType;
        com.ExecuteNonQuery();
        #endregion End of GstCaculation Insertion


        #region ShipperConsignee Insertion
        com = new SqlCommand("Insert_Shipper_Details", con, tr);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = int.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.ExecuteNonQuery();
        #endregion

        #region Invoiceno Generation For GST wffectin 01 Apr 2017
        DataTable dtInvoiceNo = new DataTable();
        //con = new SqlConnection(strCon);
        //con.Open();
        SqlCommand cmd;
        cmd = new SqlCommand("InsertInvoiceno", con, tr);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@agent_id ", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        cmd.Parameters.Add("@startDate ", SqlDbType.VarChar).Value = startDate;
        cmd.Parameters.Add("@endDate ", SqlDbType.VarChar).Value = endDate;
        cmd.Parameters.Add("@Fin_Year ", SqlDbType.VarChar).Value = FinYear;
        cmd.Parameters.Add("@Stock_id", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        cmd.Parameters.Add("@AirlineID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"]);
        cmd.ExecuteNonQuery();
        #endregion

    }
    #endregion





    #region Edit_Sales
    public void Edit_Sales(SqlTransaction tr, SqlConnection con, string SalesID)
    {
        string update;

        //Gst Applicable
        update = "update Sales set CSR_SNo=@CSR_SNo,Flight_No=@Flight_No,Flight_Open_ID=@Flight_Open_ID,AirWayBill_No=@AirWayBill_No,AWB_Date=@AWB_Date,CSR_Date=@CSR_Date,Flight_Date=@Flight_Date,Stock_ID=@Stock_ID,Agent_ID=@Agent_ID,Special_Commodity_ID=@Special_Commodity_ID,Shipment_Name=@Shipment_Name,Shipment_ID=@Shipment_ID,City_ID=@City_ID,City_Code=@City_Code,Destination_ID=@Destination_ID,Destination_Code=@Destination_Code,Airline_Detail_ID=@Airline_Detail_ID,Disbursement_Charges=@Disbursement_Charges,AWB_Fees=@AWB_Fees,Valuation_Charge=@Valuation_Charge,Tax=@Tax,No_of_houses=@No_of_houses,Total_ACI_Fees=@Total_ACI_Fees,Cartridge_Charges=@Cartridge_Charges,DueCarrier_Type=@DueCarrier_Type,TotalDueAgent_Prepaid=@TotalDueAgent_Prepaid,TotalDueAgent_Collect=@TotalDueAgent_Collect,Total_DueCarrier=@Total_DueCarrier,Total_Prepaid=@Total_Prepaid,Total_Collect=@Total_Collect,FSCRate=@FSCRate,WSCRate=@WSCRate,XRayRate=@XRayRate,War_Surcharges=@War_Surcharges,Fuel_Surcharges=@Fuel_Surcharges,Xray_Charges=@Xray_Charges,No_of_Packages=@No_of_Packages,Gross_Weight=@Gross_Weight,Volume_Weight=@Volume_Weight,Charged_Weight=@Charged_Weight,Spot_Rate=@Spot_Rate,Commission=@Commission,Special_Commodity_Incentive=@Special_Commodity_Incentive,Freight_Type=@Freight_Type,Tariff_Rate=@Tariff_Rate,Freight_Amount=@Freight_Amount,Special_Rate=@Special_Rate,Special_Amount=@Special_Amount,Principle_Rate=@Principle_Rate,Principle_Amount=@Principle_Amount,Principle_Spot_Rate=@Principle_Spot_Rate,Principle_Spot_Rate_Remarks=@Principle_Spot_Rate_Remarks,Other_DueCarrier=@Other_DueCarrier,Other_Remarks=@Other_Remarks,Remarks=@Remarks,TDS=@TDS,Surcharge=@Surcharge,Education_Cess=@Education_Cess,Approved_for_CSR=@Approved_for_CSR,Sales_Added_Date=@Sales_Added_Date,Agent_Min_Status=@Agent_Min_Status,CSR_Remarks=@CSR_Remarks,Principle_Min_Status=@Principle_Min_Status,Status=@Status,Entered_By=@Entered_By,Entered_On=@Entered_On,TruckerAmount=@TruckerAmount,TruckerPerKg=@TruckerPerKg,TruckerSupplier_id=@TruckerSupplier_id,TruckingOrigin=@TruckingOrigin,VendorAwbNo=@VendorAwbNo,Cpp_FinalAgentCity=@Cpp_FinalAgentCity,MSC_Charges=@MSC_Charges,KE_Principle_Rate=@KE_Principle_Rate,KE_Principle_Spot_Rate=@KE_Principle_Spot_Rate,KE_Principle_Min_Status=@KE_Principle_Min_Status,KE_Principle_Amount=@KE_Principle_Amount,ETCharges=@ETCharges ,Certificate_No=@Certificate_No,GstNo=@GstNo,stateCode=@stateCode,GstAddress=@GstAddress,ConversionRateToPHP=@ConversionRateToPHP where Sales_ID=@Sales_ID";


        SqlCommand com = new SqlCommand(update, con, tr);

        com.CommandType = CommandType.Text;
        //com.Parameters.Add("@Booking_ID", SqlDbType.DateTime).Value = HandoverID;
        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = long.Parse(SalesID);

        #region Generating CSR Serial Auto Number
        string CSR_Date;

        //********************************Updated On 15 Feb 2012 TK-On-Awb Date and rest Airline on FlightWise********************************//

        //////if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "232" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "297" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "180")
        //////{
        //////    CSR_Date = (txtFlightDate.Text);

        //////}
        //////else
        //////{
        //////     CSR_Date = (txtAWBDate.Text);
        //////}

        if ((ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "235") || (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "071"))
        {
            CSR_Date = (txtAWBDate.Text);

        }
        else
        {
            CSR_Date = (txtFlightDate.Text);

        }
        //*********************************************End of 15 Feb 2012***********************************************************//

        string[] d = CSR_Date.Split(new char[] { '/' });
        string strDD = d[0];
        string strMM = d[1];
        string strYYYY = d[2];
        string First = "";
        string Last = "";

        string FinancialYearLast = string.Empty;
        int LastYear = 0;
        string FinancialYearFirst = string.Empty;
        if (int.Parse(strMM) > 3)
        {
            FinancialYearFirst = "04/01/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year + 1);
            FinancialYearLast = "03/31/" + LastYear.ToString();
        }
        else
        {
            FinancialYearLast = "03/31/" + DateTime.Now.Year.ToString();
            LastYear = (DateTime.Now.Year - 1);
            FinancialYearFirst = "04/01/" + LastYear.ToString();
        }
        if (int.Parse(strDD) <= 15)
        {
            First = "01/" + strMM + "/" + strYYYY;
            Last = "15/" + strMM + "/" + strYYYY;
        }
        else
        {
            First = "16/" + strMM + "/" + strYYYY;
            DateTime Date = (Convert.ToDateTime(strMM + "/" + strYYYY)).AddMonths(1).AddDays(-1);
            string LastDate = Date.Day.ToString();
            Last = LastDate + "/" + strMM + "/" + strYYYY;
        }
        DataTable dtCSR_SNo = dw.GetAllFromQuery("select CSR_SNo from Sales where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + "  and CSR_Date between '" + FormatDateMM(First) + "'" + " and '" + FormatDateMM(Last) + "'");
        if (dtCSR_SNo.Rows.Count > 0)
        {
            com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtCSR_SNo.Rows[0]["CSR_SNo"].ToString());
        }
        else
        {
            long Maximum = 0;
            DataTable dtMaximumSales = dw.GetAllFromQuery("select isnull(max(CSR_Sno),0) as CSR_Sno from sales where Airline_Detail_ID=" + ViewState["AirlineDetailID"].ToString() + " and CSR_Date between '" + FinancialYearFirst + "'" + " and'" + FinancialYearLast + "'");
            if (dtMaximumSales.Rows[0]["CSR_Sno"].ToString() == "0")
            {
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = 1;
            }
            else
            {
                Maximum = long.Parse(dtMaximumSales.Rows[0]["CSR_Sno"].ToString());
                com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = Maximum + 1;
            }

        }
        // }
        #endregion
        ///////com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = ddlfltNo.SelectedValue.Trim();

        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value ="1234";
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = 1234;
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = FormatDateDD(txtAWBDate.Text);
        string Sales_ID = "";
        if (Request.QueryString["Sales_ID"] != null)
        {
            Sales_ID = Request.QueryString["Sales_ID"];
        }
        DataTable dtSales_ID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + Sales_ID);
        if (dtSales_ID.Rows[0]["Approved_for_CSR"].ToString() == "28")
        {
            com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtCSRDate.Text);
        }
        else
        {
            //com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtAWBDate.Text);
            //********************************Updated On 15 Feb 2012 :Tk-On-Awb date and Rest Airlines on FlightDateWise*************************


            ////if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "232" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "297" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "360" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "180")
            ////{
            ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

            ////}
            ////else
            ////{
            ////    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
            ////}


            if ((ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "235") || (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "071"))
            {
                com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
            }
            else
            {
                com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);
            }

            //****************************End of 15 Feb 2012*****************************************************************************************
        }
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = FormatDateDD(txtFlightDate.Text);
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = ddlScr.SelectedValue;
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = ddlShipmentType.SelectedItem.Text;
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = ddlShipmentType.SelectedValue;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        string strOrgin = ddlOrigin.SelectedItem.Text.Trim();
        strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = ddlDestination.SelectedValue;
        string strDestination = ddlDestination.SelectedItem.Text;
        strDestination = strDestination.Substring(0, 3);
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = strDestination;
        //com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"]);
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(txtHouses.Value);
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        //com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentP.Text);
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtDueAgentC.Text);
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtDueCarrier.Text);
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(txtPrepaid.Text);
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(txtCollect.Text);
        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRFSC.Value);
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = decimal.Parse(txtRWSC.Value);
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = decimal.Parse(txtRXRAY.Value);
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(txtPieces.Text);
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtGw.Text);
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtVolwt.Text);
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(txtCw.Text);
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpotRate.Text);
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(txtIATACommission.Text);
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(txtSCR_Incentive.Text);
        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = rbFType.SelectedValue;
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtTariffRate.Text);
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtSpAmt.Text);
        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtSpRate.Text);
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtFreightAmount.Text);
        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = txtSpotRateRemarks.Text;
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(txtOthers.Text); ;
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
        ////com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        ////com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        ////com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        ////com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(txtTDS.Text);
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(txtSurcharge.Text);
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(txtEducationalCess.Text);
        if (dtSales_ID.Rows[0]["Approved_for_CSR"].ToString() == "28")
        {
            com.Parameters.Add("@Approved_for_CSR", SqlDbType.Int).Value = 28;
        }
        else
        {
            com.Parameters.Add("@Approved_for_CSR", SqlDbType.Int).Value = 29;
        }
        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = status;
        if (ChkMinAgent.Checked == true)
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@CSR_Remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 11;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@TruckerAmount", SqlDbType.Decimal).Value = (txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim()));
        com.Parameters.Add("@TruckerPerKg", SqlDbType.Decimal).Value = (txtTruckerPerkg.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerPerkg.Text.Trim()));
        com.Parameters.Add("@TruckerSupplier_id", SqlDbType.Int).Value = (object)DBNull.Value; 
        com.Parameters.Add("@TruckingOrigin", SqlDbType.VarChar).Value = txtTruckOrigin.Text;
        com.Parameters.Add("@VendorAwbNo", SqlDbType.VarChar).Value = txtVendorAwbNo.Text;
        DataTable dtCppAgentCity = dw.GetAllFromQuery("select Offline_City from agent_Master where agent_id=" + long.Parse(ViewState["Agent_ID"].ToString()) + " and Offline_Agent='Y'");
        if (dtCppAgentCity.Rows.Count > 0)
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(dtCppAgentCity.Rows[0]["Offline_City"].ToString());
        }
        else
        {
            com.Parameters.Add("@Cpp_FinalAgentCity", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        }
        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtMSC.Text);

        //================================ Updated On 2nd july 2012  rates for ke  =============================
        com.Parameters.Add("@KE_Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@KE_Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 14;
        }

        com.Parameters.Add("@KE_Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(txtET.Text);
        com.Parameters.Add("@Certificate_No", SqlDbType.VarChar).Value = txtcertificate_no.Text;

        //Gst Applicable
        //Gst Applicable updated on 12 June 2017
        com.Parameters.Add("@StateCode", SqlDbType.VarChar).Value = ddlGstStateCode.SelectedValue;
        if (txtGstNo.Text == "")
        {
            com.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = ddlGstStateCode.SelectedValue;
        }
        else
        {
            com.Parameters.Add("@GstNo", SqlDbType.VarChar).Value = txtGstNo.Text;
        }
        com.Parameters.Add("@GstAddress", SqlDbType.VarChar).Value = txtGstAddr.Text;

        com.Parameters.Add("@ConversionRateToPHP", SqlDbType.Decimal).Value = (txtUSDToPHP.Text == "" ? 0 : decimal.Parse(txtUSDToPHP.Text));
        // end of Applicable
        //======================================================================================================

        com.ExecuteNonQuery();



        #region Gst Calculation Insertion
        string GstType = "CGST";
        decimal CGST = 9;
        decimal SGST = 9;
        decimal IGST = 18;
        string CompGstNo = "07";
        string AgentgstNo = txtGstNo.Text;
        DataTable dtCompgstNo = dw.GetAllFromQuery("Select GstNo from Airline_detail where Airline_Detail_id=" + Convert.ToInt64(ViewState["AirlineDetailID"]) + " and gstNo is not null");
        if (dtCompgstNo != null || dtCompgstNo.Rows.Count > 0)
        {
            CompGstNo = dtCompgstNo.Rows[0]["GstNo"].ToString();

        }
        if (AgentgstNo == "")
        {
            AgentgstNo = ddlGstStateCode.SelectedValue;
        }

        if (CompGstNo.Substring(0, 2) == AgentgstNo.Substring(0, 2))
        {
            IGST = 0;
        }
        else
        {
            CGST = 0;
            SGST = 0;
            GstType = "IGST";
        }
        com = new SqlCommand("GstAmtInsertion", con, tr);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = int.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@CGSTRate", SqlDbType.Decimal).Value = CGST;
        com.Parameters.Add("@SGSTRate", SqlDbType.Decimal).Value = SGST;
        com.Parameters.Add("@IGSTRate", SqlDbType.Decimal).Value = IGST;
        com.Parameters.Add("@GstType", SqlDbType.VarChar).Value = GstType;
        com.ExecuteNonQuery();
        #endregion End of GstCaculation Insertion





        #region ShipperConsignee Insertion
        com = new SqlCommand("Insert_Shipper_Details", con, tr);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.Add("@Stock_id", SqlDbType.Int).Value = int.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();


        com.ExecuteNonQuery();
        #endregion
    }
    #endregion

    #region Edit_BookingAWB
    public void Edit_BookingAWB(SqlTransaction tr, SqlConnection con, string SalesID)
    {
        string update;
        update = "update Booking_AWB set Shipper_Name=@Shipper_Name,Shipper_Address=@Shipper_Address,Consignee_Name=@Consignee_Name,Consignee_Address=@Consignee_Address,Disbursement_Charges=@Disbursement_Charges,AWB_Fees=@AWB_Fees,Valuation_Charge=@Valuation_Charge,Tax=@Tax,No_of_houses=@No_of_houses,Total_ACI_Fees=@Total_ACI_Fees,Cartridge_Charges=@Cartridge_Charges,DueCarrier_Type=@DueCarrier_Type,TotalDueAgent_Prepaid=@TotalDueAgent_Prepaid,TotalDueAgent_Collect=@TotalDueAgent_Collect,Total_DueCarrier=@Total_DueCarrier,Total_Prepaid=@Total_Prepaid,Total_Collect=@Total_Collect,War_Surcharges=@War_Surcharges,Fuel_Surcharges=@Fuel_Surcharges,Xray_Charges=@Xray_Charges,MSC_Charges=@MSC_Charges where Sales_ID=@Sales_ID";
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        //com.Parameters.Add("@Booking_ID", SqlDbType.DateTime).Value = HandoverID;
        //com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = txtShipper.Text;
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = txtShipperAddress.Text;
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = txtConsignee.Text;
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = txtConsigneeAddress.Text;

        // com.Parameters.Add("@AWC_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);

        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtDisbursmentCharges.Text);
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtAWBFee.Text);
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(txtValuationCharge.Text);
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(txtTax.Text);
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = txtHouses.Value;
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(txtACIFee.Text);
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtCatrage.Text);
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = txtDueAgentP.Text;
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = txtDueAgentC.Text;
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = txtDueCarrier.Text;
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = txtPrepaid.Text;
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = txtCollect.Text;
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtWSC.Text);
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(txtFSC.Text);
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtXRAY.Text);
        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(txtMSC.Text);
        com.ExecuteNonQuery();
    }
    #endregion

    #region Edit_Handover
    public void Edit_Handover(SqlTransaction tr, SqlConnection con, string HandoverID)
    {
        string update;

        update = "update Handover set Agent_Deal_Remarks=@Agent_Deal_Remarks where Handover_ID=@Handover_ID";
        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Agent_Deal_Remarks", SqlDbType.VarChar).Value = txtCSRRemarks.Text;
        //com.Parameters.Add("@Added_To_Sales", SqlDbType.Int).Value = 11;

        com.ExecuteNonQuery();

    }


    #endregion

    #region EditUsedLimit
    public void EditUsedLimit(SqlTransaction tr, SqlConnection con)
    {
        string update;

        update = "update Agentwise_Used_TDS set CSR_Date=@CSR_Date,Freight_Diff_Amount=@Freight_Diff_Amount,Commission_Amount=@Commission_Amount,Incentive_Amount=@Incentive_Amount,Used_Exemption_Limit=@Used_Exemption_Limit,Entered_By=@Entered_By,Entered_On=@Entered_On ,Certificate_No=@Certificate_No where Agent_ID=@Agent_ID and Stock_ID=@Stock_ID and Airline_Detail_ID=@Airline_Detail_ID";

        SqlCommand com = new SqlCommand(update, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        // com.Parameters.Add("@Company_ID", SqlDbType.Int).Value = int.Parse(ViewState["CompanyID"].ToString());
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.Int).Value = int.Parse(ViewState["AirlineDetailID"].ToString());
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtCSRDate.Text);
        //string Sales_ID = "";
        //if (Request.QueryString["Sales_ID"] != null)
        //{
        //    Sales_ID = Request.QueryString["Sales_ID"];
        //}
        //DataTable dtSales_ID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + Sales_ID);
        //if (dtSales_ID.Rows[0]["Approved_for_CSR"].ToString() == "28")
        //{
        //    com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtCSRDate.Text);
        //}
        //else
        //{
        //    //com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateDD(txtAWBDate.Text);
        //    if (ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "232" || ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3) == "297")
        //    {
        //        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtFlightDate.Text);

        //    }
        //    else
        //    {
        //        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtAWBDate.Text);
        //    }
        //}

        decimal dfa = Convert.ToDecimal(ViewState["FreightDiffAmount"]);
        com.Parameters.Add("@Freight_Diff_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["FreightDiffAmount"]);
        decimal Coam = Convert.ToDecimal(ViewState["CommissionableAmount"]);
        com.Parameters.Add("@Commission_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["CommissionableAmount"]);
        decimal Incentiver = Convert.ToDecimal(ViewState["IncentiveAmount"]);
        com.Parameters.Add("@Incentive_Amount", SqlDbType.Decimal).Value = Convert.ToDecimal(ViewState["IncentiveAmount"]);
        com.Parameters.Add("@Used_Exemption_Limit", SqlDbType.Decimal).Value = decimal.Parse(ViewState["Total_UsedExemption_Limit"].ToString());
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;

        com.Parameters.Add("@Certificate_No", SqlDbType.VarChar).Value = txtcertificate_no.Text == null ? "" : txtcertificate_no.Text;

        com.ExecuteNonQuery();
    }

    #endregion

    #region Insert_Sales_History
    public void Insert_Sales_History(SqlTransaction tr, SqlConnection con, DataTable dtSales)
    {
        string insert;

        insert = "insert into Sales_History(Sales_ID,CSR_SNo,Booking_ID,Handover_ID,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,DueCarrier_Type,TotalDueAgent_Prepaid,TotalDueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,War_Surcharges,Fuel_Surcharges,Xray_Charges,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,Principle_Spot_Rate_Remarks,Other_DueCarrier,Other_Remarks,Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Remarks,TDS,Surcharge,Education_Cess,Sales_Added_Date,Add_To_Deal,Agent_Min_Status,Principle_Min_Status,Status,Entered_By,Entered_On,TruckerAmount,TruckerPerKg,TruckerSupplier_id,TruckingOrigin,VendorAwbNo,MSC_Charges,ETCharges) values(@Sales_ID,@CSR_SNo,@Booking_ID,@Handover_ID,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Remarks,@TDS,@Surcharge,@Education_Cess,@Sales_Added_Date,@Add_To_Deal,@Agent_Min_Status,@Principle_Min_Status,@Status,@Entered_By,@Entered_On,@TruckerAmount,@TruckerPerKg,@TruckerSupplier_id,@TruckingOrigin,@VendorAwbNo,@MSC_Charges,@ETCharges)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;
        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Sales_ID"].ToString());
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["CSR_SNo"].ToString());
        com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Booking_ID"].ToString());
        com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Handover_ID"].ToString());
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = dtSales.Rows[0]["Flight_No"].ToString();
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Flight_Open_ID"].ToString());
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = dtSales.Rows[0]["AirWayBill_No"].ToString();
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["AWB_Date"].ToString();
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["CSR_Date"].ToString();
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["Flight_Date"].ToString();

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Special_Commodity_ID"].ToString());
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Shipment_Name"].ToString();
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Shipment_ID"].ToString());
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = dtSales.Rows[0]["City_Code"].ToString();
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["City_ID"].ToString());
        // com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = ddlOrigin.SelectedValue.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Destination_ID"].ToString());
        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtSales.Rows[0]["Destination_Code"].ToString();
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = long.Parse(dtSales.Rows[0]["Airline_Detail_ID"].ToString());
        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Disbursement_Charges"].ToString());
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["AWB_Fees"].ToString());
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Valuation_Charge"].ToString());
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Tax"].ToString());
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["No_of_houses"].ToString());
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Total_ACI_Fees"].ToString());
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Cartridge_Charges"].ToString());
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = dtSales.Rows[0]["DueCarrier_Type"].ToString();
        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["TotalDueAgent_Prepaid"].ToString());
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["TotalDueAgent_Collect"].ToString());
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Total_DueCarrier"].ToString());
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Total_Prepaid"].ToString());
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Total_Collect"].ToString());
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["War_Surcharges"].ToString());
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Fuel_Surcharges"].ToString());
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Xray_Charges"].ToString());
        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["No_of_Packages"].ToString());
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Gross_Weight"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Volume_Weight"].ToString());
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Charged_Weight"].ToString());
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Spot_Rate"].ToString());
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Commission"].ToString());
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Special_Commodity_Incentive"].ToString());

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtSales.Rows[0]["Freight_Type"].ToString();
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Tariff_Rate"].ToString());
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Freight_Amount"].ToString());

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Special_Rate"].ToString());
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Special_Amount"].ToString());


        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Rate"].ToString());
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Amount"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Principle_Spot_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtSales.Rows[0]["Principle_Spot_Rate"].ToString();
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Other_DueCarrier"].ToString());
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = dtSales.Rows[0]["Other_Remarks"].ToString();
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtSales.Rows[0]["Currency"].ToString();
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtSales.Rows[0]["CHGS_Code"].ToString();
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtSales.Rows[0]["Declared_Carriage_Value"].ToString();
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtSales.Rows[0]["Declared_Custom_Value"].ToString();
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = dtSales.Rows[0]["Handling_Information"].ToString();
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = dtSales.Rows[0]["Nature_and_Quantity"].ToString();
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Nature_and_Quantity"].ToString();
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtSales.Rows[0]["Shipper_Address"].ToString();
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtSales.Rows[0]["Consignee_Name"].ToString();
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtSales.Rows[0]["Consignee_Address"].ToString();
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtSales.Rows[0]["Remarks"].ToString();
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["TDS"].ToString());
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Surcharge"].ToString());
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["Education_Cess"].ToString());
        com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = dtSales.Rows[0]["Sales_Added_Date"].ToString();
        com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Agent_Min_Status"].ToString());

        com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Principle_Min_Status"].ToString());
        int adddeal = (dtSales.Rows[0]["Add_To_Deal"].ToString() == "" ? 14 : int.Parse(dtSales.Rows[0]["Add_To_Deal"].ToString()));
        com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = adddeal;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = int.Parse(dtSales.Rows[0]["Status"].ToString());
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = dtSales.Rows[0]["Entered_By"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = dtSales.Rows[0]["Entered_On"].ToString();
        com.Parameters.Add("@TruckerAmount", SqlDbType.Decimal).Value = (txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim()));
        com.Parameters.Add("@TruckerPerKg", SqlDbType.Decimal).Value = (txtTruckerPerkg.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerPerkg.Text.Trim()));
        com.Parameters.Add("@TruckerSupplier_id", SqlDbType.Int).Value = ddlTruckerSupplier.SelectedValue;
        com.Parameters.Add("@TruckingOrigin", SqlDbType.VarChar).Value = txtTruckOrigin.Text;
        com.Parameters.Add("@VendorAwbNo", SqlDbType.VarChar).Value = txtVendorAwbNo.Text;
        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["MSC_Charges"].ToString());
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(dtSales.Rows[0]["ETCharges"].ToString());
        com.ExecuteNonQuery();
    }
    #endregion

    protected void UpdateSales_Click(object sender, EventArgs e)
    {
        if (Convert.ToDateTime(FormatDateMM(txtFlightDate.Text)) >= Convert.ToDateTime("07/01/2017"))
        {
            if (txtGstNo.Text == "" && ddlGstStateCode.SelectedValue == "0")
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
                txtGstNo.Focus();
                return;
            }

            if (txtGstNo.Text == "00" && ddlGstStateCode.SelectedValue == "0")
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
                txtGstNo.Focus();
                return;
            }
        }

        txtcertificate_no.Text = hdn_certificate_no.Value;
        if (hdn_ex_cross_limit.Value == "")
        {
            ViewState["Ex_crossed_limit"] = "N";
        }
        else
        {
            ViewState["Ex_crossed_limit"] = hdn_ex_cross_limit.Value;
        }
        ////DataTable dtFlight = GetFlightDetails(ddlfltNo.SelectedValue, txtFlightDate.Text);
        ////if (dtFlight.Rows.Count == 0)
        ////{
        ////    ClientScript.RegisterStartupScript(Page.GetType(), "AlertFlight1", "<script>alert('Flight not found on this flight Date. Open flight or check flight schedule');</script>");
        ////    return;
        ////}
        ////else
        ////{
        ////    ViewState["Flight_Open_Id_New"] = dtFlight.Rows[0]["Flight_Open_ID"];

        ////}



        string Actual_Discount = "";
        string SpotRate = "";
        string SpotAmount = "";
        string CommAmount = "";
        string Inc_Amount = "";
        string Current_Discount = "";
        string Overall_Amount = "";


        string _Chargd_weight = "";
        string _spotRate = "";
        string _Commission = "";
        string _Special_commodity_incentive = "";
        string _Frieght_Amount = "";
        _Chargd_weight = txtCw.Text;
        _spotRate = txtSpotRate.Text;
        _Commission = txtIATACommission.Text;
        _Special_commodity_incentive = txtSCR_Incentive.Text;
        _Frieght_Amount = txtSpAmt.Text;



        //*********************** Condition on  AddToSales Condition on Insentive and Frieght on 23_June_2010
        Actual_Discount = Convert.ToString((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) * 5 / 100);
        if ((_spotRate == "" ? 0 : decimal.Parse(_spotRate)) > 0)
        {
            SpotAmount = Convert.ToString((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) - ((_spotRate == "" ? 0 : decimal.Parse(_spotRate)) * (_Chargd_weight == "" ? 0 : decimal.Parse(_Chargd_weight))));
        }

        CommAmount = Convert.ToString(((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) * (_Commission == "" ? 0 : decimal.Parse(_Commission))) / 100);

        Inc_Amount = Convert.ToString((((_Frieght_Amount == "" ? 0 : decimal.Parse(_Frieght_Amount)) - decimal.Parse(CommAmount)) * (_Special_commodity_incentive == "" ? 0 : decimal.Parse(_Special_commodity_incentive))) / 100);


        Current_Discount = Convert.ToString((SpotAmount == "" ? 0 : decimal.Parse(SpotAmount)) + (CommAmount == "" ? 0 : decimal.Parse(CommAmount)) + (Inc_Amount == "" ? 0 : decimal.Parse(Inc_Amount)));

        Overall_Amount = Convert.ToString((Current_Discount == "" ? 0 : decimal.Parse(Current_Discount)) - (Actual_Discount == "" ? 0 : decimal.Parse(Actual_Discount)));
        //*************************************End of Condition on Insentive and Frieght on 23_June_2010
        string AWbNum = ddlAwbNo.SelectedItem.Text.Trim().Substring(0, 3);

        /////IATA Rule condition ends
        //////if (Overall_Amount.Contains("-") && AWbNum != "235")
        ///////////if (Overall_Amount.Contains("-"))
        //////{
        //////    ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('IATA COMM IS LESS AS PER IATA RULE');</script>");
        //////}
        //////else
        //////{
        if ((txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim())) > 0 && ddlTruckerSupplier.SelectedItem.Text == "- -Select- -")
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('Please Select Trucker Supplier Name');</script>");
            ddlTruckerSupplier.Focus();
        }
        else
        {

            con = new SqlConnection(strCon);
            con.Open();
            SqlTransaction tranupdate = con.BeginTransaction();
            decimal UsedExemptionLimit = TDS();
            ViewState["Total_UsedExemption_Limit"] = UsedExemptionLimit;
            string SalesID = "";
            if (Request.QueryString["Sales_ID"] != null)
            {
                SalesID = Request.QueryString["Sales_ID"];
            }
            DataTable dtHandoverID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);

            decimal OldSalesAmount = 0;
            if (dtHandoverID.Rows.Count > 0)
            {
                DataTable dtDiscount = dw.GetAllFromQuery("select Used_Exemption_Limit from Agentwise_Used_TDS where Stock_ID=" + ViewState["Stock_ID"].ToString());
                decimal Used_Exemption_Limit = 0;
                if (dtDiscount.Rows.Count > 0)
                {
                    Used_Exemption_Limit = decimal.Parse(dtDiscount.Rows[0]["Used_Exemption_Limit"].ToString());
                }
                if (dtHandoverID.Rows[0]["Freight_Type"].ToString() == "PREPAID")
                {
                    OldSalesAmount = decimal.Parse(dtHandoverID.Rows[0]["Total_DueCarrier"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["Freight_Amount"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["Tax"].ToString()) + +decimal.Parse(dtHandoverID.Rows[0]["TDS"].ToString()) - Used_Exemption_Limit;
                }
                else
                {
                    OldSalesAmount = decimal.Parse(dtHandoverID.Rows[0]["Tax"].ToString()) - decimal.Parse(dtHandoverID.Rows[0]["TotalDueAgent_Collect"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["TDS"].ToString()) - Used_Exemption_Limit;
                }

            }
            decimal NewSalesAmount = 0;

            if (rbFType.SelectedValue == "PREPAID")
            {
                NewSalesAmount = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtSpAmt.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
            }
            else
            {
                NewSalesAmount = decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - decimal.Parse(txtDueAgentC.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
            }

            // NewSalesAmount = -OldSalesAmount + NewSalesAmount;
            ////DataTable dtUsed_Limit = dw.GetAllFromQuery("SELECT Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + ViewState["City_ID"].ToString());


            //////********************Added ON 29 Mar 2011 For(offline City Agent case)********************
            ////decimal Used_Limit = 0;
            ////if (dtUsed_Limit.Rows.Count <= 0)
            ////{
            ////    string ULimit = "";
            ////    dtUsed_Limit = dw.GetAllFromQuery("select Offline_CityID from booking_master where booking_id=" + dtHandoverID.Rows[0]["Booking_ID"].ToString() + " and Offline_CityID!=''");
            ////    if (dtUsed_Limit.Rows.Count > 0)
            ////    {
            ////        //********Offline Case***************
            ////        dtUsed_Limit = dw.GetAllFromQuery("SELECT Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + dtUsed_Limit.Rows[0]["Offline_CityID"].ToString());


            ////        if (dtUsed_Limit.Rows.Count > 0)
            ////        {
            ////            ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
            ////        }
            ////        else
            ////        {
            ////            dtUsed_Limit = dw.GetAllFromQuery("SELECT ISNULL(Used_Limit,0) AS Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and offline_city=" + dtUsed_Limit.Rows[0]["Offline_CityID"].ToString() + "");
            ////            if (dtUsed_Limit.Rows.Count > 0)
            ////            {
            ////                ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
            ////            }
            ////        }


            ////        if (ULimit == "")
            ////        {
            ////            ULimit = "0";
            ////        }

            ////        Used_Limit = decimal.Parse(ULimit) - OldSalesAmount + NewSalesAmount;
            ////    }
            ////}
            ////else
            ////{
            ////    //**********Online Case****************
            ////    Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) - OldSalesAmount + NewSalesAmount;
            ////}
            //////********************END***************************************************
            //////////decimal Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) - OldSalesAmount + NewSalesAmount;
            ////Used_Limit = Math.Round(Used_Limit, MidpointRounding.AwayFromZero);
            try
            {
                Edit_Sales(tranupdate, con, SalesID);

                InsertSalesTrans(tranupdate, con);
                /////Insert_Sales_History(tranupdate, con, dtHandoverID);
                //Edit_BookingAWB(tranupdate, con, SalesID);
                Update_AWBDate(tranupdate, con);
                /////Edit_Handover(tranupdate, con, dtHandoverID.Rows[0]["Handover_ID"].ToString());

                ////DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                ////if (dtOtherChargesID.Rows.Count > 0)
                ////{
                ////    if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                ////    {
                ////        dtOtherChargesID.Rows[0].Delete();
                ////    }
                ////}
                //////long BookingID = Convert.ToInt64(ViewState["Booking_ID"]);
               ////// Update_OtherCharges(tranupdate, con, BookingID);
                //Update_Stock(tranupdate, con, ViewState["Stock_ID"].ToString());

                //decimal Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtFreightAmount.Text);
                ///////Update_AgentLimit(tranupdate, con, Used_Limit);

               //////// EditUsedLimit(tranupdate, con);

                tranupdate.Commit();
                con.Close();
                Response.Write("<script language='javascript'>window.alert('Details saved sucessfully');window.location='SalesEdit.aspx';</script>");

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                tranupdate.Rollback();
                
            }
            //if (dtHandoverID.Rows[0]["Approved_for_CSR"].ToString() == "28")
            //{
            //    con = new SqlConnection(strCon);
            //    con.Open();
            //    SqlTransaction tr = con.BeginTransaction();
            //    try
            //    {
            //        Insert_Sales_DrCr1(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
            //        Insert_Sales_DrCr2(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
            //        tr.Commit();
            //        con.Close();
            //    }

            //    catch (Exception ex)
            //    {
            //        Response.Write(ex.Message);
            //        tr.Rollback();
            //    }
            //}
           ///// Response.Redirect("SalesEdit.aspx");
            
        }
        /////// IATA Rule condtion ends
        ////////}
    }
    protected void btnSModify_Click(object sender, EventArgs e)
    {
        if (Convert.ToDateTime(FormatDateMM(txtFlightDate.Text)) >= Convert.ToDateTime("07/01/2017"))
        {
            if (txtGstNo.Text == "" && ddlGstStateCode.SelectedValue == "0")
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
                txtGstNo.Focus();
                return;
            }
            if (txtGstNo.Text == "00" && ddlGstStateCode.SelectedValue == "0")
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "AlertGST", "<script>alert('Must select Gst StateCode or Enter 16 digit GstNo..eg: 07 or 07AHSGHSSHSAW412 And also enter GST Address');</script>");
                txtGstNo.Focus();
                return;
            }
        }


        ////DataTable dtFlight = GetFlightDetails(ddlfltNo.SelectedValue, txtFlightDate.Text);
        ////if (dtFlight.Rows.Count == 0)
        ////{
        ////    ClientScript.RegisterStartupScript(Page.GetType(), "AlertFlight2", "<script>alert('Flight not found on this flight Date. Open flight or check flight schedule');</script>");
        ////    return;
        ////}
        ////else
        ////{
        ////    ViewState["Flight_Open_Id_New"] = dtFlight.Rows[0]["Flight_Open_ID"];
        ////}
        if ((txtTruckerAmt.Text.Trim() == "" ? 0 : decimal.Parse(txtTruckerAmt.Text.Trim())) > 0 && ddlTruckerSupplier.SelectedItem.Text == "- -Select- -")
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('Please Select Trucker Supplier Name');</script>");
            ddlTruckerSupplier.Focus();
        }
        else
        {
            con = new SqlConnection(strCon);
            con.Open();
            SqlTransaction tranupdate = con.BeginTransaction();
            decimal UsedExemptionLimit = TDS();
            ViewState["Total_UsedExemption_Limit"] = UsedExemptionLimit;
            string SalesID = "";
            if (Request.QueryString["Sales_ID"] != null)
            {
                SalesID = Request.QueryString["Sales_ID"];
            }
            DataTable dtHandoverID = dw.GetAllFromQuery("select * from Sales where Sales_ID=" + SalesID);

            decimal OldSalesAmount = 0;
            if (dtHandoverID.Rows.Count > 0)
            {
                //DataTable dtDiscount = dw.GetAllFromQuery("select Used_Exemption_Limit from Agentwise_Used_TDS where Stock_ID=" + ViewState["Stock_ID"].ToString());
                ////////**************Changes made by Hemant Sharma on 11'th April 2014***********/////////
                #region Changes made by Hemant Sharma on 11'th April 2014


                DataTable dtDiscount = dw.GetAllFromQuery("IF EXISTS (SELECT Used_Exemption_Limit FROM  Agentwise_Used_TDS where Stock_ID=" + ViewState["Stock_ID"].ToString() + ") BEGIN SELECT  Used_Exemption_Limit FROM  Agentwise_Used_TDS where Stock_ID=" + ViewState["Stock_ID"].ToString() + " END  ELSE BEGIN SELECT 0 AS Used_Exemption_Limit END");
                #endregion
                if (dtHandoverID.Rows[0]["Freight_Type"].ToString() == "PREPAID")
                {
                    OldSalesAmount = decimal.Parse(dtHandoverID.Rows[0]["Total_DueCarrier"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["Freight_Amount"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["Tax"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["TDS"].ToString()) - decimal.Parse(dtDiscount.Rows[0]["Used_Exemption_Limit"].ToString());
                }
                else
                {
                    OldSalesAmount = decimal.Parse(dtHandoverID.Rows[0]["Tax"].ToString()) - decimal.Parse(dtHandoverID.Rows[0]["TotalDueAgent_Collect"].ToString()) + decimal.Parse(dtHandoverID.Rows[0]["TDS"].ToString()) - decimal.Parse(dtDiscount.Rows[0]["Used_Exemption_Limit"].ToString());
                }
            }
            decimal NewSalesAmount = 0;
            if (rbFType.SelectedValue == "PREPAID")
            {
                NewSalesAmount = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtSpAmt.Text) + decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
            }
            else
            {
                NewSalesAmount = decimal.Parse(txtTax.Text) + decimal.Parse(txtTDS.Text) - decimal.Parse(txtDueAgentC.Text) - (Convert.ToDecimal(ViewState["FreightDiffAmount"]) + Convert.ToDecimal(ViewState["CommissionableAmount"]) + Convert.ToDecimal(ViewState["IncentiveAmount"]));
            }

            // NewSalesAmount = -OldSalesAmount + NewSalesAmount;
            DataTable dtUsed_Limit = dw.GetAllFromQuery("SELECT isnull(Used_Limit,0) as Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + ViewState["City_ID"].ToString());




            //********************Added ON 29 Mar 2011 For(offline City Agent case)********************

            //////decimal Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) - OldSalesAmount + NewSalesAmount;

            decimal Used_Limit = 0;
           //// if (dtUsed_Limit.Rows.Count <= 0)
            //{
            //    string ULimit = "";
            //    dtUsed_Limit = dw.GetAllFromQuery("select Offline_CityID from booking_master where booking_id=" + dtHandoverID.Rows[0]["Booking_ID"].ToString() + " and Offline_CityID!=''");
            //    if (dtUsed_Limit.Rows.Count > 0)
            //    {
            //        //********Offline Case***************
            //        dtUsed_Limit = dw.GetAllFromQuery("SELECT Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and Belongs_To_City=" + dtUsed_Limit.Rows[0]["Offline_CityID"].ToString());


            //        if (dtUsed_Limit.Rows.Count > 0)
            //        {
            //            ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
            //        }
            //        else
            //        {
            //            dtUsed_Limit = dw.GetAllFromQuery("SELECT ISNULL(Used_Limit,0) AS Used_Limit from Agent_Branch where Agent_ID=" + ViewState["Agent_ID"].ToString() + " and offline_city=" + dtUsed_Limit.Rows[0]["Offline_CityID"].ToString() + "");
            //            if (dtUsed_Limit.Rows.Count > 0)
            //            {
            //                ULimit = dtUsed_Limit.Rows[0]["Used_Limit"].ToString();
            //            }
            //        }

            //        if (ULimit == "")
            //        {
            //            ULimit = "0";
            //        }

            //        Used_Limit = decimal.Parse(ULimit) - OldSalesAmount + NewSalesAmount;
            //        //Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) - OldSalesAmount + NewSalesAmount;
            //    }
            //}
            //else
            //{
            //    //**********Online Case****************
            //    Used_Limit = decimal.Parse(dtUsed_Limit.Rows[0]["Used_Limit"].ToString()) - OldSalesAmount + NewSalesAmount;
            //}
            ////********************END***************************************************

            //Used_Limit = Math.Round(Used_Limit, MidpointRounding.AwayFromZero);
            string AWBDate = txtAWBDate.Text;
            string CSRdate = txtCSRDate.Text;
            string[] d = AWBDate.Split(new char[] { '/' });
            string strD = d[0];
            int D = Convert.ToInt32(d[0]);
            string strM = d[1];
            int M = Convert.ToInt32(d[1]);
            string strYY = d[2];
            int YY = Convert.ToInt32(d[2]);

            string[] g = CSRdate.Split(new char[] { '/' });
            string strDD = g[0];
            int DD = Convert.ToInt32(g[0]);
            string strMM = g[1];
            int MM = Convert.ToInt32(g[1]);
            string strYYYY = g[2];
            int YYYY = Convert.ToInt32(g[2]);
            string strDate = "";
            if (D <= 15)
            {
                strDate = "16/" + strM + "/" + strYY;
                strDate = FormatDateMM(strDate);

            }
            else
            {
                int Month = M + 1;
                int Year = YY;
                if (Month == 13)
                {
                    Month = 1;
                    Year = YY + 1;
                }
                strDate = "01/" + Month.ToString() + "/" + Year.ToString();
                strDate = FormatDateMM(strDate);
            }
            CSRdate = FormatDateMM(CSRdate);
            //if (DateTime.Parse(CSRdate) >= DateTime.Parse(strDate))
            //{
            try
            {
                Edit_Sales(tranupdate, con, SalesID);

                ///////Insert_Sales_History(tranupdate, con, dtHandoverID);

                DataTable dtOtherChargesID = (DataTable)Session["dtOtherCharges"];
                if (dtOtherChargesID.Rows.Count > 0)
                {
                    if (dtOtherChargesID.Rows[0]["FeeName"].ToString() == "0")
                    {
                        dtOtherChargesID.Rows[0].Delete();
                    }
                }
                //////long BookingID = Convert.ToInt64(ViewState["Booking_ID"]);
                ///////Update_OtherCharges(tranupdate, con, BookingID);
                //Edit_BookingAWB(tranupdate, con, SalesID);
                Update_AWBDate(tranupdate, con);
               /////// Edit_Handover(tranupdate, con, dtHandoverID.Rows[0]["Handover_ID"].ToString());

                //Update_Stock(tranupdate, con, ViewState["Stock_ID"].ToString());

                //decimal Used_Limit = decimal.Parse(txtDueCarrier.Text) + Convert.ToDecimal(txtFreightAmount.Text);
                ///////Update_AgentLimit(tranupdate, con, Used_Limit);

                ////////EditUsedLimit(tranupdate, con);

                tranupdate.Commit();
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                tranupdate.Rollback();
            }
            //DataTable dtDrCr = dw.GetAllFromQuery("select Sales_ID from Sales_DrCr where Sales_ID=" + SalesID);

            if (dtHandoverID.Rows[0]["Approved_for_CSR"].ToString() == "28")
            {
                con = new SqlConnection(strCon);
                con.Open();
                SqlTransaction tr = con.BeginTransaction();
                try
                {


                    //if user want to create crdr
                    if (hdn_Modify.Value == "CRDR")
                    {
                        UpdateApproveStatus(tr, con, SalesID);
                        Insert_Sales_DrCr1(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                        Insert_Sales_DrCr2(tr, con, SalesID, dtHandoverID.Rows[0]["Handover_ID"].ToString(), dtHandoverID);
                    }
                    else
                    {
                        Update_Approve_CSR(tr, con, Convert.ToInt32(SalesID), dtHandoverID.Rows[0]["AirWayBill_No"].ToString());
                    }
                    ////Start changes made by kuldeep on 16 june 2014
                    //Update_Approve_CSR(Convert.ToInt32(SalesID), dtHandoverID.Rows[0]["AirWayBill_No"].ToString());
                    ////End changes made by kuldeep on 16 june 2014
                    tr.Commit();
                    con.Close();
                }

                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                    tr.Rollback();
                }
            }
            Response.Redirect("SalesEdit.aspx");
            //}
            //else
            //{
            //    lblMessage.Visible = true;
            //}
        }//End of UpdateSalesClick
    }
    //created on 18-06-2014  Created by:kuldeep
    #region UpdateApproveStatus
    #region UPdate CSR_Detail
    public void Update_Approve_CSR(SqlTransaction tr, SqlConnection con, int SalesID, string awbNo)
    {
        DateTime FROM_DATE, TO_DATE, date;
        DisplayWrap dpw = new DisplayWrap();



        try
        {




            string SqlQuery = " select AM.AGENT_ID,AM.AGENT_NAME,AM.AGENT_CODE,AB.Agent_Address,A.Airline_Detail_ID, a.CSR_SNo,a.CSR_Date FROM SALES a INNER JOIN Agent_Master AM ON A.Agent_ID=AM.Agent_ID INNER JOIN Agent_Branch AB ON A.Agent_ID=AB.Agent_ID AND A.CITY_ID=AB.BELONGS_TO_CITY WHERE Sales_ID='" + SalesID.ToString() + "'";

            com = new SqlCommand(SqlQuery, con, tr);
            int COUNT = 1;
            //SqlDataReader dr = com.ExecuteReader();
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dr = new DataTable();
            da.Fill(dr);
            if (dr.Rows.Count > 0)
            {
                date = Convert.ToDateTime(dr.Rows[0]["CSR_Date"]);
                if (date.Day <= 15)
                {
                    DateTime.TryParseExact(date.Month.ToString() + "/01/" + date.Year.ToString(), new[] { "MM/dd/yyyy", "M/dd/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out FROM_DATE);
                    DateTime.TryParseExact(date.Month.ToString() + "/15/" + date.Year.ToString(), new[] { "MM/dd/yyyy", "M/dd/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out TO_DATE);
                }
                else
                {
                    DateTime.TryParseExact(date.Month.ToString() + "/16/" + date.Year.ToString(), new[] { "MM/dd/yyyy", "M/dd/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out FROM_DATE);
                    DateTime Date = (Convert.ToDateTime(FROM_DATE.Month.ToString() + "/" + FROM_DATE.Year.ToString())).AddMonths(1).AddDays(-1);
                    string LastDate = Date.Day.ToString();
                    //TO_DATE = DateTime.ParseExact(date.Month.ToString() + "/LastDate/" + date.Year.ToString(), "MM/dd/yyyy", null);
                    DateTime.TryParseExact(date.Month.ToString() + "/" + LastDate + "/" + date.Year.ToString(), new[] { "MM/dd/yyyy", "M/dd/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out TO_DATE);

                }



                decimal TotComm = 0;
                decimal TotDiscount = 0;
                decimal TotFrAmount = 0;
                decimal TotFrAmountCC = 0;
                decimal EduChrg = 0;
                decimal TotTds = 0;
                decimal Total = 0;
                decimal GrandTotal = 0;
                decimal Freight_Amount = 0;
                decimal Total_DueCarrier = 0;
                decimal TotTax = 0;
                decimal Agent_Expenses = 0;
                decimal Freight_Diff_Amount = 0;
                decimal IATA_Commission = 0;
                decimal Amount_Excluding_TDS = 0;
                decimal LastTdsRate = 0;
                decimal LastSurcharge = 0;
                decimal LastEducation_Cess = 0;
                decimal TDS_Amount = 0;
                decimal surCharge = 0;
                decimal Amount_Including_TDS = 0;

                decimal TotComm_CRDR = 0;
                decimal TotDiscount_CRDR = 0;
                decimal TotFrAmount_CRDR = 0;
                decimal TotFrAmountCC_CRDR = 0;
                decimal EduChrg_CRDR = 0;
                decimal TotTds_CRDR = 0;
                decimal Total_CRDR = 0;
                decimal GrandTotal_CRDR = 0;
                decimal Freight_Amount_CRDR = 0;
                decimal Total_DueCarrier_CRDR = 0;
                decimal TotTax_CRDR = 0;
                decimal Agent_Expenses_CRDR = 0;
                decimal Freight_Diff_Amount_CRDR = 0;
                decimal IATA_Commission_CRDR = 0;
                decimal Amount_Excluding_TDS_CRDR = 0;
                decimal LastTdsRate_CRDR = 0;
                decimal LastSurcharge_CRDR = 0;
                decimal LastEducation_Cess_CRDR = 0;
                decimal TDS_Amount_CRDR = 0;
                decimal surCharge_CRDR = 0;
                decimal Amount_Including_TDS_CRDR = 0;
                int Amount_Type_CRDR;

                string AGENT_ID = dr.Rows[0]["AGENT_ID"].ToString();
                string Agent_Name = dr.Rows[0]["Agent_name"].ToString();
                string Agent_Code = dr.Rows[0]["Agent_Code"].ToString();
                string Agent_Address = dr.Rows[0]["Agent_Address"].ToString();
                string CSR_SERIALNo = dr.Rows[0]["CSR_SNo"].ToString();
                long CSR_SNo = 0;
                long CSR_SNo_CRDR = 0;
                string CSR_Durationperiod = FROM_DATE.ToString("MM/dd/yy") + "-" + TO_DATE.ToString("MM/dd/yy");
                string period = FROM_DATE.ToString("dd/MM/yy") + "-" + TO_DATE.ToString("dd/MM/yy");
                string CSR_No = dr.Rows[0]["Agent_Code"].ToString() + "-" + awbNo.Substring(0, 3) + "-" + period;
                int Amount_Type;
                string Sales_Type = "";
                string Sales_Type_CRDR = "";
                DateTime CSR_From = FROM_DATE;
                DateTime CSR_To = TO_DATE;
                string Entered_By = Session["EMailID"].ToString();
                DateTime Entered_On = DateTime.Now;
                if (dr.Rows[0]["AGENT_ID"].ToString() == "405")
                {

                }

                SqlCommand com_csr = new SqlCommand("APPROVE_CSR_DETAILS", con, tr);
                com_csr.CommandType = CommandType.StoredProcedure;
                com_csr.Parameters.AddWithValue("agent_id", AGENT_ID);
                com_csr.Parameters.AddWithValue("CSR_SNo", CSR_SERIALNo);
                com_csr.Parameters.AddWithValue("FROM_DATE", FROM_DATE);
                com_csr.Parameters.AddWithValue("TO_DATE", TO_DATE);
                com_csr.Parameters.AddWithValue("Airline_Detail_ID", dr.Rows[0]["Airline_Detail_ID"].ToString());
                SqlDataAdapter da2 = new SqlDataAdapter(com_csr);
                DataTable dt_csr = new DataTable();
                da2.Fill(dt_csr);
                //SqlDataReader dr_csr = com_csr.ExecuteReader();

                string VarDate = "07/31/2008";
                string Mh_Priod = "08/15/2008";
                foreach (DataRow dr_csr in dt_csr.Rows)
                {
                    if (dr_csr["Sales_Type"].ToString().Trim() == "INV")
                    {
                        Sales_Type = dr_csr["Sales_Type"].ToString().Trim();
                        CSR_SNo = long.Parse(dr_csr["csr_sno"].ToString());
                        Freight_Amount += Math.Round(decimal.Parse(dr_csr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        Total_DueCarrier += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);

                        Freight_Diff_Amount += Math.Round(decimal.Parse(dr_csr["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (FROM_DATE > DateTime.Parse(Mh_Priod))
                            {
                                IATA_Commission += 0;
                            }
                            else
                            {
                                IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (FROM_DATE > DateTime.Parse(VarDate))
                            {
                                IATA_Commission += 0;
                            }
                            else
                            {
                                IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            IATA_Commission += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                        }

                        Amount_Excluding_TDS += Math.Round(decimal.Parse(dr_csr["Amount_Excluding_TDS"].ToString()), MidpointRounding.AwayFromZero);

                        if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                        {

                            if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if ((FROM_DATE) > DateTime.Parse(VarDate))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                                }
                            }
                            else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
                                {
                                    TotTds -= 0;
                                    surCharge -= 0;
                                    EduChrg -= 0;
                                }
                                else
                                {
                                    TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                surCharge -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }

                        }
                        else
                        {
                            if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if ((FROM_DATE) > DateTime.Parse(VarDate))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                            {

                                if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
                                {
                                    TotTds += 0;
                                    surCharge += 0;
                                    EduChrg += 0;
                                }
                                else
                                {
                                    TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                    surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                    EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                                }
                            }
                            else
                            {
                                TotTds += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                                surCharge += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                                EduChrg += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                            }

                        }
                        LastTdsRate = decimal.Parse(dr_csr["tds"].ToString());
                        LastSurcharge = decimal.Parse(dr_csr["surcharge"].ToString());
                        LastEducation_Cess = decimal.Parse(dr_csr["Education_Cess"].ToString());


                        TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);

                        string amountPP = null;
                        string amountCC = null;
                        if (dr_csr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP = "0";
                            amountCC = dr_csr["Freight_Amount"].ToString();
                            TotFrAmountCC += Math.Round(decimal.Parse(amountCC), MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            amountPP = dr_csr["Freight_Amount"].ToString();
                            amountCC = "0";
                            TotFrAmount += Math.Round(decimal.Parse(amountPP), MidpointRounding.AwayFromZero);
                        }


                        TotTax += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {

                            if ((FROM_DATE) > DateTime.Parse(VarDate))
                            {
                                TotComm += 0;
                                TotDiscount += 0;
                                Agent_Expenses += 0;
                            }
                            else
                            {
                                TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {

                            if ((FROM_DATE) > DateTime.Parse(Mh_Priod))
                            {
                                TotComm += 0;
                                TotDiscount += 0;
                                Agent_Expenses += 0;
                            }
                            else
                            {
                                TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                                TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                                Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }

                        else
                        {
                            TotComm += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                            TotDiscount += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                            Agent_Expenses += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        }
                    }
                    else if (dr_csr["Sales_Type"].ToString().Trim() == "CRDR")
                    {
                        Sales_Type_CRDR = dr_csr["Sales_Type"].ToString().Trim();
                        CSR_SNo_CRDR = long.Parse(dr_csr["csr_sno"].ToString());
                        Freight_Amount_CRDR += Math.Round(decimal.Parse(dr_csr["Freight_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        Total_DueCarrier_CRDR += Math.Round(decimal.Parse(dr_csr["Total_DueCarrier"].ToString()), MidpointRounding.AwayFromZero);
                        TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        Agent_Expenses_CRDR += Math.Round(decimal.Parse(dr_csr["TotalDueAgent_Collect"].ToString()), MidpointRounding.AwayFromZero);
                        Freight_Diff_Amount_CRDR += Math.Round(decimal.Parse(dr_csr["Freight_Diff_Amount"].ToString()), MidpointRounding.AwayFromZero);


                        if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "232" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (FROM_DATE > DateTime.Parse(Mh_Priod))
                            {

                                IATA_Commission_CRDR += 0;
                            }
                            else
                            {
                                IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else if (dr_csr["AirwayBill_No"].ToString().Substring(0, 3).ToUpper() == "235" && dr_csr["DueCarrier_Type"].ToString() == "COLLECT")
                        {
                            if (FROM_DATE > DateTime.Parse(VarDate))
                            {
                                IATA_Commission_CRDR += 0;
                            }
                            else
                            {
                                IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                            }
                        }
                        else
                        {
                            IATA_Commission_CRDR += Math.Round(decimal.Parse(dr_csr["IATA_COMMISSION"].ToString()), MidpointRounding.AwayFromZero);
                        }
                        Amount_Excluding_TDS_CRDR += Math.Round(decimal.Parse(dr_csr["Amount_Excluding_TDS"].ToString()), MidpointRounding.AwayFromZero);

                        if (decimal.Parse(dr_csr["Freight_Amount"].ToString()) < 0)
                        {

                            TotTds_CRDR -= Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                            surCharge_CRDR -= Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                            EduChrg_CRDR -= Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);
                        }
                        else
                        {
                            TotTds_CRDR += Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString()));
                            surCharge_CRDR += Math.Round(decimal.Parse(dr_csr["only_surcharge"].ToString()), MidpointRounding.AwayFromZero);
                            EduChrg_CRDR += Math.Round((((Math.Ceiling(decimal.Parse(dr_csr["ONLY_TDS"].ToString())) + decimal.Parse(dr_csr["only_surcharge"].ToString())) * decimal.Parse(dr_csr["Education_Cess"].ToString())) / 100), MidpointRounding.AwayFromZero);

                        }
                        LastTdsRate_CRDR = decimal.Parse(dr_csr["tds"].ToString());
                        LastSurcharge_CRDR = decimal.Parse(dr_csr["surcharge"].ToString());
                        LastEducation_Cess_CRDR = decimal.Parse(dr_csr["Education_Cess"].ToString());
                        TDS_Amount_CRDR = Math.Round((TotTds_CRDR + surCharge_CRDR + EduChrg_CRDR), MidpointRounding.AwayFromZero);
                        string amountPP_CRDR = null;
                        string amountCC_CRDR = null;
                        if (dr_csr["Freight_type"].ToString() == "COLLECT")
                        {
                            amountPP_CRDR = "0";
                            amountCC_CRDR = dr_csr["Freight_Amount"].ToString();
                            TotFrAmountCC_CRDR += Math.Round(decimal.Parse(amountCC_CRDR), MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            amountPP_CRDR = dr_csr["Freight_Amount"].ToString();
                            amountCC_CRDR = "0";
                            TotFrAmount_CRDR += Math.Round(decimal.Parse(amountPP_CRDR), MidpointRounding.AwayFromZero);
                        }
                        TotTax_CRDR += Math.Round(decimal.Parse(dr_csr["Tax"].ToString()), MidpointRounding.AwayFromZero);
                        TotComm_CRDR += Math.Round(decimal.Parse(dr_csr["Commissionable_Amount"].ToString()), MidpointRounding.AwayFromZero);
                        TotDiscount_CRDR += Math.Round(decimal.Parse(dr_csr["Discount"].ToString()), MidpointRounding.AwayFromZero);
                    }
                }
                Total = Math.Round(((TotFrAmount + Total_DueCarrier + TotTax) - (Agent_Expenses + TotDiscount + TotComm)), MidpointRounding.AwayFromZero);
                Decimal Debit_Surcharge = 0;
                DataTable dt_Sur = dpw.GetAllFromQuery("SELECT Surcharge_Amount FROM Surcharge_DebitNote WHERE AGENT_ID=" + AGENT_ID + " AND AIRLINE_DETAIL_ID=" + dr.Rows[0]["Airline_Detail_ID"].ToString() + " AND (CSR_PERIOD>='" + FROM_DATE + "' AND CSR_PERIOD<='" + TO_DATE + "')");
                if (dt_Sur.Rows.Count > 0)
                {
                    Debit_Surcharge = Math.Round(Convert.ToDecimal(dt_Sur.Rows[0]["Surcharge_Amount"].ToString()), MidpointRounding.AwayFromZero);
                    EduChrg = Math.Round((((TotTds + surCharge + Debit_Surcharge) * LastEducation_Cess / 100)), MidpointRounding.AwayFromZero);
                    TDS_Amount = Math.Round((TotTds + surCharge + EduChrg), MidpointRounding.AwayFromZero);


                }
                GrandTotal = Math.Round((Total + TotTds + EduChrg + surCharge + Debit_Surcharge), MidpointRounding.AwayFromZero);
                Amount_Including_TDS = GrandTotal;

                if (Amount_Including_TDS < 0)
                {
                    Amount_Type = 24;
                }
                else
                {
                    Amount_Type = 23;
                }

                /************************/
                Total_CRDR = Math.Round(((TotFrAmount_CRDR + Total_DueCarrier_CRDR + TotTax_CRDR) - (Agent_Expenses_CRDR + TotDiscount_CRDR + TotComm_CRDR)), MidpointRounding.AwayFromZero);


                GrandTotal_CRDR = Math.Round((Total_CRDR + TotTds_CRDR + EduChrg_CRDR + surCharge_CRDR), MidpointRounding.AwayFromZero);
                Amount_Including_TDS_CRDR = GrandTotal_CRDR;
                if (Amount_Including_TDS_CRDR < 0)
                {
                    Amount_Type_CRDR = 24;
                }
                else
                {
                    Amount_Type_CRDR = 23;
                }


                SqlCommand strcom;
                SqlCommand durationIdcmd = new SqlCommand("SELECT CSR_Duration_ID FROM CSR_Duration WHERE CSR_Duration='" + CSR_Durationperiod + "' ", con, tr);
                int CSR_Duration_ID = Convert.ToInt32(durationIdcmd.ExecuteScalar());

                if (GrandTotal != 0)
                {
                    strcom = new SqlCommand("spGCCS_UpdateCSRDetail", con, tr);
                    strcom.CommandType = CommandType.StoredProcedure;
                    strcom.Parameters.AddWithValue("@COUNT", COUNT);
                    strcom.Parameters.AddWithValue("@AGENT_ID", Convert.ToInt64(AGENT_ID));
                    strcom.Parameters.AddWithValue("@Airline_Detail_ID", dr.Rows[0]["Airline_Detail_ID"].ToString());
                    strcom.Parameters.AddWithValue("@CSR_Duration_ID", CSR_Duration_ID);
                    strcom.Parameters.AddWithValue("@Sales_Type", "INV");
                    strcom.Parameters.AddWithValue("@CSR_SNo", CSR_SNo);
                    strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
                    strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
                    strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
                    strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
                    strcom.Parameters.AddWithValue("@Freight_Amount", Freight_Amount);
                    strcom.Parameters.AddWithValue("@Freight_Amount_CC", TotFrAmountCC);
                    strcom.Parameters.AddWithValue("@Freight_Amount_PP", TotFrAmount);
                    strcom.Parameters.AddWithValue("@Total_DueCarrier", Total_DueCarrier);
                    strcom.Parameters.AddWithValue("@Agent_Expenses", Agent_Expenses);
                    strcom.Parameters.AddWithValue("@Freight_Diff_Amount", Freight_Diff_Amount);
                    strcom.Parameters.AddWithValue("@IATA_Commission", IATA_Commission);
                    strcom.Parameters.AddWithValue("@Amount_Excluding_TDS", Total);
                    strcom.Parameters.AddWithValue("@TDS_Rate", LastTdsRate);
                    strcom.Parameters.AddWithValue("@Surcharge_Rate", LastSurcharge);
                    strcom.Parameters.AddWithValue("@Education_Cess_Rate", LastEducation_Cess);
                    strcom.Parameters.AddWithValue("@TDS_Amount", (Math.Ceiling(TDS_Amount) + Debit_Surcharge));
                    strcom.Parameters.AddWithValue("@Surcharge_Amount", (surCharge + Debit_Surcharge));
                    strcom.Parameters.AddWithValue("@Incentive_Amount", TotDiscount);
                    strcom.Parameters.AddWithValue("@Education_Cess_Amount", EduChrg);
                    strcom.Parameters.AddWithValue("@Amount_Including_TDS", Amount_Including_TDS);
                    strcom.Parameters.AddWithValue("@Amount_Type", Amount_Type);
                    strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
                    strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
                    strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
                    strcom.Parameters.AddWithValue("@Entered_On", Entered_On);
                    strcom.ExecuteNonQuery();

                }
                /************************************/
                if (GrandTotal_CRDR != 0)
                {

                    strcom = new SqlCommand("spGCCS_UpdateCSRDetail", con, tr);
                    strcom.CommandType = CommandType.StoredProcedure;
                    strcom.Parameters.AddWithValue("@COUNT", COUNT);
                    strcom.Parameters.AddWithValue("@AGENT_ID", AGENT_ID);
                    strcom.Parameters.AddWithValue("@Airline_Detail_ID", dr.Rows[0]["Airline_Detail_ID"].ToString());
                    strcom.Parameters.AddWithValue("@CSR_Duration_ID", CSR_Duration_ID);
                    strcom.Parameters.AddWithValue("@Sales_Type", "CRDR");
                    strcom.Parameters.AddWithValue("@CSR_SNo", CSR_SNo_CRDR);
                    strcom.Parameters.AddWithValue("@CSR_No", CSR_No);
                    strcom.Parameters.AddWithValue("@Agent_Code", Agent_Code);
                    strcom.Parameters.AddWithValue("@Agent_Name", Agent_Name);
                    strcom.Parameters.AddWithValue("@Agent_Address", Agent_Address);
                    strcom.Parameters.AddWithValue("@Freight_Amount", Freight_Amount_CRDR);
                    strcom.Parameters.AddWithValue("@Freight_Amount_CC", TotFrAmountCC_CRDR);
                    strcom.Parameters.AddWithValue("@Freight_Amount_PP", TotFrAmount_CRDR);
                    strcom.Parameters.AddWithValue("@Total_DueCarrier", Total_DueCarrier_CRDR);
                    strcom.Parameters.AddWithValue("@Agent_Expenses", Agent_Expenses_CRDR);
                    strcom.Parameters.AddWithValue("@Freight_Diff_Amount", Freight_Diff_Amount_CRDR);
                    strcom.Parameters.AddWithValue("@IATA_Commission", IATA_Commission_CRDR);
                    strcom.Parameters.AddWithValue("@Amount_Excluding_TDS", Total_CRDR);
                    strcom.Parameters.AddWithValue("@TDS_Rate", LastTdsRate_CRDR);
                    strcom.Parameters.AddWithValue("@Surcharge_Rate", LastSurcharge_CRDR);
                    strcom.Parameters.AddWithValue("@Education_Cess_Rate", LastEducation_Cess_CRDR);
                    strcom.Parameters.AddWithValue("@TDS_Amount", (Math.Ceiling(TDS_Amount_CRDR) + Debit_Surcharge));
                    strcom.Parameters.AddWithValue("@Surcharge_Amount", surCharge_CRDR);
                    strcom.Parameters.AddWithValue("@Incentive_Amount", TotDiscount_CRDR);
                    strcom.Parameters.AddWithValue("@Education_Cess_Amount", EduChrg_CRDR);
                    strcom.Parameters.AddWithValue("@Amount_Including_TDS", Amount_Including_TDS_CRDR);
                    strcom.Parameters.AddWithValue("@Amount_Type", Amount_Type_CRDR);
                    strcom.Parameters.AddWithValue("@CSR_From", CSR_From);
                    strcom.Parameters.AddWithValue("@CSR_To", CSR_To);
                    strcom.Parameters.AddWithValue("@Entered_By", Entered_By);
                    strcom.Parameters.AddWithValue("@Entered_On", Entered_On);
                    strcom.ExecuteNonQuery();
                }


                com_csr.Dispose();



            }


        }

        catch (SqlException sqe)
        {
            string err = sqe.ToString();
        }


    }
    #endregion

    //public void UpdateApproveStatus(SqlTransaction tr, SqlConnection con, string SalesID)
    //{
    //    string update;
    //    update = "update Sales set Approved_for_CSR=29 , Sales_type='CRDR' where Sales_ID=" + SalesID;
    //    SqlCommand com = new SqlCommand(update, con, tr);
    //    com.CommandType = CommandType.Text;
    //    com.ExecuteNonQuery();
    //}
    #endregion

    #region Insert_Sales_DrCr1

    public void Insert_Sales_DrCr1(SqlTransaction tr, SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    {

        string insert;

        insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,DueCarrier_Type,TotalDueAgent_Prepaid,TotalDueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,FSCRate,WSCRate,XRayRate,War_Surcharges,Fuel_Surcharges,Xray_Charges,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,GSAComm_Rate,Principle_Spot_Rate_Remarks,Other_DueCarrier,Other_Remarks,Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Remarks,TDS,Surcharge,Education_Cess,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,MSC_Charges,KE_Principle_Rate,KE_Principle_Spot_Rate,KE_Principle_Min_Status,KE_Principle_Amount,ETCharges) values(@Sales_ID,@Sales_type,@CSR_SNo,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@FSCRate,@WSCRate,@XRayRate,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Remarks,@TDS,@Surcharge,@Education_Cess,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@MSC_Charges,@KE_Principle_Rate,@KE_Principle_Spot_Rate,@KE_Principle_Min_Status,@KE_Principle_Amount,@ETCharges)";

        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "INV";
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());
       ////// com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["Booking_ID"]);
        //////com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = "1234";
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = 1234;
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
        DateTime CSR_Date = Convert.ToDateTime(dtOriginal.Rows[0]["CSR_Date"].ToString());
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = CSR_Date.ToShortDateString();//changed by Sudarshan sir
        DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
        string strOrgin = ddlOrigin.SelectedItem.Text.Trim();
        strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        //com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = ddlOrigin.SelectedValue.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();

        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"]);

        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Disbursement_Charges"].ToString());
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["AWB_Fees"].ToString());
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Valuation_Charge"].ToString());
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tax"].ToString());
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_houses"].ToString());
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_ACI_Fees"].ToString());
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Cartridge_Charges"].ToString());
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;

        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["TotalDueAgent_Prepaid"].ToString());
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["TotalDueAgent_Collect"].ToString());
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_DueCarrier"].ToString());
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Collect"].ToString());
        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["FSCRate"].ToString());
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["WSCRate"].ToString());
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["XRayRate"].ToString());
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["War_Surcharges"].ToString());
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Fuel_Surcharges"].ToString());
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Xray_Charges"].ToString());


        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Spot_Rate"].ToString());
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Commission"].ToString());
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Commodity_Incentive"].ToString());

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Freight_Amount"].ToString());

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Rate"].ToString());
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Amount"].ToString());



        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());
        com.Parameters.Add("@GSAComm_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["GSAComm_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Other_DueCarrier"].ToString());
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Other_Remarks"].ToString();

        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Currency"].ToString();
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CHGS_Code"].ToString();
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Declared_Carriage_Value"].ToString();
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Declared_Custom_Value"].ToString();
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Handling_Information"].ToString();
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Nature_and_Quantity"].ToString();
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();

        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["TDS"].ToString());
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Surcharge"].ToString());
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Education_Cess"].ToString());

        com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
        // com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;

        com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["MSC_Charges"].ToString());

        //================================ Updated On 2nd july 2012  rates for ke =============================
        com.Parameters.Add("@KE_Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@KE_Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 14;
        }

        com.Parameters.Add("@KE_Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["ETCharges"].ToString());
        //======================================================================================================
        com.ExecuteNonQuery();

    }
    #endregion

    #region Insert_Sales_DrCr2
    public void Insert_Sales_DrCr2(SqlTransaction tr, SqlConnection con, string SalesID, string HandoverID, DataTable dtOriginal)
    {
        string insert;

        insert = "insert into Sales_DrCr(Sales_ID,Sales_type,CSR_SNo,Flight_No,Flight_Open_ID,AirWayBill_No,AWB_Date,CSR_Date,Flight_Date,Stock_ID,Agent_ID,Special_Commodity_ID,Shipment_ID,Shipment_Name,City_ID,City_Code,Destination_ID,Destination_Code,Airline_Detail_ID,Disbursement_Charges,AWB_Fees,Valuation_Charge,Tax,No_of_houses,Total_ACI_Fees,Cartridge_Charges,DueCarrier_Type,TotalDueAgent_Prepaid,TotalDueAgent_Collect,Total_DueCarrier,Total_Prepaid,Total_Collect,War_Surcharges,Fuel_Surcharges,Xray_Charges,No_of_Packages,Gross_Weight,Volume_Weight,Charged_Weight,Spot_Rate,Commission,Special_Commodity_Incentive,Freight_Type,Tariff_Rate,Freight_Amount,Special_Rate,Special_Amount,Principle_Rate,Principle_Amount,Principle_Spot_Rate,GSAComm_Rate,Principle_Spot_Rate_Remarks,Other_DueCarrier,Other_Remarks,Currency,CHGS_Code,Declared_Carriage_Value,Declared_Custom_Value,Handling_Information,Nature_and_Quantity,Shipper_Name,Shipper_Address,Consignee_Name,Consignee_Address,Remarks,TDS,Surcharge,Education_Cess,CSR_No,Agent_Min_Status,Principle_Min_Status,Entered_By,Entered_On,MSC_Charges,KE_Principle_Rate,KE_Principle_Spot_Rate,KE_Principle_Min_Status,KE_Principle_Amount,ETCharges) values(@Sales_ID,@Sales_type,@CSR_SNo,@Flight_No,@Flight_Open_ID,@AirWayBill_No,@AWB_Date,@CSR_Date,@Flight_Date,@Stock_ID,@Agent_ID,@Special_Commodity_ID,@Shipment_ID,@Shipment_Name,@City_ID,@City_Code,@Destination_ID,@Destination_Code,@Airline_Detail_ID,@Disbursement_Charges,@AWB_Fees,@Valuation_Charge,@Tax,@No_of_houses,@Total_ACI_Fees,@Cartridge_Charges,@DueCarrier_Type,@TotalDueAgent_Prepaid,@TotalDueAgent_Collect,@Total_DueCarrier,@Total_Prepaid,@Total_Collect,@War_Surcharges,@Fuel_Surcharges,@Xray_Charges,@No_of_Packages,@Gross_Weight,@Volume_Weight,@Charged_Weight,@Spot_Rate,@Commission,@Special_Commodity_Incentive,@Freight_Type,@Tariff_Rate,@Freight_Amount,@Special_Rate,@Special_Amount,@Principle_Rate,@Principle_Amount,@Principle_Spot_Rate,@GSAComm_Rate,@Principle_Spot_Rate_Remarks,@Other_DueCarrier,@Other_Remarks,@Currency,@CHGS_Code,@Declared_Carriage_Value,@Declared_Custom_Value,@Handling_Information,@Nature_and_Quantity,@Shipper_Name,@Shipper_Address,@Consignee_Name,@Consignee_Address,@Remarks,@TDS,@Surcharge,@Education_Cess,@CSR_No,@Agent_Min_Status,@Principle_Min_Status,@Entered_By,@Entered_On,@MSC_Charges,@KE_Principle_Rate,@KE_Principle_Spot_Rate,@KE_Principle_Min_Status,@KE_Principle_Amount,@ETCharges)";


        SqlCommand com = new SqlCommand(insert, con, tr);
        com.CommandType = CommandType.Text;

        com.Parameters.Add("@Sales_ID", SqlDbType.BigInt).Value = SalesID;
        com.Parameters.Add("@Sales_type", SqlDbType.VarChar).Value = "CRDR";
        com.Parameters.Add("@CSR_SNo", SqlDbType.BigInt).Value = long.Parse(dtOriginal.Rows[0]["CSR_SNo"].ToString());
        //com.Parameters.Add("@Booking_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["Booking_ID"]);
        //com.Parameters.Add("@Handover_ID", SqlDbType.BigInt).Value = long.Parse(HandoverID);
        com.Parameters.Add("@Flight_No", SqlDbType.VarChar).Value = "1234";
        com.Parameters.Add("@Flight_Open_ID", SqlDbType.BigInt).Value = 1234;
        com.Parameters.Add("@AirWayBill_No", SqlDbType.VarChar).Value = ddlAwbNo.SelectedItem.Text.Trim();
        DateTime AWB_Date = Convert.ToDateTime(dtOriginal.Rows[0]["AWB_Date"].ToString());
        com.Parameters.Add("@AWB_Date", SqlDbType.DateTime).Value = AWB_Date.ToShortDateString();
        com.Parameters.Add("@CSR_Date", SqlDbType.DateTime).Value = FormatDateMM(txtCSRDate.Text);
        DateTime Flight_Date = Convert.ToDateTime(dtOriginal.Rows[0]["Flight_Date"].ToString());
        com.Parameters.Add("@Flight_Date", SqlDbType.DateTime).Value = Flight_Date.ToShortDateString();

        com.Parameters.Add("@Stock_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Stock_ID"].ToString());
        com.Parameters.Add("@Agent_ID", SqlDbType.BigInt).Value = long.Parse(ViewState["Agent_ID"].ToString());
        com.Parameters.Add("@Special_Commodity_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Special_Commodity_ID"].ToString();
        com.Parameters.Add("@Shipment_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipment_Name"].ToString();
        com.Parameters.Add("@Shipment_ID", SqlDbType.Int).Value = dtOriginal.Rows[0]["Shipment_ID"].ToString();
        string strOrgin = ddlOrigin.SelectedItem.Text.Trim();
        strOrgin = strOrgin.Substring(0, 3);
        com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = strOrgin;
        com.Parameters.Add("@City_ID", SqlDbType.Int).Value = int.Parse(ViewState["City_ID"].ToString());
        //com.Parameters.Add("@City_Code", SqlDbType.VarChar).Value = ddlOrigin.SelectedValue.Trim();
        com.Parameters.Add("@Destination_ID", SqlDbType.BigInt).Value = dtOriginal.Rows[0]["Destination_ID"].ToString();

        com.Parameters.Add("@Destination_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Destination_Code"].ToString();
        com.Parameters.Add("@Airline_Detail_ID", SqlDbType.BigInt).Value = Convert.ToInt64(ViewState["AirlineDetailID"]);

        com.Parameters.Add("@Disbursement_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Disbursement_Charges"].ToString());
        com.Parameters.Add("@AWB_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["AWB_Fees"].ToString());
        com.Parameters.Add("@Valuation_Charge", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Valuation_Charge"].ToString());
        com.Parameters.Add("@Tax", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tax"].ToString());
        com.Parameters.Add("@No_of_houses", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_houses"].ToString());
        com.Parameters.Add("@Total_ACI_Fees", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_ACI_Fees"].ToString());
        com.Parameters.Add("@Cartridge_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Cartridge_Charges"].ToString());
        com.Parameters.Add("@DueCarrier_Type", SqlDbType.VarChar).Value = rbDueFreight.SelectedValue;

        com.Parameters.Add("@TotalDueAgent_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["TotalDueAgent_Prepaid"].ToString());
        com.Parameters.Add("@TotalDueAgent_Collect", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["TotalDueAgent_Collect"].ToString());
        com.Parameters.Add("@Total_DueCarrier", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["Total_DueCarrier"].ToString());
        com.Parameters.Add("@Total_Prepaid", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Prepaid"].ToString());
        com.Parameters.Add("@Total_Collect", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Total_Collect"].ToString());
        com.Parameters.Add("@FSCRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["FSCRate"].ToString());
        com.Parameters.Add("@WSCRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["WSCRate"].ToString());
        com.Parameters.Add("@XRayRate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["XRayRate"].ToString());
        com.Parameters.Add("@War_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["War_Surcharges"].ToString());
        com.Parameters.Add("@Fuel_Surcharges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Fuel_Surcharges"].ToString());
        com.Parameters.Add("@Xray_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Xray_Charges"].ToString());

        com.Parameters.Add("@No_of_Packages", SqlDbType.Int).Value = int.Parse(dtOriginal.Rows[0]["No_of_Packages"].ToString());
        com.Parameters.Add("@Gross_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Gross_Weight"].ToString());
        com.Parameters.Add("@Volume_Weight", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Volume_Weight"].ToString());
        com.Parameters.Add("@Charged_Weight", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["Charged_Weight"].ToString());
        com.Parameters.Add("@Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Spot_Rate"].ToString());
        com.Parameters.Add("@Commission", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Commission"].ToString());
        com.Parameters.Add("@Special_Commodity_Incentive", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Commodity_Incentive"].ToString());

        com.Parameters.Add("@Freight_Type", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Freight_Type"].ToString();
        com.Parameters.Add("@Tariff_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Tariff_Rate"].ToString());
        com.Parameters.Add("@Freight_Amount", SqlDbType.Decimal).Value = -decimal.Parse(dtOriginal.Rows[0]["Freight_Amount"].ToString());

        com.Parameters.Add("@Special_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Rate"].ToString());
        com.Parameters.Add("@Special_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Special_Amount"].ToString());
        com.Parameters.Add("@Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Rate"].ToString());
        com.Parameters.Add("@Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Amount"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Principle_Spot_Rate"].ToString());
        com.Parameters.Add("@GSAComm_Rate", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["GSAComm_Rate"].ToString());
        com.Parameters.Add("@Principle_Spot_Rate_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Principle_Spot_Rate_Remarks"].ToString();
        com.Parameters.Add("@Other_DueCarrier", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Other_DueCarrier"].ToString());
        com.Parameters.Add("@Other_Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Other_Remarks"].ToString();
        com.Parameters.Add("@Currency", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Currency"].ToString();
        com.Parameters.Add("@CHGS_Code", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CHGS_Code"].ToString();
        com.Parameters.Add("@Declared_Carriage_Value", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Declared_Carriage_Value"].ToString();
        com.Parameters.Add("@Declared_Custom_Value", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Declared_Custom_Value"].ToString();
        com.Parameters.Add("@Handling_Information", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Handling_Information"].ToString();
        com.Parameters.Add("@Nature_and_Quantity", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Nature_and_Quantity"].ToString();
        com.Parameters.Add("@Shipper_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Name"].ToString();
        com.Parameters.Add("@Shipper_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Shipper_Address"].ToString();
        com.Parameters.Add("@Consignee_Name", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Name"].ToString();
        com.Parameters.Add("@Consignee_Address", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Consignee_Address"].ToString();
        com.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["Remarks"].ToString();
        com.Parameters.Add("@TDS", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["TDS"].ToString());
        com.Parameters.Add("@Surcharge", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Surcharge"].ToString());
        com.Parameters.Add("@Education_Cess", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["Education_Cess"].ToString());

        com.Parameters.Add("@CSR_No", SqlDbType.VarChar).Value = dtOriginal.Rows[0]["CSR_No"].ToString();
        // com.Parameters.Add("@Sales_Added_Date", SqlDbType.DateTime).Value = DateTime.Now;
        if (dtOriginal.Rows[0]["Agent_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Agent_Min_Status", SqlDbType.Int).Value = 14;
        }
        if (dtOriginal.Rows[0]["Principle_Min_Status"].ToString() == "13")
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@Principle_Min_Status", SqlDbType.Int).Value = 14;
        }
        // com.Parameters.Add("@Add_To_Deal", SqlDbType.Int).Value = 14;
        com.Parameters.Add("@Status", SqlDbType.Int).Value = 30;//Actual Entry
        com.Parameters.Add("@Entered_By", SqlDbType.VarChar).Value = Session["EMailID"].ToString();
        com.Parameters.Add("@Entered_On", SqlDbType.DateTime).Value = DateTime.Now;
        com.Parameters.Add("@MSC_Charges", SqlDbType.Decimal).Value = decimal.Parse(dtOriginal.Rows[0]["MSC_Charges"].ToString());

        //================================ Updated On 2nd july 2012  rates for ke =============================
        com.Parameters.Add("@KE_Principle_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPRate.Text);
        com.Parameters.Add("@KE_Principle_Spot_Rate", SqlDbType.Decimal).Value = decimal.Parse(txtPSpotRate.Text);
        if (ChkMinAirline.Checked == true)
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 13;
        }
        else
        {
            com.Parameters.Add("@KE_Principle_Min_Status", SqlDbType.Int).Value = 14;
        }

        com.Parameters.Add("@KE_Principle_Amount", SqlDbType.Decimal).Value = decimal.Parse(txtPAmount.Text);
        com.Parameters.Add("@ETCharges", SqlDbType.Decimal).Value = decimal.Parse(txtET.Text);
        //======================================================================================================
        com.ExecuteNonQuery();
    }
    #endregion

    protected void ddlGst_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (ddlGst.SelectedValue != "0")
        {
            txtGstNo.Text = ddlGst.SelectedItem.Text;
            txtGstAddr.Text = ddlGst.SelectedValue;
        }
        else if (txtGstNo.Text == "00" || txtGstNo.Text == "0")
        {
            txtGstNo.Text = ddlGstStateCode.SelectedValue;

            txtGstAddr.Text = ddlGstStateCode.SelectedItem.Text;
        }
        else
        {
            txtGstNo.Text = "";
            txtGstAddr.Text = ddlGst.SelectedItem.Text;
        }



    }
    protected void ddlGstStateCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlGstStateCode.SelectedValue != "0" && (txtGstNo.Text == "" && ddlGst.SelectedValue == "0"))
        {

            txtGstNo.Text = ddlGstStateCode.SelectedValue;

            txtGstAddr.Text = ddlGstStateCode.SelectedItem.Text;
        }
        if (txtGstNo.Text == "00" || txtGstNo.Text == "0")
        {
            txtGstNo.Text = ddlGstStateCode.SelectedValue;

            txtGstAddr.Text = ddlGstStateCode.SelectedItem.Text;
        }
        ////else if (ddlGstStateCode.SelectedValue != "0" && (txtGstNo.Text != "" && ddlGst.SelectedValue == "0"))
        ////{
        ////    txtGstNo.Text = ddlGstStateCode.SelectedValue;
        ////}

    }

    protected DataTable GetFlightDetails(string Flight_No, string Flight_Date)
    {
        con = new SqlConnection(strCon);
        com = new SqlCommand("GetFlightOpenId", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@Flight_Date", FormatDateDD(Flight_Date));
        com.Parameters.AddWithValue("@Flight_No", Flight_No);
        con.Open();
        DataTable dt = new DataTable();
        SqlDataAdapter sda = new SqlDataAdapter(com);
        sda.Fill(dt);
        con.Close();
        return dt;
    }
    private DataSet GetData(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["Gccs"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;
                sda.SelectCommand = cmd;
                using (DataSet ds = new DataSet())
                {
                    sda.Fill(ds);
                    return ds;
                }
            }
        }
    }
}
