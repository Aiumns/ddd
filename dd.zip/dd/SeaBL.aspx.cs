﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.IO;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Cfi.App.Pace.Business;
using System.Text;
using Cfi.App.CRM.Business;
using Cfi.App.Pace.WebUI;
using Cfi.SoftwareFactory.BaseBusiness;
using Cfi.SoftwareFactory.Common;
using Cfi.SoftwareFactory.Data;
using Cfi.SoftwareFactory.WebControls;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;
public partial class Cargo_SeaBL : BasePage
{
    public string strHead = string.Empty;
    string sType = string.Empty, pType = string.Empty, bType = string.Empty, strGoodsRecSnos = string.Empty,PFrom=string.Empty;
    int blSno = 0;
   // string rbtnBillToYes;
    BBookingConfirmed BC = new BBookingConfirmed();
    BSea bSea = new BSea();
    BImport bImport = new BImport();
    BAWB bAWB = new BAWB();
    BInvoice inv = new BInvoice();
    BReport bReport = new BReport();
    StringBuilder strData = new StringBuilder();
   // public string compbr = "1";
    protected void Page_Load(object sender, EventArgs e)
    {
       // compbr = Session["CompBrSno"].ToString();
       hdnCompBrSno.Value = Session["CompBrSno"].ToString();
        if (Session["UserID"] == null)
        {
            Response.Redirect("../Login.aspx");
        }        
        string url = string.Empty, decQString = string.Empty;
       
        if (Request.QueryString["seaType"] == null)
        {
            url = HttpContext.Current.Request.Url.AbsoluteUri;
            FormsAuthenticationTicket tk = FormsAuthentication.Decrypt(url.Split('?')[1]);
            decQString = tk.Name;
            sType = decQString.Split('&')[0].Split('=')[1].ToUpper();
            pType = decQString.Split('&')[1].Split('=')[1].ToUpper();
            bType = decQString.Split('&')[2].Split('=')[1].ToUpper();
            blSno = int.Parse(decQString.Split('&')[3].Split('=')[1].ToString());
            if (decQString.Split('&').Length > 4 && decQString.Split('&').Length < 6)
                hdnGoodsRecSnos.Value = decQString.Split('&')[4].Split('=')[1].ToString();
            else
                hdnBookingRedIntlSnos.Value = "0";
            if (decQString.Split('&').Length > 5)
                hdnBookingRedIntlSnos.Value = decQString.Split('&')[4].Split('=')[1].ToString();
            else
                hdnBookingRedIntlSnos.Value = "0";
            hdnSEAType.Value = sType;
            hdnBLType.Value = bType;
            hdnPageType.Value = pType;
            hdnSno.Value = blSno.ToString();           
        }
        else
        {
            sType = Request.QueryString["seaType"].ToUpper();
            pType = Request.QueryString["pageType"].ToUpper();
            bType = Request.QueryString["blType"].ToUpper();
            blSno = int.Parse(Request.QueryString["blSno"]);
            hdnSEAType.Value = sType;
            hdnBLType.Value = bType;
            hdnPageType.Value = pType;
            hdnSno.Value = blSno.ToString();
        }
        if (!IsPostBack)
        {// get Current STax Rate
            hdnCompBrSno.Value = Session["CompBrSno"].ToString();
           
            using (CommonBusiness comBusiness = new CommonBusiness())
            {
               // hdntest.Value = Session["CompBrSno"].ToString();
                DataTable dtStax = comBusiness.GetList("STaxRate", "TotalSTaxRate,DATEPART(YEAR,FromDate) AS Year,SBCessTax", string.Empty);
                foreach (DataRow drStax in dtStax.Rows)
                hdnStaxRates.Value = hdnStaxRates.Value + drStax["Year"] + "-" + drStax["TotalSTaxRate"] + ",";
                hdnSBCessTax.Value = dtStax.Rows[0]["SBCessTax"].ToString();
                // get previous page url
                ViewState["PreviousPage"] = Request.UrlReferrer != null ? (HttpContext.Current.Request.Url.AbsoluteUri.ToString() == Request.UrlReferrer.ToString() ? null : Request.UrlReferrer.ToString()) : null;
                ViewState["ContainerTableSno"] = ",";
                ViewState["SBTableSno"] = ",";
                ViewState["BLInvoiceTableSno"] = ",";
                ViewState["IncomeTableSno"] = ",";
                ViewState["ExpenseTableSno"] = ",";
                ltrlData.Text = getInitialData(sType, pType, bType, blSno);
                if (blSno != 0)
                {
                    DataTable dtGoodsRecSnos = comBusiness.GetList("sea_goods_recd", "goodsrecdid", "seaBLSNo='" + blSno + "'");
                    if (dtGoodsRecSnos.Rows.Count > 0)
                    {
                        foreach (DataRow drGoodsRecSno in dtGoodsRecSnos.Rows)
                            hdnGoodsRecSnos.Value = hdnGoodsRecSnos.Value + drGoodsRecSno["goodsrecdid"].ToString() + ",";
                    }                
                   
                        //DataTable dtBookingRedIntl = comBusiness.GetList("SeaBl_RedIntlBooking", "Sno", "seaBLSNo='" + blSno + "'");
                        //if (dtBookingRedIntl.Rows.Count > 0)
                        //{
                        //    foreach (DataRow drBookingRedIntl in dtBookingRedIntl.Rows)
                        //        hdnBookingRedIntlSnos.Value = hdnBookingRedIntlSnos.Value + drBookingRedIntl["Sno"].ToString() + ",";
                        //}
                        getDataForUpdate(blSno, bType);
                   
                }
                else
                {
                    hdnOldBill.Value = "N";
                    ViewState["OldCustBrSno"] = "0";
                    hdnOldIncomeAmt.Value = "0";
                }
            }
        }
        

    }
    // Load Page design 
    protected string getInitialData(string seaType, string pageType, string blType, int seaBLSno)
    {
        hdnCompBrSno.Value = Session["CompBrSno"].ToString();
        strHead = "SEA " + seaType.ToUpper() + " " + blType + "BL " + (bType.ToUpper() == "M" ? "[JOB]" : "[SUB JOB]");
        strData.Append("<table border='1' class='formTable'><tr style='color:red'><td colspan='4'><b> * Fields are mandatory</b>" + (Session["CompBrType"].ToString().ToUpper() == "PNP" ? "<div style='float:right'><input type='checkbox' id='cboxBaseCompany' name='cboxBaseCompany' checked='checked'/>Copy To Base Company</div>" : string.Empty) + "</td></tr>");
        // get jobnobycompany, company, city for job no.
        hdnJobNo.Value = hdnPageType.Value == "CREATE" ? bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), seaType, string.Empty).Tables[0].Rows[0][0].ToString() : string.Empty;
        // job type and job no
        strData.Append("<tr><td><b>Job Type<span style='color:red'>*</span></b></td><td><select id='ddlJobType' name='ddlJobType' onchange=\"getJobNo('" + blType + "','/" + seaType.Substring(0, 1) + "/');\"><option value='SELECT'>SELECT</option><option value='LCL'>LCL</option><option value='FCL'>FCL</option><option value='GEN'>GENERAL</option><option value='CAR'>CARAVEL</option> </select><select id='ddlJobSubType' name='ddlJobSubType'><option value='CONSOLE'>CONSOLE</option><option value='COLOAD'>COLOAD</option><option value='FCL'>FCL</option> </select></td><td><b>Job No</td><td><label id='lblJobNo' name='lblJobNo'>" + hdnJobNo.Value + "</label></td></tr>");
        // sub job allowed and job status
        strData.Append("<tr><td><b>Sub Job Allowed</b></td><td><select id='ddlSubJob' name='ddlSubJob' " + (blType == "H" ? "disabled='disabled'" : string.Empty) + " onchange=\"subJobMandatory();\"><option value='Y'>YES</option><option value='N' " + (blType == "H" ? "selected='selected'" : string.Empty) + ">NO</option></select></td><td><b>Job Status</b></td><td><select id='ddlJobStatus' name='ddlJobStatus'><option value='OPEN'>OPEN</option><option value='CLOSED'>CLOSED</option><option value='CANCELLED'>CANCELLED</option><option value='HELD'>HELD</option><option value='LOCKED'>LOCKED</option><option value='SEMI LOCKED'>SEMI LOCKED</option></select></td></tr>");
        // MBL and HBL no
        strData.Append("<tr><td><b>MBL<span style='color:red'>*</span></b></td><td><input style='width:145px;' type='text' id='txtMBLNo' name='txtMBLNo' value='" + hdnJobNo.Value.Replace("/0",string.Empty) + "'/></td><td><b>HBL" + (blType == "H" ? "<span style='color:red'>*</span>" : string.Empty) + "</b></td><td><input style='width:145px;' type='text' id='txtHBLNo' name='txtHBLNo'/></td></tr>");
        
        // BL Date
        strData.Append("<tr><td><b>"+blType+"BL Date<span style='color:red'>*</span></b></td><td><input style='width:145px;' type='text' id='txtBLDate' name='txtBLDate' readonly='readonly' />");
        if (blType == "M" || hdnPageType.Value == "CREATE")
        {
            strData.Append("<a href='javascript:void(0);' id='lnkBLDate'  onClick=\"setYears(1947, " + (DateTime.Now.Year) + ");showCalender(this, 'txtBLDate');\"> <img  src='../Images/calender.png' id='imgBLDate'></a>");
            // Calender
            strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        }
        // Vol Wt
        strData.Append("</td><td><b><div style='float:left'>Volume Weight(CBM)</div><div style='float:left'><span id='spanVolWt' style='color:red'>*</span></div></b></td><td><div style='float:left'><input type='text' style='width:145px;text-align:right' id='txtVolWt' name='txtVolWt' value='0.000'/></div>" + (blType == "M" ? "<div style='float:left'><b>Tue's</b><input type='text' style='width:145px;text-align:right' id='txtTue' name='txtTue' value='0'/></div>" : string.Empty) + "</td></tr>");
        // Net Wt and Gr Wt
        strData.Append("<tr><td><b><div style='float:left'>Net Weight</div><div style='float:left'><span id='spanNetWt' style='color:red'>*</span></div></b></td><td><input type='text' style='width:145px;text-align:right' id='txtNetWt' name='txtNetWt' value='0.000' onkeyup='blockChar(this.id);'/></td><td><b><div style='float:left'>Gross Weight</div><div style='float:left'><span id='spanGrossWt' style='color:red'>*</span></div></b></td><td><div style='float:left'><input type='text' style='width:145px;text-align:right' id='txtGrossWt' name='txtGrossWt' value='0.000'/></div><div style='float:left'><b>Billing CBM</b><input type='text' style='width:145px;text-align:right' id='txtBillingCBM' name='txtBillingCBM' value='0'/></div></td></tr>");
        // Freight and THC/IHC
        strData.Append("<tr><td><b>Ocean Freight<span style='color:red'>*</span></b></td><td><select id='ddlFreight' name='ddlFreight'><option value='P'>PRE-PAID</option><option value='C'>COLLECT</option></select></td><td><b><div style='float:left'><input type='radio' name='rbtnTHCIHC' id='rbtnTHC' value='THC' />THC<input type='radio' name='rbtnTHCIHC' id='rbtnIHC' value='IHC' checked='checked'/>IHC </div></td><td><select id='ddlTHCIHC' name='ddlTHCIHC'><option value='P'>PRE-PAID</option><option value='C'>COLLECT</option></select></td></tr>");
        // Packages and ETA
        strData.Append("<tr><td><b><div style='float:left'>Packages</div><div style='float:left'><span id='spanPackages' style='color:red'>*</span></div></b></td><td><input type='text' style='width:145px;text-align:right' id='txtPackages' name='txtPackages' value='0' onkeypress='getContainerNosData();' onblur='getContainerNosData();'/></td><td><b>ETA</b></td><td><input type='text' style='width:145px;' id='txtETADate' name='txtETADate' readonly='readonly'/><a href='javascript:void(0);' id='lnkETADate'  onClick=\"setYears(1947, " + (DateTime.Now.Year) + ");showCalender(this, 'txtETADate');\"> <img  src='../Images/calender.png' id='imgETADate'></a>");
        // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        
        // Shipping Line and ETD
        strData.Append("</td></tr><tr><td><b>Shipping Line</b></td><td><input type='text' style='width:300px;' id='txtShippingLine' name='txtShippingLine'/><input type='hidden' id='hdnShippingLine' name='hdnShippingLine'/></td><td><b>ETD</b></td><td><input type='text' style='width:145px;' id='txtETDDate' name='txtETDDate' readonly='readonly'/><a href='javascript:void(0);' id='lnkETDDate'  onClick=\"setYears(1947, " + (DateTime.Now.Year) + ");showCalender(this, 'txtETDDate');\"> <img  src='../Images/calender.png' id='imgETDDate'></a>");
        // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        // Loading and Discharge port
        strData.Append("</td></tr><tr><td><b>Place of Acceptance<span style='color:red'>*</span></b></td><td><input type='text' style='width:145px;' id='txtAcceptance' name='txtAcceptance'/><input type='hidden' id='hdnAcceptance' name='hdnAcceptance'/></td><td><b>Loading Port<span style='color:red'>*</span></b></td><td><input type='text' style='width:145px;' id='txtLoadingPort' name='txtLoadingPort'/><input type='hidden' id='hdnLoadingPort' name='hdnLoadingPort'/></td></tr>");
        // Place of acceptance and delivery
        strData.Append("<tr><td><b>Discharge Port<span style='color:red'>*</span></b></td><td><input type='text' style='width:145px;' id='txtDischargePort' name='txtDischargePort'/><input type='hidden' id='hdnDischargePort' name='hdnDischargePort'/></td><td><b>Place of Delivery<span style='color:red'>*</span></b></td><td><input type='text' style='width:145px;' id='txtDeliveryPlace' name='txtDeliveryPlace'/><input type='hidden' id='hdnDeliveryPlace' name='hdnDeliveryPlace'/></td></tr>");
        // Vessel and Voyage
        strData.Append("<tr><td><b>Vessel</b></td><td><input type='text' style='width:145px;' id='txtVessel' name='txtVessel'/></td><td><b>Voyage</b></td><td><input type='text' style='width:145px;' id='txtVoyage' name='txtVoyage'/></td></tr>");
        // Bill To and Rotation
        strData.Append("<tr><td><b><div style='float:left'>Bill <input type='radio' name='rbtnBillTo' id='rbtnBillToYes' value='Y' checked='checked' onclick=\"doReadOnlyBillTo();\"/>Y<input type='radio' name='rbtnBillTo' id='rbtnBillToNo' value='N' onclick=\"doReadOnlyBillTo();\"/>N<input type='hidden' id='hdnRbtnBillTo' name='hdnRbtnBillTo' value='0'/><input type='hidden' id='hdnRbtnStatus' name='hdnRbtnStatus' value='True'/> To</div><div style='float:left'><span id='spanBillTo' style='color:red'>*</span></div></b></td><td><div style='float:left'><input type='text' style='width:300px;' id='txtBillTo' name='txtBillTo' onblur=\"return Salesdata();\" /><input type='hidden' id='hdnBillToSno' name='hdnBillToSno' value='0'/></div><div id='divCrLimit' style='float:left'>Avl. Cr. Limit :<img id='imgRupee' src='../Images/India_Rupee_Symbol_Transparent.gif' style='height:14px;width:10px'/> <label id='lblCrLimit' ></label><input type='hidden' id='hdnCrLimit' name='hdnCrLimit' value='0'/></div></td><td><b>Rotation No</b></td><td><input type='text' style='width:145px;text-align:right' id='txtRotationNo' name='txtRotationNo'  value='1'/></td></tr>");
        // Shipper and Consignee Name
        strData.Append("<tr><td><b>Shipper</b></td><td><input type='text' style='width:300px;' id='txtShipper' name='txtShipper'/><input type='hidden' id='hdnShipperSno' name='hdnShipperSno' value='0'/></td><td><b>Consignee</b></td><td><input type='text' style='width:300px;' id='txtConsignee' name='txtConsignee'/><input type='hidden' id='hdnConsigneeSno' name='hdnConsigneeSno' value='0'/></td></tr>");
        // Shipper and Consignee Address
        strData.Append("<tr><td><b>Shipper Address</b></td><td valign='top'><textarea style='width:300px;height:70px;font-family:arial;font-size:12px;vertical-align:text-top' type='text' id='txtShipperAddress' name='txtShipperAddress' ></textarea></td><td><b>Consignee Address</b></td><td valign='top'><textarea style='width:300px;height:70px;font-family:arial;font-size:12px;vertical-align:text-top' type='text' id='txtConsigneeAddress' name='txtConsigneeAddress' ></textarea></td></tr>");
        // Shipper and Consignee Email
        strData.Append("<tr><td><b>Shipper Email</b></td><td><input type='text' style='width:300px;' id='txtShipperEmail' name='txtShipperEmail'/></td><td><b>Consignee Email</b></td><td><input type='text' style='width:300px;' id='txtConsigneeEmail' name='txtConsigneeEmail'/></td></tr>");
        // Shipper and Consignee Phone
        strData.Append("<tr><td><b>Shipper Phone</b></td><td><input type='text' style='width:145px;' id='txtShipperPhone' name='txtShipperPhone'/></td><td><b>Consignee Phone</b></td><td><input type='text' style='width:145px;' id='txtConsigneePhone' name='txtConsigneePhone'/></td></tr>");
        // Notify1 and Delivery Name
        strData.Append("<tr><td><b>Notify1</b></td><td><input type='text' style='width:300px;' id='txtNotify1' name='txtNotify1'/><input type='hidden' id='hdnNotify1Sno' name='hdnNotify1Sno' value='0'/></td><td><b>Delivery Agent</b></td><td><input type='text' style='width:300px;' id='txtDelivery' name='txtDelivery'/><input type='hidden' id='hdnDeliverySno' name='hdnDeliverySno' value='0'/></td></tr>");
        // Notify1 and Delivery Address
        strData.Append("<tr><td><b>Notify1 Address</b></td><td valign='top'><textarea style='width:300px;height:70px;font-family:arial;font-size:12px;vertical-align:text-top' type='text' id='txtNotify1Address' name='txtNotify1Address' ></textarea></td><td><b>Delivery Address</b></td><td valign='top'><textarea style='width:300px;height:70px;font-family:arial;font-size:12px;vertical-align:text-top' type='text' id='txtDeliveryAddress' name='txtDeliveryAddress' ></textarea></td></tr>");
        // Notify1 and Delivery Email
        strData.Append("<tr><td><b>Notify1 Email</b></td><td><input type='text' style='width:300px;' id='txtNotify1Email' name='txtNotify1Email'/></td><td><b>Delivery Email</b></td><td><input type='text' style='width:300px;' id='txtDeliveryEmail' name='txtDeliveryEmail'/></td></tr>");
        // Notify1 and Delivery Phone
        strData.Append("<tr><td><b>Notify1 Phone</b></td><td><input type='text' style='width:145px;' id='txtNotify1Phone' name='txtNotify1Phone'/></td><td><b>Delivery Phone</b></td><td><input type='text' style='width:145px;' id='txtDeliveryPhone' name='txtDeliveryPhone'/></td></tr>");
        // Notify2 and Notify3 Name
        strData.Append("<tr><td><b>Notify2</b></td><td><input type='text' style='width:300px;' id='txtNotify2' name='txtNotify2'/><input type='hidden' id='hdnNotify2Sno' name='hdnNotify2Sno'  value='0'/></td><td><b>Notify3</b></td><td><input type='text' style='width:300px;' id='txtNotify3' name='txtNotify3'/><input type='hidden' id='hdnNotify3Sno' name='hdnNotify3Sno' value='0'/></td></tr>");
        // Notify2 and Notify3 Address
        strData.Append("<tr><td><b>Notify2 Address</b></td><td valign='top'><textarea style='width:300px;height:70px;font-family:arial;font-size:12px;vertical-align:text-top' type='text' id='txtNotify2Address' name='txtNotify2Address' ></textarea></td><td><b>Notify3 Address</b></td><td valign='top'><textarea style='width:300px;height:70px;font-family:arial;font-size:12px;vertical-align:text-top' type='text' id='txtNotify3Address' name='txtNotify3Address' ></textarea></td></tr>");
        // Notify2 and Notify3 Email
        strData.Append("<tr><td><b>Notify2 Email</b></td><td><input type='text' style='width:300px;' id='txtNotify2Email' name='txtNotify2Email'/></td><td><b>Notify3 Email</b></td><td><input type='text' style='width:300px;' id='txtNotify3Email' name='txtNotify3Email'/></td></tr>");
        // Notify2 and Notify3 Phone
        strData.Append("<tr><td><b>Notify2 Phone</b></td><td><input type='text' style='width:145px;' id='txtNotify2Phone' name='txtNotify2Phone'/></td><td><b>Notify3 Phone</b></td><td><input type='text' style='width:145px;' id='txtNotify3Phone' name='txtNotify3Phone'/></td></tr>");
        // Destination and Forwarding Agent
        strData.Append("<tr><td><b>Destination Agent</b></td><td><input type='text' style='width:300px;' id='txtDestAgent' name='txtDestAgent'/><input type='hidden' id='hdnDestAgentSno' name='hdnDestAgentSno' value='0'/></td><td><b>Forwarding Agent</b></td><td><input type='text' style='width:300px;' id='txtForwAgent' name='txtForwAgent'/><input type='hidden' id='hdnForwAgentSno' name='hdnForwAgentSno' value='0'/></td></tr>");
        // Local Agent and Sales Person
        strData.Append("<tr><td><b>Local Agent</b></td><td><input type='text' style='width:300px;' id='txtLocalAgent' name='txtLocalAgent'/><input type='hidden' id='hdnLocalAgentSno' name='hdnLocalAgentSno' value='0'/></td><td><b>Sales Person<span style='color:red'>*</span></b></td><td><select id='ddlSalesPerson' name='ddlSalesPerson' style='width:200px'>");
         // Fill Sales Person
        BC.CompBrSNo = int.Parse(Session["CompBrSno"].ToString());
        SqlDataReader drSales = BC.getSalesPerson();
       strData.Append("<option value='SELECT'>SELECT</option>");
       while (drSales.Read())
       {
           strData.Append("<option value='" + drSales["DisplayName"].ToString().ToUpper() + "'>" + drSales["DisplayName"].ToString().ToUpper() + "</option>");
       }
       drSales.Close();
        strData.Append("</select></td></tr>");
        // Business Type and Network Group
        strData.Append("<tr><td><b>Business Type<span style='color:red'>*</span></b></td><td><select id='ddlBusinessType' name='ddlBusinessType' style='width:150px'><option value='OWN SELLING'>OWN SELLING</option><option value='NOMINATION'>NOMINATION</option></select></td><td><b>Network Group<span style='color:red'>*</span></b></td><td><select id='ddlNetworkGroup' name='ddlNetworkGroup' style='width:150px'>");
        // fill Network Name
        SqlDataReader drNetwork = bAWB.getNetworkName();
        strData.Append("<option value='SELECT'>SELECT</option>");
        while (drNetwork.Read())
        {
            strData.Append("<option value='" + drNetwork["groupname"] + "'>" + drNetwork["groupname"] + "</option>");
        }
        drNetwork.Close();
        strData.Append("</select></td></tr>");
        // Actual Customer and Overseas Agent
        strData.Append("<tr><td><b>Actual Customer<span style='color:red'>*</span></b></td><td><input style='width:300px;' type='text' id='txtActualCustomer' name='txtActualCustomer'/><input type='hidden' id='hdnActCustSno' name='hdnActCustSno' value='0'/></td><td><b>Overseas Agent<span style='color:red'>*</span></b></td><td><input style='width:300px;' type='text' id='txtOverseasAgent' name='txtOverseasAgent'/><input type='hidden' id='hdnOverseasAgentSno' name='hdnOverseasAgentSno' value='0'/></td></tr>");
        // Container No and Container Type
        strData.Append("<tr><td><b>Container Type<span style='color:red'>*</span></b></td><td><div id='divexhibitionSelect' name='divexhibitionSelect' style='float:left; padding: 5px 0px 0px 0px ;Width:155px'><select id='ddlContainerType' name='ddlContainerType' style='width:150px' onchange=\"return ExhibitionDet();\">");
        // Fill Product
        DataSet dsContainer = bSea.getConatainer();
        strData.Append("<option value='SELECT'>SELECT</option>");
        if (dsContainer.Tables[0].Rows.Count > 0)
        {
            foreach (DataRow drContainer in dsContainer.Tables[0].Rows)
            {
                strData.Append("<option value=\"" + drContainer["cont_type"].ToString() + "\">" + drContainer["cont_type"].ToString() + "</option>");
            }
        }
        
        strData.Append("</select></div></td><td colspan='2'><div id='divexhibition' name='divexhibition' style='float:left; display: none; padding: 0px 0px 0px 0px; width:100%'><table width='100%' border='1' cellspacing='0px'><td style='width:31%'><b>Fair Name</b></td><td> <select id='ddlexhibitionlist' name='ddlexhibitionlist' style='width:150px'>");
        // Fill exhibition detail
        DataSet dsexhibition = BC.GetExhibitionDet(Convert.ToInt32(Session["CompBrSno"].ToString()));
        for (int exhibition = 0; exhibition < dsexhibition.Tables[0].Rows.Count; exhibition++)
        {
            strData.Append("<option value='" + dsexhibition.Tables[0].Rows[exhibition]["SNo"].ToString() + "'>" + dsexhibition.Tables[0].Rows[exhibition]["Name"].ToString() + "</option>");
        }
        strData.Append("</select><input type='hidden' id='hdnExhibitionID' name='hdnExhibitionID'  /></td></tr></table></div><div id='divProductOther' style='float:left;display: none;padding: 0px 0px 0px 0px; width:100%'><table width='100%' border='1' cellspacing='0px'><td style='width:31%'><b>Other Type</b></td><td><select  id='ddlProductOther' name='ddlProductOther' style='width:150px'>");
        // Fill Product Other
        SqlDataReader drProductsOther = inv.getProductOtherType(hdnType.Value.Contains("OCEAN") ? "SEA" : "AIR");
        while (drProductsOther.Read())
            strData.Append("<option value=\"" + drProductsOther["OtherType"].ToString() + "\">" + drProductsOther["OtherType"].ToString() + "</option>");
        strData.Append("</select></td></tr></table></div></td></tr>");
        // Pre Carriage By and Commodity
        strData.Append("<tr><td><b>Pre Carriage By</b></td><td><input type='text' style='width:145px;' id='txtPreCarriageBy' name='txtPreCarriageBy'/></td><td><b>Commodity<span style='color:red'>*</span></b></td><td><input type='text' style='width:145px;' id='txtCommodity' name='txtCommodity'/></td></tr>");
        
        // Goods Receive and Custom Clearance date
        strData.Append("<tr><td><b>Goods Rec. Date</b></td><td><input style='width:145px;' type='text' id='txtGoodsRecDate' name='txtGoodsRecDate' readonly='readonly' /><a href='javascript:void(0);' id='lnkGoodsRecDate'  onClick=\"setYears(1947, " + (DateTime.Now.Year) + ");showCalender(this, 'txtGoodsRecDate');\"> <img  src='../Images/calender.png' id='imgGoodsRecDate'></a>");
         // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        strData.Append("</td><td><b>Custom Cl. Date</b></td><td><input style='width:145px;' type='text' id='txtCustomClDate' name='txtCustomClDate' readonly='readonly' /><a href='javascript:void(0);' id='lnkCustomClDate'  onClick=\"setYears(1947, " + (DateTime.Now.Year) + ");showCalender(this, 'txtCustomClDate');\"> <img  src='../Images/calender.png' id='imgCustomClDate'></a>");
        // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        strData.Append("</td></tr>");
        // container no l/seal no
        strData.Append("<tr><td colspan='4'>");
        ////////////////////////////CONATINER DETAIL///////////////////////////////////
        strData.Append("<div id='divContainerDetail' style='width:100%'><fieldset><legend>CONTAINER DETAILS</legend><input type='hidden' id='hdnContainerRows' name='hdnContainerRows' value='0'/><table id='tblContainerDetail' class='formTable' border='1' cellspacing='0px'>");
        strData.Append("<tr style='background-color:#0055E5;font-size:10px;color:White'><td></td><td><b>Container No</b></td><td><b>Container Type</b></td><td><b>L/Seal No</b></td><td><b>Packages</b></td><td><b>Net Weight</b></td><td><b>Gross Weight</b></td><td><b>Volume Weight(CBM)</b></td><td></td></tr>");
        strData.Append("<tr id='trContainerFooterRow'><td></td><td><input type='text' style='width:150px;' id='txtContainerNo' name='txtContainerNo' onblur=\"return checkContainerNo();\"  onkeydown=\"return checkContainerNoFormat(event.keyCode, this.value);\"  /></td><td><select id='ddlContType' name='ddlContType' style='width:150px'>");
        // Fill Product  
        strData.Append("<option value='SELECT'>SELECT</option>");
        if (dsContainer.Tables[0].Rows.Count > 0)
        {
            foreach (DataRow drContainer in dsContainer.Tables[0].Rows)
                strData.Append("<option value=\"" + drContainer["cont_type"].ToString() + "\">" + drContainer["cont_type"].ToString() + "</option>");
        }

        strData.Append("</select></td><td><input type='text' style='width:145px;' id='txtLSealNo' name='txtLSealNo'/></td><td><input type='text' style='width:145px;text-align:right' id='txtContainerPkgs' name='txtContainerPkgs' value='0' onkeyup='blockChar(this.id);'/></td><td><input type='text' style='width:145px;text-align:right' id='txtContainerNetWt' name='txtContainerNetWt' value='0.000' onkeyup='blockChar(this.id);'/></td><td><input type='text' style='width:145px;text-align:right' id='txtContainerGrWt' name='txtContainerGrWt' value='0.000' onkeyup='blockChar(this.id);'/></td><td><input type='text' style='width:145px;text-align:right' id='txtContainerVolWt' name='txtContainerVolWt' value='0.00000' onkeyup='blockChar(this.id);'/></td><td><b><input type='button' id='btnAddContainerDetail' value='Add' onclick=\"addContainerDataRow('tblContainerDetail')\" /></b></td></tr>");
        strData.Append("</table></fieldset></div></td></tr>");
        
        // Shipping Bill No and Date
        strData.Append("<tr><td colspan='2'>");
        ////////////////////////////SHIPPING BILLS DETAIL///////////////////////////////////
        strData.Append("<div id='divSBDetail' style='width:100%'><fieldset><legend>SHIPPING BILLS DETAILS</legend><input type='hidden' id='hdnSBRows' name='hdnSBRows' value='0'/><table id='tblSBDetail' class='formTable' border='1' cellspacing='0px'>");
        strData.Append("<tr style='background-color:#0055E5;font-size:10px;color:White'><td></td><td><b>Shipping Bill No</b></td><td><b>Shipping Bill Date</b></td><td></td></tr>");
        strData.Append("<tr id='trSBDetailFooterRow'><td></td><td><input type='text' style='width:145px;' id='txtSBNo' name='txtSBNo' onblur=\"return checkSBNo();\"/></td><td><input style='width:145px;' type='text' id='txtSBDate' name='txtSBDate' readonly='readonly'/><a href='javascript:void(0);' id='lnkSBDate'  onClick=\"setYears(1947, " + (DateTime.Now.Year) + ");showCalender(this, 'txtSBDate');\"> <img  src='../Images/calender.png' id='imgSBDate'></a>");
        // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        strData.Append("</td><td><b><input type='button' value='Add' id='btnAddSBNo' onclick=\"addSBDataRow('tblSBDetail')\" /></b></td></tr>");
        strData.Append("</table></fieldset></div></td>");
        // Invoice No and Date
        strData.Append("<td colspan='2'>");
        ////////////////////////////INVOICE DETAIL///////////////////////////////////
        strData.Append("<div id='divBLInvoiceDetail' style='width:100%'><fieldset><legend>BL INVOICE DETAILS</legend><input type='hidden' id='hdnBLInvoiceRows' name='hdnBLInvoiceRows' value='0'/><table id='tblBLInvoiceDetail' class='formTable' border='1' cellspacing='0px'>");
        strData.Append("<tr style='background-color:#0055E5;font-size:10px;color:White'><td></td><td><b>Invoice No</b></td><td><b>Invoice Date</b></td><td></td></tr>");
        strData.Append("<tr id='trBLInvoiceDetailFooterRow'><td></td><td><input type='text' style='width:145px;' id='txtInvoiceNo' name='txtInvoiceNo' onblur=\"return checkBLInvoiceNo();\"/></td><td><input style='width:145px;' type='text' id='txtInvoiceDate' name='txtInvoiceDate' readonly='readonly'/><a href='javascript:void(0);' id='lnkInvoiceDate'  onClick=\"setYears(1947, " + (DateTime.Now.Year) + ");showCalender(this, 'txtInvoiceDate');\"> <img  src='../Images/calender.png' id='imgInvoiceDate'></a>");
        // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        strData.Append("</td><td><b><input type='button' value='Add' id='btnAddInvoiceDetail' onclick=\"addBLInvoiceDataRow('tblBLInvoiceDetail')\" /></b></td></tr>");
        strData.Append("</table></fieldset></div></td></tr>");
        // c seal no
        strData.Append("<tr><td><b>C/Seal No</b></td><td colspan='3'><input type='text' style='width:50%;' id='txtCSealNo' name='txtCSealNo'/> Enter C/Seal numbers with ',' separated.</td></tr>");
        // IEC No and HS Code
        strData.Append("<tr><td><b>IEC No</b></td><td><input type='text' style='width:145px;' id='txtIECNo' name='txtIECNo' onkeypress='getPackageDescription();' onblur='getPackageDescription();'/></td><td><b>HS Code</b></td><td><input type='text' style='width:145px;' id='txtHSCode' name='txtHSCode' onkeypress='getPackageDescription();' onblur='getPackageDescription();'/></td></tr>");
        //// L/Seal No and C/Seal No
        //strData.Append("<tr><td><b>L/Seal No</b></td><td><input type='text' style='width:145px;' id='txtLSealNo' name='txtLSealNo' onkeypress='getPackageDescription();' onblur='getPackageDescription();'/></td></tr>");
        // Containing
        strData.Append("<tr><td><b>Containing</b></td><td colspan='3'><input type='text' style='width:98%;' id='txtContaing' name='txtContaing' onkeypress='getPackageDescription();' onblur='getPackageDescription();'/></td></tr>");
        // Remarks
        strData.Append("<tr><td><b>Remarks</b></td><td colspan='3'><input style='width:98%' type='text' id='txtRemarks' name='txtRemarks' value='ALL DESTINATION CHARGES WILL BE IN CONSIGNEE ACCOUNT' onkeypress='getPackageDescription();' onblur='getPackageDescription();'/></td></tr>");
        // Marks and Nos. Container Nos. and No. & kind of packages/ Description of goods
        strData.Append("<tr><td><b>Marks and Nos.<br/> Container Nos.</b></td><td><textarea style='width:98%;height:71px;font-family:arial;font-size:12px;vertical-align:text-top' type='text' id='txtMarks' name='txtMarks' ></textarea></td><td><b>No. & kind of packages/<br/> Description of goods</b></td><td><textarea style='width:98%;height:71px;font-family:arial;font-size:12px;vertical-align:text-top' type='text' id='txtDescriptionOfGoods' name='txtDescriptionOfGoods' ></textarea></td></tr>");
        // Date of Issue and Place
        strData.Append("<tr><td><b>Date of Issue</b></td><td><input style='width:145px;' type='text' id='txtDateOfIssue' name='txtDateOfIssue' readonly='readonly' /><a href='javascript:void(0);' id='lnkDateOfIssue'  onClick=\"setYears(1947, " + (DateTime.Now.Year) + ");showCalender(this, 'txtDateOfIssue');\"> <img  src='../Images/calender.png' id='imgDateOfIssue'></a>");
         // Calender
        strData.Append("<table id='calenderTable'><tbody id='calenderTableHead'><tr><td colspan='4' align='center'><select onChange=\"showCalenderBody(createCalender(document.getElementById('selectYear').value,this.selectedIndex, false));\"   id='selectMonth'><option value='0'>Jan</option><option value='1'>Feb</option><option value='2'>Mar</option><option value='3'>Apr</option><option value='4'>May</option><option value='5'>Jun</option><option value='6'>Jul</option><option value='7'>Aug</option><option value='8'>Sep</option><option value='9'>Oct</option><option value='10'>Nov</option><option value='11'>Dec</option></select></td><td colspan='2' align='center'><select onChange=\"showCalenderBody(createCalender(this.value,document.getElementById('selectMonth').selectedIndex, false));\" id='selectYear'></select></td><td align='center'><a href='javascript:void(0);' onClick=\"closeCalender();\"><font color='#003333' size='+1'>X</font></a></td></tr></tbody><tbody id='calenderTableDays'><tr style=''><td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td></tr></tbody><tbody id='calender'></tbody></table>");
        strData.Append("</td><td><b>Place<span style='color:red'>*</span></b></td><td><input style='width:145px' type='text' id='txtPlace' name='txtPlace' /><input type='hidden' id='hdnPlace' name='hdnPlace'/></td></tr>");

        strData.Append("<tr><td><b>BL Released Type</b></td><td " + (blType == "M" ? "colspan='3'" : string.Empty) + ">");
        using (CommonBusiness comBus = new CommonBusiness())
        {
            
            DataTable dtBLReleasedType = comBus.GetList("seaBLReleasedType", "BLReleasedType", "");
            if (dtBLReleasedType.Rows.Count > 0)
            {
                strData.Append("<select id='ddlBLReleasedType' name='ddlBLReleasedType' style='width:150px'>");
                foreach (DataRow drBLReleasedType in dtBLReleasedType.Rows)
                    strData.Append("<option value='" + drBLReleasedType["BLReleasedType"] + "'>" + drBLReleasedType["BLReleasedType"] + "</option>");
                strData.Append("</select>");
            }
        }
        strData.Append("</td>" + (blType == "H" ? "<td><b>No. of Originals issued</b></td><td><input style='width:145px' type='text' id='txtNoOfOriginals' name='txtNoOfOriginals' /></td></tr>" : "</tr>"));       
        
        strData.Append("<tr class='pageHead'><td colspan='4'>CHARGES</td></tr>");
        strData.Append("<tr><td><b><div style='float:left'>Currency</div><div style='float:left'> <span style='color:red' id='spanCurr'>*</span></div></b></td><td><input type='text' id='txtCurrency' name='txtCurrency' style='width:145px'/><input type='hidden' id='hdnCurrency' name='hdnCurrency' /></td><td><b><div style='float:left'>Exchange Rate</div><div style='float:left'> <span style='color:red' id='spanExRate'>*</span></div></b></td><td><input type='text' id='txtExchangeRate' name='txtExchangeRate'  value='1.00' style='width:145px'/></td></tr>");
        strData.Append("<tr><td><b><div style='float:left'>Base Freight</div><div style='float:left'> <span style='color:red;display:none' id='spanBaseFreight' >*</span></div></b></td><td><input type='text' id='txtBaseFreight' name='txtBaseFreight' style='width:145px;text-align:right' value='0'/></td><td colspan='2'></td></tr>");
        strData.Append("<tr><td colspan='4'>Service Tax will be calculated @ <label id='lblStaxRate'></label> % on * marked Income Heads</td></tr>");
        strData.Append("<tr><td colspan='4'>");
        ////////////////////////////INCOME///////////////////////////////////
        strData.Append("<div id='divIncome' style='width:100%'><fieldset ><legend>INCOME</legend><input type='hidden' id='hdnIncomeRows' name='hdnIncomeRows' value='0'/><table id='tblIncome' class='formTable' border='1' cellspacing='0px'>");
        strData.Append("<tr style='background-color:#0055E5;font-size:10px;color:White'><td style='width:5%'></td><td style='width:10%'><b>Charge Source</b></td><td style='width:15%'><b>Particulars</b></td><td style='width:5%'><b><label id='lblIncCurrHeader'>Curr</label></b></td><td style='width:5%'><b><label id='lblIncExRateHeader'>Ex.Rate</label></b></td><td style='width:5%'><b><label id='lblIncStatusHeader'>On</label></b></td><td style='width:10%'><b><label id='lblIncAmtHeader'>Amt</label></b></td><td style='width:10%'><b><label id='lblIncINRAmtHeader'>INR Amt</label></b></td><td style='width:25%'><b>Description</b></td><td></td></tr>");
        strData.Append("<tr id='trIncomeFooterRow'><td></td><td><select id='ddlIncomeChargeType' name='ddlIncomeChargeType' style='width:98%;' ><option value='SELECT'>SELECT</option><option value='BOOKING'>BOOKING</option><option value='" + (hdnBLType.Value == "H" ? "M" : "H") + "BL'>" + (hdnBLType.Value == "H" ? "M" : "H") + "BL</option></select></td><td><select id='ddlIncomeCharges' name='ddlIncomeCharges' style='width:98%' onchange=\"return checkIncomeCharges();\">");
                   strData.Append("<option value='SELECT'>SELECT</option>");
                   DataSet dsCharges = inv.getChargesForBilling(hdnSEAType.Value.Contains("EXP") ? "OCEANEXP" : "OCEANIMP");
                   DataSet dsCurrency = bImport.ImportCurrencyNew();
                   for (int incomeCharges = 0; incomeCharges < dsCharges.Tables[0].Rows.Count; incomeCharges++)
                   {
                       strData.Append("<option value='" + (dsCharges.Tables[0].Rows[incomeCharges]["Sno"].ToString() + "~" + dsCharges.Tables[0].Rows[incomeCharges]["headname"].ToString().Trim().ToUpper() + "~" + dsCharges.Tables[0].Rows[incomeCharges]["Taxable"].ToString().ToUpper()) + "'>" + dsCharges.Tables[0].Rows[incomeCharges]["ChargeName"].ToString().ToUpper() + "</option>");
                   }

                   strData.Append("</select></td>");
                   
                       strData.Append("<td><select id='ddlIncCurr' name='ddlIncCurr' style='width:98%' onchange=\"CurrencyIncomeAmount('ddlIncStatus','ddlIncCurr','txtIncomeAmount','txtIncExRate','txtIncAmt','txtDescription');\">");
                       foreach (DataRow drCurr in dsCurrency.Tables[0].Rows)
                       {
                           strData.Append("<option value='" + drCurr["CurrencyCode"] + "'" + (drCurr["CurrencyCode"].ToString() == "INR" ? "selected='selected'" : string.Empty) + ">" + drCurr["CurrencyCode"] + "</option>");
                       }
                       strData.Append("</td><td><input type='text' id='txtIncExRate' name='txtIncExRate' style='width:90%;text-align:right' value='1.00' onblur=\"CurrencyIncomeAmount('ddlIncStatus','ddlIncCurr','txtIncomeAmount','txtIncExRate','txtIncAmt','txtDescription');\"/></td><td><select id='ddlIncStatus' name='ddlIncStatus' onchange=\"CurrencyIncomeAmount('ddlIncStatus','ddlIncCurr','txtIncomeAmount','txtIncExRate','txtIncAmt','txtDescription');\"><option selected='selected' value='FIX'>FIX</option><option value='CBM'>CBM</option></select></td><td><input type='text' id='txtIncAmt' name='txtIncAmt' style='width:95%;text-align:right' value='0' onblur=\"CurrencyIncomeAmount('ddlIncStatus','ddlIncCurr','txtIncomeAmount','txtIncExRate','txtIncAmt','txtDescription');\"/></td>");

                       strData.Append("<td><input type='text' id='txtIncomeAmount' name='txtIncomeAmount' style='width:95%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\" onchange=\"incomeChargeValidation('ddlIncomeChargeType','ddlIncomeCharges','txtIncomeAmount');\"/></td><td><input type='text' id='txtDescription' name='txtDescription' style='width:98%'/></td><td><b><input type='button' id='btnAddIncome' value='Add' onclick=\"addIncomeDataRow('tblIncome')\" /></b></td></tr>");
        strData.Append("</table></fieldset></div>");
        ////////////////////////////EXPENSES///////////////////////////////////
        strData.Append("<div id='divIncome' style='width:100%'><fieldset ><legend>EXPENSES</legend><input type='hidden' id='hdnExpRows' name='hdnExpRows' value='0'/><table id='tblExpense' class='formTable' border='1' cellspacing='0px'>");
        strData.Append("<tr style='background-color:#0055E5;font-size:10px;color:White'><td style='width:5%'></td><td style='width:15%'><b>Charge Source</b></td><td style='width:15%'><b>Particulars</b></td><td style='width:15%'><b>Supplier</b></td><td style='width:5%'><b>Curr</b></td><td style='width:5%'><b>Ex.Rate</b></td><td style='width:8%'><b>Amt</b></td><td style='width:10%'><b>INR Amt</b></td><td style='width:7%'><b>STax Amt</b></td><td style='width:15%'><b>Remarks</b></td><td></td></tr>");
        strData.Append("<tr id='trIncomeFooterRow'><td></td><td><select id='ddlExpChargeType' name='ddlExpChargeType' style='width:98%;' ><option value='SELECT'>SELECT</option><option value='BOOKING'>BOOKING</option><option value='" + (hdnBLType.Value == "H" ? "M" : "H") + "BL'>" + (hdnBLType.Value == "H" ? "M" : "H") + "BL</option></select></td><td><select id='ddlExpCharges' name='ddlExpCharges' style='width:98%' onchange=\"return checkExpenseCharges('ddlExpCharges');\">");
        strData.Append("<option value='SELECT'>SELECT</option>");

        for (int expCharges = 0; expCharges < dsCharges.Tables[0].Rows.Count; expCharges++)
        {
            strData.Append("<option value='" + (dsCharges.Tables[0].Rows[expCharges]["Sno"].ToString() + "~" + dsCharges.Tables[0].Rows[expCharges]["headname"].ToString().Trim().ToUpper() + "~" + dsCharges.Tables[0].Rows[expCharges]["Taxable"].ToString().ToUpper()) + "'>" + dsCharges.Tables[0].Rows[expCharges]["ChargeName"].ToString().ToUpper() + "</option>");
        }

        strData.Append("</select></td>");
        strData.Append("<td><input type='text' id='txtExpSupplier' name='txtExpSupplier' style='width:95%'/><input type='hidden' id='hdnExpSupplierSno' name='hdnExpSupplierSno'/></td>");
        strData.Append("<td><select id='ddlExpCurr' name='ddlExpCurr' style='width:98%' onchange=\"CurrencyAmount('ddlExpCurr','txtExpINRAmt','txtExpExRate','txtExpAmt','ddlExpCharges','txtExpSTaxAmt','ddlExpChargeType');\" >");
        foreach (DataRow drCurr in dsCurrency.Tables[0].Rows)
        {
            strData.Append("<option value='" + drCurr["CurrencyCode"] + "'" + (drCurr["CurrencyCode"].ToString() == "INR" ? "selected='selected'" : string.Empty) + ">" + drCurr["CurrencyCode"] + "</option>");
        }
        strData.Append("</td><td><input type='text' id='txtExpExRate' name='txtExpExRate' style='width:90%;text-align:right' value='1.00' onblur=\"CurrencyAmount('ddlExpCurr','txtExpINRAmt','txtExpExRate','txtExpAmt','ddlExpCharges','txtExpSTaxAmt','ddlExpChargeType');\"/></td><td><input type='text' id='txtExpAmt' name='txtExpAmt' style='width:95%;text-align:right' value='0' onblur=\"CurrencyAmount('ddlExpCurr','txtExpINRAmt','txtExpExRate','txtExpAmt','ddlExpCharges','txtExpSTaxAmt','ddlExpChargeType');\" /></td>");

        strData.Append("<td><input type='text' id='txtExpINRAmt' name='txtExpINRAmt' style='width:95%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\" /></td><td><input type='text' id='txtExpSTaxAmt' name='txtExpSTaxAmt' style='width:90%;text-align:right' value='0' onclick=\"return test(this.id);\" onblur=\"return hiddenfld(this.id);\"/></td><td><input type='text' id='txtExpRemarks' name='txtExpRemarks' style='width:95%'/></td><td><b><input type='button' value='Add' id='btnAddExp' onclick=\"addExpDataRow('tblExpense')\" /></b></td></tr>");
        strData.Append("</table></fieldset></div>");
        strData.Append("</td></tr>");
        strData.Append("</table>");
        // Load ShippingLine
        StringBuilder strJavascriptShippingLine = new StringBuilder();
        strJavascriptShippingLine.Append(
        @"var optionsSL;
        jQuery(function() {
        optionsSL = {            
        serviceUrl: './Handlers/ShippingLine.ashx',  Width: 150,ValueControlID:document.getElementById('hdnShippingLine').id,onExtraFunction:getShippingLine 
        }; $('#txtShippingLine').autocomplete(optionsSL);});");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForShippingLine",strJavascriptShippingLine.ToString(), true);
        // Load Loading Port
        StringBuilder strJavascriptLoadingPort = new StringBuilder();
        strJavascriptLoadingPort.Append(
                 @"var optionsLP;
    jQuery(function() {
        optionsLP = {            
serviceUrl: './Handlers/CityNameCityCode.ashx',  Width: 150,ValueControlID:document.getElementById('hdnLoadingPort').id,onExtraFunction:getLoadingPort 
        }; $('#txtLoadingPort').autocomplete(optionsLP);});");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForLoadingPort",
                                            strJavascriptLoadingPort.ToString(), true);
        // Load Discharge Port
        StringBuilder strJavascriptDischargePort = new StringBuilder();
        strJavascriptDischargePort.Append(
                 @"var optionsDP;
    jQuery(function() {
        optionsDP = {            
serviceUrl: './Handlers/CityNameCityCode.ashx',  Width: 150,ValueControlID:document.getElementById('hdnDischargePort').id,onExtraFunction:getDischargePort 
        }; $('#txtDischargePort').autocomplete(optionsDP);});");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDischargePort",
                                            strJavascriptDischargePort.ToString(), true);
        // Load Place of Acceptance
        StringBuilder strJavascriptAcceptance = new StringBuilder();
        strJavascriptAcceptance.Append(
                 @"var optionsAccept;
    jQuery(function() {
        optionsAccept = {            
serviceUrl: './Handlers/CityNameCityCode.ashx',  Width: 150,ValueControlID:document.getElementById('hdnAcceptance').id,onExtraFunction:getAcceptance 
        }; $('#txtAcceptance').autocomplete(optionsAccept);});");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForAcceptance",
                                            strJavascriptAcceptance.ToString(), true);
        // Load  Place of Delivery
        StringBuilder strJavascriptDeliveryPlace = new StringBuilder();
        strJavascriptDeliveryPlace.Append(
                 @"var optionsDel;
    jQuery(function() {
        optionsDel = {            
serviceUrl: './Handlers/CityNameCityCode.ashx',  Width: 150,ValueControlID:document.getElementById('hdnDeliveryPlace').id,onExtraFunction:getDeliveryPlace
        }; $('#txtDeliveryPlace').autocomplete(optionsDel);});");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDeliveryPlace",
                                            strJavascriptDeliveryPlace.ToString(), true);
        // Load Bill To
        StringBuilder strJavascriptBillTo = new StringBuilder();
        strJavascriptBillTo.Append(
             @"var optionsBillTo;
    jQuery(function() {
debugger;
        optionsBillTo = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&Bill=Y',  Width: 300,ValueControlID:document.getElementById('hdnBillToSno').id,onExtraFunction:getBillToNameSNo }; $('#txtBillTo').autocomplete(optionsBillTo); });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForBillTo",
                                            strJavascriptBillTo.ToString(), true);
        // Load Shipper
        StringBuilder strJavascriptShip = new StringBuilder();
        strJavascriptShip.Append(
                 @"var optionsShip;
    jQuery(function() {
        optionsShip = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=SHIPPER',  Width: 300,ValueControlID:document.getElementById('hdnShipperSno').id,onExtraFunction:getShipperDet};   $('#txtShipper').autocomplete(optionsShip);  });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForShippers",
                                            strJavascriptShip.ToString(), true);
        // Load Consignee
        StringBuilder strJavascriptCon = new StringBuilder();
        strJavascriptCon.Append(
                @"var optionsCon;
    jQuery(function() {
        optionsCon = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=CONSIGNEE',  Width: 300,ValueControlID:document.getElementById('hdnConsigneeSno').id,onExtraFunction:getConsigneeDet}; $('#txtConsignee').autocomplete(optionsCon);  });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForConsignees",
                                            strJavascriptCon.ToString(), true);
        // Load Notify1
        StringBuilder strJavascriptNotify1 = new StringBuilder();
        strJavascriptNotify1.Append(
             @"var optionsNotify1;
    jQuery(function() {
        optionsNotify1 = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=',  Width: 300,ValueControlID:document.getElementById('hdnNotify1Sno').id,onExtraFunction:getNotify1Det }; $('#txtNotify1').autocomplete(optionsNotify1); });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForNotify1",
                                            strJavascriptNotify1.ToString(), true);
        // Load Delivery
        StringBuilder strJavascriptDelivery = new StringBuilder();
        strJavascriptDelivery.Append(
             @"var optionsDelivery;
    jQuery(function() {
        optionsDelivery = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=',  Width: 300,ValueControlID:document.getElementById('hdnDeliverySno').id,onExtraFunction:getDeliveryDet }; $('#txtDelivery').autocomplete(optionsDelivery); });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDelivery",
                                            strJavascriptDelivery.ToString(), true);
        // Load Notify2
        StringBuilder strJavascriptNotify2 = new StringBuilder();
        strJavascriptNotify2.Append(
             @"var optionsNotify2;
    jQuery(function() {
        optionsNotify2 = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=',  Width: 300,ValueControlID:document.getElementById('hdnNotify2Sno').id,onExtraFunction:getNotify2Det }; $('#txtNotify2').autocomplete(optionsNotify2); });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForNotify2",
                                            strJavascriptNotify2.ToString(), true);
        // Load Notify3
        StringBuilder strJavascriptNotify3 = new StringBuilder();
        strJavascriptNotify3.Append(
             @"var optionsNotify3;
    jQuery(function() {
        optionsNotify3 = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=',  Width: 300,ValueControlID:document.getElementById('hdnNotify3Sno').id,onExtraFunction:getNotify3Det }; $('#txtNotify3').autocomplete(optionsNotify3); });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForNotify3",
                                            strJavascriptNotify3.ToString(), true);
        // Load Destination Agent
        StringBuilder strJavascriptDestAgent = new StringBuilder();
        strJavascriptDestAgent.Append(
             @"var optionsDestAgent;
    jQuery(function() {
        optionsDestAgent = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=',  Width: 300,ValueControlID:document.getElementById('hdnDestAgentSno').id,onExtraFunction:getDestAgentDet }; $('#txtDestAgent').autocomplete(optionsDestAgent); });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForDestAgent",
                                            strJavascriptDestAgent.ToString(), true);
        // Load Forwarding Agent
        StringBuilder strJavascriptForwAgent = new StringBuilder();
        strJavascriptForwAgent.Append(
             @"var optionsForwAgent;
    jQuery(function() {
        optionsForwAgent = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=',  Width: 300,ValueControlID:document.getElementById('hdnForwAgentSno').id,onExtraFunction:getForwAgentDet }; $('#txtForwAgent').autocomplete(optionsForwAgent); });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForForwAgent",
                                            strJavascriptForwAgent.ToString(), true);
        // Load Local Agent
        StringBuilder strJavascriptLocalAgent = new StringBuilder();
        strJavascriptLocalAgent.Append(
             @"var optionsLocalAgent;
    jQuery(function() {
        optionsLocalAgent = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=',  Width: 300,ValueControlID:document.getElementById('hdnLocalAgentSno').id,onExtraFunction:getLocalAgentDet }; $('#txtLocalAgent').autocomplete(optionsLocalAgent); });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForLocalAgent",
                                            strJavascriptLocalAgent.ToString(), true);
        // Load Actual Customer
        StringBuilder strJavascriptActualCustomer = new StringBuilder();
        strJavascriptActualCustomer.Append(
             @"var optionsActualCustomer;
    jQuery(function() {
        optionsActualCustomer = {            
serviceUrl: './Handlers/CustomerCrLmtAddress.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "&CustType=', Width: 300, ValueControlID:document.getElementById('hdnActCustSno').id, onExtraFunction:getActualCustBrSno };  $('#txtActualCustomer').autocomplete(optionsActualCustomer);});");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForActualCustomer",
                                            strJavascriptActualCustomer.ToString(), true);
        // Load Overseas Agent
        StringBuilder strJavascriptOverseasAgent = new StringBuilder();
        strJavascriptOverseasAgent.Append(
             @"var optionsOverseasAgent;
    jQuery(function() {
        optionsOverseasAgent = {            
serviceUrl: './Handlers/overseaseAgentHandler.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "', Width: 300, ValueControlID:document.getElementById('hdnOverseasAgentSno').id, onExtraFunction:getOverseasAgentCustBrSno };  $('#txtOverseasAgent').autocomplete(optionsOverseasAgent);});");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "optionsOverseasAgent",
                                            strJavascriptOverseasAgent.ToString(), true);
        // Load Place
        StringBuilder strJavascriptPlace = new StringBuilder();
        strJavascriptPlace.Append(
                 @"var optionsPlace;
    jQuery(function() {
        optionsPlace = {            
serviceUrl: './Handlers/CityNameCityCode.ashx',  Width: 150,ValueControlID:document.getElementById('hdnPlace').id,onExtraFunction:getPlace 
        }; $('#txtPlace').autocomplete(optionsPlace);});");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForPlace",
                                            strJavascriptPlace.ToString(), true);

        // Load Currency
        StringBuilder strJavascriptCurrency = new StringBuilder();
        strJavascriptCurrency.Append(
             @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/Currency.ashx',  Width: 150,ValueControlID:document.getElementById('hdnCurrency').id,onExtraFunction:showHideIncColForOce
        };
        $('#txtCurrency').autocomplete(options);
             });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForCurrency",
                                            strJavascriptCurrency.ToString(), true);
        StringBuilder strJavascriptExpSupplier = new StringBuilder();
        strJavascriptExpSupplier.Append(
             @"var options;
    jQuery(function() {
        options = {            
serviceUrl: './Handlers/SupplierAirline.ashx?CompBrSNo=" + Session["CompBrSNo"].ToString() + "',  Width: 264,ValueControlID:document.getElementById('hdnExpSupplierSno').id  };  $('#txtExpSupplier').autocomplete(options);   });");
        ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptForExpSupplier",
                                            strJavascriptExpSupplier.ToString(), true);
        return strData.ToString();
    }
    // get Data for MBL/HBL Update and HBL Create
    public void getDataForUpdate(int Sno,string blType)
    {
        using (CommonBusiness comBus = new CommonBusiness())
        {

           

            btnSave.Text = blType == "H" && hdnPageType.Value == "CREATE" ? "SAVE" : "UPDATE";
            
            DataSet dsData = bSea.getSeaBLDetail(Sno);
            
            if (dsData.Tables[0].Rows.Count > 0)
            {
                
                // JobType
                StringBuilder strDataUpdate = new StringBuilder();
                //if (hdnPageType.Value == "CREATE" && blType == "H")
                //{
                //    hdnOldBill.Value = "N";
                //    ViewState["OldCustBrSno"] = "0";
                //    hdnOldIncomeAmt.Value = "0";
                //    strDataUpdate.Append("document.getElementById('ddlJobType').value='" + (dsData.Tables[0].Rows[0]["JobType"].ToString() == string.Empty ? "SELECT" : dsData.Tables[0].Rows[0]["JobType"].ToString()) + "';");
                //    strDataUpdate.Append("document.getElementById('txtMBLNo').value='" + dsData.Tables[0].Rows[0]["mbl_no"].ToString() + "';");
                //    strDataUpdate.Append("document.getElementById('txtBLDate').value='" + DateTime.Parse(dsData.Tables[0].Rows[0]["bl_date"].ToString()).ToString("dd-MM-yyyy") + "';");
                //    if (bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), hdnSEAType.Value, dsData.Tables[0].Rows[0]["mbl_no"].ToString()).Tables[1].Rows.Count > 0)
                //    {
                //        strDataUpdate.Append("document.getElementById('lblJobNo').innerHTML='" + bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), hdnSEAType.Value, dsData.Tables[0].Rows[0]["mbl_no"].ToString()).Tables[1].Rows[0][0].ToString() + "';");
                //        hdnJobNo.Value = bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), hdnSEAType.Value, dsData.Tables[0].Rows[0]["mbl_no"].ToString()).Tables[1].Rows[0][0].ToString();
                //    }
                //    if (hdnSEAType.Value == "EXPORT" && bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), hdnSEAType.Value, dsData.Tables[0].Rows[0]["mbl_no"].ToString()).Tables[2].Rows.Count > 0)
                //        strDataUpdate.Append("document.getElementById('txtHBLNo').value='" + bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), hdnSEAType.Value, dsData.Tables[0].Rows[0]["mbl_no"].ToString()).Tables[2].Rows[0][0].ToString() + "';");


                //}
                //else 
               if ((hdnPageType.Value == "UPDATE")||(hdnPageType.Value == "CREATE" && blType == "H"))
                {
                    hdnMainJobNo.Value = comBus.GetList("sea_bl", "job_no", "mbl_no='" + dsData.Tables[0].Rows[0]["mbl_no"].ToString() + "'").Rows[0][0].ToString().Substring(0, comBus.GetList("sea_bl", "job_no", "mbl_no='" + dsData.Tables[0].Rows[0]["mbl_no"].ToString() + "'").Rows[0][0].ToString().Length - 1);
                    if (hdnPageType.Value == "CREATE" && blType == "H")
                    {
                        hdnOldBill.Value = "N";
                        ViewState["OldCustBrSno"] = "0";
                        hdnOldIncomeAmt.Value = "0";
                        strDataUpdate.Append("document.getElementById('ddlJobType').value='" + (dsData.Tables[0].Rows[0]["JobType"].ToString() == string.Empty ? "SELECT" : dsData.Tables[0].Rows[0]["JobType"].ToString()) + "';");
                        strDataUpdate.Append("document.getElementById('ddlJobSubType').value='" + (dsData.Tables[0].Rows[0]["JobSubType"].ToString() == string.Empty ? "CONSOLE" : dsData.Tables[0].Rows[0]["JobSubType"].ToString()) + "';");
                        strDataUpdate.Append("document.getElementById('txtMBLNo').value='" + dsData.Tables[0].Rows[0]["mbl_no"].ToString() + "';");
                        strDataUpdate.Append("document.getElementById('txtBLDate').value='" + DateTime.Parse(dsData.Tables[0].Rows[0]["bl_date"].ToString()).ToString("dd-MM-yyyy") + "';");
                        if (bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), hdnSEAType.Value, dsData.Tables[0].Rows[0]["mbl_no"].ToString()).Tables[1].Rows.Count > 0)
                        {
                            strDataUpdate.Append("document.getElementById('lblJobNo').innerHTML='" + bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), hdnSEAType.Value, dsData.Tables[0].Rows[0]["mbl_no"].ToString()).Tables[1].Rows[0][0].ToString() + "';");
                            hdnJobNo.Value = bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), hdnSEAType.Value, dsData.Tables[0].Rows[0]["mbl_no"].ToString()).Tables[1].Rows[0][0].ToString();
                        }
                        if (hdnSEAType.Value == "EXPORT" && bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), hdnSEAType.Value, dsData.Tables[0].Rows[0]["mbl_no"].ToString()).Tables[2].Rows.Count > 0)
                            strDataUpdate.Append("document.getElementById('txtHBLNo').value='" + bSea.getNewJobRefNo(int.Parse(Session["CompBrSno"].ToString()), hdnSEAType.Value, dsData.Tables[0].Rows[0]["mbl_no"].ToString()).Tables[2].Rows[0][0].ToString() + "';");


                    }
                    else if (hdnPageType.Value == "UPDATE")
                    {
                       
                       // btnSave.Visible = dsData.Tables[0].Rows[0]["BMSNo"].ToString() == string.Empty;
                        if (dsData.Tables[0].Rows[0]["BMSNo"].ToString() != string.Empty)
                        { 
                            //Comment By gaurav Gaur:date:-September16 2013
                           // strDataUpdate.Append("document.getElementById('btnAddIncome').style.display='none';");
                            //////
                            strDataUpdate.Append("document.getElementById('hdnRbtnStatus').value=false;");
                            strDataUpdate.Append("document.getElementById('rbtnBillToYes').disabled=true;");
                            strDataUpdate.Append("document.getElementById('rbtnBillToNo').disabled=true;");
                        }
                        strDataUpdate.Append("document.getElementById('ddlJobType').value='" + (dsData.Tables[0].Rows[0]["JobType"].ToString() == string.Empty ? "SELECT" : dsData.Tables[0].Rows[0]["JobType"].ToString()) + "';");
                        strDataUpdate.Append("document.getElementById('ddlJobSubType').value='" + (dsData.Tables[0].Rows[0]["JobSubType"].ToString() == string.Empty ? "CONSOLE" : dsData.Tables[0].Rows[0]["JobSubType"].ToString()) + "';");
                        strDataUpdate.Append("document.getElementById('lblJobNo').innerHTML='" + dsData.Tables[0].Rows[0]["job_no"].ToString() + "';");
                        hdnJobNo.Value = dsData.Tables[0].Rows[0]["job_no"].ToString();
                        
                        strDataUpdate.Append("document.getElementById('ddlSubJob').value='" + dsData.Tables[0].Rows[0]["SubJobAllowed"].ToString() + "';");
                        strDataUpdate.Append("document.getElementById('ddlJobStatus').value='" + dsData.Tables[0].Rows[0]["JobStatus"].ToString() + "';");
                        strDataUpdate.Append("document.getElementById('txtMBLNo').value='" + dsData.Tables[0].Rows[0]["mbl_no"].ToString() + "';");
                        strDataUpdate.Append("document.getElementById('txtHBLNo').value='" + dsData.Tables[0].Rows[0]["hbl_no"].ToString() + "';");
                        strDataUpdate.Append("document.getElementById('txtBLDate').value='" + DateTime.Parse(dsData.Tables[0].Rows[0]["bl_date"].ToString()).ToString("dd-MM-yyyy") + "';");
                        strDataUpdate.Append("document.getElementById('txtVolWt').value='" + dsData.Tables[0].Rows[0]["cbm"].ToString() + "';");
                        strDataUpdate.Append("document.getElementById('txtBillingCBM').value='" + (dsData.Tables[0].Rows[0]["billingCBM"].ToString() == string.Empty ? "0" : dsData.Tables[0].Rows[0]["billingCBM"].ToString()) + "';");
                        if (hdnBLType.Value == "M")
                            strDataUpdate.Append("document.getElementById('txtTue').value='" + dsData.Tables[0].Rows[0]["tues"].ToString() + "';");
                        strDataUpdate.Append("document.getElementById('txtNetWt').value='" + dsData.Tables[0].Rows[0]["net_wt"].ToString() + "';");
                        strDataUpdate.Append("document.getElementById('txtGrossWt').value='" + dsData.Tables[0].Rows[0]["gross_wt"].ToString() + "';");
                    }
                    strDataUpdate.Append("document.getElementById('ddlFreight').value='" + dsData.Tables[0].Rows[0]["freight_type"].ToString().Trim() + "';");
                    
                    if (dsData.Tables[0].Rows[0]["ihc"].ToString().Trim() != string.Empty)
                    {
                        strDataUpdate.Append("document.getElementById('rbtnIHC').checked='checked';");
                        strDataUpdate.Append("document.getElementById('ddlTHCIHC').value='" + dsData.Tables[0].Rows[0]["ihc"].ToString().Trim() + "';");
                    }
                    else if (dsData.Tables[0].Rows[0]["thc"].ToString().Trim() != string.Empty)
                    {
                        strDataUpdate.Append("document.getElementById('rbtnTHC').checked='checked';");
                        strDataUpdate.Append("document.getElementById('ddlTHCIHC').value='" + dsData.Tables[0].Rows[0]["thc"].ToString().Trim() + "';");
                    }
                    strDataUpdate.Append("document.getElementById('txtPackages').value='" + dsData.Tables[0].Rows[0]["no_of_packages"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtETADate').value='" + (dsData.Tables[0].Rows[0]["ETA"].ToString() != string.Empty ? (DateTime.Parse(dsData.Tables[0].Rows[0]["ETA"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(dsData.Tables[0].Rows[0]["ETA"].ToString()).ToString("dd-MM-yyyy")) : string.Empty) + "';");
                    strDataUpdate.Append("document.getElementById('txtShippingLine').value='" + dsData.Tables[0].Rows[0]["shipping_line"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtETDDate').value='" + (dsData.Tables[0].Rows[0]["ETD"].ToString() != string.Empty ? (DateTime.Parse(dsData.Tables[0].Rows[0]["ETD"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(dsData.Tables[0].Rows[0]["ETD"].ToString()).ToString("dd-MM-yyyy")) : string.Empty) + "';");
                    strDataUpdate.Append("document.getElementById('txtLoadingPort').value='" + dsData.Tables[0].Rows[0]["loading_port"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('hdnLoadingPort').value='" + dsData.Tables[0].Rows[0]["loading_port"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtDischargePort').value='" + dsData.Tables[0].Rows[0]["discharge_port"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('hdnDischargePort').value='" + dsData.Tables[0].Rows[0]["discharge_port"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtAcceptance').value='" + dsData.Tables[0].Rows[0]["receipt_place"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('hdnAcceptance').value='" + dsData.Tables[0].Rows[0]["receipt_place"].ToString() + "';");
                   strDataUpdate.Append("document.getElementById('txtDeliveryPlace').value='" + dsData.Tables[0].Rows[0]["delivery_place"].ToString() + "';");
                   if (comBus.GetList("citymaster", "citycode", "'" + dsData.Tables[0].Rows[0]["delivery_place"].ToString() + "' like '%'+cityname+'%'").Rows.Count > 0)
                   {
                       strDataUpdate.Append("document.getElementById('hdnDeliveryPlace').value='" + comBus.GetList("citymaster", "citycode", "'" + dsData.Tables[0].Rows[0]["delivery_place"].ToString() + "' like '%'+cityname+'%'").Rows[0][0].ToString() + "';");
                       hdnDeliveryPlaceForHBL.Value = comBus.GetList("citymaster", "citycode", "'" + dsData.Tables[0].Rows[0]["delivery_place"].ToString() + "' like '%'+cityname+'%'").Rows[0][0].ToString();
                   }
                   else
                   {
                       strDataUpdate.Append("document.getElementById('hdnDeliveryPlace').value='" + dsData.Tables[0].Rows[0]["delivery_place"].ToString() + "';");
                       hdnDeliveryPlaceForHBL.Value = dsData.Tables[0].Rows[0]["delivery_place"].ToString();
                   }
                  
                    strDataUpdate.Append("document.getElementById('txtVessel').value=\"" + dsData.Tables[0].Rows[0]["vessel"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtVoyage').value='" + dsData.Tables[0].Rows[0]["voyage"].ToString() + "';");
                    if (dsData.Tables[0].Rows[0]["Bill"].ToString() == "Y")
                    {
                        strDataUpdate.Append("document.getElementById('rbtnBillToYes').checked='checked';");
                        strDataUpdate.Append("document.getElementById('hdnRbtnBillTo').value = 'Y';");
                    }
                    else if (dsData.Tables[0].Rows[0]["Bill"].ToString() == "N")
                    {
                        strDataUpdate.Append("document.getElementById('rbtnBillToNo').checked='checked';");
                        strDataUpdate.Append("document.getElementById('hdnRbtnBillTo').value = 'N';");
                    }
                    strDataUpdate.Append("document.getElementById('txtBillTo').value='" + dsData.Tables[0].Rows[0]["BillTo"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('hdnBillToSno').value='" + dsData.Tables[0].Rows[0]["BillTo_Code"].ToString() + "';");
                    hdnOldBill.Value = dsData.Tables[0].Rows[0]["Bill"].ToString().ToUpper();
                    ViewState["OldCustBrSno"] = dsData.Tables[0].Rows[0]["BillTo_Code"].ToString() == string.Empty ? "0" : dsData.Tables[0].Rows[0]["BillTo_Code"].ToString();
                    // show credit limit 
                    strDataUpdate.Append("document.getElementById('lblCrLimit').innerHTML='" + dsData.Tables[0].Rows[0]["AvlLimit"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('hdnCrLimit').value='" + dsData.Tables[0].Rows[0]["AvlLimit"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtRotationNo').value='" + dsData.Tables[0].Rows[0]["RotationNo"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtShipper').value=\"" + dsData.Tables[0].Rows[0]["shipper_name"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('hdnShipperSno').value='" + dsData.Tables[0].Rows[0]["shipper_code"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtShipperAddress').value=\"" + dsData.Tables[0].Rows[0]["shipper_address"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtShipperEmail').value='" + dsData.Tables[0].Rows[0]["shipper_email"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtShipperPhone').value='" + dsData.Tables[0].Rows[0]["shipper_phone"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtConsignee').value=\"" + dsData.Tables[0].Rows[0]["Consignee_name"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('hdnConsigneeSno').value='" + dsData.Tables[0].Rows[0]["Consignee_code"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtConsigneeAddress').value=\"" + dsData.Tables[0].Rows[0]["Consignee_address"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtConsigneeEmail').value='" + dsData.Tables[0].Rows[0]["Consignee_email"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtConsigneePhone').value='" + dsData.Tables[0].Rows[0]["Consignee_phone"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtNotify1').value=\"" + dsData.Tables[0].Rows[0]["Notify_name"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('hdnNotify1Sno').value='" + dsData.Tables[0].Rows[0]["Notify_code"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtNotify1Address').value=\"" + dsData.Tables[0].Rows[0]["Notify_address"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtNotify1Email').value='" + dsData.Tables[0].Rows[0]["Notify_email"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtNotify1Phone').value='" + dsData.Tables[0].Rows[0]["Notify_phone"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtDelivery').value=\"" + dsData.Tables[0].Rows[0]["Delivery_name"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('hdnDeliverySno').value='" + dsData.Tables[0].Rows[0]["Delivery_code"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtDeliveryAddress').value=\"" + dsData.Tables[0].Rows[0]["Delivery_address"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtDeliveryEmail').value='" + dsData.Tables[0].Rows[0]["Delivery_email"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtDeliveryPhone').value='" + dsData.Tables[0].Rows[0]["Delivery_phone"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtNotify2').value=\"" + dsData.Tables[0].Rows[0]["Notify2"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('hdnNotify2Sno').value='" + dsData.Tables[0].Rows[0]["Notify2_code"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtNotify2Address').value=\"" + dsData.Tables[0].Rows[0]["Notify2Address"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtNotify2Email').value='" + dsData.Tables[0].Rows[0]["Notify2Email"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtNotify2Phone').value='" + dsData.Tables[0].Rows[0]["Notify2Phone"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtNotify3').value=\"" + dsData.Tables[0].Rows[0]["Notify3"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('hdnNotify3Sno').value='" + dsData.Tables[0].Rows[0]["Notify3_code"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtNotify3Address').value=\"" + dsData.Tables[0].Rows[0]["Notify3Address"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtNotify3Email').value='" + dsData.Tables[0].Rows[0]["Notify3Email"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtNotify3Phone').value='" + dsData.Tables[0].Rows[0]["Notify3Phone"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtDestAgent').value=\"" + dsData.Tables[0].Rows[0]["DestAgent"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('hdnDestAgentSno').value='" + dsData.Tables[0].Rows[0]["DestAgent_Code"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtForwAgent').value=\"" + dsData.Tables[0].Rows[0]["ForwAgent"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('hdnForwAgentSno').value='" + dsData.Tables[0].Rows[0]["ForwAgent_Code"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtLocalAgent').value=\"" + dsData.Tables[0].Rows[0]["LocalAgent"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('hdnLocalAgentSno').value='" + dsData.Tables[0].Rows[0]["LocalAgent_Code"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('ddlSalesPerson').value='" + dsData.Tables[0].Rows[0]["SalesPerson"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('ddlBusinessType').value='" + dsData.Tables[0].Rows[0]["BusinessType"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('ddlNetworkGroup').value='" + dsData.Tables[0].Rows[0]["NetworkName"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtActualCustomer').value=\"" + (dsData.Tables[0].Rows[0]["ActualCustomer"].ToString() == string.Empty ? dsData.Tables[0].Rows[0]["actual_customer_name"].ToString() : dsData.Tables[0].Rows[0]["ActualCustomer"].ToString()) + "\";");
                    strDataUpdate.Append("document.getElementById('hdnActCustSno').value='" + dsData.Tables[0].Rows[0]["actual_customer_code"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtOverseasAgent').value=\"" + dsData.Tables[0].Rows[0]["OverseasAgent"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('hdnOverseasAgentSno').value='" + dsData.Tables[0].Rows[0]["OverseasAgentCode"].ToString() + "';");

                    strDataUpdate.Append("document.getElementById('ddlContainerType').value=\"" + dsData.Tables[0].Rows[0]["Container_Type"].ToString() + "\";");
                    if (dsData.Tables[0].Rows[0]["Container_Type"].ToString().ToUpper().Contains("EXHIBITION"))
                        strDataUpdate.Append("document.getElementById('ddlexhibitionlist').value='" + dsData.Tables[0].Rows[0]["ExhibitionID"].ToString() + "';");
                    else if (dsData.Tables[0].Rows[0]["Container_Type"].ToString().ToUpper().Contains("OTHER"))
                        strDataUpdate.Append("document.getElementById('ddlProductOther').value='" + dsData.Tables[0].Rows[0]["ProductOther"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtPreCarriageBy').value='" + dsData.Tables[0].Rows[0]["pre_carriage_by"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtCommodity').value='" + dsData.Tables[0].Rows[0]["commodity"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtGoodsRecDate').value='" + (dsData.Tables[0].Rows[0]["goods_recd_dt"].ToString() != string.Empty ? (DateTime.Parse(dsData.Tables[0].Rows[0]["goods_recd_dt"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(dsData.Tables[0].Rows[0]["goods_recd_dt"].ToString()).ToString("dd-MM-yyyy")) : string.Empty) + "';");
                    strDataUpdate.Append("document.getElementById('txtCustomClDate').value='" + (dsData.Tables[0].Rows[0]["custom_clearance_dt"].ToString() != string.Empty ? (DateTime.Parse(dsData.Tables[0].Rows[0]["custom_clearance_dt"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(dsData.Tables[0].Rows[0]["custom_clearance_dt"].ToString()).ToString("dd-MM-yyyy")) : string.Empty) + "';");
                    // Container Nos dsData.Tables[0].Rows[0]["job_no"].ToString() hdnBLType.Value == "M" || 
                    DataTable dtContainerNos = comBus.GetList("seaContainerDetail", "*", "JobNo like'%" + dsData.Tables[0].Rows[0]["job_no"].ToString() + "'");
                    //DataTable dtContainerNos = comBus.GetList("seaContainerDetail", "*", "SeaBlSno like'%" + dsData.Tables[0].Rows[0]["sno"].ToString() + "'");
                    DataTable dtGoodsRecdWt = new DataTable();
                    DataTable dtBookingRedIntl = new DataTable();
                   if (hdnPageType.Value == "CREATE" && blType == "H" && hdnGoodsRecSnos.Value != string.Empty && hdnGoodsRecSnos.Value!="0")
                    {
                        dtGoodsRecdWt = comBus.GetList("sea_goods_recd", "SUM(gross_wt) AS GrWT,SUM(cbm) AS CBM, SUM(net_wt)AS NetWt,SUM(no_of_packages) AS pkgs", "'," + hdnGoodsRecSnos.Value + ",' like '%,'+CAST(goodsrecdid AS VARCHAR) +',%'");
                        if (dtGoodsRecdWt.Rows.Count > 0)
                        {
                            strDataUpdate.Append("document.getElementById('txtVolWt').value='" + dtGoodsRecdWt.Rows[0]["CBM"] + "';");
                            strDataUpdate.Append("document.getElementById('txtBillingCBM').value='" + dtGoodsRecdWt.Rows[0]["CBM"] + "';");
                            strDataUpdate.Append("document.getElementById('txtNetWt').value='" + dtGoodsRecdWt.Rows[0]["NetWt"] + "';");
                            strDataUpdate.Append("document.getElementById('txtGrossWt').value='" + dtGoodsRecdWt.Rows[0]["GrWT"] + "';");
                            strDataUpdate.Append("document.getElementById('txtPackages').value='" + dtGoodsRecdWt.Rows[0]["pkgs"] + "';");
                        }
                    }
                   if (hdnPageType.Value == "CREATE" && blType == "H" && hdnBookingRedIntlSnos.Value != string.Empty && hdnBookingRedIntlSnos.Value != "0")
                   {
                       //dtBookingRedIntl = comBus.GetList("SeaBl_RedIntlBooking", "SUM(gross_wt) AS GrWT,SUM(cbm) AS CBM, SUM(no_of_packages) AS pkgs", "'," + hdnBookingRedIntlSnos.Value + ",' like '%,'+CAST(sno AS VARCHAR) +',%'");
                       dtBookingRedIntl = comBus.GetList("SeaBl_RedIntlBooking", "gross_wt AS GrWT,cbm AS CBM, no_of_packages AS pkgs, shipper_name, shipper_address, consignee_name, consignee_address,actual_customer_name", "'," + hdnBookingRedIntlSnos.Value + ",' like '%,'+CAST(sno AS VARCHAR) +',%'");
                       if (dtBookingRedIntl.Rows.Count > 0)
                       {
                           strDataUpdate.Append("document.getElementById('txtVolWt').value='" + dtBookingRedIntl.Rows[0]["CBM"] + "';");
                           strDataUpdate.Append("document.getElementById('txtBillingCBM').value='" + dtBookingRedIntl.Rows[0]["CBM"] + "';");
                           strDataUpdate.Append("document.getElementById('txtNetWt').value='0';");
                           strDataUpdate.Append("document.getElementById('txtGrossWt').value='" + dtBookingRedIntl.Rows[0]["GrWT"] + "';");
                           strDataUpdate.Append("document.getElementById('txtPackages').value='" + dtBookingRedIntl.Rows[0]["pkgs"] + "';");
                           strDataUpdate.Append("document.getElementById('txtShipper').value='" + dtBookingRedIntl.Rows[0]["shipper_name"] + "';");
                           strDataUpdate.Append("document.getElementById('txtShipperAddress').value='" + dtBookingRedIntl.Rows[0]["shipper_address"] + "';");
                           strDataUpdate.Append("document.getElementById('txtConsignee').value='" + dtBookingRedIntl.Rows[0]["consignee_name"] + "';");
                           strDataUpdate.Append("document.getElementById('txtConsigneeAddress').value='" + dtBookingRedIntl.Rows[0]["consignee_address"] + "';");
                           strDataUpdate.Append("document.getElementById('txtActualCustomer').value='" + dtBookingRedIntl.Rows[0]["actual_customer_name"] + "';");

                       }
                   }

                   if (hdnBookingRedIntlSnos.Value == "0")
                   {

                       if (dtContainerNos.Rows.Count > 0)
                       {
                           foreach (DataRow drContainerNos in dtContainerNos.Rows)
                           {
                               strDataUpdate.Append("document.getElementById('txtContainerNo').value ='" + drContainerNos["ContainerNo"] + "';");
                               strDataUpdate.Append("document.getElementById('ddlContType').value =\"" + drContainerNos["ContainerType"] + "\";");
                               strDataUpdate.Append("document.getElementById('txtLSealNo').value ='" + drContainerNos["LSealNo"] + "';");
                               strDataUpdate.Append("document.getElementById('txtContainerPkgs').value ='" + (dtGoodsRecdWt.Rows.Count > 0 ? (decimal.Parse(dtGoodsRecdWt.Rows[0]["pkgs"].ToString()) / dtContainerNos.Rows.Count) : drContainerNos["Packages"]) + "';");
                               strDataUpdate.Append("document.getElementById('txtContainerNetWt').value ='" + (dtGoodsRecdWt.Rows.Count > 0 ? (decimal.Parse(dtGoodsRecdWt.Rows[0]["NetWt"].ToString()) / dtContainerNos.Rows.Count) : drContainerNos["NetWeight"]) + "';");
                               strDataUpdate.Append("document.getElementById('txtContainerGrWt').value ='" + (dtGoodsRecdWt.Rows.Count > 0 ? (decimal.Parse(dtGoodsRecdWt.Rows[0]["GrWT"].ToString()) / dtContainerNos.Rows.Count) : drContainerNos["GrossWeight"]) + "';");
                               strDataUpdate.Append("document.getElementById('txtContainerVolWt').value ='" + (dtGoodsRecdWt.Rows.Count > 0 ? (decimal.Parse(dtGoodsRecdWt.Rows[0]["CBM"].ToString()) / dtContainerNos.Rows.Count) : drContainerNos["VolumeWeight"]) + "';");
                               strDataUpdate.Append("addContainerDataRow('tblContainerDetail');");
                               strDataUpdate.Append("document.getElementById(\"hdnContainerSno\"+document.getElementById('hdnContainerRows').value).value ='" + (hdnPageType.Value == "CREATE" ? '0' : drContainerNos["sno"]) + "';");
                               ViewState["ContainerTableSno"] = ViewState["ContainerTableSno"].ToString() + drContainerNos["sno"].ToString() + ",";
                               if (hdnPageType.Value == "UPDATE")
                                   hdnContainerTableSno.Value = hdnContainerTableSno.Value + drContainerNos["sno"].ToString() + ",";
                           }
                       }
                       else if (dsData.Tables[0].Rows[0]["Container_no"].ToString() != string.Empty)
                       {
                           strDataUpdate.Append("document.getElementById('txtContainerNo').value=\"" + dsData.Tables[0].Rows[0]["Container_no"].ToString() + "\";");
                           strDataUpdate.Append("document.getElementById('ddlContType').value =\"" + dsData.Tables[0].Rows[0]["Container_Type"] + "\";");
                           strDataUpdate.Append("document.getElementById('txtLSealNo').value ='" + dsData.Tables[0].Rows[0]["l_seal_no"] + "';");
                           strDataUpdate.Append("document.getElementById('txtContainerPkgs').value ='" + dsData.Tables[0].Rows[0]["no_of_packages"] + "';");
                           strDataUpdate.Append("document.getElementById('txtContainerNetWt').value ='" + dsData.Tables[0].Rows[0]["net_wt"] + "';");
                           strDataUpdate.Append("document.getElementById('txtContainerGrWt').value ='" + dsData.Tables[0].Rows[0]["gross_wt"] + "';");
                           strDataUpdate.Append("document.getElementById('txtContainerVolWt').value ='" + dsData.Tables[0].Rows[0]["cbm"] + "';");
                           strDataUpdate.Append("addContainerDataRow('tblContainerDetail');");

                       }
                   }
                    if (hdnPageType.Value == "UPDATE")
                    {

                        // SB Nos
                        DataTable dtSBNos = comBus.GetList("seaShippingBillsDetail", "*", (hdnBLType.Value == "M" ? "jobNo like'%" + hdnMainJobNo.Value + "%'" : "seaBLSno='" + Sno + "'"));
                        if (dtSBNos.Rows.Count > 0)
                        {
                            foreach (DataRow drSBNos in dtSBNos.Rows)
                            {
                                strDataUpdate.Append("document.getElementById('txtSBNo').value ='" + drSBNos["shippingBillNo"] + "';");
                                strDataUpdate.Append("document.getElementById('txtSBDate').value ='" + (drSBNos["shippingBillDate"].ToString() == string.Empty || DateTime.Parse(drSBNos["shippingBillDate"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(drSBNos["shippingBillDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                                strDataUpdate.Append("addSBDataRow('tblSBDetail');");
                                strDataUpdate.Append("document.getElementById(\"hdnSBSno\"+document.getElementById('hdnSBRows').value).value ='" + drSBNos["sno"] + "';");
                                ViewState["SBTableSno"] = ViewState["SBTableSno"].ToString() + drSBNos["sno"].ToString() + ",";
                                hdnSBTableSno.Value = hdnSBTableSno.Value + drSBNos["sno"].ToString() + ",";
                            }
                        }
                        else if (dsData.Tables[0].Rows[0]["SBNo"].ToString() != string.Empty)
                        {
                            strDataUpdate.Append("document.getElementById('txtSBNo').value=\"" + dsData.Tables[0].Rows[0]["SBNo"].ToString() + "\";");
                            strDataUpdate.Append("document.getElementById('txtSBDate').value='" + (dsData.Tables[0].Rows[0]["SBDate"].ToString() != string.Empty ? (DateTime.Parse(dsData.Tables[0].Rows[0]["SBDate"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(dsData.Tables[0].Rows[0]["SBDate"].ToString()).ToString("dd-MM-yyyy")) : string.Empty) + "';");
                            strDataUpdate.Append("addSBDataRow('tblSBDetail');");
                        }
                        // Invoice Nos
                        DataTable dtBLInvNos = comBus.GetList("seaBLInvoiceDetail", "*", (hdnBLType.Value == "M" ? "jobNo like'%" + hdnMainJobNo.Value + "%'" : "seaBLSno='" + Sno + "'"));
                        if (dtBLInvNos.Rows.Count > 0)
                        {
                            foreach (DataRow drBLInvNos in dtBLInvNos.Rows)
                            {
                                strDataUpdate.Append("document.getElementById('txtInvoiceNo').value ='" + drBLInvNos["InvoiceNo"] + "';");
                                strDataUpdate.Append("document.getElementById('txtInvoiceDate').value ='" + (drBLInvNos["InvoiceDate"].ToString() == string.Empty || DateTime.Parse(drBLInvNos["InvoiceDate"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(drBLInvNos["InvoiceDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                                strDataUpdate.Append("addBLInvoiceDataRow('tblBLInvoiceDetail');");
                                strDataUpdate.Append("document.getElementById(\"hdnBLInvSno\"+document.getElementById('hdnBLInvoiceRows').value).value ='" + drBLInvNos["sno"] + "';");
                                ViewState["BLInvoiceTableSno"] = ViewState["BLInvoiceTableSno"].ToString() + drBLInvNos["sno"].ToString() + ",";
                                hdnBLInvoiceTableSno.Value = hdnBLInvoiceTableSno.Value + drBLInvNos["sno"].ToString() + ",";
                            }
                        }
                        else if (dsData.Tables[0].Rows[0]["Invoice"].ToString() != string.Empty)
                        {
                            strDataUpdate.Append("document.getElementById('txtInvoiceNo').value=\"" + dsData.Tables[0].Rows[0]["Invoice"].ToString() + "\";");
                            strDataUpdate.Append("document.getElementById('txtInvoiceDate').value=\"" + (dsData.Tables[0].Rows[0]["InvoiceDate"].ToString() != string.Empty ? (DateTime.Parse(dsData.Tables[0].Rows[0]["InvoiceDate"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(dsData.Tables[0].Rows[0]["InvoiceDate"].ToString()).ToString("dd-MM-yyyy")) : string.Empty) + "\";");
                            strDataUpdate.Append("addBLInvoiceDataRow('tblBLInvoiceDetail');");
                        }

                        //baseFreight Amount
                        strDataUpdate.Append("document.getElementById('txtBaseFreight').value=\"" + (dsData.Tables[0].Rows[0]["baseFreightAmount"].ToString() == string.Empty ? "0" : dsData.Tables[0].Rows[0]["baseFreightAmount"].ToString()) + "\";");
                        //}
                        DataSet dsSeaBLCharges = inv.getSeaMBLBillingCharges(dsData.Tables[0].Rows[0]["Job_No"].ToString().Substring(0, dsData.Tables[0].Rows[0]["Job_No"].ToString().Length - dsData.Tables[0].Rows[0]["Job_No"].ToString().Split('/')[dsData.Tables[0].Rows[0]["Job_No"].ToString().Split('/').Length - 1].Length), dsData.Tables[0].Rows[0]["mbl_no"].ToString(), int.Parse(Session["CompBrSno"].ToString()));
                        DataTable dtIncome = new DataTable();
                        DataTable dtExpense = new DataTable();
                        //if (hdnBLType.Value == "M")
                        //{
                        if(hdnBLType.Value == "M")
                        {
                            DataView dvIncomeChargesFromHBL = new DataView(dsSeaBLCharges.Tables[0], "headtype='I' and chargesource='HBL' and cnstatus='N'", "headcode", DataViewRowState.CurrentRows);
                            hdnIncomeAmountForMBLFromHBL.Value = dvIncomeChargesFromHBL.ToTable().Rows.Count > 0 ? dvIncomeChargesFromHBL.ToTable().Compute("sum(bill_amount)", "").ToString() : "0";
                        }
                        // For Income charges 
                        DataView dvSeaMBLIncome = new DataView(dsSeaBLCharges.Tables[0], "headtype='I' and (hblno='" + (hdnBLType.Value == "M" ? string.Empty : dsData.Tables[0].Rows[0]["hbl_no"].ToString()) + "'" + (hdnBLType.Value == "M" ? " or chargesource='HBL'" : string.Empty) + ") and billtype='BOOKING'", "headcode", DataViewRowState.CurrentRows);
                        //billtype='BOOKING'
                        DataView dvSeaMBLExp = new DataView(dsSeaBLCharges.Tables[0], "(headtype='P' or headtype='E') and (hblno='" + (hdnBLType.Value == "M" ? string.Empty : dsData.Tables[0].Rows[0]["hbl_no"].ToString()) + "'" + (hdnBLType.Value == "M" ? " or chargesource='HBL'" : string.Empty) + ") and billtype='BOOKING'", "headcode", DataViewRowState.CurrentRows);
                        //billtype='BOOKING'
                        dtIncome.Clear();
                        dtExpense.Clear();
                        dtIncome = dvSeaMBLIncome.ToTable().Clone();
                        dtExpense = dvSeaMBLExp.ToTable().Clone();
                        for (int i0 = 0; i0 < dvSeaMBLIncome.ToTable().Rows.Count; i0++)
                        {
                            DataRow drSeaInc = dvSeaMBLIncome.ToTable().Rows[i0];
                            dtIncome.LoadDataRow(drSeaInc.ItemArray, false);
                        }
                        // For Expense charges 
                        for (int i1 = 0; i1 < dvSeaMBLExp.ToTable().Rows.Count; i1++)
                        {
                            DataRow drSeaExp = dvSeaMBLExp.ToTable().Rows[i1];
                            dtExpense.LoadDataRow(drSeaExp.ItemArray, false);
                        }

                        //}
                        //DataTable dtIncome = comBus.GetList("SeaMBLBillingCharges", "*", "SeaBlSno='" + Sno + "' and HeadType='I'");" + (hdnBLType.Value == "M" ? "H" : "H") + "
                        if (dtIncome.Rows.Count > 0)
                        {
                            foreach (DataRow drIncome in dtIncome.Rows)
                            {
                                strDataUpdate.Append("document.getElementById('ddlIncomeChargeType').value ='" + (hdnBLType.Value == "H" && drIncome["chargeSource"].ToString() == "HBL" ? "MBL" : drIncome["chargeSource"].ToString()) + "';");
                                strDataUpdate.Append("document.getElementById('ddlIncomeCharges').value ='" + (drIncome["HeadCode"].ToString() + "~" + drIncome["HeadName"].ToString() + "~" + drIncome["Taxable"].ToString()) + "';");
                                strDataUpdate.Append("document.getElementById('ddlIncCurr').value ='" + drIncome["currency"] + "';");
                                strDataUpdate.Append("document.getElementById('txtIncExRate').value ='" + drIncome["exchangeRate"] + "';");
                                strDataUpdate.Append("document.getElementById('ddlIncStatus').value ='" + drIncome["status"] + "';");
                                strDataUpdate.Append("document.getElementById('txtIncAmt').value ='" + Math.Round(decimal.Parse(drIncome["amount"].ToString()) / decimal.Parse(drIncome["exchangeRate"].ToString()), 2) + "';");
                                strDataUpdate.Append("document.getElementById('txtIncomeAmount').value ='" + drIncome["amount"].ToString() + "';");
                                strDataUpdate.Append("document.getElementById('txtDescription').value ='" + drIncome["remarks"] + "';");
                                strDataUpdate.Append("addIncomeDataRow('tblIncome');");
                                strDataUpdate.Append("document.getElementById(\"btnIncDelete\"+document.getElementById('hdnIncomeRows').value).style.display='" + (drIncome["CNStatus"].ToString() == "Y" ? "none" : "block") + "';");
                                strDataUpdate.Append("document.getElementById(\"cboxInc\"+document.getElementById('hdnIncomeRows').value).style.display='" + (drIncome["CNStatus"].ToString() == "Y" ? "none" : "block") + "';");
                                strDataUpdate.Append("document.getElementById(\"hdnIncomeSno\"+document.getElementById('hdnIncomeRows').value).value ='" + drIncome["sno"] + "';");
                                //Comment By Mayank Jaiswal..Change Amount to BillAmount in single line/////
                               // hdnOldIncomeAmt.Value = (decimal.Parse(hdnOldIncomeAmt.Value) + decimal.Parse(drIncome["amount"].ToString())).ToString();
                                hdnOldIncomeAmt.Value = (decimal.Parse(hdnOldIncomeAmt.Value) + (drIncome["chargeSource"].ToString()=="BOOKING"? decimal.Parse(drIncome["bill_amount"].ToString()):0)).ToString();

                                ViewState["IncomeTableSno"] = ViewState["IncomeTableSno"].ToString() + drIncome["sno"].ToString() + ",";
                                hdnIncomeTableSno.Value = hdnIncomeTableSno.Value + drIncome["sno"].ToString() + ",";
                            }
                        }
                        //DataTable dtExpense = comBus.GetList("SeaMBLBillingCharges", "*", "SeaBlSno='" + Sno + "' and HeadType!='I'");
                        if (dtExpense.Rows.Count > 0)
                        {
                            foreach (DataRow drExpense in dtExpense.Rows)
                            {
                                strDataUpdate.Append("document.getElementById('ddlExpChargeType').value ='" + (hdnBLType.Value == "H" && drExpense["chargeSource"].ToString() == "HBL" ? "MBL" : drExpense["chargeSource"].ToString()) + "';");
                                strDataUpdate.Append("document.getElementById('ddlExpCharges').value ='" + (drExpense["HeadCode"].ToString() + "~" + drExpense["HeadName"].ToString() + "~" + drExpense["Taxable"].ToString()) + "';");
                                strDataUpdate.Append("document.getElementById('txtExpSupplier').value ='" + drExpense["supplierName"] + "';");
                                strDataUpdate.Append("document.getElementById('hdnExpSupplierSno').value ='" + drExpense["supplierSno"] + "';");
                                strDataUpdate.Append("document.getElementById('ddlExpCurr').value ='" + drExpense["currency"] + "';");
                                strDataUpdate.Append("document.getElementById('txtExpExRate').value ='" + drExpense["exchangeRate"] + "';");
                                strDataUpdate.Append("document.getElementById('txtExpAmt').value ='" + Math.Round(decimal.Parse(drExpense["amount"].ToString()) / decimal.Parse(drExpense["exchangeRate"].ToString()), 2) + "';");
                                strDataUpdate.Append("document.getElementById('txtExpINRAmt').value ='" + drExpense["amount"] + "';");
                                strDataUpdate.Append("document.getElementById('txtExpSTaxAmt').value ='" + drExpense["stax_amt"] + "';");
                                strDataUpdate.Append("document.getElementById('txtExpRemarks').value ='" + drExpense["remarks"] + "';");
                                strDataUpdate.Append("addExpDataRow('tblExpense');");
                                strDataUpdate.Append("document.getElementById(\"btnExpDelete\"+document.getElementById('hdnExpRows').value).style.display='" + (drExpense["CNStatus"].ToString() == "Y" ? "none" : "block") + "';");
                                strDataUpdate.Append("document.getElementById(\"cboxExp\"+document.getElementById('hdnExpRows').value).style.display='" + (drExpense["CNStatus"].ToString() == "Y" ? "none" : "block") + "';");
                                strDataUpdate.Append("document.getElementById('hdnExpSno'+document.getElementById('hdnExpRows').value).value ='" + drExpense["sno"] + "';");
                                ViewState["ExpenseTableSno"] = ViewState["ExpenseTableSno"].ToString() + drExpense["sno"].ToString() + ",";
                                hdnExpenseTableSno.Value = hdnExpenseTableSno.Value + drExpense["sno"].ToString() + ",";
                            }
                        }
                    }
                    else if (hdnPageType.Value == "CREATE" && blType == "H" && hdnGoodsRecSnos.Value != string.Empty)
                    {
                        // SB Nos
                        DataTable dtSBNos = comBus.GetList("sea_goods_recd", "'0' as sno,shipping_bill_no as shippingBillNo,shippingBillDate,goods_recd_dt,custom_clearance_dt", "'," + hdnGoodsRecSnos.Value + ",' like '%,'+CAST(goodsrecdid AS VARCHAR) +',%'");
                        if (dtSBNos.Rows.Count > 0)
                        {
                            foreach (DataRow drSBNos in dtSBNos.Rows)
                            {
                                strDataUpdate.Append("document.getElementById('txtSBNo').value ='" + drSBNos["shippingBillNo"] + "';");
                                strDataUpdate.Append("document.getElementById('txtSBDate').value ='" + (drSBNos["shippingBillDate"].ToString() == string.Empty || DateTime.Parse(drSBNos["shippingBillDate"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(drSBNos["shippingBillDate"].ToString()).ToString("dd-MM-yyyy")) + "';");
                                strDataUpdate.Append("addSBDataRow('tblSBDetail');");
                               // strDataUpdate.Append("document.getElementById(\"hdnSBSno\"+document.getElementById('hdnSBRows').value).value ='" + drSBNos["sno"] + "';");
                               // ViewState["SBTableSno"] = ViewState["SBTableSno"].ToString() + drSBNos["sno"].ToString() + ",";
                                //hdnSBTableSno.Value = hdnSBTableSno.Value + drSBNos["sno"].ToString() + ",";
                               
                            }
                            strDataUpdate.Append("document.getElementById('txtGoodsRecDate').value='" + (dtSBNos.Rows[0]["goods_recd_dt"].ToString() != string.Empty ? (DateTime.Parse(dtSBNos.Rows[0]["goods_recd_dt"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(dtSBNos.Rows[0]["goods_recd_dt"].ToString()).ToString("dd-MM-yyyy")) : string.Empty) + "';");
                            strDataUpdate.Append("document.getElementById('txtCustomClDate').value='" + (dtSBNos.Rows[0]["custom_clearance_dt"].ToString() != string.Empty ? (DateTime.Parse(dtSBNos.Rows[0]["custom_clearance_dt"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(dtSBNos.Rows[0]["custom_clearance_dt"].ToString()).ToString("dd-MM-yyyy")) : string.Empty) + "';");
                        }
                        else if (dsData.Tables[0].Rows[0]["SBNo"].ToString() != string.Empty)
                        {
                            strDataUpdate.Append("document.getElementById('txtSBNo').value=\"" + dsData.Tables[0].Rows[0]["SBNo"].ToString() + "\";");
                            strDataUpdate.Append("document.getElementById('txtSBDate').value='" + (dsData.Tables[0].Rows[0]["SBDate"].ToString() != string.Empty ? (DateTime.Parse(dsData.Tables[0].Rows[0]["SBDate"].ToString()).ToString("dd-MM-yyyy") == "31-12-9999" ? string.Empty : DateTime.Parse(dsData.Tables[0].Rows[0]["SBDate"].ToString()).ToString("dd-MM-yyyy")) : string.Empty) + "';");
                            strDataUpdate.Append("addSBDataRow('tblSBDetail');");
                        }
                    }
                    strDataUpdate.Append("document.getElementById('txtIECNo').value=\"" + dsData.Tables[0].Rows[0]["IECNo"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtHSCode').value=\"" + dsData.Tables[0].Rows[0]["HSCode"].ToString() + "\";");

                    strDataUpdate.Append("document.getElementById('txtCSealNo').value=\"" + dsData.Tables[0].Rows[0]["c_seal_no"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtContaing').value=\"" + dsData.Tables[0].Rows[0]["Containing"].ToString() + "\";");

                    strDataUpdate.Append("document.getElementById('txtMarks').value=\"" + dsData.Tables[0].Rows[0]["container_nos"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtDescriptionOfGoods').value=\"" + dsData.Tables[0].Rows[0]["package_description"].ToString().Replace('"', ' ') + "\";");
                    strDataUpdate.Append("document.getElementById('txtRemarks').value=\"" + dsData.Tables[0].Rows[0]["remarks"].ToString() + "\";");
                    strDataUpdate.Append("document.getElementById('txtDateOfIssue').value='" + DateTime.Parse(dsData.Tables[0].Rows[0]["bl_released_dt"].ToString()).ToString("dd-MM-yyyy") + "';");
                    strDataUpdate.Append("document.getElementById('txtPlace').value='" + dsData.Tables[0].Rows[0]["place_of_issue"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('hdnPlace').value='" + dsData.Tables[0].Rows[0]["place_of_issue"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('ddlBLReleasedType').value='" + dsData.Tables[0].Rows[0]["bl_released_type"].ToString() + "';");
                    if (blType == "H")
                        strDataUpdate.Append("document.getElementById('txtNoOfOriginals').value='" + dsData.Tables[0].Rows[0]["noof_originals_issued"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtCurrency').value='" + dsData.Tables[0].Rows[0]["BillingCurrency"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('hdnCurrency').value='" + dsData.Tables[0].Rows[0]["BillingCurrency"].ToString() + "';");
                    strDataUpdate.Append("document.getElementById('txtExchangeRate').value='" + dsData.Tables[0].Rows[0]["BillingExRate"].ToString() + "';");
                }
                if (strDataUpdate.ToString() != string.Empty)
                    ScriptManager.RegisterStartupScript(Page, typeof(Page), "ScriptBindValueForUpdate", strDataUpdate.ToString().Replace("\n", "   ").Replace("\r", " ").Replace("\t", " ").Trim(), true);
               
                //.Replace("\\s"," ")
            }
        }
    }
    // credit limit check
    public int checkCreditLimitStatus(string Customer, string IncomeAmt, string CustBrSNo)
    {

        BC.custBranchSNo =  CustBrSNo;
        DataSet dsCheckCrLimt = BC.checkCreditLimit();

        if (dsCheckCrLimt.Tables[0].Rows[0]["UserStatus"].ToString().ToUpper() == "BLOCKED")
        {
            hdnErrMsg.Value = "Unable to book this shipment because " + Customer + " has been Blacklisted. ";
            return 0;
        }
        if (dsCheckCrLimt.Tables[0].Rows[0]["PaymentMode"].ToString().ToUpper() == "CREDIT")
        {
            string CrLimitStatus = "";
            if (dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() == "0.00" && dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() == "0.00")
            {
                //hdnErrMsg.Value = "Unable to book this shipment because Availaible Credit Limit defined for " + Customer + " is Zero.";
                //return 0;
                if (Convert.ToDecimal(dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString()) < Convert.ToDecimal(IncomeAmt))
                {
                    hdnErrMsg.Value = "Unable to book this shipment because of less Credit Limit for " + Customer;
                    return 0;
                }
            }
            if (dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() == "" && dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() == "")
            {
                hdnErrMsg.Value = "Unable to book this shipment because of  Credit Limit is not defined for  " + Customer + ".";
                return 0;
            }
            if (dsCheckCrLimt.Tables[0].Rows[0]["BReviewDate"].ToString() == string.Empty || dsCheckCrLimt.Tables[0].Rows[0]["GReviewDate"].ToString() == string.Empty)
            {
                hdnErrMsg.Value = "Unable to book this shipment because Credit Limit for " + Customer + " not reviewed.";
                return 0;
            }
            if (dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != "0.00" && dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != string.Empty)
            {
                CrLimitStatus = "Branch";
                if (Convert.ToDateTime(dsCheckCrLimt.Tables[0].Rows[0]["BReviewDate"].ToString()) < System.DateTime.Today)
                {
                    hdnErrMsg.Value = "Unable to book this shipment because Credit Limit has expired for this customer on  " + dsCheckCrLimt.Tables[0].Rows[0]["BReviewDate"].ToString();
                    return 0;
                }
                if (Convert.ToDecimal(dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString()) < Convert.ToDecimal(IncomeAmt))
                {
                    hdnErrMsg.Value = "Unable to book this shipment because of less Credit Limit for " + Customer;
                    return 0;
                }
                hdnErrMsg.Value = "";
            }
            if (dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != "0.00" && dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != string.Empty)
            {
                CrLimitStatus = "Group";
                if (Convert.ToDateTime(dsCheckCrLimt.Tables[0].Rows[0]["GReviewDate"].ToString()) < System.DateTime.Today)
                {
                    hdnErrMsg.Value = "Unable to book this shipment because Credit Limit has expired for this customer on  " + dsCheckCrLimt.Tables[0].Rows[0]["GReviewDate"].ToString();
                    return 0;
                }
                if (Convert.ToDecimal(dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString()) < Convert.ToDecimal(IncomeAmt))
                {
                    hdnErrMsg.Value = "Unable to book this shipment because of less Credit Limit for " + Customer;
                    return 0;
                }
                hdnErrMsg.Value = "";
            }

        }
        //hdnErrMsg.Value = "";
        return 1;
    }
    // Save and Update Data
    protected void btnSave_Click(object sender, EventArgs e)
    {            
        DateTime blDate, etaDate, etdDate, goodsRecDate, customClDate, issueDate;
        decimal SbCessTax,SBCessTaxAmt;
        try
        {
            blDate = DateTime.Parse(Request.Form["txtBLDate"].Split('-')[1] + '-' + Request.Form["txtBLDate"].Split('-')[0] + '-' + Request.Form["txtBLDate"].Split('-')[2]);
        }
        catch { blDate = DateTime.Parse(DateTime.Parse(Request.Form["txtBLDate"].ToString()).ToString("MMM dd yyyy")); }  
        if (Request.Form["hdnCrLimit"].ToString().ToUpper() != "CASH" && (Request.Form["hdnRbtnBillTo"] == "Y" || Request.Form["rbtnBillTo"] == "Y") && blDate >= DateTime.Parse("Jun 11 2012"))
        {
            if (checkCreditLimitStatus(Request.Form["txtBillTo"].ToString(), hdnTotalIncomeAmount.Value, Request.Form["hdnBillToSno"].ToString()) == 0)
                return;
        }
        try
        {
            etaDate = DateTime.Parse(Request.Form["txtETADate"].Split('-').Length > 1 ? Request.Form["txtETADate"].Split('-')[1] + '-' + Request.Form["txtETADate"].Split('-')[0] + '-' + Request.Form["txtETADate"].Split('-')[2] : "Dec 31 9999");
        }
        catch { etaDate = DateTime.Parse(DateTime.Parse(Request.Form["txtETADate"].ToString()).ToString("MMM dd yyyy")); }
        try
        {
            etdDate = DateTime.Parse(Request.Form["txtETDDate"].Split('-').Length > 1 ? Request.Form["txtETDDate"].Split('-')[1] + '-' + Request.Form["txtETDDate"].Split('-')[0] + '-' + Request.Form["txtETDDate"].Split('-')[2] : "Dec 31 9999");
        }
        catch { etdDate = DateTime.Parse(DateTime.Parse(Request.Form["txtETDDate"].ToString()).ToString("MMM dd yyyy")); }
        try
        {
            goodsRecDate = DateTime.Parse(Request.Form["txtGoodsRecDate"].Split('-').Length > 1 ? Request.Form["txtGoodsRecDate"].Split('-')[1] + '-' + Request.Form["txtGoodsRecDate"].Split('-')[0] + '-' + Request.Form["txtGoodsRecDate"].Split('-')[2] : "Dec 31 9999");
        }
        catch { goodsRecDate = DateTime.Parse(DateTime.Parse(Request.Form["txtGoodsRecDate"].ToString()).ToString("MMM dd yyyy")); }
        try
        {
            customClDate = DateTime.Parse(Request.Form["txtCustomClDate"].Split('-').Length > 1 ? Request.Form["txtCustomClDate"].Split('-')[1] + '-' + Request.Form["txtCustomClDate"].Split('-')[0] + '-' + Request.Form["txtCustomClDate"].Split('-')[2] : "Dec 31 9999");
        }
        catch { customClDate = DateTime.Parse(DateTime.Parse(Request.Form["txtCustomClDate"].ToString()).ToString("MMM dd yyyy")); }
        try
        {
            issueDate = DateTime.Parse(Request.Form["txtDateOfIssue"].Split('-')[1] + '-' + Request.Form["txtDateOfIssue"].Split('-')[0] + '-' + Request.Form["txtDateOfIssue"].Split('-')[2]);
        }
        catch { issueDate = DateTime.Parse(DateTime.Parse(Request.Form["txtDateOfIssue"].ToString()).ToString("MMM dd yyyy")); }
        string inserted = "", insertedFromPNPToComp = "", PNPToCompBillTo = "", PNPToCompBillToCode = "";
        GeneralFunction GF = new GeneralFunction();
        SqlConnection con = new SqlConnection(GF.ConnectionString);
        SqlTransaction tr = null;
        try
        {
            DateTime SBDate, InvoiceDate;
            string containing, IECNo, HSCode;
            con.Open();
            tr = con.BeginTransaction();
            //copyToBaseComapny,JobType,jobNo,SubJobAllowed,JobStatus
            bSea.bl_type = hdnBLType.Value;
            bSea.job_no = Request.Form["lblJobNo"] == null ? hdnJobNo.Value : Request.Form["lblJobNo"];
            bSea.mbl_no = Request.Form["txtMBLNo"];
            bSea.hbl_no = Request.Form["txtHBLNo"];
            bSea.bl_date = blDate;
            bSea.cbm = Math.Round(decimal.Parse(Request.Form["txtVolWt"].ToString() == string.Empty ? "0" : Request.Form["txtVolWt"]), 5);
            bSea.net_wt = Math.Round(decimal.Parse(Request.Form["txtNetWt"].ToString() == string.Empty ? "0" : Request.Form["txtNetWt"]), 3);
            bSea.gross_wt = Math.Round(decimal.Parse(Request.Form["txtGrossWt"].ToString() == string.Empty ? "0" : Request.Form["txtGrossWt"]), 3);
            bSea.freight_type = Request.Form["ddlFreight"];
            bSea.ihc = Request.Form["rbtnTHCIHC"].ToString() == "IHC" ? Request.Form["ddlTHCIHC"] : string.Empty;
            bSea.no_of_packages = int.Parse(Request.Form["txtPackages"].ToString() == string.Empty ? "0" : Request.Form["txtPackages"]);
            bSea.eta_dt = etaDate;
            bSea.shipping_line = Request.Form["txtShippingLine"];
            //ETD
            bSea.loading_port = Request.Form["txtLoadingPort"]; //txtPortofLand.Text.ToUpper();
            bSea.discharge_port = Request.Form["txtDischargePort"];
            bSea.receipt_place = Request.Form["txtAcceptance"]; //txtplaceofAccept.Text.ToUpper();
            bSea.delivery_place = Request.Form["txtDeliveryPlace"];
            bSea.vessel = Request.Form["txtVessel"];
            //Voyage,Bill,BillTo,BillTo_Code,Rotation
            //bSea.marketed_by = Request.Form["txtShippingLine"]; //txtMarketedBy.Text.Trim();
            //**************Shipper Info *********************
            bSea.shipper_name = Request.Form["txtShipper"]; //txtShNames.Text;
            bSea.shipper_address = Request.Form["txtShipperAddress"]; //txtShAddress.Text;
            bSea.shipper_phone = Request.Form["txtShipperPhone"]; //txtSPhone.Text;
            bSea.shipper_email = Request.Form["txtShipperEmail"]; //txtSEmail.Text;
            bSea.shipper_code = Request.Form["hdnShipperSno"]; //hndShNames.Value;
            //**************END**********************
            //**************Consignee Info *********************
            bSea.consignee_name = Request.Form["txtConsignee"]; //txtCnNames.Text;
            bSea.consignee_address = Request.Form["txtConsigneeAddress"]; //txtCnAddress.Text;
            bSea.consignee_phone = Request.Form["txtConsigneePhone"]; //txtCPhone.Text;
            bSea.consignee_email = Request.Form["txtConsigneeEmail"]; //txtCEmail.Text;
            bSea.consignee_code = Request.Form["hdnConsigneeSno"]; //hdnCNNames.Value;
            //**************END**********************
            //**************Notify Info *********************
            bSea.notify_name = Request.Form["txtNotify1"]; //txtNotifyName.Text;
            bSea.notify_address = Request.Form["txtNotify1Address"]; //txtNotifyAdd.Text;
            bSea.notify_email = Request.Form["txtNotify1Email"]; //txtNEmail.Text;
            bSea.notify_phone = Request.Form["txtNotify1Phone"]; //txtNPhone.Text;
            bSea.notify_code = Request.Form["hdnNotify1Sno"]; //hdnNotifyName.Value;
            //**********End********************
            //**********Delivery Agent Info ******************
            bSea.delivery_name = Request.Form["txtDelivery"]; //txtDeliveryName.Text;
            bSea.delivery_address = Request.Form["txtDeliveryAddress"]; //txtDeliveryAdd.Text;
            bSea.delivery_email = Request.Form["txtDeliveryEmail"]; //txtDEmail.Text;
            bSea.delivery_phone = Request.Form["txtDeliveryPhone"]; //txtDPhone.Text;
            bSea.delivery_code = Request.Form["hdnDeliverySno"]; //hdnDeliveryName.Value;
            //*****************end***********************
            // Notify2,Notify3,DestAgent,ForwAgent,LocalAgent,SalesPerson,BusinessType,NetworkGroup
            bSea.actual_customer_code = Request.Form["hdnActCustSno"];
            bSea.actual_customer_name = Request.Form["txtActualCustomer"];
            //OverseasCode,OverseasAgent
            // bSea.container_no = Request.Form["txtContainerNo"];
            bSea.container_type = Request.Form["ddlContainerType"];
            //ExhibitionId
            bSea.pre_carriage_by = Request.Form["txtPreCarriageBy"];
            bSea.commodity = Request.Form["txtCommodity"]; //txtComm.Text;
            bSea.goods_recd_dt = goodsRecDate;
            bSea.custom_clearance_dt = customClDate;            
            containing = Request.Form["txtContaing"];
            IECNo = Request.Form["txtIECNo"];
            HSCode = Request.Form["txtHSCode"];
            // bSea.l_seal_no = Request.Form["txtLSealNo"];
            bSea.c_seal_no = Request.Form["txtCSealNo"];
            bSea.container_nos = Request.Form["txtMarks"];
            bSea.package_description = Request.Form["txtDescriptionOfGoods"];
            bSea.remarks = Request.Form["txtRemarks"];
            bSea.bl_released_dt = issueDate;
            bSea.place_of_issue = Request.Form["txtPlace"];
            bSea.noof_originals_issued = hdnBLType.Value == "H" ? Request.Form["txtNoOfOriginals"] : string.Empty;
            bSea.CompBrSNo = Session["CompBrSNo"].ToString();
            bSea.entered_by = Session["UserID"].ToString();
            bSea.bl_released_type = Request.Form["ddlBLReleasedType"];
            // decimal IncomeAmount = 0, IncomeSTaxAmt = 0, TotalIncomeAmount = 0, ExpenseAmount = 0, ExpenseSTaxAmt = 0, TotalExpenseAmount = 0;
            BRFQ_Booking BR = new BRFQ_Booking();
            DataSet dsParentCompDet = BR.FINDPARENTCOMPAYBYCITY(Session["CompBrSno"].ToString());
            DataSet dsCustBrSno = BC.getOtherCompanyCustBrSno(int.Parse(dsParentCompDet.Tables[0].Rows[0]["Sno"].ToString()));
            //insertSeaBL
            if (pType == "CREATE")
            {
                // inser data into login company
                inserted = bSea.insertSeaBL(tr, Request.Form["ddlJobType"], (hdnBLType.Value == "H" ? "N" : Request.Form["ddlSubJob"]), Request.Form["ddlJobStatus"], etdDate, Request.Form["txtVoyage"], Request.Form["rbtnBillTo"], (Request.Form["rbtnBillTo"].ToString() == "Y" ? Request.Form["txtBillTo"] : string.Empty), (Request.Form["rbtnBillTo"].ToString() == "Y" ? int.Parse(Request.Form["hdnBillToSno"].ToString()) : 0), int.Parse(Request.Form["txtRotationNo"].ToString() == string.Empty ? "0" : Request.Form["txtRotationNo"].ToString()), int.Parse(Request.Form["hdnNotify2Sno"].ToString() == string.Empty ? "0" : Request.Form["hdnNotify2Sno"].ToString()), Request.Form["txtNotify2"], Request.Form["txtNotify2Address"], Request.Form["txtNotify2Email"], Request.Form["txtNotify2Phone"], int.Parse(Request.Form["hdnNotify3Sno"].ToString() == string.Empty ? "0" : Request.Form["hdnNotify3Sno"].ToString()), Request.Form["txtNotify3"], Request.Form["txtNotify3Address"], Request.Form["txtNotify3Email"], Request.Form["txtNotify3Phone"], int.Parse(Request.Form["hdnDestAgentSno"].ToString() == string.Empty ? "0" : Request.Form["hdnDestAgentSno"].ToString()), Request.Form["txtDestAgent"], int.Parse(Request.Form["hdnForwAgentSno"].ToString() == string.Empty ? "0" : Request.Form["hdnForwAgentSno"].ToString()), Request.Form["txtForwAgent"], int.Parse(Request.Form["hdnLocalAgentSno"].ToString() == string.Empty ? "0" : Request.Form["hdnLocalAgentSno"].ToString()), Request.Form["txtLocalAgent"], Request.Form["ddlSalesPerson"], Request.Form["ddlBusinesstype"], (Request.Form["ddlNetworkGroup"] == null ? string.Empty : Request.Form["ddlNetworkGroup"]), int.Parse(Request.Form["hdnOverseasAgentSno"].ToString() == "undefined" || Request.Form["hdnOverseasAgentSno"].ToString() == string.Empty ? "0" : Request.Form["hdnOverseasAgentSno"].ToString()), Request.Form["txtOverseasAgent"], (bSea.container_type.ToUpper().Contains("EXHIBITION") ? int.Parse(Request.Form["ddlexhibitionlist"].ToString()) : 0), Request.Form["ddlProductOther"].ToString(), hdnSEAType.Value, (Request.Form["txtTue"] == null || Request.Form["txtTue"] == string.Empty ? "0" : Request.Form["txtTue"]), IECNo, HSCode, containing, Request.Form["txtCurrency"].ToString(), decimal.Parse(Request.Form["txtExchangeRate"].ToString()), (decimal.Parse(hdnTotalIncomeAmount.Value) - decimal.Parse(hdnIncomeSTaxAmt.Value)), decimal.Parse(hdnIncomeSTaxAmt.Value), decimal.Parse(hdnTotalIncomeAmount.Value), (decimal.Parse(hdnTotalExpenseAmount.Value) - decimal.Parse(hdnExpenseSTaxAmt.Value)), decimal.Parse(hdnExpenseSTaxAmt.Value), decimal.Parse(hdnTotalExpenseAmount.Value), decimal.Parse(Request.Form["txtBillingCBM"].ToString() == string.Empty ? "0" : Request.Form["txtBillingCBM"].ToString()), Request.Form["ddlJobSubType"].ToString(), hdnGoodsRecSnos.Value, (Request.Form["rbtnTHCIHC"].ToString() == "THC" ? Request.Form["ddlTHCIHC"] : string.Empty), decimal.Parse(Request.Form["txtBaseFreight"].ToString() == string.Empty ? "0" : Request.Form["txtBaseFreight"].ToString()),hdnBookingRedIntlSnos.Value);                
                // inser data into base company(if Company is PNP and copy to base company checked)               
                if (Request.Form["cboxBaseCompany"] != null && Session["CompBrType"].Equals("PNP"))
                {
                    ////if (Session["CompBrSno"].ToString() == "53" || Session["CompBrSno"].ToString() == "54" || Session["CompBrSno"].ToString() == "55" || Session["CompBrSno"].ToString() == "56")
                    ////  {
                    ////        bSea.CompBrSNo = "35";
                    ////  }
                      ////else  if (Session["CompBrSno"].ToString() == "54")
                      ////{
                      ////    bSea.CompBrSNo = "35";
                      ////}


                    if (Session["CompBrSno"].ToString() == "53" || Session["CompBrSno"].ToString() == "56")
                    {
                        bSea.CompBrSNo = "35";
                    }

                    else if (Session["CompBrSno"].ToString() == "54" || Session["CompBrSno"].ToString() == "55")
                    {
                        bSea.CompBrSNo = "1";
                    }


                      else
                      {
                            bSea.CompBrSNo = dsParentCompDet.Tables[0].Rows[0]["Sno"].ToString();
                      }
                    
                    int Notify2Code = 0, Notify3Code = 0, DestAgentCode = 0, ForwAgentCode = 0, LocalAgentCode = 0, OverseasAgentCode = 0;
                    string Notify2Name = string.Empty, Notify2Address = string.Empty, Notify2Phone = string.Empty, Notify2Email = string.Empty, Notify3Name = string.Empty, Notify3Address = string.Empty, Notify3Phone = string.Empty, Notify3Email = string.Empty, DestAgent = string.Empty, ForwAgent = string.Empty, LocalAgent = string.Empty, OverseasAgent = string.Empty;
                    //**************Shipper Info *********************
                    DataView dvShipper = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtShipper"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvShipper.ToTable().Rows.Count > 0)
                    {
                        bSea.shipper_name = dvShipper.ToTable().Rows[0]["CustomerName"].ToString(); //txtShNames.Text;
                        bSea.shipper_address = dvShipper.ToTable().Rows[0]["Address"].ToString(); //txtShAddress.Text;
                        bSea.shipper_phone = dvShipper.ToTable().Rows[0]["Phone"].ToString(); //txtSPhone.Text;
                        bSea.shipper_email = dvShipper.ToTable().Rows[0]["Email"].ToString(); //txtSEmail.Text;
                        bSea.shipper_code = dvShipper.ToTable().Rows[0]["Sno"].ToString(); //hndShNames.Value;
                    }
                    //**************END**********************
                    //**************Consignee Info *********************
                    DataView dvConsignee = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtConsignee"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvConsignee.ToTable().Rows.Count > 0)
                    {
                        bSea.consignee_name = dvConsignee.ToTable().Rows[0]["CustomerName"].ToString(); //txtCnNames.Text;
                        bSea.consignee_address = dvConsignee.ToTable().Rows[0]["Address"].ToString(); //txtCnAddress.Text;
                        bSea.consignee_phone = dvConsignee.ToTable().Rows[0]["Phone"].ToString(); //txtCPhone.Text;
                        bSea.consignee_email = dvConsignee.ToTable().Rows[0]["Email"].ToString(); //txtCEmail.Text;
                        bSea.consignee_code = dvConsignee.ToTable().Rows[0]["Sno"].ToString(); //hdnCNNames.Value;
                    }
                    //**************END**********************
                    //**************Notify1 Info *********************
                    DataView dvNotify1 = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtNotify1"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvNotify1.ToTable().Rows.Count > 0)
                    {
                        bSea.notify_name = dvNotify1.ToTable().Rows[0]["CustomerName"].ToString(); //txtNotifyName.Text;
                        bSea.notify_address = dvNotify1.ToTable().Rows[0]["Address"].ToString(); //txtNotifyAdd.Text;
                        bSea.notify_email = dvNotify1.ToTable().Rows[0]["Email"].ToString(); //txtNEmail.Text;
                        bSea.notify_phone = dvNotify1.ToTable().Rows[0]["Phone"].ToString(); //txtNPhone.Text;
                        bSea.notify_code = dvNotify1.ToTable().Rows[0]["Sno"].ToString(); //hdnNotifyName.Value;
                    }
                    //**********End********************
                    //**********Delivery Agent Info ******************
                    DataView dvDeliveryAgent = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtDelivery"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvDeliveryAgent.ToTable().Rows.Count > 0)
                    {
                        bSea.delivery_name = dvDeliveryAgent.ToTable().Rows[0]["CustomerName"].ToString(); //txtDeliveryName.Text;
                        bSea.delivery_address = dvDeliveryAgent.ToTable().Rows[0]["Address"].ToString(); //txtDeliveryAdd.Text;
                        bSea.delivery_email = dvDeliveryAgent.ToTable().Rows[0]["Email"].ToString(); //txtDEmail.Text;
                        bSea.delivery_phone = dvDeliveryAgent.ToTable().Rows[0]["Phone"].ToString(); //txtDPhone.Text;
                        bSea.delivery_code = dvDeliveryAgent.ToTable().Rows[0]["Sno"].ToString(); //hdnDeliveryName.Value;
                    }
                    //*****************end***********************
                    //**************Notify2 Info *********************
                    DataView dvNotify2 = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtNotify2"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvNotify2.ToTable().Rows.Count > 0)
                    {
                        Notify2Name = dvNotify2.ToTable().Rows[0]["CustomerName"].ToString(); //txtNotifyName.Text;
                        Notify2Address = dvNotify2.ToTable().Rows[0]["Address"].ToString(); //txtNotifyAdd.Text;
                        Notify2Email = dvNotify2.ToTable().Rows[0]["Email"].ToString(); //txtNEmail.Text;
                        Notify2Phone = dvNotify2.ToTable().Rows[0]["Phone"].ToString(); //txtNPhone.Text;
                        Notify2Code = int.Parse(dvNotify2.ToTable().Rows[0]["Sno"].ToString()); //hdnNotifyName.Value;
                    }
                    //**********End********************
                    //**************Notify3 Info *********************
                    DataView dvNotify3 = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtNotify3"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvNotify3.ToTable().Rows.Count > 0)
                    {
                        Notify3Name = dvNotify3.ToTable().Rows[0]["CustomerName"].ToString(); //txtNotifyName.Text;
                        Notify3Address = dvNotify3.ToTable().Rows[0]["Address"].ToString(); //txtNotifyAdd.Text;
                        Notify3Email = dvNotify3.ToTable().Rows[0]["Email"].ToString(); //txtNEmail.Text;
                        Notify3Phone = dvNotify3.ToTable().Rows[0]["Phone"].ToString(); //txtNPhone.Text;
                        Notify3Code = int.Parse(dvNotify3.ToTable().Rows[0]["Sno"].ToString()); //hdnNotifyName.Value;
                    }
                    //**********End********************
                    //**************Destination Agent Info *********************
                    DataView dvDestAgent = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtDestAgent"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvDestAgent.ToTable().Rows.Count > 0)
                    {
                        DestAgent = dvDestAgent.ToTable().Rows[0]["CustomerName"].ToString();
                        DestAgentCode = int.Parse(dvDestAgent.ToTable().Rows[0]["Sno"].ToString());
                    }
                    //**********End********************
                    //**************Forwarding Agent Info *********************
                    DataView dvForwAgent = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtForwAgent"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvForwAgent.ToTable().Rows.Count > 0)
                    {
                        ForwAgent = dvForwAgent.ToTable().Rows[0]["CustomerName"].ToString();
                        ForwAgentCode = int.Parse(dvForwAgent.ToTable().Rows[0]["Sno"].ToString());
                    }
                    //**********End********************
                    //**************Local Agent Info *********************
                    DataView dvLocalAgent = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtLocalAgent"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvLocalAgent.ToTable().Rows.Count > 0)
                    {
                        LocalAgent = dvLocalAgent.ToTable().Rows[0]["CustomerName"].ToString();
                        LocalAgentCode = int.Parse(dvLocalAgent.ToTable().Rows[0]["Sno"].ToString());
                    }
                    //**********End********************
                    // Notify2,Notify3,DestAgent,ForwAgent,LocalAgent,SalesPerson,BusinessType,NetworkGroup
                    //**************Actual Customer Info *********************
                    DataView dvActCust = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtActualCustomer"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvActCust.ToTable().Rows.Count > 0)
                    {
                        bSea.actual_customer_code = dvActCust.ToTable().Rows[0]["Sno"].ToString();
                        bSea.actual_customer_name = dvActCust.ToTable().Rows[0]["CustomerName"].ToString();
                    }
                    //**********End********************
                    //**************Overseas Customer Info *********************
                    DataView dvOverseasAgent = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["txtOverseasAgent"] + "'", "CustomerName", DataViewRowState.CurrentRows);
                    if (dvOverseasAgent.ToTable().Rows.Count > 0)
                    {
                        OverseasAgentCode = int.Parse(dvOverseasAgent.ToTable().Rows[0]["Sno"].ToString());
                        OverseasAgent = dvOverseasAgent.ToTable().Rows[0]["CustomerName"].ToString();
                    }
                    //**********End********************
                    PNPToCompBillTo = dsParentCompDet.Tables[1].Rows[0]["Name"].ToString();
                    PNPToCompBillToCode = dsParentCompDet.Tables[1].Rows[0]["CustBrSno"].ToString();
                    insertedFromPNPToComp = bSea.insertSeaBL(tr, Request.Form["ddlJobType"], (hdnBLType.Value == "H" ? "N" : Request.Form["ddlSubJob"]), Request.Form["ddlJobStatus"], etdDate, Request.Form["txtVoyage"], Request.Form["rbtnBillTo"], (Request.Form["rbtnBillTo"].ToString() == "Y" ? dsParentCompDet.Tables[1].Rows[0]["Name"].ToString() : string.Empty), (Request.Form["rbtnBillTo"].ToString() == "Y" ? int.Parse(dsParentCompDet.Tables[1].Rows[0]["CustBrSno"].ToString()) : 0), int.Parse(Request.Form["txtRotationNo"].ToString() == string.Empty ? "0" : Request.Form["txtRotationNo"].ToString()), Notify2Code, Notify2Name, Notify2Address, Notify2Email, Notify2Phone, Notify3Code, Notify3Name, Notify3Address, Notify3Email, Notify3Phone, DestAgentCode, DestAgent, ForwAgentCode, ForwAgent, LocalAgentCode, LocalAgent, Request.Form["ddlSalesPerson"], Request.Form["ddlBusinesstype"], (Request.Form["ddlNetworkGroup"] == null ? string.Empty : Request.Form["ddlNetworkGroup"]), OverseasAgentCode, OverseasAgent, (bSea.container_type.ToUpper().Contains("EXHIBITION") ? int.Parse(Request.Form["ddlexhibitionlist"].ToString()) : 0), Request.Form["ddlProductOther"].ToString(), hdnSEAType.Value, (Request.Form["txtTue"] == null || Request.Form["txtTue"] == string.Empty ? "0" : Request.Form["txtTue"]), IECNo, HSCode, containing, Request.Form["txtCurrency"].ToString(), decimal.Parse(Request.Form["txtExchangeRate"].ToString()), (decimal.Parse(hdnTotalIncomeAmount.Value) - decimal.Parse(hdnIncomeSTaxAmt.Value)), decimal.Parse(hdnIncomeSTaxAmt.Value), decimal.Parse(hdnTotalIncomeAmount.Value), (decimal.Parse(hdnTotalExpenseAmount.Value) - decimal.Parse(hdnExpenseSTaxAmt.Value)), decimal.Parse(hdnExpenseSTaxAmt.Value), decimal.Parse(hdnTotalExpenseAmount.Value), decimal.Parse(Request.Form["txtBillingCBM"].ToString() == string.Empty ? "0" : Request.Form["txtBillingCBM"].ToString()), Request.Form["ddlJobSubType"].ToString(), hdnGoodsRecSnos.Value, (Request.Form["rbtnTHCIHC"].ToString() == "THC" ? Request.Form["ddlTHCIHC"] : string.Empty), decimal.Parse(Request.Form["txtBaseFreight"].ToString() == string.Empty ? "0" : Request.Form["txtBaseFreight"].ToString()),hdnBookingRedIntlSnos.Value);

                }
              

            }
            else if (pType == "UPDATE")
            {
                bSea.sno = int.Parse(hdnSno.Value);
                inserted = bSea.updateSeaBL(tr, Request.Form["ddlJobStatus"], etdDate, Request.Form["txtVoyage"], (Request.Form["hdnRbtnStatus"] == "True" ? Request.Form["rbtnBillTo"] : Request.Form["hdnRbtnBillTo"]), ((Request.Form["hdnRbtnStatus"] == "True" ? Request.Form["rbtnBillTo"] : Request.Form["hdnRbtnBillTo"]) == "Y" ? Request.Form["txtBillTo"] : string.Empty), ((Request.Form["hdnRbtnStatus"] == "True" ? Request.Form["rbtnBillTo"] : Request.Form["hdnRbtnBillTo"]) == "Y" ? int.Parse(Request.Form["hdnBillToSno"].ToString()) : 0), int.Parse(Request.Form["txtRotationNo"].ToString() == string.Empty ? "0" : Request.Form["txtRotationNo"].ToString()), int.Parse(Request.Form["hdnNotify2Sno"].ToString() == string.Empty ? "0" : Request.Form["hdnNotify2Sno"].ToString()), Request.Form["txtNotify2"], Request.Form["txtNotify2Address"], Request.Form["txtNotify2Email"], Request.Form["txtNotify2Phone"], int.Parse(Request.Form["hdnNotify3Sno"].ToString() == string.Empty ? "0" : Request.Form["hdnNotify3Sno"].ToString()), Request.Form["txtNotify3"], Request.Form["txtNotify3Address"], Request.Form["txtNotify3Email"], Request.Form["txtNotify3Phone"], int.Parse(Request.Form["hdnDestAgentSno"].ToString() == string.Empty ? "0" : Request.Form["hdnDestAgentSno"].ToString()), Request.Form["txtDestAgent"], int.Parse(Request.Form["hdnForwAgentSno"].ToString() == string.Empty ? "0" : Request.Form["hdnForwAgentSno"].ToString()), Request.Form["txtForwAgent"], int.Parse(Request.Form["hdnLocalAgentSno"].ToString() == string.Empty ? "0" : Request.Form["hdnLocalAgentSno"].ToString()), Request.Form["txtLocalAgent"], Request.Form["ddlSalesPerson"], Request.Form["ddlBusinesstype"], (Request.Form["ddlNetworkGroup"] == null ? string.Empty : Request.Form["ddlNetworkGroup"]), int.Parse(Request.Form["hdnOverseasAgentSno"].ToString() == "undefined" || Request.Form["hdnOverseasAgentSno"].ToString() == string.Empty ? "0" : Request.Form["hdnOverseasAgentSno"].ToString()), Request.Form["txtOverseasAgent"], (bSea.container_type.ToUpper().Contains("EXHIBITION") ? int.Parse(Request.Form["ddlexhibitionlist"].ToString()) : 0), Request.Form["ddlProductOther"].ToString(), hdnSEAType.Value, (Request.Form["txtTue"] == null || Request.Form["txtTue"] == string.Empty ? "0" : Request.Form["txtTue"]), IECNo, HSCode, containing, Request.Form["txtCurrency"].ToString(), decimal.Parse(Request.Form["txtExchangeRate"].ToString()), (decimal.Parse(hdnTotalIncomeAmount.Value) - decimal.Parse(hdnIncomeSTaxAmt.Value)), decimal.Parse(hdnIncomeSTaxAmt.Value), decimal.Parse(hdnTotalIncomeAmount.Value), (decimal.Parse(hdnTotalExpenseAmount.Value) - decimal.Parse(hdnExpenseSTaxAmt.Value)), decimal.Parse(hdnExpenseSTaxAmt.Value), decimal.Parse(hdnTotalExpenseAmount.Value), decimal.Parse(Request.Form["txtBillingCBM"].ToString() == string.Empty ? "0" : Request.Form["txtBillingCBM"].ToString()), Request.Form["ddlJobSubType"].ToString(), hdnGoodsRecSnos.Value, (Request.Form["rbtnTHCIHC"].ToString() == "THC" ? Request.Form["ddlTHCIHC"] : string.Empty), decimal.Parse(Request.Form["txtBaseFreight"].ToString() == string.Empty ? "0" : Request.Form["txtBaseFreight"].ToString()),hdnBookingRedIntlSnos.Value);
               
            }
            // update goods rec.
            if (hdnGoodsRecSnos.Value != string.Empty && hdnGoodsRecSnos.Value != "0")
                bSea.updateSeaGoodsRecAfterHBLCreation(int.Parse(inserted), hdnGoodsRecSnos.Value);
            // Update SeaBooking RedIntl Record.
            if (hdnBookingRedIntlSnos.Value != string.Empty && hdnBookingRedIntlSnos.Value != "0")
                bSea.updateSeaBookingRedIntlAfterHBLCreation( int.Parse(inserted),bSea.hbl_no, hdnBookingRedIntlSnos.Value);
            // insert/Update container details
            for (int i = 1; i <= int.Parse(Request.Form["hdnContainerRows"].ToString()); i++)
            {
                if (Request.Form["hdnContainerNo" + i] != null)
                {
                    bSea.insertUpdateSeaContainerDetail(tr, int.Parse(Request.Form["hdnContainerSno" + i].ToString()), int.Parse(inserted), bSea.job_no, Request.Form["hdnContainerNo" + i].ToString(), Request.Form["hdnContType" + i].ToString(), Request.Form["hdnLSealNo" + i].ToString(), int.Parse(Request.Form["hdnContainerPkgs" + i].ToString()), decimal.Parse(Request.Form["hdnContainerNetWt" + i].ToString()), decimal.Parse(Request.Form["hdnContainerGrWt" + i].ToString()), decimal.Parse(Request.Form["hdnContainerVolWt" + i].ToString()), Session["UserId"].ToString());

                    if (pType == "UPDATE")
                    {
                        //ViewState["ContainerTableSno"].ToString().Replace("," + Request.Form["hdnContainerSno" + i].ToString() + ",", ",");
                        hdnContainerTableSno.Value = hdnContainerTableSno.Value.Replace("," + Request.Form["hdnContainerSno" + i].ToString() + ",", ",");
                    }

                    if (insertedFromPNPToComp != "")
                        bSea.insertUpdateSeaContainerDetail(tr, int.Parse(Request.Form["hdnContainerSno" + i].ToString()), int.Parse(insertedFromPNPToComp), bSea.job_no, Request.Form["hdnContainerNo" + i].ToString(), Request.Form["hdnContType" + i].ToString(), Request.Form["hdnLSealNo" + i].ToString(), int.Parse(Request.Form["hdnContainerPkgs" + i].ToString()), decimal.Parse(Request.Form["hdnContainerNetWt" + i].ToString()), decimal.Parse(Request.Form["hdnContainerGrWt" + i].ToString()), decimal.Parse(Request.Form["hdnContainerVolWt" + i].ToString()), Session["UserId"].ToString());
                    
                }
            }
            // insert/Update SBNo details
            for (int j = 1; j <= int.Parse(Request.Form["hdnSBRows"].ToString()); j++)
            {
                if (Request.Form["hdnSBNo" + j] != null)
                {
                    try
                    {
                        SBDate = DateTime.Parse(Request.Form["hdnSBDate" + j].Split('-')[1] + '-' + Request.Form["hdnSBDate" + j].Split('-')[0] + '-' + Request.Form["hdnSBDate" + j].Split('-')[2]);
                        
                    }
                    catch
                    {
                        SBDate = DateTime.Parse(Request.Form["hdnSBDate" + j] == null || Request.Form["hdnSBDate" + j].ToString() == string.Empty ? "Dec 31 9999" : Request.Form["hdnSBDate" + j].ToString());
                    }
                    bSea.insertUpdateSeaSBillsDetail(tr, int.Parse(Request.Form["hdnSBSno" + j].ToString()), int.Parse(inserted), bSea.job_no, Request.Form["hdnSBNo" + j], SBDate, Session["UserId"].ToString());

                    if (pType == "UPDATE")
                    {
                        //ViewState["SBTableSno"].ToString().Replace("," + Request.Form["hdnSBSno" + j].ToString() + ",", ",");
                        hdnSBTableSno.Value = hdnSBTableSno.Value.Replace("," + Request.Form["hdnSBSno" + j].ToString() + ",", ",");
                    }

                    if (insertedFromPNPToComp != "")
                        bSea.insertUpdateSeaSBillsDetail(tr, int.Parse(Request.Form["hdnSBSno" + j].ToString()), int.Parse(insertedFromPNPToComp), bSea.job_no, Request.Form["hdnSBNo" + j], SBDate, Session["UserId"].ToString());
                    
                }
            }
            // insert/Update BL Invoice details
            for (int k = 1; k <= int.Parse(Request.Form["hdnBLInvoiceRows"].ToString()); k++)
            {
                if (Request.Form["hdnInvoiceNo" + k] != null)
                {
                    try
                    {
                        InvoiceDate = DateTime.Parse(Request.Form["hdnInvoiceDate" + k].Split('-')[1] + '-' + Request.Form["hdnInvoiceDate" + k].Split('-')[0] + '-' + Request.Form["hdnInvoiceDate" + k].Split('-')[2]);
                        
                    }
                    catch
                    {
                        InvoiceDate = DateTime.Parse(Request.Form["hdnInvoiceDate" + k] == null || Request.Form["hdnInvoiceDate" + k].ToString() == string.Empty ? "Dec 31 9999" : Request.Form["hdnInvoiceDate" + k].ToString());
                    }
                    bSea.insertUpdateSeaBLInvoiceDetail(tr, int.Parse(Request.Form["hdnBLInvSno" + k].ToString()), int.Parse(inserted), bSea.job_no, Request.Form["hdnInvoiceNo" + k], InvoiceDate, Session["UserId"].ToString());

                    if (pType == "UPDATE")
                    {
                        //ViewState["BLInvoiceTableSno"].ToString().Replace("," + Request.Form["hdnBLInvSno" + k].ToString() + ",", ",");
                        hdnBLInvoiceTableSno.Value = hdnBLInvoiceTableSno.Value.Replace("," + Request.Form["hdnBLInvSno" + k].ToString() + ",", ",");
                    }

                    if (insertedFromPNPToComp != "")
                        bSea.insertUpdateSeaBLInvoiceDetail(tr, int.Parse(Request.Form["hdnBLInvSno" + k].ToString()), int.Parse(insertedFromPNPToComp), bSea.job_no, Request.Form["hdnInvoiceNo" + k], InvoiceDate, Session["UserId"].ToString());
                    
                }
            }
            //////////////////////////////// insert/update SeaBLCharges ////////////////////////////
            inv.service_tax_rate = decimal.Parse(hdnStaxRate.Value);
            inv.SBCessTax = decimal.Parse(hdnSBCessTax.Value);
            string insertInc = "", insertExp = "";
            string chargeSource = string.Empty;
            // insert/Update Income details for login company
            for (int inc = 1; inc <= int.Parse(Request.Form["hdnIncomeRows"].ToString()); inc++)
            {
                if (Request.Form["hdnIncomeCharge" + inc] != null)
                {
                    inv.SNo = 0;
                    inv.mawb_no = bSea.mbl_no;
                    inv.hawb_no = bSea.hbl_no;
                    inv.vol_wt = bSea.cbm;
                    inv.gross_wt = bSea.gross_wt;
                    inv.chargeable_wt = bSea.net_wt;
                    inv.headcode = int.Parse(Request.Form["hdnIncomeChargeSno" + inc].ToString());
                    inv.headname = Request.Form["hdnIncomeCharge" + inc];
                    inv.headtype = 'I';
                    inv.taxable = char.Parse(Request.Form["hdnIncomeChargeTaxable" + inc].ToString());
                    inv.supplier_sno = Request.Form["hdnBillToSno"].ToString();
                    inv.supplier_name = Request.Form["txtBillTo"] != null ? Request.Form["txtBillTo"].ToString() : string.Empty;
                    inv.description = Request.Form["hdnIncDescription" + inc].ToString();
                    inv.curr_code = (Request.Form["txtCurrency"] == "INR" ? Request.Form["hdnIncCurr" + inc] : Request.Form["txtCurrency"]);
                    inv.exchange_rate = Convert.ToDecimal(Request.Form["txtCurrency"] == "INR" ? Request.Form["hdnIncExRate" + inc] : Request.Form["txtExchangeRate"]);
                    inv.amount = Math.Round(decimal.Parse(Request.Form["hdnIncINRAmt" + inc]) * decimal.Parse(Request.Form["txtExchangeRate"]), 2);                  
                    inv.stax_amt = Math.Round((decimal.Parse(Request.Form["hdnIncINRAmt" + inc]) * (inv.service_tax_rate / 100)) * decimal.Parse(Request.Form["txtExchangeRate"]), 2);
                    inv.SBCessAmt = Math.Round((decimal.Parse(Request.Form["hdnIncINRAmt" + inc]) * (inv.SBCessTax / 100)) * decimal.Parse(Request.Form["txtExchangeRate"]), 2);                 inv.bill_amount = inv.amount + inv.stax_amt+inv.SBCessAmt;
                    if (Request.Form["hdnIncomeChargeType" + inc].ToString() == "MBL" && hdnBLType.Value == "H")
                        chargeSource = "HBL";
                    else
                        chargeSource = Request.Form["hdnIncomeChargeType" + inc].ToString();
                    // for login company
                    if (inserted != "")
                    {
                        inv.awbtable_sno = int.Parse(inserted);
                        
                        //    if (Request.Form["hdnIncomeChargeType" + inc].ToString() == "MBL" && hdnBLType.Value == "M")
                        //    chargeSource = "MBL";
                        //else if (Request.Form["hdnIncomeChargeType" + inc].ToString() == "HBL" && hdnBLType.Value == "M")
                        //    chargeSource = "HBL";
                        // else if (Request.Form["hdnIncomeChargeType" + inc].ToString() == "BOOKING")
                        //    chargeSource = "BOOKING";

                        if (hdnIncomeTableSno.Value.Contains("," + Request.Form["hdnIncomeSno" + inc].ToString() + ","))
                        {
                            inv.updateSeaMBLBillingCharges(tr, int.Parse(Request.Form["hdnIncomeSno" + inc]), inv.exchange_rate, chargeSource, string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" ? Request.Form["hdnIncStatus" + inc] : string.Empty), 0, Convert.ToDateTime("Jan 01 1900"), Session["UserID"].ToString());
                            //ViewState["IncomeTableSno"].ToString().Replace("," + Request.Form["hdnIncomeSno" + inc].ToString() + ",", ",");
                            hdnIncomeTableSno.Value = hdnIncomeTableSno.Value.Replace("," + Request.Form["hdnIncomeSno" + inc].ToString() + ",", ",");
                        }
                        else
                        {
                            inv.insertSeaMBLBillingCharges(tr, inv.exchange_rate, chargeSource, string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" ? Request.Form["hdnIncStatus" + inc] : string.Empty), 0, Convert.ToDateTime("Jan 01 1900"), blDate, Session["UserID"].ToString(), int.Parse(Session["CompBrSno"].ToString()), "BOOKING");
                        }
                    }
                    // copy to base company checked(entry for PACE)
                    if (insertedFromPNPToComp != "")
                    {
                        inv.awbtable_sno = int.Parse(insertedFromPNPToComp);
                        inv.supplier_sno = PNPToCompBillToCode;
                        inv.supplier_name = PNPToCompBillTo;// PNP name
                        insertInc = inv.insertSeaMBLBillingCharges(tr, inv.exchange_rate, chargeSource, string.Empty, Convert.ToDateTime("Jan 01 1900"), (Request.Form["txtCurrency"] == "INR" ? Request.Form["hdnIncStatus" + inc] : string.Empty), 0, Convert.ToDateTime("Jan 01 1900"), blDate, Session["UserID"].ToString(), int.Parse(bSea.CompBrSNo), "BOOKING");
                    }
                }
            }
            // insert/Update Expense details for login company
            for (int exp = 1; exp <= int.Parse(Request.Form["hdnExpRows"].ToString()); exp++)
            {
                if (Request.Form["hdnExpCharge" + exp] != null)
                {
                    inv.SNo = 0;
                    inv.mawb_no = bSea.mbl_no;
                    inv.hawb_no = bSea.hbl_no;
                    inv.vol_wt = bSea.cbm;
                    inv.gross_wt = bSea.gross_wt;
                    inv.chargeable_wt = bSea.net_wt;
                    inv.headcode = int.Parse(Request.Form["hdnExpChargeSno" + exp].ToString());
                    inv.headname = Request.Form["hdnExpCharge" + exp];
                    inv.headtype = 'E';
                    inv.taxable = char.Parse(Request.Form["hdnExpChargeTaxable" + exp].ToString());
                    inv.description = Request.Form["hdnExpRemarks" + exp].ToString();
                    inv.curr_code = Request.Form["hdnExpCurr" + exp];
                    inv.exchange_rate = Convert.ToDecimal(Request.Form["hdnExpExRate" + exp].ToString());
                    inv.amount =decimal.Parse(Request.Form["hdnExpINRAmt" + exp]) ;
                    inv.stax_amt = decimal.Parse(Request.Form["hdnExpSTax" + exp]);
                    inv.SBCessAmt = inv.amount * decimal.Parse(".50") / 100;
                    inv.bill_amount = inv.amount + inv.stax_amt;
                    if (Request.Form["hdnExpChargeType" + exp].ToString() == "MBL" && hdnBLType.Value == "H")
                        chargeSource = "HBL";
                    else 
                        chargeSource = Request.Form["hdnExpChargeType" + exp].ToString();
                    //    if (Request.Form["hdnExpChargeType" + exp].ToString() == "MBL" && hdnBLType.Value == "M")
                    //    chargeSource = "MBL";
                    //else if (Request.Form["hdnExpChargeType" + exp].ToString() == "HBL" && hdnBLType.Value == "M")
                    //    chargeSource = "HBL";
                    // else if (Request.Form["hdnExpChargeType" + exp].ToString() == "BOOKING")
                    //    chargeSource = "BOOKING";
                    // for login company
                    if (inserted != "")
                    {
                        inv.awbtable_sno = int.Parse(inserted);
                        // for PNP and checked copy to base company

                        if (Request.Form["cboxBaseCompany"] != null && Session["CompBrType"].Equals("PNP"))
                        {
                            inv.supplier_name = dsParentCompDet.Tables[2].Rows[0]["CustomerName"].ToString();
                            inv.supplier_sno = dsParentCompDet.Tables[2].Rows[0]["Sno"].ToString();
                        }
                        else// for Login company and not checked copy to base company
                        {
                            inv.supplier_name = Request.Form["hdnExpSupplier" + exp].ToString();
                            inv.supplier_sno = Request.Form["hdnExpSupplierSno" + exp].ToString();
                        }
                        if (hdnExpenseTableSno.Value.Contains("," + Request.Form["hdnExpSno" + exp].ToString() + ","))
                        {
                            inv.updateSeaMBLBillingCharges(tr, int.Parse(Request.Form["hdnExpSno" + exp]), inv.exchange_rate, chargeSource, string.Empty, Convert.ToDateTime("Jan 01 1900"), "UNPAID", 0, Convert.ToDateTime("Jan 01 1900"), Session["UserID"].ToString());
                            //ViewState["ExpenseTableSno"].ToString().Replace("," + Request.Form["hdnExpSno" + exp].ToString() + ",", ",");
                            hdnExpenseTableSno.Value = hdnExpenseTableSno.Value.Replace("," + Request.Form["hdnExpSno" + exp].ToString() + ",", ",");
                        }
                        else
                        {
                            inv.insertSeaMBLBillingCharges(tr, inv.exchange_rate, chargeSource, string.Empty, Convert.ToDateTime("Jan 01 1900"), "UNPAID", 0, Convert.ToDateTime("Jan 01 1900"), blDate, Session["UserID"].ToString(), int.Parse(Session["CompBrSno"].ToString()), "BOOKING");
                        }
                    }
                    // copy to base company checked(entry for PACE)
                    if (insertedFromPNPToComp != "")
                    {
                        inv.awbtable_sno = int.Parse(insertedFromPNPToComp);
                        DataView dvSupp = new DataView(dsCustBrSno.Tables[0], "CustomerName='" + Request.Form["hdnExpSupplier"].ToString() + "'", "CustomerName", DataViewRowState.CurrentRows);
                        inv.supplier_sno = dvSupp.ToTable().Rows[0]["Sno"].ToString();
                        inv.supplier_name = dvSupp.ToTable().Rows[0]["CustomerName"].ToString();
                        insertExp = inv.insertSeaMBLBillingCharges(tr, inv.exchange_rate, chargeSource, string.Empty, Convert.ToDateTime("Jan 01 1900"), "UNPAID", 0, Convert.ToDateTime("Jan 01 1900"), blDate, Session["UserID"].ToString(), int.Parse(bSea.CompBrSNo), "BOOKING");
                    }
                }
            }
            tr.Commit();
            // delete Sea container detail
            for (int seaCont = 0; seaCont < hdnContainerTableSno.Value.Split(',').Length - 1; seaCont++)
            {
                inv.deleteSeaContainerDet(int.Parse(hdnContainerTableSno.Value.Split(',')[seaCont].ToString() == string.Empty ? "0" : hdnContainerTableSno.Value.Split(',')[seaCont].ToString()), Session["UserID"].ToString());

            }
            // delete SBNo detail
            for (int seaSBNo = 0; seaSBNo < hdnSBTableSno.Value.Split(',').Length - 1; seaSBNo++)
            {
                inv.deleteSeaSBNoDet(int.Parse(hdnSBTableSno.Value.Split(',')[seaSBNo].ToString() == string.Empty ? "0" : hdnSBTableSno.Value.Split(',')[seaSBNo].ToString()), Session["UserID"].ToString());

            }
            // delete BL Invoice No
            for (int seaBLInv = 0; seaBLInv < hdnBLInvoiceTableSno.Value.Split(',').Length - 1; seaBLInv++)
            {
                inv.deleteSeaBLInvDet(int.Parse(hdnBLInvoiceTableSno.Value.Split(',')[seaBLInv].ToString() == string.Empty ? "0" : hdnBLInvoiceTableSno.Value.Split(',')[seaBLInv].ToString()), Session["UserID"].ToString());

            }
            // delete from seaMBLCharges
            string seaMBLTSno = hdnIncomeTableSno.Value + hdnExpenseTableSno.Value;
            for (int seaMblTsn = 0; seaMblTsn < seaMBLTSno.Split(',').Length - 1; seaMblTsn++)
            {
                inv.modified_by = Session["UserID"].ToString();
                inv.deleteSeaMBLCharges(int.Parse(seaMBLTSno.Split(',')[seaMblTsn].ToString() == string.Empty ? "0" : seaMBLTSno.Split(',')[seaMblTsn].ToString()), "BOOKING");

            }
            /////// Credit limit /////////////////////
            string Status = string.Empty;
            if (hdnOldBill.Value == "Y")//&& (Request.Form["rbtnBillToNo"] != null || Request.Form["rbtnBillToYes"] != null)
            {
                // reverse credit limit for old customer
                BC.custBranchSNo = ViewState["OldCustBrSno"].ToString();
                DataSet dsCheckCrLimt = BC.checkCreditLimit();
                if (dsCheckCrLimt.Tables[0].Rows.Count > 0)
                {
                    if (dsCheckCrLimt.Tables[0].Rows[0]["PaymentMode"].ToString().ToUpper() == "CREDIT")
                    {
                        if (dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != "0.00" && dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != string.Empty)
                            Status = "Branch";
                        if (dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != "0.00" && dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != string.Empty)
                            Status = "Group";

                        BC.restoreCreditLimit(decimal.Parse(hdnOldIncomeAmt.Value), Status);

                        bReport.insertCreditLimitUses(int.Parse(dsCheckCrLimt.Tables[0].Rows[0]["custMastSno"].ToString()), int.Parse(BC.custBranchSNo), int.Parse(Session["CompBrSno"].ToString()), "SeaBooking", decimal.Parse("-" + hdnOldIncomeAmt.Value), (Status == "Group" ? decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["groupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["branchLimit"].ToString())), decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["usedLimit"].ToString()), (decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["usedLimit"].ToString()) - decimal.Parse(hdnOldIncomeAmt.Value)), (Status == "Group" ? decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString())), ((Status == "Group" ? decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["AvlGroupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt.Tables[0].Rows[0]["AvlBranchLimit"].ToString())) + decimal.Parse(hdnOldIncomeAmt.Value)), Status, Session["UserID"].ToString(), 0, 0, 0, 0);
                    }
                }
            }
            if ((Request.Form["hdnRbtnStatus"] == "True" ? Request.Form["rbtnBillTo"] : Request.Form["hdnRbtnBillTo"]) == "Y") //hdnOldBill.Value == "N" && 
            {
                string CrLimitStatus = "";
                // deduct credit limit for new customer
                BC.custBranchSNo = Request.Form["hdnBillToSno"].ToString();//hdnCustBrSno.Value == string.Empty ? ViewState["CustIID"].ToString() : hdnCustBrSno.Value;
                DataSet dsCheckCrLimt1 = BC.checkCreditLimit();// && inv.invto_code_type.ToUpper()!="CAN CUSTOMER"
                if (dsCheckCrLimt1.Tables[0].Rows.Count > 0)
                {
                    if (dsCheckCrLimt1.Tables[0].Rows[0]["PaymentMode"].ToString().ToUpper() == "CREDIT")
                    {
                        if (dsCheckCrLimt1.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != "0.00" && dsCheckCrLimt1.Tables[0].Rows[0]["AvlBranchLimit"].ToString() != string.Empty)
                            CrLimitStatus = "Branch";
                        if (dsCheckCrLimt1.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != "0.00" && dsCheckCrLimt1.Tables[0].Rows[0]["AvlGroupLimit"].ToString() != string.Empty)
                            CrLimitStatus = "Group";

                        BC.updateCreditLimit(decimal.Parse(hdnTotalIncomeAmount.Value), CrLimitStatus);
                        bReport.insertCreditLimitUses(int.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["custMastSno"].ToString()), int.Parse(BC.custBranchSNo), int.Parse(Session["CompBrSno"].ToString()), "SeaBooking", decimal.Parse(hdnTotalIncomeAmount.Value), (Status == "Group" ? decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["groupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["branchLimit"].ToString())), decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["usedLimit"].ToString()), (decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["usedLimit"].ToString()) + decimal.Parse(hdnTotalIncomeAmount.Value)), (Status == "Group" ? decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["AvlGroupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["AvlBranchLimit"].ToString())), ((Status == "Group" ? decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["AvlGroupLimit"].ToString()) : decimal.Parse(dsCheckCrLimt1.Tables[0].Rows[0]["AvlBranchLimit"].ToString())) - decimal.Parse(hdnTotalIncomeAmount.Value)), Status, Session["UserID"].ToString(), 0, 0, 0, 0);
                    }
                }
            }
            
            //Response.Redirect("BrowseSeaCreateMBLInvoice.aspx");
            hdnErrMsg.Value = inserted != string.Empty ? "Record Insert/Update successfully." : string.Empty;
            if (ViewState["PreviousPage"] != null)
                hdnPreviousPage.Value = ViewState["PreviousPage"].ToString();
            else if (hdnSEAType.Value == "EXPORT")
                Response.Redirect("BrowseSeaCreateMBLInvoice.aspx");
            else if (hdnSEAType.Value == "IMPORT")
                Response.Redirect("BrowseSeaImportBL.aspx");
        }
        catch (SqlException sqle)
        {
            btnSave.Style.Add("display", "block");
            String err = sqle.ToString();
            tr.Rollback();
            //btnSave.Text = inserted != "0" ? "UPDATE" : "SAVE";
            string url = HttpContext.Current.Request.Url.AbsoluteUri;
            //FormsAuthenticationTicket tk = FormsAuthentication.Decrypt(url.Split('?')[1]);
            //url = url.Split('?')[0] + "?" + tk.Name;
            //url = inserted != "0" ? url.Split('&')[0] + "&Sno=" + inserted + "&BillType=Modify&" + url.Split('&')[3] : url;
            Response.Redirect(url);
        }
        finally
        {
            if (con != null && con.State == ConnectionState.Open)
                con.Close();
            Response.Redirect("BrowseSeaCreateMBLInvoice.aspx");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e) 
    {
        if (ViewState["PreviousPage"] != null)
            hdnPreviousPage.Value = ViewState["PreviousPage"].ToString();
        else if (hdnSEAType.Value == "EXPORT")
            Response.Redirect("BrowseSeaCreateMBLInvoice.aspx");
        else if (hdnSEAType.Value == "IMPORT")
            Response.Redirect("BrowseSeaImportBL.aspx");
    }
}