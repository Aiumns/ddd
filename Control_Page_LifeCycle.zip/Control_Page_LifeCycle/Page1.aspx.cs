﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class Page1 : System.Web.UI.Page
{
    public string Name
    {
        set
        {
            this.hdName.Value = value;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.Name = "Shaikh Azimuddin";
        }
    }
}