﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class MyWebUserControl : System.Web.UI.UserControl
{   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {

            //You can access Parent page textbox control value 
            txtName.Text = ((this.Parent.Page).FindControl("hdName") as HiddenField).Value;

            TextBox txt = this.Parent.FindControl("txtVisitorName") as TextBox;
            txt.Text = "Krishna"; //u can set ur value here
        }
    }
}