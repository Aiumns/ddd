﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //UserControl _dummyUserControl = (UserControl)Page.LoadControl("WebUserControl.ascx");
        //pnlDynamicControl.Controls.Add(_dummyUserControl);

        //((this.Master.FindControl("usercontrol") as UserControl).FindControl("txtname") as TextBox).Text = "pqr";


        TextBox txt = ((UserControl)Master.FindControl("TextBox1")).FindControl("TextBox1") as TextBox;


        foreach (Control c in Form.Controls)
        {
            string str=c.GetType().Name.ToLower();
            //if (c.GetType().Name.ToLower() == "WebUserControl1")
            //{
            //    UserControl uc = (UserControl)c;

            //    TextBox txt = (TextBox)uc.FindControl("txtuserId");

            //    Response.Write("Controlvalue:   " + txt.Text + "</br>");
            //}
        }


        ////////////////

        //Find User Control Which is exists in Master Page
        //((this.Master.FindControl("WebUserControl") as UserControl).FindControl("txtuserId") as TextBox).Text = "pqr";

        //Find User Control Which is exists in Master Page 2 Approach
        //TextBox txt = ((UserControl)Master.FindControl("txtuserId")).FindControl("txtuserId") as TextBox;


        //You cannot get the property of parent page but you can get the Controls value like this. I am setting the property value in HiddenField 
        //and finding the HiddenField value in UserControl PageLoad event.

        //Label lbl = (Label)_dummyUserControl.FindControl("lblmsg");
        //pnlDynamicControl.Controls.Add(lbl);
    }
}